import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("041", "##                                                                                                  ", "                              ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        float[] floatArray3 = new float[] { (byte) 100, 10.0f, 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', (int) ' ', (int) (byte) 1);
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100.0410.0410.0" + "'", str5.equals("100.0410.0410.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 100.0f + "'", float13 == 100.0f);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "               h                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "sun.lw#wt.m#cosx.CPrinterJo", (java.lang.CharSequence) "t");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "class [Iclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Java Virtual Machine Specification ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "u                                                                    -14104-1", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        int[] intArray2 = new int[] { 1, '4' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1#52" + "'", str4.equals("1#52"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(18.0f, 0.0f, (float) 3L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 18.0f + "'", float3 == 18.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        char[] charArray5 = new char[] { ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, '4');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " " + "'", str11.equals(" "));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("100.0#10.0#10.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        float[] floatArray5 = new float[] { (byte) 1, 0.0f, (short) 100, (byte) -1, 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a0.0a100.0a-1.0a0.0" + "'", str7.equals("1.0a0.0a100.0a-1.0a0.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.040.04100.04-1.040.0" + "'", str10.equals("1.040.04100.04-1.040.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.040.04100.04-1.040.0" + "'", str12.equals("1.040.04100.04-1.040.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.0#0.0#100.0#-1.0#0.0" + "'", str14.equals("1.0#0.0#100.0#-1.0#0.0"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "-1a97a10", (java.lang.CharSequence) "1.0a0.0a100.0a-1.0a0.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("100.0410.0410.0#####################################################################################", "                                                                hi!4http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0410.0410.0#####################################################################################" + "'", str2.equals("100.0410.0410.0#####################################################################################"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "/Uss/sh/Dcumns/dfcsj/m/un_ond.l_9819_150275", "SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.444444444444444E99d + "'", double2 == 4.444444444444444E99d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.0a97.0a4.0", "1-40141-", "7.0_8");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("X86_64aaaaaaaaaaaaaaaaaaaaaaa", "hi!4http://java.oracle.com");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Java HotSpot(TM) 64-Bit Server VM", 0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503aaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", "                                                                                              69 100", (int) (short) 100);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("00.0 0.0 1.0/Uss/sh/Dcumns/dfcsj/m/un_ond.", 69, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "-1a97a10", (java.lang.CharSequence) "mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("X86_64");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                          ", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                                                          aaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Platform API Specification4Java Platform API Specification4Java Platform API Specification4 OS X", (java.lang.CharSequence) "                                                                                          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "JavaaPlatformaAPIaSpevifivation", (java.lang.CharSequence) "###########################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1#52/Use", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("u         9642541u         ", "51.0", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "u         9642541u         " + "'", str3.equals("u         9642541u         "));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "1#52#69");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(10L, (long) 12, (long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        float[] floatArray3 = new float[] { (byte) 100, 10.0f, 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        java.lang.Class<?> wildcardClass6 = floatArray3.getClass();
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', 10, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100.0410.0410.0" + "'", str5.equals("100.0410.0410.0"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        java.lang.String[] strArray6 = new java.lang.String[] { "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", "", "", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503" };
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "1452", 4, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1#52#69");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        long[] longArray3 = new long[] { (byte) -1, (short) 10, (-1L) };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1 10 -1" + "'", str7.equals("-1 10 -1"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("#100", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "A#", (java.lang.CharSequence) "9819_15602765/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_4:/Users/sophie/Documents/defects", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Mac OMac O", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "Java HotSpot(TM) 6-Bit Server VMhJava HotSpot(TM) 6-Bit Server VMiJava HotSpot(TM) 6-Bit Server VM!Java HotSpot(TM) 6-Bit Server VMJava HotSpot(TM) 6-Bit Server VMhJava HotSpot(TM) 6-Bit Server VMtJava HotSpot(TM) 6-Bit Server VMtJava HotSpot(TM) 6-Bit Server VMpJava HotSpot(TM) 6-Bit Server VM:Java HotSpot(TM) 6-Bit Server VM/Java HotSpot(TM) 6-Bit Server VM/Java HotSpot(TM) 6-Bit Server VMjJava HotSpot(TM) 6-Bit Server VMaJava HotSpot(TM) 6-Bit Server VMvJava HotSpot(TM) 6-Bit Server VMaJava HotSpot(TM) 6-Bit Server VM.Java HotSpot(TM) 6-Bit Server VMoJava HotSpot(TM) 6-Bit Server VMrJava HotSpot(TM) 6-Bit Server VMaJava HotSpot(TM) 6-Bit Server VMcJava HotSpot(TM) 6-Bit Server VMlJava HotSpot(TM) 6-Bit Server VMeJava HotSpot(TM) 6-Bit Server VM.Java HotSpot(TM) 6-Bit Server VMcJava HotSpot(TM) 6-Bit Server VMoJava HotSpot(TM) 6-Bit Server VMmJava HotSpot(TM) 6-Bit Server VM/Java HotSpot(TM) 6-Bit Server VM", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "a#", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification", "0#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification" + "'", str2.equals("java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        double[] doubleArray3 = new double[] { 1L, 'a', 4 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a', (int) (byte) 1, 2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0 97.0 4.0" + "'", str5.equals("1.0 97.0 4.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a97.0a4.0" + "'", str7.equals("1.0a97.0a4.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "97.0" + "'", str11.equals("97.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.0497.044.0" + "'", str13.equals("1.0497.044.0"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) " #", 393);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("100.0410.0410.0");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0410.0410.0" + "'", str3.equals("100.0410.0410.0"));
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) 'a', 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) ":/users/sophie/documents/defects4j/tmp/run_randoop.pl_49819_15602765/users/sophie/documents/defects4", (java.lang.CharSequence) "1.0a0.0a100.0a-1.0a0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        char[] charArray5 = new char[] { ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " " + "'", str10.equals(" "));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("425426256526552");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "42542625652655" + "'", str1.equals("42542625652655"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!4http://java.oracle.com/", 94);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!4http://java.oracle.com/" + "'", str2.equals("hi!4http://java.oracle.com/"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503aaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1#52/Use");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a" + "'", str2.equals("0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("x86_64", "                                          mixed mode");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "a#", (java.lang.CharSequence[]) strArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 15, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 15");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "86_64" + "'", str4.equals("86_64"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("#############################################################################################################################################", "/Users/...", (int) '#', (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "###################################/Users/...#########################################################################################" + "'", str4.equals("###################################/Users/...#########################################################################################"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("0#100#35#100#10#52", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#100#35#100#10#52" + "'", str2.equals("0#100#35#100#10#52"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("m");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "M" + "'", str1.equals("M"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1-40141-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                         1.0 97.0 4.0                                         ", 67);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67 + "'", int2 == 67);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hi!#http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0a1" + "'", str9.equals("0a1"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        int[] intArray2 = new int[] { 281, 5 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        double[] doubleArray5 = new double[] { ' ', 10.0f, 'a', 69, 10L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 143, 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 15, (int) (byte) 1);
        double double16 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 97.0d + "'", double16 == 97.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Documents/d...", (java.lang.CharSequence) "java(TM)SERuntimeEnvironment", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#52/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_49819_1560276503", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaa", "Java Platform API Specification");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        long[] longArray6 = new long[] { 0L, (short) 100, '#', (short) 100, (short) 10, '4' };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 27, (int) (byte) 10);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Mac OMac O", (java.lang.CharSequence) "444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", "hi!mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode4444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 52, 10);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 51, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 51");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 1" + "'", str7.equals("0 1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 1 + "'", byte12 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 0 + "'", byte14 == (byte) 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("100.0 10.0 10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0 10.0 10.0" + "'", str1.equals("100.0 10.0 10.0"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Virtual Machine SpecificationMac OS X", (java.lang.CharSequence) "10#100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        char[] charArray4 = new char[] { ' ', '#' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                ", charArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 9642541, (int) ' ');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        short[] shortArray0 = new short[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ', (int) (short) 100, (int) '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', (int) (byte) 100, (int) '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', 2, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "A#", "Mac OMac O");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", (java.lang.CharSequence) "#521.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("#############################################################################################################################################", 28, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#############################################################################################################################################" + "'", str3.equals("#############################################################################################################################################"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "OracleCorporation");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "-1.0 10.0");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "10a67a18a29a94", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        short[] shortArray0 = new short[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ', (int) (short) 100, (int) '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', (int) ' ', 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', 0, (int) (byte) 0);
        try {
            short short19 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaa", "44444", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10#1", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 0, "u         9642541u         u         9642541u      :avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("#521.7.0_80", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("u                                                                                                  ");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 41.0f, 18.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "HI!#HTTP://JAVA.ORACLE.COM/");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: HI!#HTTP://JAVA.ORACLE.COM/");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java Platform API Specification4");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("97.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("u                                                                    -14104-1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("694100", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("##                                                                                                  ", "1.7.0_80", "100.0a10.0a10.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##                                                                                                  " + "'", str3.equals("##                                                                                                  "));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#a ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean11 = javaVersion8.atLeast(javaVersion10);
        boolean boolean12 = javaVersion5.atLeast(javaVersion10);
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean17 = javaVersion15.atLeast(javaVersion16);
        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion16);
        boolean boolean19 = javaVersion10.atLeast(javaVersion16);
        java.lang.String str20 = javaVersion10.toString();
        boolean boolean21 = javaVersion3.atLeast(javaVersion10);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.7" + "'", str20.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" A#", "Java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification", (int) ' ');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503javaaPlatformaAPIaSpevifivation/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503javaaPlatformaAPIaSpevifivation/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503javaaPlatformaAPIaSpevifivationjavaaPlatformaAPIaSpevifivationjavaaPlatformaAPIaSpevifivation/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "sophie    ", (int) '4', 142);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("x86_64", (int) (byte) 100, "-1.0#10.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0#10.0-1.0#10.0-1.0#10.0-1.0#10.0-1.0#10.0-1.0#10.0-1.0#10.0-1.0#10.0-1.0#10.0-1.0#10.0-1.0x86_64" + "'", str3.equals("-1.0#10.0-1.0#10.0-1.0#10.0-1.0#10.0-1.0#10.0-1.0#10.0-1.0#10.0-1.0#10.0-1.0#10.0-1.0#10.0-1.0x86_64"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                                                          aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                          AAAAAAAAAA" + "'", str1.equals("                                                                                          AAAAAAAAAA"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "/Users/sophie");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                  ##", (int) (byte) 0, "1.040.04100.04-1.040.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                  ##" + "'", str3.equals("                                                                                                  ##"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4", "52", "u         9642541u         u         9642541u      :avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4j/tmp/run_randoop.pl_49819_1u60 76u/Users/sophie/Documents/defects4" + "'", str3.equals("4j/tmp/run_randoop.pl_49819_1u60 76u/Users/sophie/Documents/defects4"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "-1 97 100 69", (java.lang.CharSequence) "sophi");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "-1 97 100 69" + "'", charSequence2.equals("-1 97 100 69"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                                                                                                  ", (java.lang.CharSequence) "10");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                                                  " + "'", charSequence2.equals("                                                                                                  "));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("t");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "t" + "'", str1.equals("t"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10#10", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        short[] shortArray0 = new short[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ', (int) (short) 100, (int) '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', (int) ' ', 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', 0, (int) (byte) 0);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ');
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("52/Use#1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/UsHas/stph69100/UsHas/stph", 52, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/UsHas/stph69100/UsHas/stph                         " + "'", str3.equals("/UsHas/stph69100/UsHas/stph                         "));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("AA PAFOR API SPEIFIAION", (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        double[] doubleArray3 = new double[] { 1L, 'a', 4 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a', (int) (byte) 1, 2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0 97.0 4.0" + "'", str5.equals("1.0 97.0 4.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a97.0a4.0" + "'", str7.equals("1.0a97.0a4.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "97.0" + "'", str11.equals("97.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.0#97.0#4.0" + "'", str13.equals("1.0#97.0#4.0"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("52.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52." + "'", str1.equals("52."));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "-1 97 100 69", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.CharSequence charSequence7 = null;
        char[] charArray9 = new char[] { '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny(charSequence7, charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification ", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "u", charArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', 28, (int) (short) -1);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENT", charArray9);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10#100", charArray9);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Virtual Machine Specification", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Specification Machine Virtual JavaXSpecification Machine Virtual Java8Specification Machine Virtual Java6Specification Machine Virtual Java_Specification Machine Virtual Java6Specification Machine Virtual Java4Specification Machine Virtual Java", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specification Machine Virtual JavaXSpecification Machine Virtual Java8Specification Machine Virtual Java6Specification Machine Virtual Java_Specification Machine Virtual Java6Specification Machine Virtual Java4Specification Machine Virtual Java" + "'", str2.equals("Specification Machine Virtual JavaXSpecification Machine Virtual Java8Specification Machine Virtual Java6Specification Machine Virtual Java_Specification Machine Virtual Java6Specification Machine Virtual Java4Specification Machine Virtual Java"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 100, 29, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 29 + "'", int3 == 29);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) ":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4", (java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "JavaVirtualMachineSpecificationMacOSX", 9642541, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.0 97.0 4.0", "", "en");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(" a#69410069410069410069410069");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " a#69410069410069410069410069" + "'", str1.equals(" a#69410069410069410069410069"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sunlwwtmcosxCPrinterJob", "10#10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("############7.0_8#############");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                              69 100", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "69.0 10.0 100.0 1.0 -1.0 100.0", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("b", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b" + "'", str3.equals("b"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        char[] charArray3 = new char[] { ' ', '#' };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray3, '#');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + " ##" + "'", str6.equals(" ##"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + " ##" + "'", str8.equals(" ##"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 100.0f, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "0#100#35#100#10#52aaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "HI!#HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503javaaPlatformaAPIaSpevifivation/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503javaaPlatformaAPIaSpevifivation/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503javaaPlatformaAPIaSpevifivationjavaaPlatformaAPIaSpevifivationjavaaPlatformaAPIaSpevifivation/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("JAVA/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA: /uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:vIRTUAL/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA: /uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:mACHINE/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA: /uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:sPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"JAVA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 52, 10);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 1" + "'", str7.equals("0 1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 1 + "'", byte12 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 0 + "'", byte14 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0a1" + "'", str16.equals("0a1"));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 0 + "'", byte17 == (byte) 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JavaVirtualMachineSpecificationMacOSX", charSequence1, 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", '4');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", "51.0", 0);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "OracleCorporation");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("\n", strArray5, strArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) " A#", (java.lang.CharSequence[]) strArray11);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0", "                                ");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                    10.14.3", strArray11, strArray16);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "\n" + "'", str12.equals("\n"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "                    10.14.3" + "'", str17.equals("                    10.14.3"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 97, 146);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(10, (int) (short) 0, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray6 = new char[] { '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny(charSequence4, charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification ", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Specification Machine Virtual Java", charArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "class [Iclass [Ljava.lang.String;", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4" + "'", str12.equals("4"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("X86_64aaaaaaaaaaaaaaaaaaaaaa", 73, "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.X86_64aaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.X86_64aaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "hi!#http://java.oracle.com/", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#521.7.0_80", 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        int[] intArray2 = new int[] { 1, '4' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', 29, 3);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1#52" + "'", str4.equals("1#52"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 2, (double) 52, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 73, (double) 4.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 73.0d + "'", double3 == 73.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("10#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#94");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#94\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        double[] doubleArray2 = new double[] { (short) -1, 69 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', (int) (short) 0, (int) (byte) 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', 32, 4);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double17 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 69.0d + "'", double3 == 69.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 69.0d + "'", double9 == 69.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 69.0d + "'", double14 == 69.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1.0a69.0" + "'", str16.equals("-1.0a69.0"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 69.0d + "'", double17 == 69.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 73);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_49819_1560276503", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_156027650");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "0#1", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        int[] intArray4 = new int[] { (short) -1, 'a', (byte) 100, 69 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "X86_64aaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "-1.0 10.0");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                   4", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 143);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                                                                              " + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                                                                              "));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Specification Machine Virtual Java", (java.lang.CharSequence) "0 ##0410410410410410");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "#100", (java.lang.CharSequence) "sun.lw#wt.m#cosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 146, 51.0d, (double) 28L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.0d + "'", double3 == 28.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", "51.0", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "OracleCorporation");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str7.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        char[] charArray3 = new char[] { ' ' };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "noitacificepS enihcaM lautriV avaJ", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) " ##");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = javaVersion3.atLeast(javaVersion5);
        boolean boolean7 = javaVersion0.atLeast(javaVersion5);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean10 = javaVersion5.atLeast(javaVersion9);
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean14 = javaVersion12.atLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean16 = javaVersion12.atLeast(javaVersion15);
        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean19 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion18);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean22 = javaVersion20.atLeast(javaVersion21);
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean24 = javaVersion21.atLeast(javaVersion23);
        boolean boolean25 = javaVersion18.atLeast(javaVersion23);
        boolean boolean26 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
        org.apache.commons.lang3.JavaVersion javaVersion27 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion28 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean29 = javaVersion27.atLeast(javaVersion28);
        org.apache.commons.lang3.JavaVersion javaVersion30 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean31 = javaVersion28.atLeast(javaVersion30);
        boolean boolean32 = javaVersion23.atLeast(javaVersion28);
        boolean boolean33 = javaVersion12.atLeast(javaVersion28);
        boolean boolean34 = javaVersion5.atLeast(javaVersion28);
        org.apache.commons.lang3.JavaVersion javaVersion35 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean36 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion35);
        boolean boolean37 = javaVersion28.atLeast(javaVersion35);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + javaVersion27 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion27.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion28 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion28.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + javaVersion30 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion30.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + javaVersion35 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion35.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("041", "9642541", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(" a#69410069410069410069410069", " #");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " a#69410069410069410069410069" + "'", str2.equals(" a#69410069410069410069410069"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1452469", "1.0a0.0a100.0a-1.0a0.0");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "0a1");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1452469" + "'", str3.equals("1452469"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1452469" + "'", str5.equals("1452469"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4j/tmp/run_randoop.pl_49819_1u60 76u/Users/sophie/Documents/defects4", (java.lang.CharSequence) "Java Platform API Specification4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", 73);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        long[] longArray5 = new long[] { (short) 10, 67, 18L, 29, 94 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10#67#18#29#94" + "'", str7.equals("10#67#18#29#94"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a67a18a29a94" + "'", str9.equals("10a67a18a29a94"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10#67#18#29#94" + "'", str11.equals("10#67#18#29#94"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vm4", "                                                                                          AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "8_0.7", (java.lang.CharSequence) "                         ...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "35.0 100.0 0.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                    sun.lwawt.macosx.CPrinterJob                                    ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("0.0 -1.0 100.0 0.0 1.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 30);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10#100" + "'", str4.equals("10#100"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0410410410410410 ##0410410410410410", "10");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "u                                                                                                  ", 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("JavaaPlatformaAPIaSpevifivation");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("m", "#521.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "m" + "'", str2.equals("m"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("-1#10#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#10#-1" + "'", str1.equals("-1#10#-1"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "49#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#01", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("A", "A#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        float[] floatArray5 = new float[] { '#', (byte) 100, 0.0f, (byte) -1, 10.0f };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4', 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35.0 100.0 0.0 -1.0 10.0" + "'", str9.equals("35.0 100.0 0.0 -1.0 10.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "-1.0#69.0", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        long[] longArray5 = new long[] { (short) 10, 67, 18L, 29, 94 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10#67#18#29#94" + "'", str7.equals("10#67#18#29#94"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 94L + "'", long9 == 94L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "                                                   4");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503", (java.lang.CharSequence) "                                                                hi!4http://java.oracle.com/", 121);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("tionaSpevifivaAPIatformaPlavaJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"tionaSpevifivaAPIatformaPlavaJ\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Specificataaaaaaaaaa", (java.lang.CharSequence) "1#52/Use", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 52, 10);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 1" + "'", str7.equals("0 1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 1 + "'", byte12 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 1 + "'", byte13 == (byte) 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7", 121, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                      1.7" + "'", str3.equals("                                                                                                                      1.7"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "m", (java.lang.CharSequence) "java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("10#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#94");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#94" + "'", str1.equals("10#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#94"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("35.0 100.0 0.0 -1.0 10.0", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35.0 100.0 0.0 -1.0 10.0" + "'", str2.equals("35.0 100.0 0.0 -1.0 10.0"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" HotSpot(TM) 64-Bit Server VMhJava HotSpot(TM) 64-Bit Server VMiJava HotSpot(TM) 64-Bit Server VM!Java HotSpot(TM) 64-Bit Server VM4Java HotSpot(TM) 64-Bit Server VMhJava HotSpot(TM) 64-Bit Server VMtJava HotSpot(TM) 64-Bit Server VMtJava HotSpot(TM) 64-Bit Server VMpJava HotSpot(TM) 64-Bit Server VM:Java HotSpot(TM) 64-Bit Server VM/Java HotSpot(TM) 64-Bit Server VM/Java HotSpot(TM) 64-Bit Server VMjJava HotSpot(TM) 64-Bit Server VMaJava HotSpot(TM) 64-Bit Server VMvJava HotSpot(TM) 64-Bit Server VMaJava HotSpot(TM) 64-Bit Server VM.Java HotSpot(TM) 64-Bit Server VMoJava HotSpot(TM) 64-Bit Server VMrJava HotSpot(TM) 64-Bit Server VMaJava HotSpot(TM) 64-Bit Server VMcJava HotSpot(TM) 64-Bit Server VMlJava HotSpot(TM) 64-Bit Server VMeJava HotSpot(TM) 64-Bit Server VM.Java HotSpot(TM) 64-Bit Server VMcJava HotSpot(TM) 64-Bit Server VMoJava HotSpot(TM) 64-Bit Server VMmJava HotSpot(TM) 64-Bit Server VM/Java HotSpot(TM) 64-Bit Server V", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ".7", (java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:4/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "hi!mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode4444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1#52#69", "8");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "69.0410.04100.041.04-1.04100.0", (java.lang.CharSequence) "aaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", ") 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "0 ##0410410410410410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        int[] intArray2 = new int[] { 69, 100 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ":avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", 67);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/UsHas/stph69 100/UsHas/stph", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/UsHas/stph69 100/UsHas/stph" + "'", str2.equals("/UsHas/stph69 100/UsHas/stph"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) ":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.X86_64aaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 52, 10);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 1" + "'", str7.equals("0 1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 0 + "'", byte14 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 0 + "'", byte15 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0 1" + "'", str17.equals("0 1"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.0a0.0a100.0a-1.0a0.0", charSequence1, 94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("u                                                                                                   ", (int) ' ', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 52, 10);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ', 27, 1);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', 143, (int) (short) 100);
        byte byte22 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 1" + "'", str7.equals("0 1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 1 + "'", byte17 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + byte22 + "' != '" + (byte) 1 + "'", byte22 == (byte) 1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava(TM)SERuntimeEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "\n");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "\n:", 2, (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "a#", (java.lang.CharSequence) "                                                                                          aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("10.14.310.14.310.14.310.14.310.14.310.14.310.X86_64aaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "SERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PLSERS/SOPHIE/dOCUMENTS/a#SERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PLSERS/SOPHIE/dOCUMENTS/", (java.lang.CharSequence) "X86_64aaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_15602765", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(" ", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = javaVersion3.atLeast(javaVersion5);
        boolean boolean7 = javaVersion0.atLeast(javaVersion5);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean10 = javaVersion5.atLeast(javaVersion9);
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean14 = javaVersion12.atLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean16 = javaVersion12.atLeast(javaVersion15);
        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean19 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion18);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean22 = javaVersion20.atLeast(javaVersion21);
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean24 = javaVersion21.atLeast(javaVersion23);
        boolean boolean25 = javaVersion18.atLeast(javaVersion23);
        boolean boolean26 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
        org.apache.commons.lang3.JavaVersion javaVersion27 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion28 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean29 = javaVersion27.atLeast(javaVersion28);
        org.apache.commons.lang3.JavaVersion javaVersion30 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean31 = javaVersion28.atLeast(javaVersion30);
        boolean boolean32 = javaVersion23.atLeast(javaVersion28);
        boolean boolean33 = javaVersion12.atLeast(javaVersion28);
        boolean boolean34 = javaVersion5.atLeast(javaVersion28);
        boolean boolean35 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion36 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean37 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion36);
        boolean boolean38 = javaVersion5.atLeast(javaVersion36);
        org.apache.commons.lang3.JavaVersion javaVersion39 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean40 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion39);
        org.apache.commons.lang3.JavaVersion javaVersion41 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion42 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean43 = javaVersion41.atLeast(javaVersion42);
        org.apache.commons.lang3.JavaVersion javaVersion44 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean45 = javaVersion42.atLeast(javaVersion44);
        boolean boolean46 = javaVersion39.atLeast(javaVersion44);
        boolean boolean47 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion44);
        org.apache.commons.lang3.JavaVersion javaVersion48 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean49 = javaVersion44.atLeast(javaVersion48);
        org.apache.commons.lang3.JavaVersion javaVersion50 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion51 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean52 = javaVersion50.atLeast(javaVersion51);
        org.apache.commons.lang3.JavaVersion javaVersion53 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean54 = javaVersion51.atLeast(javaVersion53);
        boolean boolean55 = javaVersion44.atLeast(javaVersion51);
        java.lang.String str56 = javaVersion44.toString();
        org.apache.commons.lang3.JavaVersion javaVersion57 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion58 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean59 = javaVersion57.atLeast(javaVersion58);
        org.apache.commons.lang3.JavaVersion javaVersion60 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean61 = javaVersion57.atLeast(javaVersion60);
        boolean boolean62 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion60);
        org.apache.commons.lang3.JavaVersion javaVersion63 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion64 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean65 = javaVersion63.atLeast(javaVersion64);
        org.apache.commons.lang3.JavaVersion javaVersion66 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean67 = javaVersion63.atLeast(javaVersion66);
        org.apache.commons.lang3.JavaVersion javaVersion68 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion69 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean70 = javaVersion68.atLeast(javaVersion69);
        org.apache.commons.lang3.JavaVersion javaVersion71 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean72 = javaVersion68.atLeast(javaVersion71);
        boolean boolean73 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion68);
        boolean boolean74 = javaVersion66.atLeast(javaVersion68);
        boolean boolean75 = javaVersion60.atLeast(javaVersion68);
        boolean boolean76 = javaVersion44.atLeast(javaVersion68);
        boolean boolean77 = javaVersion36.atLeast(javaVersion44);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + javaVersion27 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion27.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion28 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion28.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + javaVersion30 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion30.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + javaVersion36 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion36.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + javaVersion39 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion39.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + javaVersion41 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion41.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion42 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion42.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + javaVersion44 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion44.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + javaVersion48 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion48.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + javaVersion50 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion50.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion51 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion51.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + javaVersion53 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion53.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "1.7" + "'", str56.equals("1.7"));
        org.junit.Assert.assertTrue("'" + javaVersion57 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion57.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion58 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion58.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + javaVersion60 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion60.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + javaVersion63 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion63.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion64 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion64.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + javaVersion66 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion66.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + javaVersion68 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion68.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion69 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion69.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + javaVersion71 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion71.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaa", 32, "sophie    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100.0 10.0 10.0", (java.lang.CharSequence) "4MV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaj");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "1#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("100.0410.0410.0#####################################################################################", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0410.0410.0#####################################################################################" + "'", str2.equals("100.0410.0410.0#####################################################################################"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("9642541", "", "mixed mod");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9642541" + "'", str3.equals("9642541"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        double[] doubleArray2 = new double[] { (short) -1, 69 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', (int) (short) 0, (int) (byte) 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', 32, 4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double16 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 69.0d + "'", double3 == 69.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 69.0d + "'", double9 == 69.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1.0a69.0" + "'", str15.equals("-1.0a69.0"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 69.0d + "'", double16 == 69.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1#97#100#6", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        long[] longArray6 = new long[] { 0L, (short) 100, '#', (short) 100, (short) 10, '4' };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 27, (int) (byte) 10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0 100 35 100 10 52" + "'", str13.equals("0 100 35 100 10 52"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("52/Use#1", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52/Use#1" + "'", str2.equals("52/Use#1"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                         ...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                         ...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("hi!mixedmode444444444444444444444444444mixedmode444444444444444444444444444mixedmode4444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!mixedmode444444444444444444444444444mixedmode444444444444444444444444444mixedmode4444444" + "'", str1.equals("Hi!mixedmode444444444444444444444444444mixedmode444444444444444444444444444mixedmode4444444"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10#1", (double) 28L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 28.0d + "'", double2 == 28.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        double[] doubleArray2 = new double[] { (short) -1, 69 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', (int) (short) 0, (int) (byte) 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 69.0d + "'", double3 == 69.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 69.0d + "'", double9 == 69.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0469.0" + "'", str11.equals("-1.0469.0"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("mixed mode", "", (int) (short) -1, 393);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 1, (float) 28, 2.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 28.0f + "'", float3 == 28.0f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("AA PAFOR API SPEIFIAION", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_156027650");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AA PAFOR API SPEIFIAION" + "'", str2.equals("AA PAFOR API SPEIFIAION"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean8 = javaVersion6.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean10 = javaVersion6.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean13 = javaVersion11.atLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean15 = javaVersion11.atLeast(javaVersion14);
        boolean boolean16 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean17 = javaVersion9.atLeast(javaVersion11);
        boolean boolean18 = javaVersion3.atLeast(javaVersion11);
        boolean boolean19 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "-1 10 -1", (java.lang.CharSequence) "-1#97#100#69");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "10#67#18#29#94", (java.lang.CharSequence) "u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("u         9642541u         ", "8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest7.test255");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
//        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        boolean boolean10 = javaVersion8.atLeast(javaVersion9);
//        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        boolean boolean12 = javaVersion9.atLeast(javaVersion11);
//        boolean boolean13 = javaVersion6.atLeast(javaVersion11);
//        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
//        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        boolean boolean17 = javaVersion15.atLeast(javaVersion16);
//        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        boolean boolean19 = javaVersion16.atLeast(javaVersion18);
//        boolean boolean20 = javaVersion11.atLeast(javaVersion16);
//        boolean boolean21 = javaVersion0.atLeast(javaVersion16);
//        boolean boolean22 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion16);
//        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean24 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
//        boolean boolean25 = javaVersion16.atLeast(javaVersion23);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("100.0410.0410.0");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "#100", 9, 67);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0410.0410.0" + "'", str3.equals("100.0410.0410.0"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0 1");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sop", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         ", "\n:", "52.", 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         " + "'", str4.equals("u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         "));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.14.3", 0, 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 15, (double) 31.0f, (double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sunlwwtmcosxCPrinterJob");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sunlwwtmcosxCPrinterJob" + "'", str2.equals("sunlwwtmcosxCPrinterJob"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!4http://java.oracle.com/", "/Users/sophie");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "49#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#01", 69, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 69");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mac OS X", "                                                                                                                         ", 73);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(") 64-Bit Server VM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "1.0 0.0 100.0 -1.0 0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Specification Machine Virtual JavaXSpecification Machine Virtual Java8Specification Machine Virtual Java6Specification Machine Virtual Java_Specification Machine Virtual Java6Specification Machine Virtual Java4Specification Machine Virtual Java", "http://java.oracle.com/", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Specification Machine Virtual JavaXSpechttp://java.oracle.com/ava4Specification Machine Virtual Java" + "'", str3.equals("Specification Machine Virtual JavaXSpechttp://java.oracle.com/ava4Specification Machine Virtual Java"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "class [Iclass [Ljava.lang.String;", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("69.0 10.0 100.0 1.0 -1.0 100.0", "4");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1.0#10.0", 142);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("10#67#18#29#94");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#67#18#29#94" + "'", str1.equals("10#67#18#29#94"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0410410410", 143, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0410410410aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0410410410aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Uss/sh/Dcumns/dfcsj/m/un_ond.l_9819_150275", 28, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Uss/sh/Dcumns/dfcsj/m/un_ond.l_9819_150275" + "'", str3.equals("/Uss/sh/Dcumns/dfcsj/m/un_ond.l_9819_150275"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1#52/Use", 0, "javaaPlatformaAPIaSpevifivation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1#52/Use" + "'", str3.equals("1#52/Use"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("100.0#10.0#10.0", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0#10.0#10.0" + "'", str2.equals("100.0#10.0#10.0"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "               h                ", (java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-14104-1", (java.lang.CharSequence) ":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Virtual Machine SpecificationMac OS X", "#100", 97);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "49#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#01", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("#52/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_49819_1560276503");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        long[] longArray3 = new long[] { (byte) 1, '4', 69 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', (int) (byte) 1, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1452469" + "'", str5.equals("1452469"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 69L + "'", long6 == 69L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1#52#69" + "'", str8.equals("1#52#69"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765031.8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765031.8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765031.81.81.8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "M");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        double[] doubleArray1 = new double[] { 52.0d };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', (int) ' ', (int) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52.0" + "'", str3.equals("52.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java HotSpot(TM) 6-Bit Server VMhJava HotSpot(TM) 6-Bit Server VMiJava HotSpot(TM) 6-Bit Server VM!Java HotSpot(TM) 6-Bit Server VMJava HotSpot(TM) 6-Bit Server VMhJava HotSpot(TM) 6-Bit Server VMtJava HotSpot(TM) 6-Bit Server VMtJava HotSpot(TM) 6-Bit Server VMpJava HotSpot(TM) 6-Bit Server VM:Java HotSpot(TM) 6-Bit Server VM/Java HotSpot(TM) 6-Bit Server VM/Java HotSpot(TM) 6-Bit Server VMjJava HotSpot(TM) 6-Bit Server VMaJava HotSpot(TM) 6-Bit Server VMvJava HotSpot(TM) 6-Bit Server VMaJava HotSpot(TM) 6-Bit Server VM.Java HotSpot(TM) 6-Bit Server VMoJava HotSpot(TM) 6-Bit Server VMrJava HotSpot(TM) 6-Bit Server VMaJava HotSpot(TM) 6-Bit Server VMcJava HotSpot(TM) 6-Bit Server VMlJava HotSpot(TM) 6-Bit Server VMeJava HotSpot(TM) 6-Bit Server VM.Java HotSpot(TM) 6-Bit Server VMcJava HotSpot(TM) 6-Bit Server VMoJava HotSpot(TM) 6-Bit Server VMmJava HotSpot(TM) 6-Bit Server VM/Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HOTSPOT(TM) 6-BIT SERVER VMHJAVA HOTSPOT(TM) 6-BIT SERVER VMIJAVA HOTSPOT(TM) 6-BIT SERVER VM!JAVA HOTSPOT(TM) 6-BIT SERVER VMJAVA HOTSPOT(TM) 6-BIT SERVER VMHJAVA HOTSPOT(TM) 6-BIT SERVER VMTJAVA HOTSPOT(TM) 6-BIT SERVER VMTJAVA HOTSPOT(TM) 6-BIT SERVER VMPJAVA HOTSPOT(TM) 6-BIT SERVER VM:JAVA HOTSPOT(TM) 6-BIT SERVER VM/JAVA HOTSPOT(TM) 6-BIT SERVER VM/JAVA HOTSPOT(TM) 6-BIT SERVER VMJJAVA HOTSPOT(TM) 6-BIT SERVER VMAJAVA HOTSPOT(TM) 6-BIT SERVER VMVJAVA HOTSPOT(TM) 6-BIT SERVER VMAJAVA HOTSPOT(TM) 6-BIT SERVER VM.JAVA HOTSPOT(TM) 6-BIT SERVER VMOJAVA HOTSPOT(TM) 6-BIT SERVER VMRJAVA HOTSPOT(TM) 6-BIT SERVER VMAJAVA HOTSPOT(TM) 6-BIT SERVER VMCJAVA HOTSPOT(TM) 6-BIT SERVER VMLJAVA HOTSPOT(TM) 6-BIT SERVER VMEJAVA HOTSPOT(TM) 6-BIT SERVER VM.JAVA HOTSPOT(TM) 6-BIT SERVER VMCJAVA HOTSPOT(TM) 6-BIT SERVER VMOJAVA HOTSPOT(TM) 6-BIT SERVER VMMJAVA HOTSPOT(TM) 6-BIT SERVER VM/JAVA HOTSPOT(TM) 6-BIT SERVER VM" + "'", str1.equals("JAVA HOTSPOT(TM) 6-BIT SERVER VMHJAVA HOTSPOT(TM) 6-BIT SERVER VMIJAVA HOTSPOT(TM) 6-BIT SERVER VM!JAVA HOTSPOT(TM) 6-BIT SERVER VMJAVA HOTSPOT(TM) 6-BIT SERVER VMHJAVA HOTSPOT(TM) 6-BIT SERVER VMTJAVA HOTSPOT(TM) 6-BIT SERVER VMTJAVA HOTSPOT(TM) 6-BIT SERVER VMPJAVA HOTSPOT(TM) 6-BIT SERVER VM:JAVA HOTSPOT(TM) 6-BIT SERVER VM/JAVA HOTSPOT(TM) 6-BIT SERVER VM/JAVA HOTSPOT(TM) 6-BIT SERVER VMJJAVA HOTSPOT(TM) 6-BIT SERVER VMAJAVA HOTSPOT(TM) 6-BIT SERVER VMVJAVA HOTSPOT(TM) 6-BIT SERVER VMAJAVA HOTSPOT(TM) 6-BIT SERVER VM.JAVA HOTSPOT(TM) 6-BIT SERVER VMOJAVA HOTSPOT(TM) 6-BIT SERVER VMRJAVA HOTSPOT(TM) 6-BIT SERVER VMAJAVA HOTSPOT(TM) 6-BIT SERVER VMCJAVA HOTSPOT(TM) 6-BIT SERVER VMLJAVA HOTSPOT(TM) 6-BIT SERVER VMEJAVA HOTSPOT(TM) 6-BIT SERVER VM.JAVA HOTSPOT(TM) 6-BIT SERVER VMCJAVA HOTSPOT(TM) 6-BIT SERVER VMOJAVA HOTSPOT(TM) 6-BIT SERVER VMMJAVA HOTSPOT(TM) 6-BIT SERVER VM/JAVA HOTSPOT(TM) 6-BIT SERVER VM"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.awt.CGraphicsEnvironment", " a#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM4", "51.0");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/" + "'", str5.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("0410410410", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0410410410                  " + "'", str2.equals("0410410410                  "));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "###################################/Users/...#########################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "OracleCorporationaaaaaaaaaaaaaaa", (java.lang.CharSequence) "-1.0#69.0", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java Platform API Specification", 2, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "va Platform API Specificatio" + "'", str3.equals("va Platform API Specificatio"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "AVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(":/users/sophie/documents/defects4j/tmp/run_randoop.pl_49819_15602765/users/sophie/documents/defects4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":/users/sophie/documents/defects4j/tmp/run_randoop.pl_49819_15602765/users/sophie/documents/defects4" + "'", str1.equals(":/users/sophie/documents/defects4j/tmp/run_randoop.pl_49819_15602765/users/sophie/documents/defects4"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("X86_64aaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_15602765", "mixed mod");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64aaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_15602765" + "'", str2.equals("X86_64aaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_15602765"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("97.0", 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                               97.0" + "'", str2.equals("                                                               97.0"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "u                                                                    -14104-1", (java.lang.CharSequence) "1.6", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1.0 10.0", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("0.0 -1.0 100.0 0.0 1.0/Uss/sh/Dcumns/dfcsj/m/un_ond.", "#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(35.0d, (double) (byte) -1, 31.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Documents/d...", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/d..." + "'", str2.equals("/Users/sophie/Documents/d..."));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "-1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java Virtual Machine Specification");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification" + "'", str3.equals("Java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("SUN.AWT.CGRAPHICSENVIRONMENT", "-1a10a-", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503aaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str3.equals("SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUX86_64", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUX86_64" + "'", str2.equals("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUX86_64"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 281, (float) 32, (float) 30L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 30.0f + "'", float3 == 30.0f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", "", 10);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "10.14.3", (-1));
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("1.0a0.0a100.0a-1.0a0.0", strArray5, strArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "X86_64");
        boolean boolean15 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "java(TM)SERuntimeEnvironment", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Mac OS X" + "'", str11.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0a0.0a100.0a-1.0a0.0" + "'", str12.equals("1.0a0.0a100.0a-1.0a0.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Mac OS X" + "'", str14.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                              ", "RANDOOP-CURRENT.JATION/RATION/GENERAMEWORK/LIB/TEST_GENERASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRARGET/CLANDOOP.PL_49819_1560276503/TA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_R");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              " + "'", str2.equals("                              "));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(94.0d, 52.0d, 4.444444444444444E99d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("u                                                                                                   ", "u                                                                                                  ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Uscss/scm/69 100/Uscss/scm/", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Uscss/scm/69 100/Uscss/scm/" + "'", str3.equals("/Uscss/scm/69 100/Uscss/scm/"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("############7.0_8#############", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############7.0_8#############" + "'", str2.equals("############7.0_8#############"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "m", (java.lang.CharSequence) "#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Specification Machine Virtual JavaXSpecification Machine Virtual Java8Specification Machine Virtual Java6Specification Machine Virtual Java_Specification Machine Virtual Java6Specification Machine Virtual Java4Specification Machine Virtual Java", "/Users/soph69 100/Users/soph");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specification Machine Virtual JavaXSpecification Machine Virtual Java8Specification Machine Virtual Java6Specification Machine Virtual Java_Specification Machine Virtual Java6Specification Machine Virtual Java4Specification Machine Virtual Java" + "'", str2.equals("Specification Machine Virtual JavaXSpecification Machine Virtual Java8Specification Machine Virtual Java6Specification Machine Virtual Java_Specification Machine Virtual Java6Specification Machine Virtual Java4Specification Machine Virtual Java"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        short[] shortArray2 = new short[] { (byte) 0, (short) 1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "041" + "'", str5.equals("041"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-1 10 -1", (java.lang.CharSequence) "52/Use#1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "X86_64aaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("#########", (int) (short) 0, "JavaVirtualMachineSpecificationMacOSX");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########" + "'", str3.equals("#########"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 9642541, "1.0#97.0#4.0");
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java HotSpot(TM) 6-Bit Server VMhJava HotSpot(TM) 6-Bit Server VMiJava HotSpot(TM) 6-Bit Server VM!Java HotSpot(TM) 6-Bit Server VMJava HotSpot(TM) 6-Bit Server VMhJava HotSpot(TM) 6-Bit Server VMtJava HotSpot(TM) 6-Bit Server VMtJava HotSpot(TM) 6-Bit Server VMpJava HotSpot(TM) 6-Bit Server VM:Java HotSpot(TM) 6-Bit Server VM/Java HotSpot(TM) 6-Bit Server VM/Java HotSpot(TM) 6-Bit Server VMjJava HotSpot(TM) 6-Bit Server VMaJava HotSpot(TM) 6-Bit Server VMvJava HotSpot(TM) 6-Bit Server VMaJava HotSpot(TM) 6-Bit Server VM.Java HotSpot(TM) 6-Bit Server VMoJava HotSpot(TM) 6-Bit Server VMrJava HotSpot(TM) 6-Bit Server VMaJava HotSpot(TM) 6-Bit Server VMcJava HotSpot(TM) 6-Bit Server VMlJava HotSpot(TM) 6-Bit Server VMeJava HotSpot(TM) 6-Bit Server VM.Java HotSpot(TM) 6-Bit Server VMcJava HotSpot(TM) 6-Bit Server VMoJava HotSpot(TM) 6-Bit Server VMmJava HotSpot(TM) 6-Bit Server VM/Java HotSpot(TM) 6-Bit Server VM", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("JavaHotSpot(TM)64-BitServerVMhJavaHotSpot(TM)64-BitServerVMiJavaHotSpot(TM)64-BitServerVM!JavaHotSpot(TM)64-BitServerVM4JavaHotSpot(TM)64-BitServerVMhJavaHotSpot(TM)64-BitServerVMtJavaHotSpot(TM)64-BitServerVMtJavaHotSpot(TM)64-BitServerVMpJavaHotSpot(TM)64-BitServerVM:JavaHotSpot(TM)64-BitServerVM/JavaHotSpot(TM)64-BitServerVM/JavaHotSpot(TM)64-BitServerVMjJavaHotSpot(TM)64-BitServerVMaJavaHotSpot(TM)64-BitServerVMvJavaHotSpot(TM)64-BitServerVMaJavaHotSpot(TM)64-BitServerVM.JavaHotSpot(TM)64-BitServerVMoJavaHotSpot(TM)64-BitServerVMrJavaHotSpot(TM)64-BitServerVMaJavaHotSpot(TM)64-BitServerVMcJavaHotSpot(TM)64-BitServerVMlJavaHotSpot(TM)64-BitServerVMeJavaHotSpot(TM)64-BitServerVM.JavaHotSpot(TM)64-BitServerVMcJavaHotSpot(TM)64-BitServerVMoJavaHotSpot(TM)64-BitServerVMmJavaHotSpot(TM)64-BitServerVM/JavaHotSpot(TM)64-BitServerVM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaHotSpot(TM)64-BitServerVMhJavaHotSpot(TM)64-BitServerVMiJavaHotSpot(TM)64-BitServerVM!JavaHotSpot(TM)64-BitServerVM4JavaHotSpot(TM)64-BitServerVMhJavaHotSpot(TM)64-BitServerVMtJavaHotSpot(TM)64-BitServerVMtJavaHotSpot(TM)64-BitServerVMpJavaHotSpot(TM)64-BitServerVM:JavaHotSpot(TM)64-BitServerVM/JavaHotSpot(TM)64-BitServerVM/JavaHotSpot(TM)64-BitServerVMjJavaHotSpot(TM)64-BitServerVMaJavaHotSpot(TM)64-BitServerVMvJavaHotSpot(TM)64-BitServerVMaJavaHotSpot(TM)64-BitServerVM.JavaHotSpot(TM)64-BitServerVMoJavaHotSpot(TM)64-BitServerVMrJavaHotSpot(TM)64-BitServerVMaJavaHotSpot(TM)64-BitServerVMcJavaHotSpot(TM)64-BitServerVMlJavaHotSpot(TM)64-BitServerVMeJavaHotSpot(TM)64-BitServerVM.JavaHotSpot(TM)64-BitServerVMcJavaHotSpot(TM)64-BitServerVMoJavaHotSpot(TM)64-BitServerVMmJavaHotSpot(TM)64-BitServerVM/JavaHotSpot(TM)64-BitServerVM" + "'", str2.equals("JavaHotSpot(TM)64-BitServerVMhJavaHotSpot(TM)64-BitServerVMiJavaHotSpot(TM)64-BitServerVM!JavaHotSpot(TM)64-BitServerVM4JavaHotSpot(TM)64-BitServerVMhJavaHotSpot(TM)64-BitServerVMtJavaHotSpot(TM)64-BitServerVMtJavaHotSpot(TM)64-BitServerVMpJavaHotSpot(TM)64-BitServerVM:JavaHotSpot(TM)64-BitServerVM/JavaHotSpot(TM)64-BitServerVM/JavaHotSpot(TM)64-BitServerVMjJavaHotSpot(TM)64-BitServerVMaJavaHotSpot(TM)64-BitServerVMvJavaHotSpot(TM)64-BitServerVMaJavaHotSpot(TM)64-BitServerVM.JavaHotSpot(TM)64-BitServerVMoJavaHotSpot(TM)64-BitServerVMrJavaHotSpot(TM)64-BitServerVMaJavaHotSpot(TM)64-BitServerVMcJavaHotSpot(TM)64-BitServerVMlJavaHotSpot(TM)64-BitServerVMeJavaHotSpot(TM)64-BitServerVM.JavaHotSpot(TM)64-BitServerVMcJavaHotSpot(TM)64-BitServerVMoJavaHotSpot(TM)64-BitServerVMmJavaHotSpot(TM)64-BitServerVM/JavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1452469");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) ' ', 2.0f, 67.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 67.0f + "'", float3 == 67.0f);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                                                                             " + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                                                                                             "));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        char[] charArray4 = new char[] { ' ', '#' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", charArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray4, '#', 281, 51);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + " ##" + "'", str7.equals(" ##"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " a#" + "'", str10.equals(" a#"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray5 = new char[] { '4' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification ", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "86_64", charArray5);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray7 = new char[] { '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny(charSequence5, charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification ", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API Specification", charArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 8, 0);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaa", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4" + "'", str14.equals("4"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "-1#97#100#69", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", (java.lang.CharSequence) "class [Iclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(15, 32, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray4 = new char[] { '4' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "u         9642541u         ", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " 100", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("100.0410.0410.0#####################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#####################################################################################0.0140.0140.001" + "'", str1.equals("#####################################################################################0.0140.0140.001"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                          AAAAAAAAAA", "69.0 10.0 100.0 1.0 -1.0 100.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String[] strArray7 = new java.lang.String[] { "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", "", "", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503" };
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, 'a');
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", "", 10);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "10.14.3", (-1));
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray21, 'a');
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEach("1.0a0.0a100.0a-1.0a0.0", strArray17, strArray21);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray10, strArray21);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "javaaPlatformaAPIaSpevifivation");
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "#############################################################################################################################################");
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503aaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503" + "'", str12.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503aaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Mac OS X" + "'", str23.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1.0a0.0a100.0a-1.0a0.0" + "'", str24.equals("1.0a0.0a100.0a-1.0a0.0"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503javaaPlatformaAPIaSpevifivation/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503javaaPlatformaAPIaSpevifivation/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503javaaPlatformaAPIaSpevifivationjavaaPlatformaAPIaSpevifivationjavaaPlatformaAPIaSpevifivation/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503" + "'", str27.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503javaaPlatformaAPIaSpevifivation/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503javaaPlatformaAPIaSpevifivation/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503javaaPlatformaAPIaSpevifivationjavaaPlatformaAPIaSpevifivationjavaaPlatformaAPIaSpevifivation/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503"));
        org.junit.Assert.assertNotNull(strArray29);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("42542625652655");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.2542625652655E13d + "'", double1.equals(4.2542625652655E13d));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        short[] shortArray1 = new short[] { (byte) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("M", 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("-1.0469.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                    sun.lwawt.macosx.CPrinterJob                                    ", 'a');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "sun.lw#wt.m#cosx.CPrinterJob");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10#100", strArray2, strArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#100" + "'", str8.equals("10#100"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 27, 0L, (long) 67);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 91, 281.0d, 18.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 281.0d + "'", double3 == 281.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM4", "va Platform API Specificatio", 29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM4" + "'", str3.equals("java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM4"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("24.80-B11");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray7 = new char[] { ' ', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", charArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray7);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10#100", charArray7);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " ##" + "'", str10.equals(" ##"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " a#" + "'", str13.equals(" a#"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0410410410410410 ##0410410410410410", (java.lang.CharSequence) "-1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10#100", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.040.04100.04-1.040.0         ", (java.lang.CharSequence) "Specification Machine Virtual JavaXSpecification Machine Virtual Java8Specification Machine Virtual Java6Specification Machine Virtual Java_Specification Machine Virtual Java6Specification Machine Virtual Java4Specification Machine Virtual Java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ', 100, 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10#100" + "'", str4.equals("10#100"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10#100" + "'", str11.equals("10#100"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 32L, (float) 28, (float) 4);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("4j/tmp/run_randoop.pl_49819_1u60 76u/Users/sophie/Documents/defects4", "/Uss/sh/Dcumns/dfcsj/m/un_ond.l_9819_150275", "/UsHas/stph69100/UsHas/stph");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4j/tmp/run_randoop.pl_49819_1u60 76u/Users/sophie/Documents/defects4" + "'", str3.equals("4j/tmp/run_randoop.pl_49819_1u60 76u/Users/sophie/Documents/defects4"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0410.0410.0#####################################################################################", "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:4/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        int[] intArray2 = new int[] { 69, 100 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', (int) (byte) 100, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        java.lang.Class<?> wildcardClass11 = intArray2.getClass();
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', (int) 'a', 3);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "69#100" + "'", str10.equals("69#100"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM4", "\n");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                    10.14.3", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        int[] intArray4 = new int[] { (short) -1, 'a', (byte) 100, 69 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, '4');
        java.lang.Class<?> wildcardClass11 = strArray8.getClass();
        java.lang.Class[] classArray13 = new java.lang.Class[2];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray14 = (java.lang.Class<?>[]) classArray13;
        wildcardClassArray14[0] = wildcardClass6;
        wildcardClassArray14[1] = wildcardClass11;
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray14);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.reflect.GenericDeclaration[]) wildcardClassArray14);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503" + "'", str10.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(classArray13);
        org.junit.Assert.assertNotNull(wildcardClassArray14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "class [Iclass [Ljava.lang.String;" + "'", str19.equals("class [Iclass [Ljava.lang.String;"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "class [Iclass [Ljava.lang.String;" + "'", str20.equals("class [Iclass [Ljava.lang.String;"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/users/sophie/documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randoop.pl_49819_1560276503" + "'", str1.equals("/users/sophie/documents/defects4j/tmp/run_randoop.pl_49819_1560276503"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503javaaPlatformaAPIaSpevifivation/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503javaaPlatformaAPIaSpevifivation/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503javaaPlatformaAPIaSpevifivationjavaaPlatformaAPIaSpevifivationjavaaPlatformaAPIaSpevifivation/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("SERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("7.0_8", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7.0_8" + "'", str2.equals("7.0_8"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        long[] longArray3 = new long[] { (byte) -1, (short) 10, (-1L) };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-14104-1" + "'", str7.equals("-14104-1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1a10a-1" + "'", str9.equals("-1a10a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1#10#-1" + "'", str11.equals("-1#10#-1"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_156027650", (java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray3, strArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "x86_64");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str8.equals("/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = javaVersion3.atLeast(javaVersion5);
        boolean boolean7 = javaVersion0.atLeast(javaVersion5);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean10 = javaVersion5.atLeast(javaVersion9);
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean14 = javaVersion12.atLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean16 = javaVersion12.atLeast(javaVersion15);
        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean19 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion18);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean22 = javaVersion20.atLeast(javaVersion21);
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean24 = javaVersion21.atLeast(javaVersion23);
        boolean boolean25 = javaVersion18.atLeast(javaVersion23);
        boolean boolean26 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
        org.apache.commons.lang3.JavaVersion javaVersion27 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion28 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean29 = javaVersion27.atLeast(javaVersion28);
        org.apache.commons.lang3.JavaVersion javaVersion30 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean31 = javaVersion28.atLeast(javaVersion30);
        boolean boolean32 = javaVersion23.atLeast(javaVersion28);
        boolean boolean33 = javaVersion12.atLeast(javaVersion28);
        boolean boolean34 = javaVersion5.atLeast(javaVersion28);
        boolean boolean35 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        java.lang.String str36 = javaVersion5.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + javaVersion27 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion27.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion28 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion28.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + javaVersion30 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion30.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1.7" + "'", str36.equals("1.7"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.040.04100.04-1.040.0         ", "/UsHas/stph69100/UsHas/stph                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1.0#69.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_49819_1560276503", (java.lang.CharSequence) " a#69410069410069410069410069", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence6 = null;
        char[] charArray8 = new char[] { '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny(charSequence6, charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification ", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "u", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', 28, (int) (short) -1);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENT", charArray8);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a", 146, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a" + "'", str3.equals("0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        char[] charArray2 = new char[] { ' ' };
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray2);
        java.lang.Class<?> wildcardClass4 = charArray2.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray2, '#');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + " " + "'", str6.equals(" "));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("0 1", (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("#####");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#####\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("-1.0#10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#10.0" + "'", str1.equals("-1.0#10.0"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/soph69 100/Users/soph", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7", "10#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#9410#67#18#29#94");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        float[] floatArray5 = new float[] { (byte) 1, 0.0f, (short) 100, (byte) -1, 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a0.0a100.0a-1.0a0.0" + "'", str7.equals("1.0a0.0a100.0a-1.0a0.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0 0.0 100.0 -1.0 0.0" + "'", str10.equals("1.0 0.0 100.0 -1.0 0.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "tionaSpevifivaAPIatformaPlavaJ", (java.lang.CharSequence) "-1#97#100#6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java Virtual Machine Specification", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaPlatformAPISpecification" + "'", str1.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        short[] shortArray0 = new short[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ', (int) (short) 100, (int) '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', (int) ' ', 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ');
        try {
            short short17 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("8_0.7", "JavaVirtualMachineSpecificationMacOSX", 393);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                    sun.lwawt.macosx.CPrinterJob                                    ", 143, "0 1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                    sun.lwawt.macosx.CPrinterJob                                    0 10 10 10 10 10 10 10 10 10 10 10 10 10 10" + "'", str3.equals("                                    sun.lwawt.macosx.CPrinterJob                                    0 10 10 10 10 10 10 10 10 10 10 10 10 10 10"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        char[] charArray5 = new char[] { ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " " + "'", str11.equals(" "));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("hi!4http://java.oracle.com");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!4http://java.oracle.com" + "'", str1.equals("hi!4http://java.oracle.com"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        long[] longArray3 = new long[] { (byte) 1, '4', 69 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.Class<?> wildcardClass8 = longArray3.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1452469" + "'", str5.equals("1452469"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 69L + "'", long6 == 69L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 52 69" + "'", str10.equals("1 52 69"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray1, strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "mixed mode");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Java(TM)mixed modeSEmixed modeRuntimemixed modeEnvironment" + "'", str6.equals("Java(TM)mixed modeSEmixed modeRuntimemixed modeEnvironment"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        int[] intArray4 = new int[] { (short) -1, 'a', (byte) 100, 69 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("tionaSpevifivaAPIatformaPlavaJ", "", 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1a97a10", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("hi!mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode4444444", "", 51);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode4444444" + "'", str3.equals("hi!mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode4444444"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/U/sr///Users/Lrbrary/Java/Extsn/rUn/:/Lrbrary/Java/Extsn/rUn/:/NstwUrk/Lrbrary/Java/Extsn/rUn/:/Sy/tsm/Lrbrary/Java/Extsn/rUn/:/u/r/lrb/java:.", '4');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!4http://java.oracle.com/", "/Users/sophie");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" ##", strArray4, strArray7);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                    sun.lwawt.macosx.CPrinterJob                                    ", 'a');
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("U", strArray12, strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.lwawt.macosx.LWCToolkit", strArray4, strArray15);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + " ##" + "'", str8.equals(" ##"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "U" + "'", str16.equals("U"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str17.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("69.0 10.0 100.0 1.0 -1.0 100.0", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1452469145246914524691452469444444444444444444444444444444444444444444444444444444444444444444444", "ava(TM)S");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1452469145246914524691452469444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("1452469145246914524691452469444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        char[] charArray4 = new char[] { ' ', '#' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "javaaPlatformaAPIaSpevifivation", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(9, (int) (short) 0, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("10", "u                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lw#wt.m#cosx.CPrinterJo", (java.lang.CharSequence) "0410410410");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("-1 10 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 10 -" + "'", str1.equals("-1 10 -"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("a", "1#52");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44444", "1#52#69");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 'a', (long) 13, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(281.0f, (float) 9642541L, (float) 51L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 51.0f + "'", float3 == 51.0f);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                                                              69 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("javaPlatformAPISpecificatio", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "javaPlatformAPISpecificatio" + "'", str2.equals("javaPlatformAPISpecificatio"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        int[] intArray2 = new int[] { 1, '4' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1#52" + "'", str4.equals("1#52"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a52" + "'", str9.equals("1a52"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1#52" + "'", str11.equals("1#52"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = javaVersion3.atLeast(javaVersion5);
        boolean boolean7 = javaVersion0.atLeast(javaVersion5);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("u         9642541u         ", "/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4", 51, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4" + "'", str3.equals(":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "javaaPlatformaAPIaSpevifivation", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("JAVA HOTSPOT(TM) 6-BIT SERVER VMHJAVA HOTSPOT(TM) 6-BIT SERVER VMIJAVA HOTSPOT(TM) 6-BIT SERVER VM!JAVA HOTSPOT(TM) 6-BIT SERVER VMJAVA HOTSPOT(TM) 6-BIT SERVER VMHJAVA HOTSPOT(TM) 6-BIT SERVER VMTJAVA HOTSPOT(TM) 6-BIT SERVER VMTJAVA HOTSPOT(TM) 6-BIT SERVER VMPJAVA HOTSPOT(TM) 6-BIT SERVER VM:JAVA HOTSPOT(TM) 6-BIT SERVER VM/JAVA HOTSPOT(TM) 6-BIT SERVER VM/JAVA HOTSPOT(TM) 6-BIT SERVER VMJJAVA HOTSPOT(TM) 6-BIT SERVER VMAJAVA HOTSPOT(TM) 6-BIT SERVER VMVJAVA HOTSPOT(TM) 6-BIT SERVER VMAJAVA HOTSPOT(TM) 6-BIT SERVER VM.JAVA HOTSPOT(TM) 6-BIT SERVER VMOJAVA HOTSPOT(TM) 6-BIT SERVER VMRJAVA HOTSPOT(TM) 6-BIT SERVER VMAJAVA HOTSPOT(TM) 6-BIT SERVER VMCJAVA HOTSPOT(TM) 6-BIT SERVER VMLJAVA HOTSPOT(TM) 6-BIT SERVER VMEJAVA HOTSPOT(TM) 6-BIT SERVER VM.JAVA HOTSPOT(TM) 6-BIT SERVER VMCJAVA HOTSPOT(TM) 6-BIT SERVER VMOJAVA HOTSPOT(TM) 6-BIT SERVER VMMJAVA HOTSPOT(TM) 6-BIT SERVER VM/JAVA HOTSPOT(TM) 6-BIT SERVER VM", "9642541", "u                                                                                                   ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                                                hi!4http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!4http://java.oracle.com/" + "'", str1.equals("hi!4http://java.oracle.com/"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a" + "'", str2.equals("#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "69.0 10.0 100.0 1.0 -1.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("444444444444444444444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "Java Platform API Specification4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JAVA/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA: /uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:vIRTUAL/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA: /uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:mACHINE/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA: /uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:sPECIFICATION", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("JavaaPlatformaAPIaSpevifivation", (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.0", "tionaSpevifivaAPIatformaPlavaJ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/users/sophie/documents/defects4j/tmp/run_randoop.pl_49819_1560276503", (int) (byte) 10, 2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "-1#97#100#69", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 31.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.0d + "'", double2 == 31.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "u                                                                                                   ", (java.lang.CharSequence) "sun.lw#wt.m#cosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("X86_64", "                                         1.0 97.0 4.0                                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64" + "'", str2.equals("X86_64"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Specificataaaaaaaaaa", "1#52");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '4', (-1), 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM4", "/Users/sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("69 100", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "69 100" + "'", str2.equals("69 100"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 52, 10);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ', 27, 1);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', 91, 69);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 1" + "'", str7.equals("0 1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765031.8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765031.8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765031.81.81.8/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", (int) '4', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("X86_64aaaaaaaaaaaaaaaaaaaaaaa", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64aaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("X86_64aaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "9642541", (java.lang.CharSequence) "                                                                                          ", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM4", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                       08_0.7.125#                                                       ", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                       08_0.7.125a                                                       " + "'", str3.equals("                                                       08_0.7.125a                                                       "));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JAVA HOTSPOT(TM) 6-BIT SERVER VMHJAVA HOTSPOT(TM) 6-BIT SERVER VMIJAVA HOTSPOT(TM) 6-BIT SERVER VM!JAVA HOTSPOT(TM) 6-BIT SERVER VMJAVA HOTSPOT(TM) 6-BIT SERVER VMHJAVA HOTSPOT(TM) 6-BIT SERVER VMTJAVA HOTSPOT(TM) 6-BIT SERVER VMTJAVA HOTSPOT(TM) 6-BIT SERVER VMPJAVA HOTSPOT(TM) 6-BIT SERVER VM:JAVA HOTSPOT(TM) 6-BIT SERVER VM/JAVA HOTSPOT(TM) 6-BIT SERVER VM/JAVA HOTSPOT(TM) 6-BIT SERVER VMJJAVA HOTSPOT(TM) 6-BIT SERVER VMAJAVA HOTSPOT(TM) 6-BIT SERVER VMVJAVA HOTSPOT(TM) 6-BIT SERVER VMAJAVA HOTSPOT(TM) 6-BIT SERVER VM.JAVA HOTSPOT(TM) 6-BIT SERVER VMOJAVA HOTSPOT(TM) 6-BIT SERVER VMRJAVA HOTSPOT(TM) 6-BIT SERVER VMAJAVA HOTSPOT(TM) 6-BIT SERVER VMCJAVA HOTSPOT(TM) 6-BIT SERVER VMLJAVA HOTSPOT(TM) 6-BIT SERVER VMEJAVA HOTSPOT(TM) 6-BIT SERVER VM.JAVA HOTSPOT(TM) 6-BIT SERVER VMCJAVA HOTSPOT(TM) 6-BIT SERVER VMOJAVA HOTSPOT(TM) 6-BIT SERVER VMMJAVA HOTSPOT(TM) 6-BIT SERVER VM/JAVA HOTSPOT(TM) 6-BIT SERVER VM", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("49#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#01", (int) (byte) -1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "49#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#01" + "'", str3.equals("49#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#0149#92#81#76#01"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Uss/sh/Dcumns/dfcsj/m/un_ond.l_9819_150275", (java.lang.CharSequence) "HI!#HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 35, (long) 91);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "J4v4 HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "                                    sun.lwawt.macosx.CPrinterJob                                    0 10 10 10 10 10 10 10 10 10 10 10 10 10 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "42542625652655", "69#100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", (java.lang.CharSequence) "               h                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "-1.0469.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed", 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105 + "'", int2 == 105);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "-1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("m#cosx.CPrinterJob", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "m#cosx.CPrinterJob" + "'", str2.equals("m#cosx.CPrinterJob"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("4.0 97.0 1.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaa", 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0" + "'", str3.equals("4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                          mixed mode");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', 100, 94);
        java.lang.Class<?> wildcardClass7 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "m" + "'", str2.equals("m"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "0a1", (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Specification Machine Virtual JavaXSpechttp://java.oracle.com/ava4Specification Machine Virtual Java");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String[] strArray8 = new java.lang.String[] { "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", "", "", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503" };
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "");
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", (java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray19 = new java.lang.String[] { "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", "", "", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503" };
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.stripAll(strArray19, "");
        int int22 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", (java.lang.CharSequence[]) strArray21);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray10, strArray21);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray21, "");
        java.lang.Class<?> wildcardClass26 = strArray21.getClass();
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 69 + "'", int11 == 69);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 69 + "'", int22 == 69);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503" + "'", str25.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503"));
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "35.0 100.0 0.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "-1#10#-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        char[] charArray6 = new char[] { ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', (int) 'a', 91);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                              ", "PlatformAPISpecification");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 143, (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1#52#69", (java.lang.CharSequence) "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_49819_1560276503/ta/Users/sophie/Documents/defects4j/tmp/run_r", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", "", 10);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "10.14.3", (-1));
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("1.0a0.0a100.0a-1.0a0.0", strArray5, strArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "X86_64");
        int int15 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Mac OS X" + "'", str11.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0a0.0a100.0a-1.0a0.0" + "'", str12.equals("1.0a0.0a100.0a-1.0a0.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Mac OS X" + "'", str14.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JavaaPlatformaAPIaSpevifivation", 15, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        char[] charArray3 = new char[] {};
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ');
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!4http://java.oracle.com/", charArray3);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-1a10a-1", charArray3);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "OracleCorporationaaaaaaaaaaaaaaa", charArray3);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray3, '#', (int) (byte) -1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("7.0_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.0_8" + "'", str1.equals("7.0_8"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0 1", 0, " a#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 1" + "'", str3.equals("0 1"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" ##", "#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A 7.0_8#A", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 97L, (float) (byte) 1, (float) 4L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 1, (double) 1L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                         ...", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                hi!4http://java.oracle.com/", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90 + "'", int2 == 90);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("0 100 35 100 10 52");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 100 35 100 10 52" + "'", str1.equals("0 100 35 100 10 52"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", "Java HotSpot(TM) 6-Bit Server VMhJava HotSpot(TM) 6-Bit Server VMiJava HotSpot(TM) 6-Bit Server VM!Java HotSpot(TM) 6-Bit Server VMJava HotSpot(TM) 6-Bit Server VMhJava HotSpot(TM) 6-Bit Server VMtJava HotSpot(TM) 6-Bit Server VMtJava HotSpot(TM) 6-Bit Server VMpJava HotSpot(TM) 6-Bit Server VM:Java HotSpot(TM) 6-Bit Server VM/Java HotSpot(TM) 6-Bit Server VM/Java HotSpot(TM) 6-Bit Server VMjJava HotSpot(TM) 6-Bit Server VMaJava HotSpot(TM) 6-Bit Server VMvJava HotSpot(TM) 6-Bit Server VMaJava HotSpot(TM) 6-Bit Server VM.Java HotSpot(TM) 6-Bit Server VMoJava HotSpot(TM) 6-Bit Server VMrJava HotSpot(TM) 6-Bit Server VMaJava HotSpot(TM) 6-Bit Server VMcJava HotSpot(TM) 6-Bit Server VMlJava HotSpot(TM) 6-Bit Server VMeJava HotSpot(TM) 6-Bit Server VM.Java HotSpot(TM) 6-Bit Server VMcJava HotSpot(TM) 6-Bit Server VMoJava HotSpot(TM) 6-Bit Server VMmJava HotSpot(TM) 6-Bit Server VM/Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8" + "'", str2.equals("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE" + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/d...", (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(" a#", "10#10");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!4http://java.oracle.com/");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1#52#69", strArray3, strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1#52#69" + "'", str6.equals("1#52#69"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 52, 10);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 1" + "'", str7.equals("0 1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 1 + "'", byte12 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0#1" + "'", str15.equals("0#1"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sunlwwtmcosxCPrinterJob");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        double[] doubleArray2 = new double[] { (short) -1, 69 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', (int) (short) 0, (int) (byte) 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', 32, 4);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', 3, 1);
        double double21 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 69.0d + "'", double3 == 69.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 69.0d + "'", double9 == 69.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 69.0d + "'", double14 == 69.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1.0a69.0" + "'", str16.equals("-1.0a69.0"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.0d) + "'", double21 == (-1.0d));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        char[] charArray2 = new char[] {};
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie", charArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray2, '#', (int) (short) 1, 1);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1#10#-1", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "V revreS tiB-46 )MT(topStoH avaJ/MV revreS tiB-46 )MT(topStoH avaJmMV revreS tiB-46 )MT(topStoH avaJoMV revreS tiB-46 )MT(topStoH avaJcMV revreS tiB-46 )MT(topStoH avaJ.MV revreS tiB-46 )MT(topStoH avaJeMV revreS tiB-46 )MT(topStoH avaJlMV revreS tiB-46 )MT(topStoH avaJcMV revreS tiB-46 )MT(topStoH avaJaMV revreS tiB-46 )MT(topStoH avaJrMV revreS tiB-46 )MT(topStoH avaJoMV revreS tiB-46 )MT(topStoH avaJ.MV revreS tiB-46 )MT(topStoH avaJaMV revreS tiB-46 )MT(topStoH avaJvMV revreS tiB-46 )MT(topStoH avaJaMV revreS tiB-46 )MT(topStoH avaJjMV revreS tiB-46 )MT(topStoH avaJ/MV revreS tiB-46 )MT(topStoH avaJ/MV revreS tiB-46 )MT(topStoH avaJ:MV revreS tiB-46 )MT(topStoH avaJpMV revreS tiB-46 )MT(topStoH avaJtMV revreS tiB-46 )MT(topStoH avaJtMV revreS tiB-46 )MT(topStoH avaJhMV revreS tiB-46 )MT(topStoH avaJ4MV revreS tiB-46 )MT(topStoH avaJ!MV revreS tiB-46 )MT(topStoH avaJiMV revreS tiB-46 )MT(topStoH avaJhMV revreS tiB-46 )MT(topStoH ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("u         9642541u         u         9642541u      :avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         ", 5, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     9642541u         u         9642541u      :avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:sn" + "'", str3.equals("     9642541u         u         9642541u      :avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:sn"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("u                                                                    -14104-1", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "u                                                                    -14104-1" + "'", str2.equals("u                                                                    -14104-1"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", 73, 51);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENT" + "'", str3.equals("RY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENT"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AVA PLATFORM API SPECIFICATION", " ");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "                                                                                          ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("9642541", "0#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9642541" + "'", str2.equals("9642541"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("0#100#35#100#10#52aaaaaaaaaaaaaaaaa", "http://java.oracle.com/", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0#100#35#100#10#52aaaaaaaaaaaaaaaaa" + "'", str3.equals("0#100#35#100#10#52aaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.7.0_80", "hi!4http://java.oracle.com", 67);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "52/Use#1", charSequence1, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str5 = javaVersion3.toString();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean8 = javaVersion6.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean10 = javaVersion6.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean13 = javaVersion11.atLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean15 = javaVersion11.atLeast(javaVersion14);
        boolean boolean16 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean17 = javaVersion9.atLeast(javaVersion11);
        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean21 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion20);
        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean24 = javaVersion22.atLeast(javaVersion23);
        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean26 = javaVersion23.atLeast(javaVersion25);
        boolean boolean27 = javaVersion20.atLeast(javaVersion25);
        boolean boolean28 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion25);
        org.apache.commons.lang3.JavaVersion javaVersion29 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean30 = javaVersion25.atLeast(javaVersion29);
        boolean boolean31 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion25);
        org.apache.commons.lang3.JavaVersion javaVersion32 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion33 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean34 = javaVersion32.atLeast(javaVersion33);
        org.apache.commons.lang3.JavaVersion javaVersion35 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean36 = javaVersion32.atLeast(javaVersion35);
        boolean boolean37 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion32);
        org.apache.commons.lang3.JavaVersion javaVersion38 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean39 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion38);
        org.apache.commons.lang3.JavaVersion javaVersion40 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion41 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean42 = javaVersion40.atLeast(javaVersion41);
        org.apache.commons.lang3.JavaVersion javaVersion43 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean44 = javaVersion41.atLeast(javaVersion43);
        boolean boolean45 = javaVersion38.atLeast(javaVersion43);
        boolean boolean46 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion43);
        org.apache.commons.lang3.JavaVersion javaVersion47 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion48 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean49 = javaVersion47.atLeast(javaVersion48);
        org.apache.commons.lang3.JavaVersion javaVersion50 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean51 = javaVersion48.atLeast(javaVersion50);
        boolean boolean52 = javaVersion43.atLeast(javaVersion48);
        boolean boolean53 = javaVersion32.atLeast(javaVersion48);
        boolean boolean54 = javaVersion25.atLeast(javaVersion48);
        boolean boolean55 = javaVersion19.atLeast(javaVersion48);
        boolean boolean56 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion48);
        boolean boolean57 = javaVersion11.atLeast(javaVersion48);
        boolean boolean58 = javaVersion3.atLeast(javaVersion48);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.5" + "'", str5.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + javaVersion29 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion29.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + javaVersion32 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion32.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion33 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion33.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + javaVersion35 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion35.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + javaVersion38 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion38.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + javaVersion40 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion40.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion41 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion41.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + javaVersion43 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion43.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + javaVersion47 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion47.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion48 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion48.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + javaVersion50 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion50.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("44444444444444444444444444", "#############################################################################################################################################10", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0#1", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("00.0 0.0 1.0/Uss/sh/Dcumns/dfcsj/m/un_ond.", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava(TM)SERuntimeEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava(TM)SERuntimeEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava(TM)SERuntimeEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }
}

