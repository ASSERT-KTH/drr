import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test01");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4", "                                                                                          ", (int) (short) -1);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence1, (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "UTF-8");
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1#0", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test02");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "#####################################################################################0.0140.0140.001", (java.lang.CharSequence) "#52/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_49819_1560276503", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test03");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "#####MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test04");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Mac OMac O", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OMac O" + "'", str2.equals("OMac O"));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test05");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("100.0410.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test06");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("0#100", "#####000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#100" + "'", str2.equals("0#100"));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test07");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("UTF-8", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test08");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", "", 10);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "http://java.oracle.com/" + "'", str6.equals("http://java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test09");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/", (java.lang.CharSequence) "aaaaaaaa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/" + "'", charSequence2.equals("/"));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test10");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.8", (int) (short) 1, 13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".8" + "'", str3.equals(".8"));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test11");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test12");
        long[] longArray3 = new long[] { (byte) 1, '4', 69 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ', (int) (byte) 100, 30);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1452469" + "'", str5.equals("1452469"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 69L + "'", long6 == 69L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test13");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 32, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test14");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("425426256526552", (double) 9642541);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.25426256526552E14d + "'", double2 == 4.25426256526552E14d);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test15");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java HotSpot(TM) 64-Bit Server VM", "1.040.04100.04-1.040.0         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test16");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "1-40141-");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test17");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "OMac O");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test18");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "100.0#10.0#10.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test19");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "JavaaPlatformaAPIaSpevifivation", (java.lang.CharSequence) "cuments/defects4j/tmp/run_rndoop.pl_49819_1560276503");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test20");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "-1.0469.0", (java.lang.CharSequence) "1452469145246914524691452469444444444444444444444444444444444444444444444444444444444444444444444", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test21");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("52");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5" + "'", str1.equals("5"));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test22");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("-1a97a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a97a10" + "'", str1.equals("-1a97a10"));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test23");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Specificataaaaaaaaaa", "mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode" + "'", str2.equals("mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode"));
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test24");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test25");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sun.lwawt.macosx.LWCToolkit", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test26");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv:" + "'", str2.equals("/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv:"));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test27");
        float[] floatArray5 = new float[] { (byte) 1, 0.0f, (short) 100, (byte) -1, 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a0.0a100.0a-1.0a0.0" + "'", str7.equals("1.0a0.0a100.0a-1.0a0.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.040.04100.04-1.040.0" + "'", str11.equals("1.040.04100.04-1.040.0"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + (-1.0f) + "'", float13 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.0a0.0a100.0a-1.0a0.0" + "'", str15.equals("1.0a0.0a100.0a-1.0a0.0"));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test28");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode", "OMac O");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test29");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray6 = new char[] { '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny(charSequence4, charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification ", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "86_64", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test30");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "SERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PLSERS/SOPHIE/dOCUMENTS/a#SERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PLSERS/SOPHIE/dOCUMENTS/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test31");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test32");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1#52#69", "44444444444444444444444444", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1#52#69" + "'", str3.equals("1#52#69"));
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test33");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "SERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PLSERS/SOPHIE/dOCUMENTS/a#SERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PLSERS/SOPHIE/dOCUMENTS/", 18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test34");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(" ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test35");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.0497.044.0", 91, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "....044.0" + "'", str3.equals("....044.0"));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test36");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test37");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("08_0.7.125#", "4MV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "08_0.7.125#" + "'", str2.equals("08_0.7.125#"));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test38");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 52, 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test39");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("u         9642541u      51.0       9642541u         ", 91, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test40");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "-14104-1", (java.lang.CharSequence) "69.0 10.0 100.0 1.0 -1.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test41");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1a52", "Java HotSpot(TM) 64-Bit Server VM", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test42");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "               h                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test43");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("HI!#HTTP://JAVA.ORACLE.COM/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test44");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test45");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 10, 0.0f, (float) 91L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test46");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, 'a', 146, 30);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test47");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray1, strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "a", 15, 2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test48");
        float[] floatArray5 = new float[] { (byte) 1, 0.0f, (short) 100, (byte) -1, 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ', 9642541, (int) (short) 100);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a0.0a100.0a-1.0a0.0" + "'", str7.equals("1.0a0.0a100.0a-1.0a0.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.040.04100.04-1.040.0" + "'", str11.equals("1.040.04100.04-1.040.0"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.0#0.0#100.0#-1.0#0.0" + "'", str18.equals("1.0#0.0#100.0#-1.0#0.0"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.0a0.0a100.0a-1.0a0.0" + "'", str20.equals("1.0a0.0a100.0a-1.0a0.0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1.0 0.0 100.0 -1.0 0.0" + "'", str22.equals("1.0 0.0 100.0 -1.0 0.0"));
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test49");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "javaPlatformAPISpecificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test50");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("35.0 100.0 0.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "35.0 100.0 0.0 -1.0 10.0" + "'", str1.equals("35.0 100.0 0.0 -1.0 10.0"));
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test51");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test52");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/4hi!", charSequence1, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test53");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("u", "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUX86_64", 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "u" + "'", str3.equals("u"));
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test54");
        int[] intArray2 = new int[] { 1, '4' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        java.lang.Class<?> wildcardClass10 = intArray2.getClass();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1#52" + "'", str4.equals("1#52"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1452" + "'", str9.equals("1452"));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test55");
        double[] doubleArray3 = new double[] { 1L, 'a', 4 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0 97.0 4.0" + "'", str5.equals("1.0 97.0 4.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0 97.0 4.0" + "'", str7.equals("1.0 97.0 4.0"));
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test56");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9819_15602765034j/tmp/run_randoop.pl_4/Users/sophie/Documents/defects" + "'", str2.equals("9819_15602765034j/tmp/run_randoop.pl_4/Users/sophie/Documents/defects"));
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test57");
        char[] charArray7 = new char[] { ' ', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", charArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) 'a', (int) (byte) 1);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1452", charArray7);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " #", charArray7);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a 7.0_8#a", charArray7);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', (int) (short) 10, 0);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " ##" + "'", str10.equals(" ##"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " a#" + "'", str13.equals(" a#"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test58");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "OracleCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test59");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", 30L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 30L + "'", long2 == 30L);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test60");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "0.0 -1.0 100.0 0.0 1.0", (java.lang.CharSequence) "http://java.oracle.com/4hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test61");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test62");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java Virtual Machine SpecificationMac OS X", "                                                                                          aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                          aaaaaaaaaa" + "'", str2.equals("                                                                                          aaaaaaaaaa"));
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test63");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444444444444444444444", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sun.lw#wt.m#cosx.CPrinterJob", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test64");
        short[][] shortArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(shortArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test65");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(69L, (long) 4, (long) 13);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4L + "'", long3 == 4L);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test66");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java(TM)mixed modeSEmixed modeRuntimemixed modeEnvironment", "/Users/sophie/Documents/defects4j/tmp/run_rX86_64ndoop.pl_49819_156027650");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM)mixed modeSEmixed modeRuntimemixed modeEnvironment" + "'", str2.equals("Java(TM)mixed modeSEmixed modeRuntimemixed modeEnvironment"));
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test67");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.0 0.0 100.0 -1.0 0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test68");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("X86_64", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64" + "'", str2.equals("X86_64"));
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test69");
        char[] charArray7 = new char[] { ' ', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", charArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) 'a', (int) (byte) 1);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1452", charArray7);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "m#cosx.CPrinterJob", charArray7);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_49819_1560276503", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " ##" + "'", str10.equals(" ##"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " a#" + "'", str13.equals(" a#"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test70");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test71");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(".7", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".7" + "'", str3.equals(".7"));
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test72");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "b");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test73");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test74");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "-1.0 10.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test75");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 100, "hi!mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode4444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "h444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaahi" + "'", str3.equals("h444444444444444444444444444444444444444444444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaahi"));
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test76");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503", "/Users/soph69 100/Users/soph");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test77");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "SERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test78");
        short[] shortArray0 = new short[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ', (int) (short) 100, (int) '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', (int) (byte) 100, (int) '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', (int) (short) 100, (int) (short) 1);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#', (int) (byte) 0, 281);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test79");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444M", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test80");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Hi!mixedmode444444444444444444444444444mixedmode444444444444444444444444444mixedmode4444444");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test81");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Platform API Specification4Java Platform API Specification4Java Platform API Specification4 OS X", (java.lang.CharSequence) "1.040.04100.04-1.040.0         ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test82");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "52", (java.lang.CharSequence) "4j/tmp/run_randoop.pl_49819_1u60 76u/Users/sophie/Documents/defects4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test83");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0aaaaaaaaaaaaaaaaaaaaaaaaaaa4.0 97.0 1.0", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test84");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed", 90);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test85");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test86");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "javaPlatformAPISpecification", charSequence1, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test87() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test87");
        double[] doubleArray2 = new double[] { (-1.0f), (short) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (-1), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0 10.0" + "'", str4.equals("-1.0 10.0"));
    }

    @Test
    public void test88() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test88");
        java.lang.CharSequence charSequence7 = null;
        char[] charArray9 = new char[] { '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny(charSequence7, charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification ", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API Specification", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "m", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                       08_0.7.125a                                                       ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }
}

