import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "100.0a10.0a10.0", (java.lang.CharSequence) "javaaPlatformaAPIaSpevifivation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", charSequence2.equals("/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification", "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification" + "'", str2.equals("Java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0 1" + "'", str5.equals("0 1"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "7.0_8", (java.lang.CharSequence) "10#100", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("h", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.0a0.0a100.0a-1.0a0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "8_0.7", (java.lang.CharSequence) "                                ", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java Virtual Machine SpecificationMac OS X", charSequence1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "a#", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                                                                                  ##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.0 97.0 4.0", (java.lang.CharSequence) " a#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                   4");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "Mac OMac O");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1452469");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("#52");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765", "7.0_8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                            ...");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ##", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 67 + "'", int1 == 67);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "69 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503", 121, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "1.7.0_80", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "\n", "Users/sophie/Documents/defects4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "10.14.3", (-1));
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1452469");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("OracleCorporationaaaaaaaaaaaaaaa", "1452469");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporationaaaaaaaaaaaaaaa" + "'", str2.equals("OracleCorporationaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        char[] charArray4 = new char[] { ' ', '#' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        char[] charArray3 = new char[] {};
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ');
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!4http://java.oracle.com/", charArray3);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-1a10a-1", charArray3);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100.0410.0410.0#####################################################################################", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(":", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("100.0a10.0a10.0", "Java(TM)Smixed modeJava(TM)S");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0a10.0a10.0" + "'", str2.equals("100.0a10.0a10.0"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sophie", 94, 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "                                                                                                  ##");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                                                  ##", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                  " + "'", str2.equals("                                                                                                  "));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vm4", (java.lang.CharSequence) "javaaPlatformaAPIaSpevifivation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91 + "'", int2 == 91);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7", 97, "4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7" + "'", str3.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OMac O", "hi!4http://java.oracle.com/");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 29, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 29");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        short[] shortArray1 = new short[] { (short) 100 };
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                          mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                          mixed mod" + "'", str1.equals("                                          mixed mod"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mac OS X", "sun.lwawt.macosx.LWCToolkit", (int) 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#', 0, 0);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", "", 10);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "10.14.3", (-1));
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, 'a');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("1.0a0.0a100.0a-1.0a0.0", strArray13, strArray17);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray17);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray17);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Mac OS X" + "'", str19.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.0a0.0a100.0a-1.0a0.0" + "'", str20.equals("1.0a0.0a100.0a-1.0a0.0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1a52");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) " ##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_rX86_64ndoop.pl_49819_156027650", (java.lang.CharSequence) "tionaSpevifivaAPIatformaPlavaJ", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_49819_1560276503");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_49819_1560276503"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "10.14.3", (-1));
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "1452469");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) ":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.5", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", "-1a10a-1");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("52.0", "1#52/Use", "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52.0" + "'", str3.equals("52.0"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray7 = new char[] { '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny(charSequence5, charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification ", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API Specification", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ":", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.040.04100.04-1.040.0         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "         0.040.1-40.00140.040.1" + "'", str1.equals("         0.040.1-40.00140.040.1"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.040.04100.04-1.040.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                                                                                         ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "m");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_156027650", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_156027650" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_156027650"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "-1a10a-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.040.04100.04-1.040.0", (java.lang.CharSequence) "-1a10a-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vm4", (java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vm4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "u         9642541u         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("X86_64", "", "Specification Machine Virtual Java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Specification Machine Virtual JavaXSpecification Machine Virtual Java8Specification Machine Virtual Java6Specification Machine Virtual Java_Specification Machine Virtual Java6Specification Machine Virtual Java4Specification Machine Virtual Java" + "'", str3.equals("Specification Machine Virtual JavaXSpecification Machine Virtual Java8Specification Machine Virtual Java6Specification Machine Virtual Java_Specification Machine Virtual Java6Specification Machine Virtual Java4Specification Machine Virtual Java"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("69 100", "JavaVirtualMachineSpecificationMacOSX");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Users/sophie/Documents/defects4j/tmp/run_rX86_64ndoop.pl_49819_156027650", "u                                                                                                   ", "24.80-B11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_rX86_64ndoop.pl_49819_156027650" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_rX86_64ndoop.pl_49819_156027650"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION", (java.lang.CharSequence) "1a52");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Uss/sh/Dcumns/dfcsj/m/un_ond.l_9819_150275", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("-1#10#-1", "h", 29);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 94, (float) 143, (float) 51);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 51.0f + "'", float3 == 51.0f);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        byte[] byteArray0 = new byte[] {};
        byte[][] byteArray1 = new byte[][] { byteArray0 };
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle(":", "cuments/defects4j/tmp/run_rndoop.pl_49819_1560276503", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.040.04100.04-1.040.0         ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("X86_64", 97, "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUX86_64" + "'", str3.equals("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUX86_64"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray3 = new char[] { '4' };
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0#100#35#100#10#52", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        long[] longArray6 = new long[] { 0L, (short) 100, '#', (short) 100, (short) 10, '4' };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 8, (int) (short) 1);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("JAVA PLATFORM API SPECIFICATION", (-1), ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA PLATFORM API SPECIFICATION" + "'", str3.equals("JAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = javaVersion3.atLeast(javaVersion5);
        boolean boolean7 = javaVersion0.atLeast(javaVersion5);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean11 = javaVersion9.atLeast(javaVersion10);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean13 = javaVersion10.atLeast(javaVersion12);
        boolean boolean14 = javaVersion5.atLeast(javaVersion10);
        java.lang.String str15 = javaVersion5.toString();
        java.lang.String str16 = javaVersion5.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.7" + "'", str15.equals("1.7"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.7" + "'", str16.equals("1.7"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" ", "-1 10 -1", (int) (short) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', 121, (int) (short) 100);
        java.lang.CharSequence charSequence9 = null;
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByCharacterType("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence9, (java.lang.CharSequence[]) strArray11);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("Mac OS X", strArray4, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 56");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 100.0d, (double) 27L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 94, (float) (byte) -1, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        char[] charArray6 = new char[] { '#', 'a', ' ', 'a', ' ', ' ' };
        char[] charArray13 = new char[] { '#', 'a', ' ', 'a', ' ', ' ' };
        char[][] charArray14 = new char[][] { charArray6, charArray13 };
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray14);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray14);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        float[] floatArray3 = new float[] { (byte) 100, 10.0f, 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', (int) (short) -1, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100.0410.0410.0" + "'", str5.equals("100.0410.0410.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.lw#wt.m#cosx.CPrinterJob", (int) (byte) 10, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "m#cosx.CPrinterJob" + "'", str3.equals("m#cosx.CPrinterJob"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "100.0410.0410.0#####################################################################################", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification", (java.lang.CharSequence) "sunlwwtmcosxCPrinterJob", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Mac OMac O", 18, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    Mac OMac O    " + "'", str3.equals("    Mac OMac O    "));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 1" + "'", str7.equals("0 1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 1" + "'", str9.equals("0 1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "Java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "UTF-8", 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "tionaSpevifivaAPIatformaPlavaJ", (java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_49819_1560276503");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("X86_64", 29, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_64aaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("X86_64aaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10#100", (java.lang.CharSequence) "1#52", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.lwawt.macosx.LWCToolkit", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        long[] longArray3 = new long[] { (byte) -1, (short) 10, (-1L) };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 10, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-14104-1" + "'", str7.equals("-14104-1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1a10a-1" + "'", str9.equals("-1a10a-1"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 'a', 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", "    Mac OMac O    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "0#100#35#100#10#52");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "1#0", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("444444444444444444444444444", 100, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_156027650", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("J4v4 HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: J4v4 HotSpot(TM) 64-Bit Server VM is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("US");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("u                                                                                                   ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "u" + "'", str2.equals("u"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        int[] intArray2 = new int[] { 1, '4' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1#52" + "'", str4.equals("1#52"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a52" + "'", str9.equals("1a52"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444" + "'", str1.equals("444444444444444444444444444"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("#100", "9642541", "Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#100" + "'", str3.equals("#100"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hi!", "                                    sun.lwawt.macosx.CPrinterJob                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         ", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444448_0.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         " + "'", str2.equals("u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         "));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444448_0.7", (java.lang.CharSequence) "Specification Machine Virtual JavaXSpecification Machine Virtual Java8Specification Machine Virtual Java6Specification Machine Virtual Java_Specification Machine Virtual Java6Specification Machine Virtual Java4Specification Machine Virtual Java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!4http://java.oracle.com/", "/Users/sophie");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("51.0", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Users/sophie/Documents/defects4", ":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4", "9642541");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "425426256526552" + "'", str3.equals("425426256526552"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("-1 10 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 10 -1" + "'", str1.equals("-1 10 -1"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", "51.0", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "OracleCorporation");
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", 0, 94);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("javaaPlatformaAPIaSpevifivation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(" a#", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, 0, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 52, 10);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 18, 5);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "en");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: en");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 1" + "'", str7.equals("0 1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.lw#wt.m#cosx.CPrinterJob", 27, 143);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b" + "'", str3.equals("b"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring(" A#", 51, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a1" + "'", str8.equals("0a1"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 100, "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("-1#10#-1", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#10#-1" + "'", str2.equals("-1#10#-1"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.7.0_80-b15", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " A#", (java.lang.CharSequence) "mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "52.0", (java.lang.CharSequence) "#100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("///", (int) (byte) -1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        int[] intArray2 = new int[] { 1, '4' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', (int) (byte) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1#52" + "'", str4.equals("1#52"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        float[] floatArray3 = new float[] { (byte) 100, 10.0f, 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100.0410.0410.0" + "'", str5.equals("100.0410.0410.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 10.0 10.0" + "'", str7.equals("100.0 10.0 10.0"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 18.0f, (double) 51);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.0d + "'", double3 == 51.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100L, 0.0f, (float) 30);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", "m");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14." + "'", str2.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14."));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/U/sr///Users/Lrbrary/Java/Extsn/rUn/:/Lrbrary/Java/Extsn/rUn/:/NstwUrk/Lrbrary/Java/Extsn/rUn/:/Sy/tsm/Lrbrary/Java/Extsn/rUn/:/u/r/lrb/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "69 100", "                                                                                                                         ");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, ":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/soph69 100/Users/soph", (java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        float[] floatArray3 = new float[] { (byte) 100, 10.0f, 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', 91, (int) '#');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100.0410.0410.0" + "'", str5.equals("100.0410.0410.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        char[] charArray5 = new char[] { ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " #", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " " + "'", str10.equals(" "));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("4", "", "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:4/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:" + "'", str3.equals("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:4/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/UsHas/stph69 100/UsHas/stph", ") 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/UsHas/stph69 100/UsHas/stph" + "'", str2.equals("/UsHas/stph69 100/UsHas/stph"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1#0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "X86_64aaaaaaaaaaaaaaaaaaaaaaa", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(18L, (long) (short) 100, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "-1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("52.0", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503aaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Users/sophie/Documents/defects4", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("7.0_8", 30, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############7.0_8#############" + "'", str3.equals("############7.0_8#############"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("aaaaaaaaaa", "OracleCorporationaaaaaaaaaaaaaaa", "1.0a0.0a100.0a-1.0a0.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa" + "'", str3.equals("aaaaaaaaaa"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Virtual Machine Specification ", (java.lang.CharSequence) "                                                   4", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10#10", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", (int) (short) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14." + "'", str3.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14."));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUX86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7", (java.lang.CharSequence) "                            ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("JavaVirtualMachineSpecificationMacOSX", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a", "Java Virtual Machine Specification");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) " A#", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4" + "'", str5.equals("4"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0 1", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "-1#10#-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("444444444444444444444444444", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4" + "'", str2.equals("4"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.040.04100.04-1.040.0         ", (java.lang.CharSequence) "cuments/defects4j/tmp/run_rndoop.pl_49819_1560276503", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "///", (java.lang.CharSequence) "                                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "0#1", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("#52", "javaaPlatformaAPIaSpevifivation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#52" + "'", str2.equals("#52"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 8, (float) 28, (float) 'a');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = javaVersion3.atLeast(javaVersion5);
        boolean boolean7 = javaVersion0.atLeast(javaVersion5);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean11 = javaVersion9.atLeast(javaVersion10);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean13 = javaVersion10.atLeast(javaVersion12);
        boolean boolean14 = javaVersion5.atLeast(javaVersion10);
        org.apache.commons.lang3.JavaVersion javaVersion15 = null;
        try {
            boolean boolean16 = javaVersion10.atLeast(javaVersion15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("cuments/defects4j/tmp/run_rndoop.pl_49819_1560276503", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444448_0.7", "1.5");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("24.80-B11", "javaaPlatformaAPIaSpevifivation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-B11" + "'", str2.equals("24.80-B11"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(52, 0, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503aaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                    sun.lwawt.macosx.CPrinterJob                                    ", 'a');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Mac OMac O");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("                                          mixed mode", strArray6, strArray9);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("randoop-current.jJava Virtual Machine Specification fects4j/tmp/run_r", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 99 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "                                          mixed mode" + "'", str10.equals("                                          mixed mode"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0#100#35#100#10#52", 9642541);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 100, (long) 281, (long) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 281L + "'", long3 == 281L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                          mixed mod", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         mixed mod" + "'", str2.equals("                                         mixed mod"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 8, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaa" + "'", str3.equals("aaaaaaaa"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("JavaVirtualMachineSpecificationMacOSX", 29, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaVirtualMachineSpecificationMacOSX" + "'", str3.equals("JavaVirtualMachineSpecificationMacOSX"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("cuments/defects4j/tmp/run_rndoop.pl_49819_1560276503", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                                                  ##", "u");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                  ##" + "'", str2.equals("                                                                                                  ##"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("0", 0, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.0 0.0 100.0 -1.0 0.0", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0 -1.0 100.0 0.0 1.0" + "'", str2.equals("0.0 -1.0 100.0 0.0 1.0"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "10#10");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#', 9642541, (int) '#');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "0#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("SUN.AWT.CGRAPHICSENVIRONMENT", "-1.0#69.0", "0 1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str3.equals("SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 1, 0.0f, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        char[] charArray3 = new char[] {};
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ');
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!4http://java.oracle.com/", charArray3);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-1a10a-1", charArray3);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "randoop-current.jJava Virtual Machine Specification fects4j/tmp/run_r", charArray3);
        java.lang.Class<?> wildcardClass9 = charArray3.getClass();
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaa" + "'", str1.equals("aaaaaaaaa"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", " #");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        double[] doubleArray2 = new double[] { (short) -1, 69 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', (int) (short) 0, (int) (byte) 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', 32, 4);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4', 4, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 69.0d + "'", double3 == 69.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 69.0d + "'", double9 == 69.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "///", (java.lang.CharSequence) "u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.0a97.0a4.0", "444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a97.0a4.0" + "'", str2.equals("1.0a97.0a4.0"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_rX86_64ndoop.pl_49819_156027650", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0.0 -1.0 100.0 0.0 1.0", 52, "/Uss/sh/Dcumns/dfcsj/m/un_ond.l_9819_150275");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0 -1.0 100.0 0.0 1.0/Uss/sh/Dcumns/dfcsj/m/un_ond." + "'", str3.equals("0.0 -1.0 100.0 0.0 1.0/Uss/sh/Dcumns/dfcsj/m/un_ond."));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("u                                                                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "u                                                                                                  " + "'", str1.equals("u                                                                                                  "));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("OracleCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "               h                ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "############7.0_8#############", ":");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("U");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("SUN.AWT.CGRAPHICSENVIRONMENT");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "", (int) (short) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Uss/sh/Dcumns/dfcsj/m/un_ond.l_9819_150275", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Uss/sh/Dcumns/dfcsj/m/un_ond.l_9819_150275" + "'", str2.equals("/Uss/sh/Dcumns/dfcsj/m/un_ond.l_9819_150275"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.0a97.0a4.0", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a97.0a4.0" + "'", str4.equals("1.0a97.0a4.0"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "1.0a0.0a100.0a-1.0a0.0", (java.lang.CharSequence) "javaaPlatformaAPIaSpevifivation");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.0a0.0a100.0a-1.0a0.0" + "'", charSequence2.equals("1.0a0.0a100.0a-1.0a0.0"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("-1 10 -1", "Specification Machine Virtual JavaXSpecification Machine Virtual Java8Specification Machine Virtual Java6Specification Machine Virtual Java_Specification Machine Virtual Java6Specification Machine Virtual Java4Specification Machine Virtual Java", "/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1 10 -1" + "'", str3.equals("-1 10 -1"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        short[] shortArray0 = new short[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ', (int) (short) 100, (int) '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', (int) ' ', 10);
        try {
            short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("69.0 10.0 100.0 1.0 -1.0 100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"69.0 10.0 100.0 1.0 -1.0 100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("OracleCorporationaaaaaaaaaaaaaaa", "Java Virtual Machine SpecificationMac OS X", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean9 = javaVersion5.atLeast(javaVersion8);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean11 = javaVersion3.atLeast(javaVersion5);
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean15 = javaVersion13.atLeast(javaVersion14);
        java.lang.Class<?> wildcardClass16 = javaVersion13.getClass();
        boolean boolean17 = javaVersion5.atLeast(javaVersion13);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        java.lang.CharSequence[] charSequenceArray3 = new java.lang.CharSequence[] { "hi!", "http://java.oracle.com/" };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray3, '4');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "51.0", charSequenceArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray3, '#');
        org.junit.Assert.assertNotNull(charSequenceArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!4http://java.oracle.com/" + "'", str6.equals("hi!4http://java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!#http://java.oracle.com/" + "'", str9.equals("hi!#http://java.oracle.com/"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.0 97.0 4.0", 94);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         1.0 97.0 4.0                                         " + "'", str2.equals("                                         1.0 97.0 4.0                                         "));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("a#", "Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a#" + "'", str2.equals("a#"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart(" ", "1452");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/UsHas/stph69 100/UsHas/stph", (java.lang.CharSequence) "u                                                                                                  ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/UsHas/stph69 100/UsHas/stph" + "'", charSequence2.equals("/UsHas/stph69 100/UsHas/stph"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Uss/sh/Dcumns/dfcsj/m/un_ond.l_9819_150275");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "69.0 10.0 100.0 1.0 -1.0 100.0", (java.lang.CharSequence) "Users/sophie/Documents/defects4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        double[] doubleArray1 = new double[] { (short) 1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0" + "'", str5.equals("1.0"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 100, (double) (short) 10, (double) 4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("100.0a10.0a10.0", "-1a10a-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0a10.0a10.0" + "'", str2.equals("100.0a10.0a10.0"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        short[] shortArray0 = new short[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ', (int) (short) 100, (int) '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', (int) ' ', 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#', 0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1L, (float) 31, (float) 97);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 52, 4.0f, (float) 281);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 281.0f + "'", float3 == 281.0f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("///");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "///" + "'", str1.equals("///"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "100.0a10.0a10.0", (java.lang.CharSequence) " A#", 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 91, (long) 18, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 91L + "'", long3 == 91L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("U");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"U\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 52, 10);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "jAVA hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vm4");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: jAVA hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vm4");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 1" + "'", str7.equals("0 1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vmjAVA hOTsPOT(tm) 64-bIT sERVER vm4", "100.0410.0410.0#####################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0#100#35#100#10#52", (java.lang.CharSequence) "86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Documents/defects4j/tmp/run_rX86_64ndoop.pl_49819_156027650");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_rX86_64ndoop.pl_49819_156027650" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_rX86_64ndoop.pl_49819_156027650"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charSequence1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str1.equals("SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Specification Machine Virtual JavaXSpecification Machine Virtual Java8Specification Machine Virtual Java6Specification Machine Virtual Java_Specification Machine Virtual Java6Specification Machine Virtual Java4Specification Machine Virtual Java", "-1#97#100#69");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specification Machine Virtual JavaXSpecification Machine Virtual Java8Specification Machine Virtual Java6Specification Machine Virtual Java_Specification Machine Virtual Java6Specification Machine Virtual Java4Specification Machine Virtual Java" + "'", str2.equals("Specification Machine Virtual JavaXSpecification Machine Virtual Java8Specification Machine Virtual Java6Specification Machine Virtual Java_Specification Machine Virtual Java6Specification Machine Virtual Java4Specification Machine Virtual Java"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "\n:", (java.lang.CharSequence) "-1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        char[] charArray5 = new char[] { ' ', '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-b15", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0#1", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        short[] shortArray0 = new short[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ', (int) (short) 100, (int) '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', (int) (byte) 100, (int) '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        try {
            short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("mixed mode", "444444444444444444444444444", 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode" + "'", str3.equals("mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode444444444444444444444444444mixed mode"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.040.04100.04-1.040.0         ", (java.lang.CharSequence) "1.040.04100.04-1.040.0         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "52.0", (java.lang.CharSequence) "u                                                                                                   ", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("35.0 100.0 0.0 -1.0 10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"35.0 100.0 0.0 -1.0 10.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "///");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-14104-1", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(" a#", "/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " a#" + "'", str2.equals(" a#"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4", (java.lang.CharSequence) "                                                                                                  ##", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1a52", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a52" + "'", str2.equals("1a52"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "-1.0#69.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", " ##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-14104-1", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hi!4http://java.oracle.com");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMhJava HotSpot(TM) 64-Bit Server VMiJava HotSpot(TM) 64-Bit Server VM!Java HotSpot(TM) 64-Bit Server VM4Java HotSpot(TM) 64-Bit Server VMhJava HotSpot(TM) 64-Bit Server VMtJava HotSpot(TM) 64-Bit Server VMtJava HotSpot(TM) 64-Bit Server VMpJava HotSpot(TM) 64-Bit Server VM:Java HotSpot(TM) 64-Bit Server VM/Java HotSpot(TM) 64-Bit Server VM/Java HotSpot(TM) 64-Bit Server VMjJava HotSpot(TM) 64-Bit Server VMaJava HotSpot(TM) 64-Bit Server VMvJava HotSpot(TM) 64-Bit Server VMaJava HotSpot(TM) 64-Bit Server VM.Java HotSpot(TM) 64-Bit Server VMoJava HotSpot(TM) 64-Bit Server VMrJava HotSpot(TM) 64-Bit Server VMaJava HotSpot(TM) 64-Bit Server VMcJava HotSpot(TM) 64-Bit Server VMlJava HotSpot(TM) 64-Bit Server VMeJava HotSpot(TM) 64-Bit Server VM.Java HotSpot(TM) 64-Bit Server VMcJava HotSpot(TM) 64-Bit Server VMoJava HotSpot(TM) 64-Bit Server VMmJava HotSpot(TM) 64-Bit Server VM/Java HotSpot(TM) 64-Bit Server VM", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                          mixed mod", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", "cuments/defects4j/tmp/run_rndoop.pl_49819_1560276503", 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "aaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Java Platform API Specification", 1, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1a10a-", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1#52");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                    sun.lwawt.macosx.CPrinterJob                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("100.0410.0410.0#####################################################################################", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0410.0410.0#####################################################################################" + "'", str2.equals("100.0410.0410.0#####################################################################################"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1452469");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1452469" + "'", str1.equals("1452469"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Uss/sh/Dcumns/dfcsj/m/un_ond.l_9819_150275", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("8_0.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8_0.7" + "'", str1.equals("8_0.7"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "#52", (-1), 27);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("69 100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("-1#10#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#10#-1" + "'", str1.equals("-1#10#-1"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4", 94, "0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4" + "'", str3.equals(":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9819_15602765/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_4:/Users/sophie/Documents/defects" + "'", str2.equals("9819_15602765/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_4:/Users/sophie/Documents/defects"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "Java HotSpot(TM) 64-Bit Server VMhJava HotSpot(TM) 64-Bit Server VMiJava HotSpot(TM) 64-Bit Server VM!Java HotSpot(TM) 64-Bit Server VM4Java HotSpot(TM) 64-Bit Server VMhJava HotSpot(TM) 64-Bit Server VMtJava HotSpot(TM) 64-Bit Server VMtJava HotSpot(TM) 64-Bit Server VMpJava HotSpot(TM) 64-Bit Server VM:Java HotSpot(TM) 64-Bit Server VM/Java HotSpot(TM) 64-Bit Server VM/Java HotSpot(TM) 64-Bit Server VMjJava HotSpot(TM) 64-Bit Server VMaJava HotSpot(TM) 64-Bit Server VMvJava HotSpot(TM) 64-Bit Server VMaJava HotSpot(TM) 64-Bit Server VM.Java HotSpot(TM) 64-Bit Server VMoJava HotSpot(TM) 64-Bit Server VMrJava HotSpot(TM) 64-Bit Server VMaJava HotSpot(TM) 64-Bit Server VMcJava HotSpot(TM) 64-Bit Server VMlJava HotSpot(TM) 64-Bit Server VMeJava HotSpot(TM) 64-Bit Server VM.Java HotSpot(TM) 64-Bit Server VMcJava HotSpot(TM) 64-Bit Server VMoJava HotSpot(TM) 64-Bit Server VMmJava HotSpot(TM) 64-Bit Server VM/Java HotSpot(TM) 64-Bit Server VM", "100.0a10.0a10.0", 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("u         9642541u         ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion1.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(" #", "", "0.0 -1.0 100.0 0.0 1.0/Uss/sh/Dcumns/dfcsj/m/un_ond.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " #" + "'", str3.equals(" #"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "69.0 10.0 100.0 1.0 -1.0 100.0", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503aaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                    sun.lwawt.macosx.CPrinterJob                                    ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "8_0.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "#52");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "aaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("U", 121);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED" + "'", str1.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        float[] floatArray3 = new float[] { (byte) 100, 10.0f, 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        java.lang.Class<?> wildcardClass6 = floatArray3.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', 100, 2);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100.0410.0410.0" + "'", str5.equals("100.0410.0410.0"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100.0a10.0a10.0" + "'", str8.equals("100.0a10.0a10.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                          mixed mode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4444441.7\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '4', (long) 9642541, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "javaaPlatformaAPIaSpevifivation", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java Virtual Machine Specification ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("10#100", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#100" + "'", str2.equals("0#100"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.0a97.0a4.0", 69);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a97.0a4.0" + "'", str2.equals("1.0a97.0a4.0"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUX86_64", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("-1a10a-1", 28, "0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a10a-100000000000000000000" + "'", str3.equals("-1a10a-100000000000000000000"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Users/sophie/Documents/defects4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        double[] doubleArray5 = new double[] { ' ', 10.0f, 'a', 69, 10L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "-1.0#69.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_156027650", (java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(strArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (byte) 10, 281);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "1.7.0_80-b15", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.7.0_80-b15" + "'", charSequence2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        int[] intArray2 = new int[] { 69, 100 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', 3, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("-14104-1", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 97, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 29, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 15, (double) 281);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophierandoop-current.jation/ration/generame", "0#100#35#100#10#52", "4");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 27, (double) 9642541L, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         ", "51.0", 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "u         9642541u      51.0       9642541u         " + "'", str3.equals("u         9642541u      51.0       9642541u         "));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(" A#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " A#" + "'", str1.equals(" A#"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a", "Java Virtual Machine Specification");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("                                          mixed mode");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("                                         mixed mod", strArray3, strArray7);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '#', (int) (byte) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4" + "'", str5.equals("4"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "m" + "'", str8.equals("m"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "                                         mixed mod" + "'", str9.equals("                                         mixed mod"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("hi!#http://java.oracle.com/", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!#http://java.oracle.com/" + "'", str2.equals("hi!#http://java.oracle.com/"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("///", 9642541L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9642541L + "'", long2 == 9642541L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "hi!#http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!#http://java.oracle.com/" + "'", str2.equals("hi!#http://java.oracle.com/"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("mac OS X");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("#52", "1.7.0_80", (int) (short) 10, 94);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#521.7.0_80" + "'", str4.equals("#521.7.0_80"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 1, (float) (byte) 10, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", charSequence2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "u         9642541u         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "\n:");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        long[] longArray3 = new long[] { (byte) -1, (short) 10, (-1L) };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ', (int) (short) 100, 1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1a10a-1" + "'", str10.equals("-1a10a-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1 10 -1" + "'", str12.equals("-1 10 -1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        int[] intArray4 = new int[] { (short) -1, 'a', (byte) 100, 69 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 281, 27);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                                                                                                         ", "", "hi!4http://java.oracle.com", 8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                                                         " + "'", str4.equals("                                                                                                                         "));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.0a0.0a100.0a-1.0a0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        long[] longArray3 = new long[] { (byte) -1, (short) 10, (-1L) };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1 10 -1" + "'", str7.equals("-1 10 -1"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "8_0.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("-1#97#100#69");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 0, (float) 69L, (float) 2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.8", 121);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1452469", "0.0 -1.0 100.0 0.0 1.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        int[] intArray4 = new int[] { (short) -1, 'a', (byte) 100, 69 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "52.0", (java.lang.CharSequence) "10#10");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "52.0" + "'", charSequence2.equals("52.0"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_156027650");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_156027650" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_156027650"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaa", (long) 51);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 51L + "'", long2 == 51L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification" + "'", str1.equals("java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java(TM)SERuntimeEnvironment", 281, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava(TM)SERuntimeEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava(TM)SERuntimeEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         ", "-1a10a-");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sop" + "'", str2.equals("/Users/sop"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "hi!4http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                            ...", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         ..." + "'", str2.equals("                         ..."));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1#52", (java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava(TM)SERuntimeEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7", charSequence1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_156027650", (java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray3, strArray6);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByCharacterType("en");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, 'a', (int) (short) 1, 1);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" ", "-1 10 -1", (int) (short) -1);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("1452469", strArray11, strArray19);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaaaaa", strArray3, strArray11);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str8.equals("/Library/Java/JavaVirtualMachines/jdk/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1452469" + "'", str20.equals("1452469"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "aaaaaaaaaa" + "'", str21.equals("aaaaaaaaaa"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_rX86_64ndoop.pl_49819_156027650", (java.lang.CharSequence) ") 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1 10 -1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1 10 -1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("0.0 -1.0 100.0 0.0 1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0 -1.0 100.0 0.0 1.0" + "'", str1.equals("0.0 -1.0 100.0 0.0 1.0"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "a#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                          aaaaaaaaaa", (java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION", 281);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(1.0d, (double) 2, (double) 281L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("u                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        double[] doubleArray2 = new double[] { (short) -1, 69 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', (int) (short) 0, (int) (byte) 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 69.0d + "'", double3 == 69.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 69.0d + "'", double8 == 69.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 69.0d + "'", double9 == 69.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("u         9642541u         ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 94);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1 10 -1", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger(":");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION", (java.lang.CharSequence) "u                                                                                                  ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "JAVA PLATFORM API SPECIFICATION" + "'", charSequence2.equals("JAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("UTF-8", "                                                                                          ", 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a", "Java Virtual Machine Specification");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("69#100", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        long[] longArray4 = new long[] { (-1), 51L, 91, 100L };
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 27, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 27");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                         ...", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                                                                  ##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                  ##" + "'", str1.equals("                                                                                                  ##"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("java/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Virtual/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Machine/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA: /uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:vIRTUAL/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA: /uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:mACHINE/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA: /uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:sPECIFICATION" + "'", str1.equals("JAVA/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA: /uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:vIRTUAL/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA: /uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:mACHINE/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA: /uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:sPECIFICATION"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1#52/Use", "m");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#52/Use" + "'", str2.equals("1#52/Use"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 121);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1452469");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("m", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "m" + "'", str2.equals("m"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "u                                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "9642541", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("X86_64", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                ", (int) (byte) 1, "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                " + "'", str3.equals("                                "));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!#http://java.oracle.com/", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "OracleCorporationaaaaaaaaaaaaaaa", (java.lang.CharSequence) "0#1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "hi!4http://java.oracle.com");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "                                          mixed mod");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) -1, 0, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("0.0 -1.0 100.0 0.0 1.0/Uss/sh/Dcumns/dfcsj/m/un_ond.", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0 -1.0 100.0 0.0 1.0/Uss/sh/Dcumns/dfcsj/m/un_ond." + "'", str2.equals("0.0 -1.0 100.0 0.0 1.0/Uss/sh/Dcumns/dfcsj/m/un_ond."));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        short[] shortArray0 = new short[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ', (int) (short) 100, (int) '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', (int) ' ', 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4', 69, (int) (short) 10);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#', 100, (int) '4');
        try {
            short short21 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "cuments/defects4j/tmp/run_rndoop.pl_49819_1560276503");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                         mixed mod", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         mixed mod" + "'", str2.equals("                                         mixed mod"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1.0#69.0", "SUN.AWT.CGRAPHICSENVIRONMENT", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.0 0.0 100.0 -1.0 0.0", 15, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0 0.0 100.0 -1.0 0.0" + "'", str3.equals("1.0 0.0 100.0 -1.0 0.0"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("#52", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_49819_1560276503", 69, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#52/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_49819_1560276503" + "'", str4.equals("#52/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_49819_1560276503"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "         0.040.1-40.00140.040.1", (java.lang.CharSequence) "                                                                                          aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "    Mac OMac O    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "#52", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        double[] doubleArray1 = new double[] { (short) 1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENT", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "                                    sun.lwawt.macosx.CPrinterJob                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sun.lwawt.macosx.CPrinterJob", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503aaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("U");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "u" + "'", str1.equals("u"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        double[] doubleArray5 = new double[] { ' ', 10.0f, 'a', 69, 10L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u" + "'", str1.equals("u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u         u         9642541u"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("u");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str1.equals(":avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUX86_64");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUX86_64");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "JAVA/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA: /uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:vIRTUAL/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA: /uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:mACHINE/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA: /uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                         mixed mod", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java Virtual Machine Specification ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765", (java.lang.CharSequence) "10#10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503aaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_1560276503");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophi" + "'", str1.equals("/Users/sophi"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) 1, "Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "M" + "'", str3.equals("M"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4', 32, 52);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("               h                ", "", "100.0 10.0 10.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               h                " + "'", str3.equals("               h                "));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0a1", "X86_64aaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("b", "100.0 10.0 10.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Java(TM)SERuntimeEnvironment", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "t" + "'", str2.equals("t"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = javaVersion3.atLeast(javaVersion5);
        boolean boolean7 = javaVersion0.atLeast(javaVersion5);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean10 = javaVersion5.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean13 = javaVersion11.atLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean15 = javaVersion12.atLeast(javaVersion14);
        boolean boolean16 = javaVersion5.atLeast(javaVersion12);
        java.lang.String str17 = javaVersion5.toString();
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean20 = javaVersion18.atLeast(javaVersion19);
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean22 = javaVersion18.atLeast(javaVersion21);
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion24 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean25 = javaVersion23.atLeast(javaVersion24);
        org.apache.commons.lang3.JavaVersion javaVersion26 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean27 = javaVersion23.atLeast(javaVersion26);
        boolean boolean28 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
        boolean boolean29 = javaVersion21.atLeast(javaVersion23);
        boolean boolean30 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion21);
        boolean boolean31 = javaVersion5.atLeast(javaVersion21);
        boolean boolean32 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.7" + "'", str17.equals("1.7"));
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion24 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion24.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + javaVersion26 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion26.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_49819_1560276503/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" #");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("35.0 100.0 0.0 -1.0 10.0", strArray1, strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "35.0 100.0 0.0 -1.0 10.0" + "'", str4.equals("35.0 100.0 0.0 -1.0 10.0"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#0" + "'", str1.equals("1#0"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("SUN.AWT.CGRAPHICSENVIRONMENT", "44444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str2.equals("SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils1 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils2 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils3 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils4 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray5 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0, numberUtils1, numberUtils2, numberUtils3, numberUtils4 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray5);
        org.junit.Assert.assertNotNull(numberUtilsArray5);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM4", "1.040.04100.04-1.040.0         ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("#52");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#52" + "'", str1.equals("#52"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("tionaSpevifivaAPIatformaPlavaJ", "-1.0#69.0", "0#1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tionaSpevifivaAPIatformaPlavaJ" + "'", str3.equals("tionaSpevifivaAPIatformaPlavaJ"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("OracleCorporationaaaaaaaaaaaaaaa", (-1), "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCorporationaaaaaaaaaaaaaaa" + "'", str3.equals("OracleCorporationaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("100.0410.0410.0", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("US", "");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "X86_64");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "m#cosx.CPrinterJob", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(":/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_49819_15602765/Users/sophie/Documents/defects4", "X86_64");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaPlatformAPISpecification" + "'", str1.equals("JavaPlatformAPISpecification"));
    }
}

