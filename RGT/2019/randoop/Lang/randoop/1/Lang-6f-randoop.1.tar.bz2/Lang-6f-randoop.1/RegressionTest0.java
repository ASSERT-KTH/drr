import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.String str0 = org.apache.commons.lang3.StringUtils.EMPTY;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "hi!", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        int[] intArray9 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(intArray9, (int) (byte) 0);
        try {
            byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.removeAll(byteArray2, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("hi!", (int) (byte) -1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!" + "'", str3.equals("!"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) 0L, (java.lang.Object) 1.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        java.io.Writer writer2 = null;
        try {
            unicodeEscaper0.translate((java.lang.CharSequence) "", writer2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Writer must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[][] strArray2 = new java.lang.String[][] { strArray0, strArray1 };
        try {
            java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        short[] shortArray0 = null;
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray0, (-1), (int) '4');
        org.junit.Assert.assertNull(shortArray3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("hi!", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.lang3.ArrayUtils.remove(intArray0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "hi!", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("!", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        float[] floatArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray0, 0.0f);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("!", 100, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeEcmaScript("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml3("!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!" + "'", str1.equals("!"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray2 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper0, unicodeEscaper1 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator3 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray2);
        java.lang.String str5 = aggregateTranslator3.translate((java.lang.CharSequence) "");
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeCsv("!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!" + "'", str1.equals("!"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 1, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "", "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper2 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper3 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        java.lang.String str5 = unicodeEscaper3.translate((java.lang.CharSequence) "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper6 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        java.lang.String str8 = unicodeEscaper6.translate((java.lang.CharSequence) "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper9 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray10 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] { unicodeEscaper0, unicodeEscaper1, unicodeEscaper2, unicodeEscaper3, unicodeEscaper6, unicodeEscaper9 };
        int[] intArray11 = null;
        try {
            org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray12 = org.apache.commons.lang3.ArrayUtils.removeAll(codePointTranslatorArray10, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(codePointTranslatorArray10);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!" + "'", str1.equals("!"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        java.lang.String str2 = unicodeEscaper0.translate((java.lang.CharSequence) "");
        java.io.Writer writer5 = null;
        try {
            int int6 = unicodeEscaper0.translate((java.lang.CharSequence) "!", 2, writer5);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 2");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "-1.0 -1.0 1.0 -1.0 1.0 1.0", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", charSequence2.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1.0 -1.0 1.0 -1.0 1.0 1.0", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26 + "'", int2 == 26);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "", (java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("-1.0 -1.0 1.0 -1.0 1.0 1.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("!", "", "!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!" + "'", str3.equals("!"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        float[] floatArray0 = null;
        float[] floatArray1 = org.apache.commons.lang3.ArrayUtils.clone(floatArray0);
        org.junit.Assert.assertNull(floatArray1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        java.lang.Integer[] intArray8 = new java.lang.Integer[] {};
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray8);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray9);
        int[] intArray15 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(intArray15, (int) (byte) 0);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray15);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray10, intArray18);
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray18, 2);
        try {
            double[] doubleArray22 = org.apache.commons.lang3.ArrayUtils.removeAll(doubleArray7, intArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 10);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 100);
        try {
            byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.add(byteArray6, (int) (byte) 100, (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1.0 -1.0 1.0 -1.0 1.0 1.0", (java.lang.CharSequence) "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "", (java.lang.CharSequence) "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        char[] charArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, ' ', (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        try {
            short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (int) (short) 100, (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.lang3.ArrayUtils.remove(intArray0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.lang3.text.translate.EntityArrays entityArrays0 = new org.apache.commons.lang3.text.translate.EntityArrays();
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper2 = org.apache.commons.lang3.text.translate.UnicodeEscaper.outsideOf((int) (byte) 1, 0);
        org.junit.Assert.assertNotNull(unicodeEscaper2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.Short[] shortArray0 = null;
        short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        org.junit.Assert.assertNull(shortArray1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeHtml4("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml4("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', 10, (int) (short) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        try {
            short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (int) '4', (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeCsv("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-1.0 -1.0 1.0 -1.0 1.0 1.0", (int) (short) 100, "hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int[] intArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray0, 100, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_UNESCAPE();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "", (java.lang.CharSequence) "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hi!", (int) (byte) 100, "!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + "'", str3.equals("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        try {
            float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.add(floatArray3, 6, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("-1.0 -1.0 1.0 -1.0 1.0 1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str1.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("hi!", "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        java.io.Writer writer3 = null;
        try {
            int int4 = unicodeEscaper0.translate((java.lang.CharSequence) "", (int) (byte) 100, writer3);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 100");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("!", "!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("!", (int) (short) 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         !" + "'", str3.equals("         !"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml4("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        byte[] byteArray0 = null;
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        org.junit.Assert.assertNull(byteArray1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator0 = org.apache.commons.lang3.StringEscapeUtils.UNESCAPE_CSV;
        org.junit.Assert.assertNotNull(charSequenceTranslator0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (-1), (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        char[] charArray1 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray1);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", (java.lang.CharSequence) "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray2 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper0, unicodeEscaper1 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator3 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray2);
        java.io.Writer writer6 = null;
        try {
            int int7 = aggregateTranslator3.translate((java.lang.CharSequence) "", 10, writer6);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 10");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeHtml4("         !");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "         !" + "'", str1.equals("         !"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("!", "         !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        boolean[] booleanArray0 = null;
        boolean[] booleanArray2 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray0, false);
        org.junit.Assert.assertNull(booleanArray2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", (java.lang.CharSequence) "hi!", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h-1.0 -1.0 1.0 -1.0 1.0 1.0h" + "'", str2.equals("h-1.0 -1.0 1.0 -1.0 1.0 1.0h"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.String str1 = org.apache.commons.lang3.text.translate.CharSequenceTranslator.hex((int) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "23" + "'", str1.equals("23"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + "'", str2.equals("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.lang.String str0 = org.apache.commons.lang3.StringUtils.SPACE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + " " + "'", str0.equals(" "));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.lang3.StringEscapeUtils stringEscapeUtils0 = new org.apache.commons.lang3.StringEscapeUtils();
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (short) 0);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray6, (short) (byte) 0);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        char[] charArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(charArray0, '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("         !", "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.lang.String str1 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) 1.0f);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0" + "'", str1.equals("1.0"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeHtml4("{0,97,100,10}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0,97,100,10}" + "'", str1.equals("{0,97,100,10}"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" ", "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1a-1a-1", (java.lang.CharSequence) "1a-1a-1", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("h-1.0 -1.0 1.0 -1.0 1.0 1.0h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h-1.0 -1.0 1.0 -1.0 1.0 1.0h" + "'", str1.equals("h-1.0 -1.0 1.0 -1.0 1.0 1.0h"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) " ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.lang.Character[] charArray0 = null;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0, '#');
        org.junit.Assert.assertNull(charArray2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        char[] charArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray0, '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray2 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper0, unicodeEscaper1 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator3 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray2);
        java.io.Writer writer6 = null;
        try {
            int int7 = aggregateTranslator3.translate((java.lang.CharSequence) "-1.0 -1.0 1.0 -1.0 1.0 1.0", 100, writer6);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 100");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        char[] charArray4 = new char[] { '#', '#', '#', ' ' };
        char[] charArray8 = new char[] { 'a', ' ', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray8);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray9);
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.add(charArray10, '4');
        char[] charArray13 = null;
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray12, charArray13);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        java.io.Writer writer2 = null;
        try {
            unicodeEscaper0.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", writer2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Writer must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.0", "         !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         !" + "'", str2.equals("         !"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "23");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray6);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.lang3.ArrayUtils arrayUtils0 = new org.apache.commons.lang3.ArrayUtils();
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("h-1.0 -1.0 1.0 -1.0 1.0 1.0h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h-1.0 -1.0 1.0 -1.0 1.0 1.0h" + "'", str1.equals("h-1.0 -1.0 1.0 -1.0 1.0 1.0h"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", (java.lang.CharSequence) "23");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray14 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray19 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[][] byteArray20 = new byte[][] { byteArray4, byteArray9, byteArray14, byteArray19 };
        byte[] byteArray27 = new byte[] { (byte) -1, (byte) 1, (byte) -1, (byte) 0, (byte) 10, (byte) 10 };
        byte[][] byteArray28 = new byte[][] { byteArray27 };
        byte[][] byteArray29 = org.apache.commons.lang3.ArrayUtils.removeElements(byteArray20, byteArray28);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isEmpty((java.lang.Object[]) byteArray28);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper0 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        java.lang.String str2 = unicodeUnescaper0.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        java.io.Writer writer5 = null;
        try {
            int int6 = unicodeUnescaper0.translate((java.lang.CharSequence) " ", (int) '4', writer5);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 52");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("!", "hi!", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray2 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper0, unicodeEscaper1 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator3 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray2);
        java.lang.CharSequence charSequence4 = null;
        java.lang.String str5 = aggregateTranslator3.translate(charSequence4);
        java.io.Writer writer8 = null;
        try {
            int int9 = aggregateTranslator3.translate((java.lang.CharSequence) "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", (int) (byte) 0, writer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray2);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeCsv(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " " + "'", str1.equals(" "));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.Object[] objArray0 = null;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(objArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml3("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 2);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.clone(intArray10);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(intArray14, (int) 'a');
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "0a97a100a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeHtml3("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "         !");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int[] intArray0 = null;
        try {
            int[] intArray3 = org.apache.commons.lang3.ArrayUtils.add(intArray0, 26, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 26, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "h-1.0 -1.0 1.0 -1.0 1.0 1.0h");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int[] intArray6 = new int[] { (byte) 0, 10, (short) 0, (byte) 1, (byte) 0, (byte) -1 };
        int[] intArray13 = new int[] { (byte) 0, 10, (short) 0, (byte) 1, (byte) 0, (byte) -1 };
        int[] intArray20 = new int[] { (byte) 0, 10, (short) 0, (byte) 1, (byte) 0, (byte) -1 };
        int[][] intArray21 = new int[][] { intArray6, intArray13, intArray20 };
        int[][] intArray24 = org.apache.commons.lang3.ArrayUtils.subarray(intArray21, 100, 4);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) intArray21, "");
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeHtml3("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        java.lang.String str2 = unicodeEscaper0.translate((java.lang.CharSequence) "");
        java.io.Writer writer4 = null;
        try {
            boolean boolean5 = unicodeEscaper0.translate(1, writer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1.0 -1.0 1.0 -1.0 1.0 1.0", " ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("0a97a100a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a97a100a10" + "'", str1.equals("0a97a100a10"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        float[] floatArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray0, (-1.0f));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeEcmaScript("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.lang.Character[] charArray0 = null;
        char[] charArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0);
        org.junit.Assert.assertNull(charArray1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        try {
            long[] longArray21 = org.apache.commons.lang3.ArrayUtils.add(longArray3, (int) (short) 10, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("-1.0 -1.0 1.0 -1.0 1.0 1.0", (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 100, (int) (byte) -1);
        int[] intArray11 = null;
        try {
            double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.removeAll(doubleArray6, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) strArray3, (java.lang.Object) 1L, (int) (byte) -1);
        java.lang.Object[] objArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty((java.lang.Object[]) strArray3);
        java.lang.Object obj8 = null;
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(objArray7, obj8);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray3);
        try {
            float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.remove(floatArray3, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.lang3.text.translate.OctalUnescaper octalUnescaper0 = new org.apache.commons.lang3.text.translate.OctalUnescaper();
        java.io.Writer writer3 = null;
        try {
            int int4 = octalUnescaper0.translate((java.lang.CharSequence) "{0,97,100,10}", (int) '#', writer3);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 35");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "23", (java.lang.CharSequence) "1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator0 = org.apache.commons.lang3.StringEscapeUtils.ESCAPE_JAVA;
        org.junit.Assert.assertNotNull(charSequenceTranslator0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray8);
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.subarray(longArray8, (int) (byte) 0, 2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray12);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("         !", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         !" + "'", str2.equals("         !"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        float[] floatArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray0, (float) (short) -1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#', (int) (short) 0, (int) (short) 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "{0,97,100,10}", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("         !");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "         !" + "'", str1.equals("         !"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "{0,97,100,10}", "0a97a100a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray11, 26, (int) '4');
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray11);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeEcmaScript("1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0" + "'", str1.equals("1.0"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        float[] floatArray0 = null;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int[] intArray0 = new int[] {};
        int[][] intArray1 = new int[][] { intArray0 };
        int[] intArray2 = new int[] {};
        int[][] intArray3 = new int[][] { intArray2 };
        int[] intArray4 = new int[] {};
        int[][] intArray5 = new int[][] { intArray4 };
        int[] intArray6 = new int[] {};
        int[][] intArray7 = new int[][] { intArray6 };
        int[][][] intArray8 = new int[][][] { intArray1, intArray3, intArray5, intArray7 };
        try {
            int[][][] intArray10 = org.apache.commons.lang3.ArrayUtils.remove(intArray8, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("         !", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         !" + "'", str2.equals("         !"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator0 = org.apache.commons.lang3.StringEscapeUtils.UNESCAPE_XML;
        org.junit.Assert.assertNotNull(charSequenceTranslator0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", " ", "0a97a100a10", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.lang3.StringUtils stringUtils0 = new org.apache.commons.lang3.StringUtils();
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("-1.0 -1.0 1.0 -1.0 1.0 1.0", "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator0 = org.apache.commons.lang3.StringEscapeUtils.ESCAPE_ECMASCRIPT;
        org.junit.Assert.assertNotNull(charSequenceTranslator0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.lang.Object[] objArray0 = null;
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        byte[] byteArray10 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.remove(byteArray10, 0);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray7, byteArray10);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.add(byteArray10, (byte) 1);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(objArray0, (java.lang.Object) byteArray10);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray4);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.lang.CharSequence[] charSequenceArray7 = new java.lang.CharSequence[] { "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1a-1a-1", "0a97a100a10", "0a97a100a10", "", "{0,97,100,10}" };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) " ", charSequenceArray7);
        org.junit.Assert.assertNotNull(charSequenceArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        try {
            short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.remove(shortArray4, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeHtml3("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray2);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-1.0 -1.0 1.0 -1.0 1.0 1.0", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator0 = org.apache.commons.lang3.StringEscapeUtils.ESCAPE_HTML3;
        org.junit.Assert.assertNotNull(charSequenceTranslator0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + "'", str2.equals("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 26);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (-1.0f), (double) 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int[] intArray0 = null;
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray0, (int) 'a');
        org.junit.Assert.assertNull(intArray2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d, 0.0d, 100.0d, 10.0d };
        double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray4);
        int[] intArray6 = null;
        try {
            double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.removeAll(doubleArray5, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("23", 6, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  23  " + "'", str3.equals("  23  "));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        short[] shortArray0 = null;
        try {
            short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.add(shortArray0, (int) (short) 100, (short) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("-1.0 -1.0 1.0 -1.0 1.0 1.0", "{0,97,100,10}", "  23  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str3.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.lang.Long[] longArray0 = null;
        long[] longArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray0);
        org.junit.Assert.assertNull(longArray1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray1, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 26);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray1);
        java.lang.Integer[] intArray22 = new java.lang.Integer[] { (-1), 3, 100, 10, 3, 2 };
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray22, (int) '4');
        try {
            double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.removeAll(doubleArray1, intArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        java.lang.String str2 = unicodeEscaper0.translate((java.lang.CharSequence) "");
        java.io.Writer writer4 = null;
        try {
            boolean boolean5 = unicodeEscaper0.translate(0, writer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml3(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " " + "'", str1.equals(" "));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                    " + "'", str3.equals("                                                                                                    "));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        char[] charArray4 = new char[] { '#', '#', '#', ' ' };
        char[] charArray8 = new char[] { 'a', ' ', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray8);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray9);
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.add(charArray10, '4');
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.subarray(charArray12, (int) '4', 0);
        try {
            char[] charArray18 = org.apache.commons.lang3.ArrayUtils.add(charArray12, (int) '#', ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 8");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray15);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "-1a100a1", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("974100410410", "0a97a100a10", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        short[] shortArray0 = null;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("{0,97,100,10}", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0,97,100,10}                   " + "'", str2.equals("{0,97,100,10}                   "));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 95 + "'", int1 == 95);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        char[] charArray4 = new char[] { '#', '#', '#', ' ' };
        char[] charArray8 = new char[] { 'a', ' ', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray9, '4');
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray9, '#');
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(charArray9);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray4);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(byteArray4, (byte) 0);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray4);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                                    ", "-1a100a1", "1a-1a-1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("-1a100a1", 95);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a100a1" + "'", str2.equals("-1a100a1"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[][] charSequenceTranslatorArray0 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[][] {};
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(charSequenceTranslatorArray0);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray11);
        try {
            float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.remove(floatArray11, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4');
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray0, (short) (byte) 1);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray0);
        try {
            short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.add(shortArray0, 26, (short) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 26, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.0", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeJava("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " ", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int[] intArray2 = new int[] { (byte) 0, 10 };
        int[] intArray5 = new int[] { (byte) 0, 10 };
        int[] intArray8 = new int[] { (byte) 0, 10 };
        int[] intArray11 = new int[] { (byte) 0, 10 };
        int[] intArray14 = new int[] { (byte) 0, 10 };
        int[] intArray17 = new int[] { (byte) 0, 10 };
        int[][] intArray18 = new int[][] { intArray2, intArray5, intArray8, intArray11, intArray14, intArray17 };
        int[] intArray21 = new int[] { (byte) 0, 10 };
        int[] intArray24 = new int[] { (byte) 0, 10 };
        int[] intArray27 = new int[] { (byte) 0, 10 };
        int[] intArray30 = new int[] { (byte) 0, 10 };
        int[] intArray33 = new int[] { (byte) 0, 10 };
        int[] intArray36 = new int[] { (byte) 0, 10 };
        int[][] intArray37 = new int[][] { intArray21, intArray24, intArray27, intArray30, intArray33, intArray36 };
        int[] intArray40 = new int[] { (byte) 0, 10 };
        int[] intArray43 = new int[] { (byte) 0, 10 };
        int[] intArray46 = new int[] { (byte) 0, 10 };
        int[] intArray49 = new int[] { (byte) 0, 10 };
        int[] intArray52 = new int[] { (byte) 0, 10 };
        int[] intArray55 = new int[] { (byte) 0, 10 };
        int[][] intArray56 = new int[][] { intArray40, intArray43, intArray46, intArray49, intArray52, intArray55 };
        int[][][] intArray57 = new int[][][] { intArray18, intArray37, intArray56 };
        try {
            int[][][] intArray59 = org.apache.commons.lang3.ArrayUtils.remove(intArray57, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray57);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int int0 = org.apache.commons.lang3.ArrayUtils.INDEX_NOT_FOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "{0,97,100,10}                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        char[] charArray3 = new char[] { 'a', 'a', ' ' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.remove(charArray3, (int) (byte) 1);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(charArray5, ' ');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (short) 0);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, 3, (short) 10);
        try {
            short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (int) (short) 10, (short) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray9);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int[] intArray0 = null;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(intArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "h-1.0 -1.0 1.0 -1.0 1.0 1.0h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h-1.0 -1.0 1.0 -1.0 1.0 1.0h" + "'", str2.equals("h-1.0 -1.0 1.0 -1.0 1.0 1.0h"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "  23  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("{0,97,100,10}", "h-1.0 -1.0 1.0 -1.0 1.0 1.0h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0,97,100,10}" + "'", str2.equals("{0,97,100,10}"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray4);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "!");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: !");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray8);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "         !", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.lang.Short[] shortArray1 = new java.lang.Short[] { (short) 1 };
        java.lang.Short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray1);
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray1, (short) 100);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double[] doubleArray0 = null;
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 2, 3, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        boolean[] booleanArray0 = null;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.lang.Long[] longArray4 = new java.lang.Long[] { 10L, 10L, 0L, 1L };
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray5);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.lang.Object[] objArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(objArray0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "!", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", (java.lang.CharSequence) "{0,97,100,10}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Byte[] byteArray0 = null;
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0, (byte) 100);
        org.junit.Assert.assertNull(byteArray2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "974100410410", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        char[] charArray4 = new char[] { '#', '#', '#', ' ' };
        char[] charArray8 = new char[] { 'a', ' ', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray8);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray9);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray9, '4', (int) (byte) 0);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeCsv("h-1.0 -1.0 1.0 -1.0 1.0 1.0h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h-1.0 -1.0 1.0 -1.0 1.0 1.0h" + "'", str1.equals("h-1.0 -1.0 1.0 -1.0 1.0 1.0h"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double[] doubleArray0 = null;
        double[] doubleArray3 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray0, 2, (int) (byte) 100);
        org.junit.Assert.assertNull(doubleArray3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.lang.Float[][] floatArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(floatArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "{0,97,100,10}", (java.lang.CharSequence) "974100410410");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "{0,97,100,10}                   ", (java.lang.CharSequence) "0 97 100 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        java.lang.Object obj7 = null;
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray5, obj7, 100);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("{0,97,100,10}", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("0 97 100 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 97 100 10" + "'", str1.equals("0 97 100 10"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper2 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between((-1), 4);
        org.junit.Assert.assertNotNull(unicodeEscaper2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray3);
        float[] floatArray21 = new float[] { 'a' };
        float[] floatArray23 = new float[] { (byte) -1 };
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray21, floatArray23);
        float[] floatArray31 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray33 = new float[] { 'a' };
        float[] floatArray35 = new float[] { (byte) -1 };
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray33, floatArray35);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray31, floatArray33);
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray23, floatArray31);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray31, (float) 10, 100);
        float[] floatArray42 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray3, floatArray31);
        float[] floatArray43 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(floatArray31);
        int int46 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray31, (float) 'a', 0);
        int int48 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray31, (float) 'a');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper0 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        java.lang.String str2 = unicodeUnescaper0.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper3 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        java.lang.String str5 = unicodeUnescaper3.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray6 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper0, unicodeUnescaper3 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper8 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        java.lang.String str10 = unicodeUnescaper8.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        try {
            org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray11 = org.apache.commons.lang3.ArrayUtils.add(unicodeUnescaperArray6, (int) (short) -1, unicodeUnescaper8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str5.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
        org.junit.Assert.assertNotNull(unicodeUnescaperArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str10.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.lang.Double[] doubleArray0 = null;
        java.lang.Double[] doubleArray1 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.clone(shortArray7);
        try {
            short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.remove(shortArray7, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        boolean[] booleanArray5 = new boolean[] { true, false, true, true, false };
        boolean[] booleanArray11 = new boolean[] { true, false, true, true, false };
        boolean[] booleanArray17 = new boolean[] { true, false, true, true, false };
        boolean[] booleanArray23 = new boolean[] { true, false, true, true, false };
        boolean[][] booleanArray24 = new boolean[][] { booleanArray5, booleanArray11, booleanArray17, booleanArray23 };
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray24);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("0a97a100a10", 95);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                    0a97a100a10" + "'", str2.equals("                                                                                    0a97a100a10"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.lang.Character[] charArray8 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray8, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", charArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "aa4aaa a4a#" + "'", str14.equals("aa4aaa a4a#"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("0a97a100a10", "{0,97,100,10}                   ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a97a100a10" + "'", str3.equals("0a97a100a10"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        long[] longArray0 = null;
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        try {
            long[] longArray2 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        short[] shortArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray0, (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.lang3.text.translate.OctalUnescaper octalUnescaper0 = new org.apache.commons.lang3.text.translate.OctalUnescaper();
        java.io.Writer writer3 = null;
        int int4 = octalUnescaper0.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 6, writer3);
        java.lang.CharSequence charSequence5 = null;
        java.io.Writer writer7 = null;
        try {
            int int8 = octalUnescaper0.translate(charSequence5, 10, writer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "!", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "0 97 100 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                                                                    ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "{0,97,100,10}                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeCsv("         !");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "         !" + "'", str1.equals("         !"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.lang.Boolean[] booleanArray3 = new java.lang.Boolean[] { true, false, false };
        boolean[] booleanArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray3, true);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray5);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aa4aaa a4a#", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0" + "'", str1.equals("1.0"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray14 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray19 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[][] byteArray20 = new byte[][] { byteArray4, byteArray9, byteArray14, byteArray19 };
        byte[] byteArray27 = new byte[] { (byte) -1, (byte) 1, (byte) -1, (byte) 0, (byte) 10, (byte) 10 };
        byte[][] byteArray28 = new byte[][] { byteArray27 };
        byte[][] byteArray29 = org.apache.commons.lang3.ArrayUtils.removeElements(byteArray20, byteArray28);
        java.lang.Byte[] byteArray35 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray35);
        byte[] byteArray37 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray35);
        byte[] byteArray39 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray35, (byte) 100);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) byteArray20, (java.lang.Object[]) byteArray35);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray8, false, (int) (short) 0);
        boolean[] booleanArray19 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.add(booleanArray19, true);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray21);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray21, false, (int) (short) 0);
        boolean[] booleanArray26 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray21);
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray8, true, (int) ' ');
        boolean[] booleanArray30 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray30);
        boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray30);
        int int35 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray8, true, (int) (short) 100);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(booleanArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.lang3.text.translate.OctalUnescaper octalUnescaper0 = new org.apache.commons.lang3.text.translate.OctalUnescaper();
        java.io.Writer writer3 = null;
        int int4 = octalUnescaper0.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 6, writer3);
        java.io.Writer writer7 = null;
        try {
            int int8 = octalUnescaper0.translate((java.lang.CharSequence) "                                                                                    0a97a100a10", (int) 'a', writer7);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 97");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", '4');
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("23", strArray4, strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "23" + "'", str6.equals("23"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.0 -1.0 1.0 -1.0 1.0 1.0", "!", (int) (short) 100);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a', (int) '#', (int) (short) 10);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "1.0");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray5, strArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0", (java.lang.CharSequence[]) strArray12);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1.0 -1.0 1.0 -1.0 1.0 1.0", (java.lang.CharSequence) "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "", (java.lang.CharSequence) "1a-1a-1", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        java.lang.Byte[] byteArray10 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray10);
        byte[] byteArray14 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.remove(byteArray14, 0);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray11, byteArray14);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.add(byteArray14, (byte) 1);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray19, (int) (short) 1, (int) '4');
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray4, byteArray22);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray22);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.lang.Object[] objArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(objArray0, (java.lang.Object) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.clone(longArray18);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(longArray18, ' ');
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray18);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0 97 100 10" + "'", str21.equals("0 97 100 10"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("aa4aaa a4a#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa4aaa a4a#" + "'", str1.equals("aa4aaa a4a#"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray22);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray18, floatArray22);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(floatArray22);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.0 -1.0 1.0 -1.0 1.0 1.0", "-1.0 -1.0 1.0 -1.0 1.0 1.0", 1);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) (byte) 10, (java.lang.Object) 1);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("0 97 100 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 97 100 10" + "'", str1.equals("0 97 100 10"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                    0a97a100a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                    0A97A100A10" + "'", str1.equals("                                                                                    0A97A100A10"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray0 = null;
        org.apache.commons.lang3.ArrayUtils arrayUtils1 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils2 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils3 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils4 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils5 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils6 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray7 = new org.apache.commons.lang3.ArrayUtils[] { arrayUtils1, arrayUtils2, arrayUtils3, arrayUtils4, arrayUtils5, arrayUtils6 };
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray8 = org.apache.commons.lang3.ArrayUtils.removeElements(arrayUtilsArray0, arrayUtilsArray7);
        org.junit.Assert.assertNotNull(arrayUtilsArray7);
        org.junit.Assert.assertNull(arrayUtilsArray8);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("aa4aaa a4a#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa4aaa a4a#" + "'", str1.equals("aa4aaa a4a#"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        java.lang.Integer[] intArray4 = new java.lang.Integer[] {};
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray5);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray3, intArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', (int) ' ', (-1));
        try {
            int[] intArray13 = org.apache.commons.lang3.ArrayUtils.remove(intArray6, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!", "-1a100a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("-1a100a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a100a1" + "'", str1.equals("-1a100a1"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1a-1a-1", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1a-1a-1" + "'", str3.equals("1a-1a-1"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.lang.Long[] longArray2 = new java.lang.Long[] { 1L, 100L };
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1 100" + "'", str5.equals("1 100"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "0 97 100 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "", (java.lang.CharSequence) "!", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "0 97 100 10", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0a97a100a10", 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a97a100a10                                                                                         " + "'", str3.equals("0a97a100a10                                                                                         "));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1a-1a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray7);
        java.lang.Double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) doubleArray9, "1.0", 95, (int) '4');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                                                                    0A97A100A10", "aa4aaa a4a#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        int[] intArray0 = null;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                    0A97A100A10", (int) ' ', "0a97a100a10                                                                                         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                    0A97A100A10" + "'", str3.equals("                                                                                    0A97A100A10"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("-1a100a1", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a1" + "'", str2.equals("a1"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1 100", (java.lang.CharSequence) "a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!", 1, 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10, 0);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        try {
            short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, 100, (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray8);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray3);
        try {
            float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.add(floatArray3, (int) '4', 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#####" + "'", str2.equals("#####"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "#####", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                    0a97a100a10", (java.lang.CharSequence) "0a97a100a10                                                                                         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                                                                    0A97A100A10", (int) '4', 95);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator0 = org.apache.commons.lang3.StringEscapeUtils.UNESCAPE_HTML3;
        org.junit.Assert.assertNotNull(charSequenceTranslator0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        java.lang.Byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.0", (java.lang.CharSequence) "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        java.lang.Integer[] intArray4 = new java.lang.Integer[] {};
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray5);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray3, intArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray6, 5, 2);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("23", "a1", "#####");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "23" + "'", str3.equals("23"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        char[] charArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(charArray0, 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("-1.0 -1.0 1.0 -1.0 1.0 1.0", "h-1.0 -1.0 1.0 -1.0 1.0 1.0h", "1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str3.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "{-1,3,100,10,3,2}", (java.lang.CharSequence) "                                                                                    0a97a100a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        byte[] byteArray0 = null;
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray0, 24, (int) (byte) 100);
        org.junit.Assert.assertNull(byteArray3);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) doubleArray0, "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (short) 100, 2);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        boolean[] booleanArray0 = null;
        boolean[] booleanArray7 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.add(booleanArray7, true);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray9);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray9, false, (int) (short) 0);
        boolean[] booleanArray20 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray22 = org.apache.commons.lang3.ArrayUtils.add(booleanArray20, true);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray22);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray22, false, (int) (short) 0);
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray9, booleanArray22);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray0, booleanArray27);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        char[] charArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(charArray0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("{0,97,100,10}                   ", "         !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0,97,100,10}                   " + "'", str2.equals("{0,97,100,10}                   "));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("-1.0 -1.0 1.0 -1.0 1.0 1.0", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str2.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1 100", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("-1a100a1", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-" + "'", str2.equals("-"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("0a97a100a10", "-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeXml("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + "'", str1.equals("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("!", 2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.subarray(longArray3, 100, (int) (byte) 100);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray21, (long) 24);
        long[] longArray24 = null;
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray21, longArray24);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.contains(longArray24, (long) 0);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0a97a100a10", 26);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("974100410410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "974100410410" + "'", str1.equals("974100410410"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        byte[] byteArray0 = null;
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray0, 24, 0);
        org.junit.Assert.assertNull(byteArray3);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    " + "'", str1.equals("                                                                                                    "));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray21 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray23 = new float[] { 'a' };
        float[] floatArray25 = new float[] { (byte) -1 };
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray23, floatArray25);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray21, floatArray23);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.join(floatArray21, '4', (int) '#', (int) (byte) 1);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray6, floatArray21);
        java.lang.Integer[] intArray33 = new java.lang.Integer[] {};
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray33);
        int[] intArray35 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray34);
        int[] intArray40 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean42 = org.apache.commons.lang3.ArrayUtils.contains(intArray40, (int) (byte) 0);
        int[] intArray43 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray40);
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray35, intArray43);
        int int46 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray43, 2);
        int[] intArray47 = org.apache.commons.lang3.ArrayUtils.clone(intArray43);
        try {
            float[] floatArray48 = org.apache.commons.lang3.ArrayUtils.removeAll(floatArray32, intArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(intArray47);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "{0,97,100,10}                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "0a97a100a10                                                                                         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        long[] longArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray0, (long) 0);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper2 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between((int) (byte) -1, (int) (short) 0);
        org.junit.Assert.assertNotNull(unicodeEscaper2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.lang3.ArrayUtils arrayUtils0 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils1 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils2 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils3 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray4 = new org.apache.commons.lang3.ArrayUtils[] { arrayUtils0, arrayUtils1, arrayUtils2, arrayUtils3 };
        org.apache.commons.lang3.ArrayUtils arrayUtils5 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils6 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils7 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils8 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray9 = new org.apache.commons.lang3.ArrayUtils[] { arrayUtils5, arrayUtils6, arrayUtils7, arrayUtils8 };
        org.apache.commons.lang3.ArrayUtils[][] arrayUtilsArray10 = new org.apache.commons.lang3.ArrayUtils[][] { arrayUtilsArray4, arrayUtilsArray9 };
        int[] intArray11 = null;
        try {
            org.apache.commons.lang3.ArrayUtils[][] arrayUtilsArray12 = org.apache.commons.lang3.ArrayUtils.removeAll(arrayUtilsArray10, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrayUtilsArray4);
        org.junit.Assert.assertNotNull(arrayUtilsArray9);
        org.junit.Assert.assertNotNull(arrayUtilsArray10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        boolean[] booleanArray4 = new boolean[] { true, true, true, false };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray4, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray4, (int) ' ', 6);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray9, 4, (int) (byte) 0);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray12);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.0", "-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0" + "'", str2.equals("1.0"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "  23  ", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "!", (java.lang.CharSequence) "hi!", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + "'", str1.equals("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10" + "'", str1.equals("10"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        byte[] byteArray0 = null;
        java.lang.Byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray0);
        org.junit.Assert.assertNull(byteArray1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', 1, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                    ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeXml("{-1,3,100,10,3,2}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{-1,3,100,10,3,2}" + "'", str1.equals("{-1,3,100,10,3,2}"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, 1.0d, 10.0d);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray17 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray18);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, (double) 2, (int) '#', (double) (short) 10);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray0, doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double[] doubleArray2 = new double[] { 100.0f, (short) 1 };
        java.lang.Integer[] intArray3 = new java.lang.Integer[] {};
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        int[] intArray10 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.contains(intArray10, (int) (byte) 0);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray13);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray13, 2);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray13);
        try {
            double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.removeAll(doubleArray2, intArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray8);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray8, (long) (byte) 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray8);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("{0,97,100,10}                   ", "                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0,97,100,10}                   " + "'", str2.equals("{0,97,100,10}                   "));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.lang.Long[] longArray0 = new java.lang.Long[] {};
        long[] longArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray0);
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray0, (long) ' ');
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray3);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "", (java.lang.CharSequence) "0 97 100 10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("h-1.0 -1.0 1.0 -1.0 1.0 1.0h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h-1.0-1.01.0-1.01.01.0h" + "'", str1.equals("h-1.0-1.01.0-1.01.01.0h"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.lang.Object obj0 = null;
        java.lang.Object obj1 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isEquals(obj0, obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("0 97 100 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 97 100 1" + "'", str1.equals("0 97 100 1"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                                                                    0A97A100A10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "0a97a100a10");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray8, false, (int) (short) 0);
        boolean[] booleanArray19 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.add(booleanArray19, true);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray21);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray21, false, (int) (short) 0);
        boolean[] booleanArray26 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray21);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray26);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(booleanArray26);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("-", 10, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("974100410410", "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "974100410410" + "'", str2.equals("974100410410"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.lang.CharSequence[] charSequenceArray0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        try {
            double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray6, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "-1a100a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.lang3.text.translate.OctalUnescaper octalUnescaper0 = new org.apache.commons.lang3.text.translate.OctalUnescaper();
        org.apache.commons.lang3.text.translate.OctalUnescaper octalUnescaper1 = new org.apache.commons.lang3.text.translate.OctalUnescaper();
        org.apache.commons.lang3.text.translate.OctalUnescaper octalUnescaper2 = new org.apache.commons.lang3.text.translate.OctalUnescaper();
        org.apache.commons.lang3.text.translate.OctalUnescaper octalUnescaper3 = new org.apache.commons.lang3.text.translate.OctalUnescaper();
        java.io.Writer writer6 = null;
        int int7 = octalUnescaper3.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 6, writer6);
        org.apache.commons.lang3.text.translate.OctalUnescaper[] octalUnescaperArray8 = new org.apache.commons.lang3.text.translate.OctalUnescaper[] { octalUnescaper0, octalUnescaper1, octalUnescaper2, octalUnescaper3 };
        try {
            org.apache.commons.lang3.text.translate.OctalUnescaper[] octalUnescaperArray10 = org.apache.commons.lang3.ArrayUtils.remove(octalUnescaperArray8, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(octalUnescaperArray8);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.lang.Float[] floatArray0 = null;
        float[] floatArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0);
        org.junit.Assert.assertNull(floatArray1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray22);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray18, floatArray22);
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.add(floatArray18, (float) 0);
        float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, 26, 1);
        float[] floatArray46 = new float[] { 'a' };
        float[] floatArray48 = new float[] { (byte) -1 };
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray46, floatArray48);
        float[] floatArray56 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray58 = new float[] { 'a' };
        float[] floatArray60 = new float[] { (byte) -1 };
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray58, floatArray60);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray56, floatArray58);
        float[] floatArray63 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray48, floatArray56);
        float[] floatArray66 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray56, 26, (int) '4');
        float[] floatArray67 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray44, floatArray56);
        java.lang.String str69 = org.apache.commons.lang3.StringUtils.join(floatArray44, '4');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "" + "'", str69.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("h-1.0 -1.0 1.0 -1.0 1.0 1.0h", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap3 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) strArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, 'hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray4);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.remove(intArray4, 2);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) ' ', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-", "                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-" + "'", str2.equals("-"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        long[] longArray0 = null;
        long[] longArray1 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray0);
        org.junit.Assert.assertNotNull(longArray1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.lang.String str1 = org.apache.commons.lang3.text.translate.CharSequenceTranslator.hex(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A" + "'", str1.equals("A"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                    0a97a100a10", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.lang.String str1 = org.apache.commons.lang3.text.translate.CharSequenceTranslator.hex((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "34" + "'", str1.equals("34"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("-", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-" + "'", str2.equals("-"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        short[] shortArray0 = null;
        short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.clone(shortArray0);
        org.junit.Assert.assertNull(shortArray1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, (long) 100);
        java.lang.Integer[] intArray11 = new java.lang.Integer[] {};
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray11);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray12);
        int[] intArray18 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.contains(intArray18, (int) (byte) 0);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray18);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray13, intArray21);
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray21, 2);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.clone(intArray21);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray21);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.clone(intArray26);
        try {
            long[] longArray28 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray7, intArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10", "10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1 100" + "'", str1.equals("1 100"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        int[] intArray2 = new int[] { 1, (byte) -1 };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray22);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray18, floatArray22);
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.add(floatArray18, (float) 0);
        float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, 26, 1);
        float[] floatArray46 = new float[] { 'a' };
        float[] floatArray48 = new float[] { (byte) -1 };
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray46, floatArray48);
        float[] floatArray56 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray58 = new float[] { 'a' };
        float[] floatArray60 = new float[] { (byte) -1 };
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray58, floatArray60);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray56, floatArray58);
        float[] floatArray63 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray48, floatArray56);
        float[] floatArray66 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray56, 26, (int) '4');
        float[] floatArray67 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray44, floatArray56);
        int[] intArray72 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean74 = org.apache.commons.lang3.ArrayUtils.contains(intArray72, (int) (byte) 0);
        try {
            float[] floatArray75 = org.apache.commons.lang3.ArrayUtils.removeAll(floatArray56, intArray72);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(shortArray0, (short) 0);
        try {
            short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.add(shortArray0, (int) (byte) -1, (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("hi!", 95);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!                                                                                            " + "'", str2.equals("hi!                                                                                            "));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray2 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper0, unicodeEscaper1 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator3 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray2);
        java.lang.CharSequence charSequence4 = null;
        java.lang.String str5 = aggregateTranslator3.translate(charSequence4);
        java.io.Writer writer8 = null;
        try {
            int int9 = aggregateTranslator3.translate((java.lang.CharSequence) "                                                    ", (int) '#', writer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray2);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeXml("                                                                                    0a97a100a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                    0a97a100a10" + "'", str1.equals("                                                                                    0a97a100a10"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0 97 100 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0971001" + "'", str1.equals("0971001"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray0 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper1 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray0);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper2 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray0);
        java.io.Writer writer5 = null;
        try {
            int int6 = numericEntityUnescaper2.translate((java.lang.CharSequence) " ", (int) (short) 1, writer5);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(oPTIONArray0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("h-1.0-1.01.0-1.01.01.0h", "", "0971001");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.APOS_ESCAPE();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray22);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray18, floatArray22);
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.add(floatArray18, (float) 0);
        float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, 26, 1);
        float[] floatArray46 = new float[] { 'a' };
        float[] floatArray48 = new float[] { (byte) -1 };
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray46, floatArray48);
        float[] floatArray56 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray58 = new float[] { 'a' };
        float[] floatArray60 = new float[] { (byte) -1 };
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray58, floatArray60);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray56, floatArray58);
        float[] floatArray63 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray48, floatArray56);
        float[] floatArray66 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray56, 26, (int) '4');
        float[] floatArray67 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray44, floatArray56);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray44);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray67);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray22);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray18, floatArray22);
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.add(floatArray18, (float) 0);
        float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, 26, 1);
        float[] floatArray46 = new float[] { 'a' };
        float[] floatArray48 = new float[] { (byte) -1 };
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray46, floatArray48);
        float[] floatArray56 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray58 = new float[] { 'a' };
        float[] floatArray60 = new float[] { (byte) -1 };
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray58, floatArray60);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray56, floatArray58);
        float[] floatArray63 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray48, floatArray56);
        float[] floatArray66 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray56, 26, (int) '4');
        float[] floatArray67 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray44, floatArray56);
        float[] floatArray69 = org.apache.commons.lang3.ArrayUtils.add(floatArray67, (float) 'a');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray69);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        long[] longArray22 = new long[] { (short) 0, 'a', 100 };
        long[] longArray24 = new long[] { (short) 10 };
        long[] longArray25 = new long[] {};
        long[] longArray26 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray24, longArray25);
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.addAll(longArray22, longArray26);
        long[] longArray28 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray27);
        long[] longArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray27, (long) (byte) 0);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.join(longArray27, 'a');
        long[] longArray33 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray16, longArray27);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertNotNull(longArray26);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0a97a100a10" + "'", str32.equals("0a97a100a10"));
        org.junit.Assert.assertNotNull(longArray33);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "         !");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.remove(byteArray4, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray1, byteArray6);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(byteArray6);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                                                    0a97a100a10");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        long[] longArray1 = new long[] { (short) 10 };
        org.apache.commons.lang3.ArrayUtils.reverse(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "974100410410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION0 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.semiColonOptional;
        org.junit.Assert.assertTrue("'" + oPTION0 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.semiColonOptional + "'", oPTION0.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.semiColonOptional));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = org.apache.commons.lang3.text.translate.UnicodeEscaper.below((int) 'a');
        java.io.Writer writer3 = null;
        try {
            boolean boolean4 = unicodeEscaper1.translate(5, writer3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unicodeEscaper1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.lang.Boolean[] booleanArray0 = new java.lang.Boolean[] {};
        java.lang.Boolean[] booleanArray1 = new java.lang.Boolean[] {};
        java.lang.Boolean[] booleanArray2 = new java.lang.Boolean[] {};
        java.lang.Boolean[][] booleanArray3 = new java.lang.Boolean[][] { booleanArray0, booleanArray1, booleanArray2 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '#', 0, 2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "", "#####");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####h#####i#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####" + "'", str3.equals("#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####h#####i#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1 100" + "'", str1.equals("1 100"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("{0,97,100,10}                   ", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0,97,100,10}                   " + "'", str2.equals("{0,97,100,10}                   "));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray10, '4');
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "974100410410" + "'", str13.equals("974100410410"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        java.lang.Integer[] intArray10 = new java.lang.Integer[] { (-1), 3, 100, 10, 3, 2 };
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray10, (int) '4');
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray12, 2, 0);
        try {
            long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray2, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeHtml4("aa4aaa a4a#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa4aaa a4a#" + "'", str1.equals("aa4aaa a4a#"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper2 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between((-1), (int) ' ');
        org.junit.Assert.assertNotNull(unicodeEscaper2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.String[] strArray5 = new java.lang.String[] { "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", " ", "1 100", " ", "hi!" };
        java.lang.String[] strArray11 = new java.lang.String[] { "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", " ", "1 100", " ", "hi!" };
        java.lang.String[][] strArray12 = new java.lang.String[][] { strArray5, strArray11 };
        java.lang.String[][] strArray13 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray12);
        java.lang.Object[] objArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty((java.lang.Object[]) strArray13);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) strArray3, (java.lang.Object) 1L, (int) (byte) -1);
        java.lang.Object[] objArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty((java.lang.Object[]) strArray3);
        try {
            java.lang.Comparable<java.lang.String>[] strComparableArray10 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray3, 1, (java.lang.Comparable<java.lang.String>) "                                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml4("                                                                                    0A97A100A10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                    0A97A100A10" + "'", str1.equals("                                                                                    0A97A100A10"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1a-1a-1", (java.lang.CharSequence) "0a97a100a10                                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                    0A97A100A10", "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####h#####i#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        boolean[] booleanArray4 = new boolean[] { true, true, true, false };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray4, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray4, (int) ' ', 6);
        int[] intArray14 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(intArray14, (int) (byte) 0);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray14);
        java.lang.Integer[] intArray18 = new java.lang.Integer[] {};
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray18);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray19);
        int[] intArray25 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.contains(intArray25, (int) (byte) 0);
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray25);
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray20, intArray28);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray14, intArray20);
        int[] intArray32 = org.apache.commons.lang3.ArrayUtils.add(intArray14, 0);
        try {
            boolean[] booleanArray33 = org.apache.commons.lang3.ArrayUtils.removeAll(booleanArray9, intArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("h-1.0-1.01.0-1.01.01.0h", "0971001", "974100410410", 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "h-1.0-1.01.0-1.01.01.0h" + "'", str4.equals("h-1.0-1.01.0-1.01.01.0h"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence) "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("  23  ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        float[] floatArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray0, 0.0f, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeEcmaScript("h-1.0 -1.0 1.0 -1.0 1.0 1.0h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h-1.0 -1.0 1.0 -1.0 1.0 1.0h" + "'", str1.equals("h-1.0 -1.0 1.0 -1.0 1.0 1.0h"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        byte[] byteArray0 = null;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("!", "#####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        char[] charArray1 = new char[] { '#' };
        char[] charArray3 = org.apache.commons.lang3.ArrayUtils.add(charArray1, '#');
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray3);
        int[] intArray5 = null;
        try {
            char[] charArray6 = org.apache.commons.lang3.ArrayUtils.removeAll(charArray4, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.clone(longArray18);
        long[] longArray20 = null;
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.addAll(longArray19, longArray20);
        java.lang.String str23 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) longArray19, "h-1.0 -1.0 1.0 -1.0 1.0 1.0h");
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray19);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{0,97,100,10}" + "'", str23.equals("{0,97,100,10}"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 26);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(doubleArray0);
        try {
            double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        int[] intArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(intArray0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 0);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray7, 0.0d);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray14, (int) (short) 1, (int) '4');
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray14, (byte) 100);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(byteArray14, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double[] doubleArray1 = new double[] { 0.0d };
        double[] doubleArray3 = new double[] { 0.0d };
        double[] doubleArray5 = new double[] { 0.0d };
        double[] doubleArray7 = new double[] { 0.0d };
        double[] doubleArray9 = new double[] { 0.0d };
        double[][] doubleArray10 = new double[][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        double[] doubleArray17 = new double[] { (short) 100, (-1L), 2, 10, (byte) 0, 1L };
        double[] doubleArray24 = new double[] { (short) 100, (-1L), 2, 10, (byte) 0, 1L };
        double[][] doubleArray25 = new double[][] { doubleArray17, doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.lang3.ArrayUtils.removeElements(doubleArray10, doubleArray25);
        java.lang.String str28 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) doubleArray10, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{{0.0},{0.0},{0.0},{0.0},{0.0}}" + "'", str28.equals("{{0.0},{0.0},{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.lang3.text.translate.OctalUnescaper octalUnescaper0 = new org.apache.commons.lang3.text.translate.OctalUnescaper();
        java.io.Writer writer3 = null;
        int int4 = octalUnescaper0.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 6, writer3);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper5 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper6 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper7 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper8 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper9 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper10 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray11 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper5, unicodeUnescaper6, unicodeUnescaper7, unicodeUnescaper8, unicodeUnescaper9, unicodeUnescaper10 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray12 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray11);
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator13 = octalUnescaper0.with((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray12);
        java.io.Writer writer16 = null;
        try {
            int int17 = octalUnescaper0.translate((java.lang.CharSequence) " ", (int) ' ', writer16);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 32");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray11);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray12);
        org.junit.Assert.assertNotNull(charSequenceTranslator13);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        short[] shortArray0 = null;
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray0, 3, (int) (short) 1);
        org.junit.Assert.assertNull(shortArray3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '#', 5, 3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1a100a1", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString(" ", "-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray8 = new java.lang.reflect.AnnotatedElement[] { wildcardClass3, wildcardClass7 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(annotatedElementArray8);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(annotatedElementArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                    0A97A100A10", (-1), "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                    0A97A100A10" + "'", str3.equals("                                                                                    0A97A100A10"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray0 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper1 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray0);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray2 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper3 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray2);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION4 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        boolean boolean5 = numericEntityUnescaper3.isSet(oPTION4);
        boolean boolean6 = numericEntityUnescaper1.isSet(oPTION4);
        java.io.Writer writer8 = null;
        try {
            numericEntityUnescaper1.translate((java.lang.CharSequence) "  23  ", writer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Writer must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(oPTIONArray0);
        org.junit.Assert.assertNotNull(oPTIONArray2);
        org.junit.Assert.assertTrue("'" + oPTION4 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION4.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeEcmaScript("-1.0 -1.0 1.0 -1.0 1.0 1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str1.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#####", "10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 26, "-1a100a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                                                    ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        boolean[] booleanArray4 = new boolean[] { true, true, true, false };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray4, false);
        boolean[] booleanArray13 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.add(booleanArray13, true);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray4, booleanArray15);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray4);
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.add(booleanArray18, 1, true);
        boolean[] booleanArray22 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray22);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.lang.Long[] longArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_OBJECT_ARRAY;
        java.lang.Object[] objArray1 = org.apache.commons.lang3.ArrayUtils.nullToEmpty((java.lang.Object[]) longArray0);
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray0, (long) '4');
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(longArray3);
    }
}

