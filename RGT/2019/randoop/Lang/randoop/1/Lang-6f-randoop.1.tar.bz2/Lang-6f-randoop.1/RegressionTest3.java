import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) 2, (int) '#', (double) (short) 10);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray7);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) 10);
        java.lang.Byte[] byteArray19 = new java.lang.Byte[] { (byte) 1, (byte) 10, (byte) -1 };
        java.lang.Byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray19);
        java.lang.Byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray20);
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray20, (byte) 0);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) (byte) 10, (java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 2);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.clone(intArray10);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.clone(intArray15);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.remove(intArray15, 1);
        java.lang.Integer[] intArray19 = new java.lang.Integer[] {};
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray19);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray20);
        int[] intArray26 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.contains(intArray26, (int) (byte) 0);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray26);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray21, intArray29);
        int int32 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray29, 2);
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.clone(intArray29);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray29);
        int[] intArray35 = org.apache.commons.lang3.ArrayUtils.clone(intArray34);
        int[] intArray37 = org.apache.commons.lang3.ArrayUtils.remove(intArray34, 1);
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray18, intArray37);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        double[] doubleArray0 = null;
        int int4 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (short) 1, 26, (-1.0d));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("#####", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#####" + "'", str2.equals("#####"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                    0a97a100a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a97a100a10" + "'", str1.equals("0a97a100a10"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (short) 10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        java.lang.Integer[] intArray8 = new java.lang.Integer[] {};
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray8);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray9);
        int[] intArray15 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(intArray15, (int) (byte) 0);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray15);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray10, intArray18);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray4, intArray10);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 0);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(intArray22);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D", 0, "hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D" + "'", str3.equals("\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = org.apache.commons.lang3.text.translate.UnicodeEscaper.below((int) '#');
        org.junit.Assert.assertNotNull(unicodeEscaper1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10, 0);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray9, '4');
        short[] shortArray15 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray16 = org.apache.commons.lang3.ArrayUtils.clone(shortArray15);
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray15, (short) 0);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(shortArray18, 'a', 95, 1);
        short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.removeElements(shortArray9, shortArray18);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray18);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray4, (short) (byte) 100);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.clone(shortArray7);
        short[] shortArray12 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.clone(shortArray12);
        short[] shortArray17 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.clone(shortArray17);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray18, (short) 10);
        short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray12, shortArray18);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray21, (short) 10);
        short[] shortArray27 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray28 = org.apache.commons.lang3.ArrayUtils.clone(shortArray27);
        short[] shortArray32 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray33 = org.apache.commons.lang3.ArrayUtils.clone(shortArray32);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray33, (short) 10);
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray27, shortArray33);
        short[] shortArray39 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray27, 0, 95);
        short[] shortArray41 = org.apache.commons.lang3.ArrayUtils.add(shortArray39, (short) (byte) 100);
        short[] shortArray42 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray21, shortArray39);
        short[] shortArray43 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray7, shortArray39);
        short[] shortArray46 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray7, (int) (short) 10, 31);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(shortArray27);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertNotNull(shortArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertNotNull(shortArray41);
        org.junit.Assert.assertNotNull(shortArray42);
        org.junit.Assert.assertNotNull(shortArray43);
        org.junit.Assert.assertNotNull(shortArray46);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray8);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray8, (long) (byte) 0);
        long[] longArray12 = null;
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.addAll(longArray8, longArray12);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray8, 0L);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper2 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between((int) (short) 100, 95);
        java.io.Writer writer4 = null;
        boolean boolean5 = unicodeEscaper2.translate(2, writer4);
        java.io.Writer writer7 = null;
        boolean boolean8 = unicodeEscaper2.translate(2, writer7);
        org.junit.Assert.assertNotNull(unicodeEscaper2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D", "{{0.0},{0.0},{0.0},{0.0},{0.0}}");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D" + "'", str2.equals("\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        boolean[] booleanArray4 = new boolean[] { true, true, true, false };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray4, false);
        java.lang.Class<?> wildcardClass7 = booleanArray4.getClass();
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray4, false);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray4, 95, (int) (byte) 10);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray12);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray1 = new boolean[] {};
        boolean[] booleanArray2 = new boolean[] {};
        boolean[][] booleanArray3 = new boolean[][] { booleanArray0, booleanArray1, booleanArray2 };
        boolean[][][] booleanArray4 = new boolean[][][] { booleanArray3 };
        boolean[][][] booleanArray7 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray4, (int) '4', 90);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray7);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        long[] longArray0 = null;
        long[] longArray2 = new long[] { (short) 10 };
        long[] longArray3 = new long[] {};
        long[] longArray4 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray2, longArray3);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray4);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray4, (long) '4');
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray4, (long) (short) 0, 26);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray4);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray0, longArray4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray0);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 99, "0 97 100 1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 97 100 10 97 100 10 97 100 10 97 100 10 97 100 10 97 100 10 97 100 10 97 100 10 97 100 10 97 100 " + "'", str3.equals("0 97 100 10 97 100 10 97 100 10 97 100 10 97 100 10 97 100 10 97 100 10 97 100 10 97 100 10 97 100 "));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        float[] floatArray1 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray1, (float) 'a', (int) (byte) -1);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray1, (float) 2);
        float[] floatArray7 = null;
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray1, floatArray7);
        float[] floatArray10 = new float[] { 'a' };
        float[] floatArray12 = new float[] { (byte) -1 };
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray10, floatArray12);
        float[] floatArray20 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray22 = new float[] { 'a' };
        float[] floatArray24 = new float[] { (byte) -1 };
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray22, floatArray24);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray12, floatArray20);
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray20, 26, (int) '4');
        float[] floatArray31 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray1, floatArray20);
        java.lang.Float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) booleanArray0, (java.lang.Object) floatArray32);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#####", (int) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        byte[] byteArray0 = null;
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        byte[] byteArray10 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.remove(byteArray10, 0);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray7, byteArray10);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.add(byteArray10, (byte) 1);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray15, (int) (short) 1, (int) '4');
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray15, (byte) 1);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray15, (byte) 10);
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray15, (byte) 1);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray0, byteArray24);
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray0);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(byteArray26);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_ESCAPE();
        java.lang.Object[][] objArray1 = org.apache.commons.lang3.ArrayUtils.toArray((java.lang.Object[][]) strArray0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) objArray1, "23", (int) (short) 100, (-1));
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 2);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.add(intArray10, (int) (short) 1);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray15, (int) (byte) 10, (int) (short) -1);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray11, 26, (int) '4');
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.clone(floatArray11);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "A");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        char[] charArray5 = new char[] { '#', '#', '#', ' ' };
        char[] charArray9 = new char[] { 'a', ' ', '#' };
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.addAll(charArray5, charArray9);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray10);
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.subarray(charArray12, 0, (int) ' ');
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                      0a97a100a10  ", charArray12);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray12);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        java.lang.Boolean[] booleanArray4 = new java.lang.Boolean[] { false, false, false, false };
        java.lang.Boolean[] booleanArray5 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray4);
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray4);
        java.lang.Boolean[] booleanArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####H#####I#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.APOS_UNESCAPE();
        java.io.Serializable[] serializableArray3 = org.apache.commons.lang3.ArrayUtils.subarray((java.io.Serializable[]) strArray0, (int) '4', 24);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.util.Map<java.lang.Object, java.lang.Object> objMap5 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) strArray0);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(serializableArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(objMap5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray0 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray1 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] { oPTIONArray0 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray2 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper3 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray2);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray4 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper5 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray4);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION6 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        boolean boolean7 = numericEntityUnescaper5.isSet(oPTION6);
        boolean boolean8 = numericEntityUnescaper3.isSet(oPTION6);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION9 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION10 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray11 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] { oPTION6, oPTION9, oPTION10 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray12 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] { oPTIONArray11 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray13 = org.apache.commons.lang3.ArrayUtils.removeElements(oPTIONArray1, oPTIONArray12);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray14 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray15 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] { oPTIONArray14 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray16 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper17 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray16);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray18 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper19 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray18);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION20 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        boolean boolean21 = numericEntityUnescaper19.isSet(oPTION20);
        boolean boolean22 = numericEntityUnescaper17.isSet(oPTION20);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION23 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION24 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray25 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] { oPTION20, oPTION23, oPTION24 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray26 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] { oPTIONArray25 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray27 = org.apache.commons.lang3.ArrayUtils.removeElements(oPTIONArray15, oPTIONArray26);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray28 = org.apache.commons.lang3.ArrayUtils.removeElements(oPTIONArray13, oPTIONArray15);
        java.lang.Short[] shortArray32 = new java.lang.Short[] { (short) 100, (short) -1, (short) 1 };
        short[] shortArray34 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray32, (short) 1);
        java.lang.Short[] shortArray35 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray32);
        int int37 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) oPTIONArray15, (java.lang.Object) shortArray32, (int) ' ');
        int int40 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray32, (java.lang.Object) "0a9hi!0a97", (int) '4');
        org.junit.Assert.assertNotNull(oPTIONArray0);
        org.junit.Assert.assertNotNull(oPTIONArray1);
        org.junit.Assert.assertNotNull(oPTIONArray2);
        org.junit.Assert.assertNotNull(oPTIONArray4);
        org.junit.Assert.assertTrue("'" + oPTION6 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION6.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + oPTION9 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION9.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + oPTION10 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION10.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertNotNull(oPTIONArray11);
        org.junit.Assert.assertNotNull(oPTIONArray12);
        org.junit.Assert.assertNotNull(oPTIONArray13);
        org.junit.Assert.assertNotNull(oPTIONArray14);
        org.junit.Assert.assertNotNull(oPTIONArray15);
        org.junit.Assert.assertNotNull(oPTIONArray16);
        org.junit.Assert.assertNotNull(oPTIONArray18);
        org.junit.Assert.assertTrue("'" + oPTION20 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION20.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + oPTION23 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION23.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + oPTION24 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION24.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertNotNull(oPTIONArray25);
        org.junit.Assert.assertNotNull(oPTIONArray26);
        org.junit.Assert.assertNotNull(oPTIONArray27);
        org.junit.Assert.assertNotNull(oPTIONArray28);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("{-1,3,100,10,3,2", "{1,-1,-1}");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1,-1,-1}" + "'", str2.equals("1,-1,-1}"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "-", (java.lang.CharSequence) "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("{0,97,100,10}                   ", "974100410410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0,97,100,10}                   " + "'", str2.equals("{0,97,100,10}                   "));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.subarray(longArray3, 100, (int) (byte) 100);
        long[] longArray22 = org.apache.commons.lang3.ArrayUtils.clone(longArray21);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertNotNull(longArray22);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.contains(floatArray18, 100.0f);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray18);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray18, (float) 0L);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray3);
        float[] floatArray21 = new float[] { 'a' };
        float[] floatArray23 = new float[] { (byte) -1 };
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray21, floatArray23);
        float[] floatArray31 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray33 = new float[] { 'a' };
        float[] floatArray35 = new float[] { (byte) -1 };
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray33, floatArray35);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray31, floatArray33);
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray23, floatArray31);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray31, (float) 10, 100);
        float[] floatArray42 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray3, floatArray31);
        int int45 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray3, (float) (byte) 0, (int) (byte) -1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                                    0A97A100A10", (java.lang.CharSequence) "10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeCsv("09710010");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "09710010" + "'", str1.equals("09710010"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("974100410410", "                                                                                    0a97a100a10", (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "974100410410" + "'", str3.equals("974100410410"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        boolean[] booleanArray4 = new boolean[] { true, true, true, false };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray4, false);
        boolean[] booleanArray13 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.add(booleanArray13, true);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray4, booleanArray15);
        boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.add(booleanArray4, true);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(booleanArray19);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 2);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray10);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray10);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("{-1,3,100,10,3,2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{-1,3,100,10,3,2" + "'", str1.equals("{-1,3,100,10,3,2"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.clone(longArray18);
        long[] longArray20 = null;
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.addAll(longArray19, longArray20);
        java.lang.String str23 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) longArray19, "h-1.0 -1.0 1.0 -1.0 1.0 1.0h");
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray19);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray19, (long) 0);
        long[] longArray30 = new long[] { (short) 0, 'a', 100 };
        long[] longArray32 = new long[] { (short) 10 };
        long[] longArray33 = new long[] {};
        long[] longArray34 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray32, longArray33);
        long[] longArray35 = org.apache.commons.lang3.ArrayUtils.addAll(longArray30, longArray34);
        long[] longArray39 = new long[] { (short) 0, 'a', 100 };
        long[] longArray41 = new long[] { (short) 10 };
        long[] longArray42 = new long[] {};
        long[] longArray43 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray41, longArray42);
        long[] longArray44 = org.apache.commons.lang3.ArrayUtils.addAll(longArray39, longArray43);
        long[] longArray45 = org.apache.commons.lang3.ArrayUtils.addAll(longArray30, longArray43);
        long[] longArray48 = org.apache.commons.lang3.ArrayUtils.subarray(longArray30, 100, (int) (byte) 100);
        long[] longArray51 = org.apache.commons.lang3.ArrayUtils.subarray(longArray30, (int) 'a', (int) '#');
        long[] longArray55 = new long[] { (short) 0, 'a', 100 };
        long[] longArray57 = new long[] { (short) 10 };
        long[] longArray58 = new long[] {};
        long[] longArray59 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray57, longArray58);
        long[] longArray60 = org.apache.commons.lang3.ArrayUtils.addAll(longArray55, longArray59);
        long[] longArray64 = new long[] { (short) 0, 'a', 100 };
        long[] longArray66 = new long[] { (short) 10 };
        long[] longArray67 = new long[] {};
        long[] longArray68 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray66, longArray67);
        long[] longArray69 = org.apache.commons.lang3.ArrayUtils.addAll(longArray64, longArray68);
        long[] longArray70 = org.apache.commons.lang3.ArrayUtils.addAll(longArray55, longArray68);
        long[] longArray73 = org.apache.commons.lang3.ArrayUtils.subarray(longArray55, 100, (int) (byte) 100);
        long[] longArray76 = org.apache.commons.lang3.ArrayUtils.subarray(longArray55, (int) 'a', (int) '#');
        long[] longArray77 = org.apache.commons.lang3.ArrayUtils.addAll(longArray51, longArray55);
        int int80 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray55, (long) 4, 6);
        long[] longArray81 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray19, longArray55);
        int int84 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray55, (long) (byte) 10, (int) (short) 0);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{0,97,100,10}" + "'", str23.equals("{0,97,100,10}"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertNotNull(longArray32);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertNotNull(longArray34);
        org.junit.Assert.assertNotNull(longArray35);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertNotNull(longArray41);
        org.junit.Assert.assertNotNull(longArray42);
        org.junit.Assert.assertNotNull(longArray43);
        org.junit.Assert.assertNotNull(longArray44);
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertNotNull(longArray48);
        org.junit.Assert.assertNotNull(longArray51);
        org.junit.Assert.assertNotNull(longArray55);
        org.junit.Assert.assertNotNull(longArray57);
        org.junit.Assert.assertNotNull(longArray58);
        org.junit.Assert.assertNotNull(longArray59);
        org.junit.Assert.assertNotNull(longArray60);
        org.junit.Assert.assertNotNull(longArray64);
        org.junit.Assert.assertNotNull(longArray66);
        org.junit.Assert.assertNotNull(longArray67);
        org.junit.Assert.assertNotNull(longArray68);
        org.junit.Assert.assertNotNull(longArray69);
        org.junit.Assert.assertNotNull(longArray70);
        org.junit.Assert.assertNotNull(longArray73);
        org.junit.Assert.assertNotNull(longArray76);
        org.junit.Assert.assertNotNull(longArray77);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertNotNull(longArray81);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml3("-1.0#-1.0#1.0#-1.0#1.0#1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#-1.0#1.0#-1.0#1.0#1.0" + "'", str1.equals("-1.0#-1.0#1.0#-1.0#1.0#1.0"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#a4a aaa4aa", (java.lang.CharSequence) "{1,-1,-1}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "#a4a aaa4aa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeCsv("{1.0}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{1.0}" + "'", str1.equals("{1.0}"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.clone(longArray18);
        java.lang.String str21 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) longArray19, "23");
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.contains(longArray19, (long) 24);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{0,97,100,10}" + "'", str21.equals("{0,97,100,10}"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 1, (byte) 1 };
        byte[][] byteArray4 = new byte[][] { byteArray3 };
        byte[] byteArray8 = new byte[] { (byte) 10, (byte) 1, (byte) 1 };
        byte[][] byteArray9 = new byte[][] { byteArray8 };
        byte[][][] byteArray10 = new byte[][][] { byteArray4, byteArray9 };
        byte[] byteArray15 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray20 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray25 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray30 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[][] byteArray31 = new byte[][] { byteArray15, byteArray20, byteArray25, byteArray30 };
        byte[] byteArray38 = new byte[] { (byte) -1, (byte) 1, (byte) -1, (byte) 0, (byte) 10, (byte) 10 };
        byte[][] byteArray39 = new byte[][] { byteArray38 };
        byte[][] byteArray40 = org.apache.commons.lang3.ArrayUtils.removeElements(byteArray31, byteArray39);
        byte[] byteArray44 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray46 = org.apache.commons.lang3.ArrayUtils.remove(byteArray44, 0);
        java.lang.String[][] strArray47 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_ESCAPE();
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) byteArray46, (java.lang.Object) strArray47);
        byte[][] byteArray49 = org.apache.commons.lang3.ArrayUtils.add(byteArray31, (int) (byte) 0, byteArray46);
        byte[][][] byteArray50 = org.apache.commons.lang3.ArrayUtils.add(byteArray10, byteArray31);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertNotNull(strArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(byteArray49);
        org.junit.Assert.assertNotNull(byteArray50);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray0, (int) (byte) 100, 1);
        boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean[] booleanArray7 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray4, (int) (byte) 100, 1);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray0, booleanArray7);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray7, true);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray8, false, (int) (short) 0);
        int[] intArray13 = null;
        try {
            boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.removeAll(booleanArray8, intArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        byte[] byteArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray0, (byte) 100, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray1, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 26);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray1);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray18);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray19);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray20, (double) 2, (int) (byte) -1, (double) 0.0f);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray25, doubleArray31);
        double[] doubleArray33 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray20, doubleArray31);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray31, (double) 2, 26);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray43 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray44 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray37, doubleArray43);
        int int47 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray44, (double) (byte) -1, (double) (byte) 1);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray44);
        double[] doubleArray49 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray31, doubleArray44);
        double[] doubleArray52 = org.apache.commons.lang3.ArrayUtils.add(doubleArray49, 10, (double) 'a');
        int int55 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray49, (double) 'a', 31);
        java.lang.Double[] doubleArray56 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray49);
        boolean boolean57 = org.apache.commons.lang3.ArrayUtils.isEmpty((java.lang.Object[]) doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        java.lang.Integer[] intArray3 = new java.lang.Integer[] {};
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        int[] intArray10 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.contains(intArray10, (int) (byte) 0);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray13);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray13, 2);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.clone(intArray13);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray13);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(intArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray19, (int) (short) 0);
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.add(intArray19, (-1));
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeAll(intArray2, intArray19);
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.subarray(intArray25, (-1), 3);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        java.lang.String[] strArray4 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray9 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray14 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray19 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[][] strArray20 = new java.lang.String[][] { strArray4, strArray9, strArray14, strArray19 };
        java.lang.String[][] strArray21 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray20);
        org.apache.commons.lang3.text.translate.LookupTranslator lookupTranslator22 = new org.apache.commons.lang3.text.translate.LookupTranslator((java.lang.CharSequence[][]) strArray21);
        java.io.Writer writer25 = null;
        int int26 = lookupTranslator22.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (int) (byte) 0, writer25);
        java.lang.CharSequence charSequence27 = null;
        java.io.Writer writer29 = null;
        try {
            int int30 = lookupTranslator22.translate(charSequence27, 6, writer29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper2 = org.apache.commons.lang3.text.translate.UnicodeEscaper.outsideOf(1, (int) '#');
        java.io.Writer writer5 = null;
        int int6 = unicodeEscaper2.translate((java.lang.CharSequence) "                     ...", (int) (byte) 0, writer5);
        org.junit.Assert.assertNotNull(unicodeEscaper2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        char[] charArray3 = new char[] { 'a', 'a', ' ' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.remove(charArray3, (int) (byte) 1);
        char[] charArray10 = new char[] { '#', '#', '#', ' ' };
        char[] charArray14 = new char[] { 'a', ' ', '#' };
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.addAll(charArray10, charArray14);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray3, charArray14);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray17, 'a');
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray19, ' ');
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray14, charArray19);
        java.lang.Character[] charArray23 = org.apache.commons.lang3.ArrayUtils.toObject(charArray22);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray23);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 100);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, 10, 3);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 0);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray9, (byte) 1, 24);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (short) 0);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, 3, (short) 10);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray9, (short) (byte) -1, (int) (short) 10);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray9);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(shortArray13);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                     ...", "-1a100a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     ..." + "'", str2.equals("                     ..."));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        int[] intArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(intArray0);
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (int) (short) 0);
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.add(intArray0, (-1));
        java.lang.Integer[] intArray6 = new java.lang.Integer[] {};
        java.lang.Integer[][] intArray7 = new java.lang.Integer[][] { intArray6 };
        java.lang.Integer[][] intArray8 = org.apache.commons.lang3.ArrayUtils.toArray(intArray7);
        int[] intArray13 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(intArray13, (int) (byte) 0);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray13);
        java.lang.Integer[] intArray17 = new java.lang.Integer[] {};
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray17);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray18);
        int[] intArray24 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.contains(intArray24, (int) (byte) 0);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray24);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray19, intArray27);
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray13, intArray19);
        java.lang.Integer[] intArray30 = org.apache.commons.lang3.ArrayUtils.toObject(intArray13);
        int int32 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) intArray8, (java.lang.Object) intArray13, 4);
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.clone(intArray13);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(intArray13);
        java.lang.Integer[] intArray35 = new java.lang.Integer[] {};
        int[] intArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray35);
        int[] intArray37 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray36);
        int[] intArray42 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.contains(intArray42, (int) (byte) 0);
        int[] intArray45 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray42);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray37, intArray45);
        int int48 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray45, 2);
        int[] intArray49 = org.apache.commons.lang3.ArrayUtils.clone(intArray45);
        int[] intArray50 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray45);
        int[] intArray51 = org.apache.commons.lang3.ArrayUtils.clone(intArray50);
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray13, intArray50);
        int[] intArray53 = org.apache.commons.lang3.ArrayUtils.removeElements(intArray0, intArray50);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(intArray53);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray6);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10, 0);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray4);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray9, (short) (byte) 1, (int) ' ');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeHtml4("974100410410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "974100410410" + "'", str1.equals("974100410410"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "{{0.0},{0.0},{0.0},{0.0},{0.0}}");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray4);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray4);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray4, (byte) -1, (int) (byte) 100);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeCsv("{-1,100}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{-1,100}" + "'", str1.equals("{-1,100}"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        java.lang.Integer[] intArray4 = new java.lang.Integer[] {};
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray5);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray3, intArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray7, (long) (short) 0, 2);
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) '4');
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        java.lang.Integer[] intArray17 = new java.lang.Integer[] {};
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray17);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray18);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray16, intArray19);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray20, (long) (short) 0, 2);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray20, (long) '4');
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join(longArray20, ' ', (int) (short) 10, (int) (short) 10);
        long[] longArray30 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray7, longArray20);
        long[] longArray32 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 100);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertNotNull(longArray32);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        java.lang.Byte[] byteArray3 = new java.lang.Byte[] { (byte) -1, (byte) 10, (byte) -1 };
        java.lang.Byte[][] byteArray4 = new java.lang.Byte[][] { byteArray3 };
        java.lang.Byte[] byteArray9 = new java.lang.Byte[] { (byte) 1, (byte) 10, (byte) -1 };
        java.lang.Byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray9);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray10);
        java.lang.Byte[][] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray4, (int) (short) 0, byteArray11);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("974100410410", (int) (short) 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                            974100410410                                            " + "'", str3.equals("                                            974100410410                                            "));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        char[] charArray5 = new char[] { '#', '#', '#', ' ' };
        char[] charArray9 = new char[] { 'a', ' ', '#' };
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.addAll(charArray5, charArray9);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray10);
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.add(charArray11, '4');
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray11, ' ', (-1));
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0 97 100 10", charArray11);
        java.lang.Character[] charArray18 = org.apache.commons.lang3.ArrayUtils.toObject(charArray11);
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.add(charArray11, 0, ' ');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray21);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 0);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) 10, 1, 0.0d);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray7, 0.0d);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 26, 10);
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.add(doubleArray7, (double) 100);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("          ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("          ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("  23  ", "{-1,3,100,10,3,2}");
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { (-1), 3, 100, 10, 3, 2 };
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray9, (int) '4');
        java.lang.String str13 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) intArray9, "0a97a100a10");
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray9);
        java.lang.Integer[] intArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray9);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strArray2, (java.lang.Object[]) intArray15);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "{-1,3,100,10,3,2}" + "'", str13.equals("{-1,3,100,10,3,2}"));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeCsv("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        java.lang.Integer[] intArray0 = null;
        java.lang.Integer[] intArray1 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray0);
        java.lang.Integer[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeXml("-1.0435.040.041.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0435.040.041.04-1.0410.0" + "'", str1.equals("-1.0435.040.041.04-1.0410.0"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        long[] longArray0 = null;
        try {
            long[] longArray2 = org.apache.commons.lang3.ArrayUtils.remove(longArray0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("-", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-" + "'", str2.equals("-"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray0);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.APOS_UNESCAPE();
        java.io.Serializable[] serializableArray3 = org.apache.commons.lang3.ArrayUtils.subarray((java.io.Serializable[]) strArray0, (int) '4', 24);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray0, '4');
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(serializableArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray3, (long) 'a', (int) (short) 0);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray3, (long) (short) 100, (int) (short) 10);
        long[] longArray16 = new long[] { 2, 'a', '#', 90, ' ', (short) 100 };
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(longArray16, ' ');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2 97 35 90 32 100" + "'", str19.equals("2 97 35 90 32 100"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray3, (long) 'a', (int) (short) 0);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray3, (long) (short) 100, (int) (short) 10);
        long[] longArray16 = new long[] { 2, 'a', '#', 90, ' ', (short) 100 };
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(longArray17, '#');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10#2#97#35#90#32#100" + "'", str19.equals("10#2#97#35#90#32#100"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        byte[][][] byteArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(byteArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray1, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 26);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray1);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray18);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray19);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray20, (double) 2, (int) (byte) -1, (double) 0.0f);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray25, doubleArray31);
        double[] doubleArray33 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray20, doubleArray31);
        java.lang.String str35 = org.apache.commons.lang3.StringUtils.join(doubleArray33, '4');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1.040.0410.04100.040.04-1.0410.0" + "'", str35.equals("1.040.0410.04100.040.04-1.0410.0"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        float[] floatArray0 = null;
        float[] floatArray3 = org.apache.commons.lang3.ArrayUtils.add(floatArray0, 0, 0.0f);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray3, (float) (-1), 95);
        int[] intArray11 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray11, (int) (byte) 0);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray11);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.add(intArray11, 10);
        try {
            float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.removeAll(floatArray3, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("{0,97,u00,u0}", "                                                 34                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        char[] charArray5 = new char[] { '#', '#', '#', ' ' };
        char[] charArray9 = new char[] { 'a', ' ', '#' };
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.addAll(charArray5, charArray9);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray10);
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.add(charArray11, '4');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#####", charArray13);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.subarray(charArray13, 24, (int) (byte) 1);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(charArray17);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        byte[] byteArray0 = null;
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.add(byteArray0, (byte) -1);
        java.lang.String str4 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) byteArray0, "");
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.0 -1.0 1.0 -1.0 1.0 1.0", "-1.0 -1.0 1.0 -1.0 1.0 1.0", 1);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", strArray6, strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "h-1.0-1.01.0-1.01.01.0h", (java.lang.CharSequence[]) strArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str9.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) 2, (int) '#', (double) (short) 10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray7, '4');
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray7, (double) (short) -1);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) 10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.04100.040.04-1.0410.0" + "'", str14.equals("10.04100.040.04-1.0410.0"));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper2 = org.apache.commons.lang3.text.translate.UnicodeEscaper.outsideOf(100, 4);
        java.io.Writer writer4 = null;
        try {
            unicodeEscaper2.translate((java.lang.CharSequence) "#4#4#4 4a4 4#", writer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Writer must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unicodeEscaper2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "64");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        float[] floatArray3 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray0, 90, 99);
        float[] floatArray5 = new float[] { 'a' };
        float[] floatArray7 = new float[] { (byte) -1 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray5, floatArray7);
        float[] floatArray15 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray17 = new float[] { 'a' };
        float[] floatArray19 = new float[] { (byte) -1 };
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray17, floatArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray15, floatArray17);
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray7, floatArray15);
        float[] floatArray24 = new float[] { 'a' };
        float[] floatArray26 = new float[] { (byte) -1 };
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray24, floatArray26);
        float[] floatArray34 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray36 = new float[] { 'a' };
        float[] floatArray38 = new float[] { (byte) -1 };
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray36, floatArray38);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray34, floatArray36);
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray26, floatArray34);
        boolean boolean42 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray22, floatArray34);
        float[] floatArray43 = null;
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray22, floatArray43);
        float[] floatArray45 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray3, floatArray43);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(floatArray45);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(byteArray2, (byte) 0);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.add(byteArray2, (byte) 0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeJava("1F");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1F" + "'", str1.equals("1F"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####h#####i#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "1.0");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray2, strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray4);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray4, (byte) 1, 2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4');
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray0, (short) (byte) 1);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray0);
        short[] shortArray9 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.clone(shortArray9);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray10, (short) 0);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray0, shortArray10);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray10, (short) (byte) 10, (int) (byte) -1);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray10, (short) (byte) 100, 0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        java.lang.Boolean[] booleanArray4 = new java.lang.Boolean[] { false, false, false, false };
        java.lang.Boolean[] booleanArray5 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray4);
        boolean[] booleanArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray4, false);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "64");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        java.lang.Short[] shortArray1 = new java.lang.Short[] { (short) 1 };
        java.lang.Short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray1);
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray2);
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray2);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (short) (byte) 10);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (int) (short) 0, (short) (byte) 0);
        short[] shortArray13 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.clone(shortArray13);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray14, (short) 10);
        java.lang.Short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray14);
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray17);
        short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray18, (short) 0);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray20);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray23 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray25 = new float[] { 'a' };
        float[] floatArray27 = new float[] { (byte) -1 };
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray25, floatArray27);
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray23, floatArray25);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.join(floatArray23, ' ');
        float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.add(floatArray23, (float) 0L);
        float[] floatArray35 = org.apache.commons.lang3.ArrayUtils.add(floatArray23, (float) (short) 100);
        float[] floatArray37 = new float[] { 'a' };
        float[] floatArray39 = new float[] { (byte) -1 };
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray37, floatArray39);
        float[] floatArray47 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray49 = new float[] { 'a' };
        float[] floatArray51 = new float[] { (byte) -1 };
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray49, floatArray51);
        boolean boolean53 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray47, floatArray49);
        float[] floatArray54 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray39, floatArray47);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray39);
        float[] floatArray56 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray35, floatArray39);
        float[] floatArray57 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray6, floatArray39);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str31.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray57);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray11);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray11);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray7, doubleArray11);
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray7, (double) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray1, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 26);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray1);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray18);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray19);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray20, (double) 2, (int) (byte) -1, (double) 0.0f);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray25, doubleArray31);
        double[] doubleArray33 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray20, doubleArray31);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray31, (double) 2, 26);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray43 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray44 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray37, doubleArray43);
        int int47 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray44, (double) (byte) -1, (double) (byte) 1);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray44);
        double[] doubleArray49 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray31, doubleArray44);
        double[] doubleArray51 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray44, (double) 0.0f);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray0, (float) 'a', (int) (byte) -1);
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray0, (float) 2);
        float[] floatArray6 = null;
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray0, floatArray6);
        java.lang.Float[] floatArray12 = new java.lang.Float[] { 0.0f, 0.0f, 10.0f, (-1.0f) };
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray13);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray13, (int) '4', 2);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray7, floatArray13);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray7, (float) (byte) 1, 0);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 100);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray11);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "{1.0}");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.remove(byteArray4, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray1, byteArray6);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.add(byteArray6, (byte) 0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        java.lang.Integer[] intArray4 = new java.lang.Integer[] {};
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray5);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray3, intArray6);
        long[] longArray9 = new long[] { (short) 10 };
        long[] longArray10 = new long[] {};
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray9, longArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray11);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray11, (long) '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray14, ' ');
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray14, (long) 10, (int) ' ');
        long[] longArray21 = new long[] { (short) 10 };
        long[] longArray22 = new long[] {};
        long[] longArray23 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray21, longArray22);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray14, longArray21);
        long[] longArray26 = org.apache.commons.lang3.ArrayUtils.add(longArray14, (long) 11);
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray14);
        long[] longArray31 = new long[] { (short) 0, 'a', 100 };
        long[] longArray33 = new long[] { (short) 10 };
        long[] longArray34 = new long[] {};
        long[] longArray35 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray33, longArray34);
        long[] longArray36 = org.apache.commons.lang3.ArrayUtils.addAll(longArray31, longArray35);
        long[] longArray40 = new long[] { (short) 0, 'a', 100 };
        long[] longArray42 = new long[] { (short) 10 };
        long[] longArray43 = new long[] {};
        long[] longArray44 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray42, longArray43);
        long[] longArray45 = org.apache.commons.lang3.ArrayUtils.addAll(longArray40, longArray44);
        long[] longArray46 = org.apache.commons.lang3.ArrayUtils.addAll(longArray31, longArray44);
        long[] longArray49 = org.apache.commons.lang3.ArrayUtils.subarray(longArray31, 100, (int) (byte) 100);
        long[] longArray52 = org.apache.commons.lang3.ArrayUtils.subarray(longArray31, (int) 'a', (int) '#');
        long[] longArray56 = new long[] { (short) 0, 'a', 100 };
        long[] longArray58 = new long[] { (short) 10 };
        long[] longArray59 = new long[] {};
        long[] longArray60 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray58, longArray59);
        long[] longArray61 = org.apache.commons.lang3.ArrayUtils.addAll(longArray56, longArray60);
        long[] longArray65 = new long[] { (short) 0, 'a', 100 };
        long[] longArray67 = new long[] { (short) 10 };
        long[] longArray68 = new long[] {};
        long[] longArray69 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray67, longArray68);
        long[] longArray70 = org.apache.commons.lang3.ArrayUtils.addAll(longArray65, longArray69);
        long[] longArray71 = org.apache.commons.lang3.ArrayUtils.addAll(longArray56, longArray69);
        long[] longArray74 = org.apache.commons.lang3.ArrayUtils.subarray(longArray56, 100, (int) (byte) 100);
        long[] longArray77 = org.apache.commons.lang3.ArrayUtils.subarray(longArray56, (int) 'a', (int) '#');
        long[] longArray78 = org.apache.commons.lang3.ArrayUtils.addAll(longArray52, longArray56);
        long[] longArray80 = org.apache.commons.lang3.ArrayUtils.add(longArray56, 0L);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray80);
        long[] longArray82 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray80);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10" + "'", str16.equals("10"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(longArray26);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray31);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertNotNull(longArray34);
        org.junit.Assert.assertNotNull(longArray35);
        org.junit.Assert.assertNotNull(longArray36);
        org.junit.Assert.assertNotNull(longArray40);
        org.junit.Assert.assertNotNull(longArray42);
        org.junit.Assert.assertNotNull(longArray43);
        org.junit.Assert.assertNotNull(longArray44);
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertNotNull(longArray46);
        org.junit.Assert.assertNotNull(longArray49);
        org.junit.Assert.assertNotNull(longArray52);
        org.junit.Assert.assertNotNull(longArray56);
        org.junit.Assert.assertNotNull(longArray58);
        org.junit.Assert.assertNotNull(longArray59);
        org.junit.Assert.assertNotNull(longArray60);
        org.junit.Assert.assertNotNull(longArray61);
        org.junit.Assert.assertNotNull(longArray65);
        org.junit.Assert.assertNotNull(longArray67);
        org.junit.Assert.assertNotNull(longArray68);
        org.junit.Assert.assertNotNull(longArray69);
        org.junit.Assert.assertNotNull(longArray70);
        org.junit.Assert.assertNotNull(longArray71);
        org.junit.Assert.assertNotNull(longArray74);
        org.junit.Assert.assertNotNull(longArray77);
        org.junit.Assert.assertNotNull(longArray78);
        org.junit.Assert.assertNotNull(longArray80);
        org.junit.Assert.assertNotNull(longArray82);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray6);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray6, 0);
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray11, true);
        java.lang.Integer[] intArray14 = new java.lang.Integer[] {};
        java.lang.Integer[] intArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray14);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, (int) (byte) 0);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeAll(booleanArray13, intArray17);
        java.lang.Boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray19);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        char[] charArray4 = new char[] { '#', '#', '#', ' ' };
        char[] charArray8 = new char[] { 'a', ' ', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray8, '#', (int) (byte) 10);
        char[] charArray13 = null;
        char[] charArray14 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray8, charArray13);
        java.lang.Character[] charArray15 = org.apache.commons.lang3.ArrayUtils.toObject(charArray8);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(charArray8, '#');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10,3,2}", "1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "2 97 35 90 32 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) 'a', (int) (short) -1);
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (byte) -1, (int) (short) -1, (double) 11);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.APOS_UNESCAPE();
        java.io.Serializable[] serializableArray3 = org.apache.commons.lang3.ArrayUtils.subarray((java.io.Serializable[]) strArray0, (int) '4', 24);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "", 90, 26);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(serializableArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        long[] longArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_ARRAY;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray0);
        long[] longArray5 = new long[] { (short) 0, 'a', 100 };
        long[] longArray7 = new long[] { (short) 10 };
        long[] longArray8 = new long[] {};
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray7, longArray8);
        long[] longArray10 = org.apache.commons.lang3.ArrayUtils.addAll(longArray5, longArray9);
        long[] longArray14 = new long[] { (short) 0, 'a', 100 };
        long[] longArray16 = new long[] { (short) 10 };
        long[] longArray17 = new long[] {};
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray16, longArray17);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray18);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.addAll(longArray5, longArray18);
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.clone(longArray20);
        long[] longArray22 = null;
        long[] longArray23 = org.apache.commons.lang3.ArrayUtils.addAll(longArray21, longArray22);
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray0, longArray22);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.contains(longArray24, 0L);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "  23                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        char[] charArray1 = new char[] { '#' };
        char[] charArray3 = org.apache.commons.lang3.ArrayUtils.add(charArray1, '#');
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray3);
        char[] charArray10 = new char[] { '#', '#', '#', ' ' };
        char[] charArray14 = new char[] { 'a', ' ', '#' };
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.addAll(charArray10, charArray14);
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray15);
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.add(charArray16, '4');
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#####", charArray18);
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray4, charArray18);
        java.lang.Character[] charArray21 = org.apache.commons.lang3.ArrayUtils.toObject(charArray4);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, '#');
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        char[] charArray2 = new char[] {};
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "", charArray2);
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray2);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10,3,2}", charArray4);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, 'a');
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(charArray4, '#');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####H#####I#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####", (java.lang.CharSequence) "###########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        float[] floatArray0 = null;
        float[] floatArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray0, floatArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                                                                    0A97A100A10");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                    0a97a100a10", '#');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', (int) (byte) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray21 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray23 = new float[] { 'a' };
        float[] floatArray25 = new float[] { (byte) -1 };
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray23, floatArray25);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray21, floatArray23);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.join(floatArray21, '4', (int) '#', (int) (byte) 1);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray6, floatArray21);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray3, (long) (short) 1);
        java.lang.Long[] longArray21 = org.apache.commons.lang3.ArrayUtils.toObject(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(longArray21);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray8);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray8, (long) (byte) 0);
        long[] longArray12 = null;
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.addAll(longArray8, longArray12);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (long) 26);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "-1a100a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) 2, (int) '#', (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 5);
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray7, 0.0d);
        double[] doubleArray17 = null;
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray7, doubleArray17);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray17, (double) 6, (double) '4');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                     ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                     .." + "'", str1.equals("                     .."));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 0);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray19 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray13, doubleArray19);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray20, (double) (byte) -1, (double) (byte) 1);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray20, (double) 0);
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray20, (double) 10, 1, 0.0d);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray7, doubleArray20);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray7, (double) 24, (double) 2);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("!                                                                                     0A97A100A10   ", (int) '4', 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        java.lang.Integer[][] intArray1 = new java.lang.Integer[][] { intArray0 };
        java.lang.Integer[][] intArray2 = org.apache.commons.lang3.ArrayUtils.toArray(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        java.lang.Integer[] intArray11 = new java.lang.Integer[] {};
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray11);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray12);
        int[] intArray18 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.contains(intArray18, (int) (byte) 0);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray18);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray13, intArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray7, intArray13);
        java.lang.Integer[] intArray24 = org.apache.commons.lang3.ArrayUtils.toObject(intArray7);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) intArray2, (java.lang.Object) intArray7, 4);
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.add(intArray7, (int) '4');
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("  1   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray5 = null;
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, 0, 0.0f);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray3, floatArray5);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray3);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.clone(floatArray3);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray11, (float) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray11);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}", 11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        java.lang.Byte[] byteArray3 = new java.lang.Byte[] { (byte) 1, (byte) 10, (byte) -1 };
        java.lang.Byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray3);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray4, (byte) 0);
        java.lang.Byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray4);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray8, (byte) 0);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray8);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strArray3, (java.lang.Object[]) booleanArray4);
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray4);
        boolean[] booleanArray13 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.add(booleanArray13, true);
        boolean[] booleanArray16 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray13);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray13);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray13);
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray13, false);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray20, false);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        long[] longArray0 = null;
        try {
            long[] longArray3 = org.apache.commons.lang3.ArrayUtils.add(longArray0, 26, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 26, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                      0a97a100a10  ", "", "                                             0 97 100 1                                             ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                      0a97a100a10  " + "'", str3.equals("                                                                                      0a97a100a10  "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        float[] floatArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.contains(floatArray18, 100.0f);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray18);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray21, (float) (-1L));
        java.lang.Float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(floatArray21);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "{}", "{0,97,u00,u0}");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        float[] floatArray19 = null;
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray6, floatArray19);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("0-1.01.01.0h", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h" + "'", str2.equals("0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(shortArray8, (short) 0);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray4, shortArray8);
        try {
            short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.remove(shortArray11, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shortArray11);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        java.lang.Character[] charArray7 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray7, 'a');
        java.lang.Character[] charArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charArray10, 'a', (int) '#', (int) (byte) 0);
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray10, 'a');
        java.lang.Character[] charArray17 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray10);
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray17, '4');
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray17);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "{-1,100}", charArray20);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        java.lang.Integer[] intArray8 = new java.lang.Integer[] {};
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray8);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray9);
        int[] intArray15 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(intArray15, (int) (byte) 0);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray15);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray10, intArray18);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray4, intArray10);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray10, 99);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "0a9hi!0a97", (java.lang.CharSequence) "                                                                                      0A97A100A10  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                      0A97A100A10  ", "                                                                                    0a97a100a10");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        java.lang.Character[] charArray8 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray8, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", charArray10);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray10, '#', 3);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.add(charArray10, 'a');
        java.lang.Character[] charArray24 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray24, 'a');
        java.lang.Character[] charArray27 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray24);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charArray27, 'a', (int) '#', (int) (byte) 0);
        char[] charArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray27, 'a');
        java.lang.Character[] charArray34 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray27);
        char[] charArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray34, '4');
        char[] charArray37 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray34);
        char[] charArray38 = org.apache.commons.lang3.ArrayUtils.addAll(charArray10, charArray37);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertNotNull(charArray38);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray6);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray6, 0);
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray11, true);
        java.lang.Integer[] intArray14 = new java.lang.Integer[] {};
        java.lang.Integer[] intArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray14);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, (int) (byte) 0);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeAll(booleanArray13, intArray17);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(intArray17, '4', 100, 5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray8);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray8, (long) (byte) 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray11);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray11, 'a', (int) (byte) 100, 2);
        try {
            long[] longArray18 = org.apache.commons.lang3.ArrayUtils.remove(longArray11, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        org.apache.commons.lang3.text.translate.OctalUnescaper octalUnescaper0 = new org.apache.commons.lang3.text.translate.OctalUnescaper();
        java.io.Writer writer3 = null;
        int int4 = octalUnescaper0.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 6, writer3);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper5 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper6 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper7 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper8 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper9 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper10 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray11 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper5, unicodeUnescaper6, unicodeUnescaper7, unicodeUnescaper8, unicodeUnescaper9, unicodeUnescaper10 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray12 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray11);
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator13 = octalUnescaper0.with((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray12);
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator14 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray11);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray12);
        org.junit.Assert.assertNotNull(charSequenceTranslator13);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        char[] charArray0 = null;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.add(charArray0, '4');
        char[] charArray7 = new char[] { '#', '#', '#', ' ' };
        char[] charArray11 = new char[] { 'a', ' ', '#' };
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.addAll(charArray7, charArray11);
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray12);
        char[] charArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray12);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.add(charArray14, 0, '#');
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.addAll(charArray2, charArray17);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray17, 'a', (int) (short) 0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 4, "  23                      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  23" + "'", str3.equals("  23"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 26);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(doubleArray0);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray14, (double) 5);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0a9hi!0a97", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = org.apache.commons.lang3.text.translate.UnicodeEscaper.above((int) (short) 0);
        org.junit.Assert.assertNotNull(unicodeEscaper1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.clone(longArray18);
        java.lang.String str21 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) longArray19, "23");
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(longArray19, 'a');
        java.lang.Long[] longArray26 = new java.lang.Long[] { 1L, 100L };
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray26);
        long[] longArray29 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray26, (long) (short) 0);
        long[] longArray30 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray19, longArray29);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{0,97,100,10}" + "'", str21.equals("{0,97,100,10}"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0a97a100a10" + "'", str23.equals("0a97a100a10"));
        org.junit.Assert.assertNotNull(longArray26);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray29);
        org.junit.Assert.assertNotNull(longArray30);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeJava("97410041041040");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97410041041040" + "'", str1.equals("97410041041040"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray3);
        long[] longArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray3, (long) '4');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray3, (long) (short) 0, 26);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray3);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray3);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray11);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        java.lang.Byte[] byteArray3 = new java.lang.Byte[] { (byte) 1, (byte) 10, (byte) -1 };
        java.lang.Byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray3);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray4, (byte) -1);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 100);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(byteArray6);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 10 -1" + "'", str10.equals("1 10 -1"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) shortArray7, "");
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray7);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{1,-1,-1}" + "'", str9.equals("{1,-1,-1}"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "            -1a100a             aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 95);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        char[] charArray4 = new char[] { '#', '#', '#', ' ' };
        char[] charArray8 = new char[] { 'a', ' ', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray8);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray9);
        char[] charArray16 = new char[] { '#', '#', '#', ' ' };
        char[] charArray20 = new char[] { 'a', ' ', '#' };
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.addAll(charArray16, charArray20);
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray21);
        char[] charArray24 = org.apache.commons.lang3.ArrayUtils.add(charArray22, '4');
        boolean boolean25 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#####", charArray24);
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray24, '#');
        char[] charArray28 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray10, charArray24);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(charArray28);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "            -1a100a             ", (java.lang.CharSequence) "-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray4);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(byteArray4, (byte) 0);
        java.lang.Byte[] byteArray13 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray13);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray14, (byte) 100, 0);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray14, (-1), (int) (short) 100);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray4, byteArray20);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray21);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        java.lang.Byte[] byteArray30 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray30);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray31, (byte) 100, 0);
        byte[] byteArray37 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray31, (-1), (int) (short) 100);
        byte[] byteArray40 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray42 = org.apache.commons.lang3.ArrayUtils.remove(byteArray40, 0);
        java.lang.Byte[] byteArray48 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray49 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray48);
        byte[] byteArray52 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray54 = org.apache.commons.lang3.ArrayUtils.remove(byteArray52, 0);
        boolean boolean55 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray49, byteArray52);
        byte[] byteArray57 = org.apache.commons.lang3.ArrayUtils.add(byteArray52, (byte) 1);
        byte[] byteArray60 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray57, (int) (short) 1, (int) '4');
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray42, byteArray60);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray37, byteArray42);
        boolean boolean63 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.Object) byteArray42);
        byte[] byteArray65 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray42, (byte) 1);
        byte[] byteArray66 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray21, byteArray42);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertNotNull(byteArray49);
        org.junit.Assert.assertNotNull(byteArray52);
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(byteArray57);
        org.junit.Assert.assertNotNull(byteArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(byteArray65);
        org.junit.Assert.assertNotNull(byteArray66);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih0.1 0.1 0.1- 0.1 0.1- 0.1-h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih0.1 0.1 0.1- 0.1 0.1- 0.1-h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str1.equals("h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih0.1 0.1 0.1- 0.1 0.1- 0.1-h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper2 = org.apache.commons.lang3.text.translate.UnicodeEscaper.outsideOf((int) (short) -1, 31);
        org.junit.Assert.assertNotNull(unicodeEscaper2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray3);
        float[] floatArray21 = new float[] { 'a' };
        float[] floatArray23 = new float[] { (byte) -1 };
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray21, floatArray23);
        float[] floatArray31 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray33 = new float[] { 'a' };
        float[] floatArray35 = new float[] { (byte) -1 };
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray33, floatArray35);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray31, floatArray33);
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray23, floatArray31);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray31, (float) 10, 100);
        float[] floatArray42 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray3, floatArray31);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(floatArray42);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aa4aaa a4a#", "1 100", (-1));
        java.lang.String[] strArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "{&gt;=>, &quot;=\", &amp;=&, &lt;=<}", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "{>=>, \"=\", &=&, <=<}");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                            974100410410                                            ", (java.lang.CharSequence) "{>=>, \"=\", &=&, <=<}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(shortArray4);
        java.lang.Short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", (int) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) shortArray9, (java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(" ", "-1#1#10#10#10#-1#1#10#10#10");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h0-1.01.01.0h", (java.lang.CharSequence) "10.0#100.0#0.0#-1.0#10.0#0.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray1, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 26);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray1);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray18);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray19);
        long[] longArray22 = new long[] { (short) 10 };
        long[] longArray23 = new long[] {};
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray22, longArray23);
        java.lang.Integer[] intArray25 = new java.lang.Integer[] {};
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray25);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray26);
        long[] longArray28 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray24, intArray27);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.clone(intArray27);
        try {
            double[] doubleArray30 = org.apache.commons.lang3.ArrayUtils.removeAll(doubleArray0, intArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 10);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        char[] charArray4 = new char[] { '#', '#', '#', ' ' };
        char[] charArray8 = new char[] { 'a', ' ', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray8);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray9);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.contains(charArray9, 'a');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("  23                      ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "23" + "'", str2.equals("23"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.remove(intArray7, 3);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.clone(intArray7);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray11, 26, (int) '4');
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray11, (int) ' ', 0);
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.clone(floatArray24);
        int int27 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray24, 0.0f);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        java.lang.Integer[] intArray8 = new java.lang.Integer[] {};
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray8);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray9);
        int[] intArray15 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(intArray15, (int) (byte) 0);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray15);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray10, intArray18);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray4, intArray10);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 0);
        java.lang.Integer[] intArray23 = org.apache.commons.lang3.ArrayUtils.toObject(intArray22);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.subarray(intArray22, 0, (int) (short) 10);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97a100a10a10" + "'", str9.equals("97a100a10a10"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("!                                                                                     0A97A100A10   ", "a#4#a# #4##", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeCsv("1a-1a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a-1a-1" + "'", str1.equals("1a-1a-1"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray18, (long) 24);
        java.lang.Long[] longArray21 = org.apache.commons.lang3.ArrayUtils.toObject(longArray18);
        java.lang.Class<?> wildcardClass22 = longArray21.getClass();
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray0, (float) 'a', (int) (byte) -1);
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray0, (float) 2);
        float[] floatArray6 = null;
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray0, floatArray6);
        float[] floatArray9 = new float[] { 'a' };
        float[] floatArray11 = new float[] { (byte) -1 };
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray9, floatArray11);
        float[] floatArray19 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray21 = new float[] { 'a' };
        float[] floatArray23 = new float[] { (byte) -1 };
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray21, floatArray23);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray19, floatArray21);
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray11, floatArray19);
        float[] floatArray29 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray19, 26, (int) '4');
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray0, floatArray19);
        float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray0, 0, 5);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("         !", "{{0.0},{0.0},{0.0},{0.0},{0.0}}");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         !" + "'", str2.equals("         !"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1 ", (java.lang.CharSequence) "14-14-1", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        java.lang.Long[] longArray2 = new java.lang.Long[] { 1L, 100L };
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2, (long) (short) 0);
        java.lang.Long[] longArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray2);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6, (long) (short) -1);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray4);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(byteArray4, (byte) 0);
        java.lang.Byte[] byteArray13 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray13);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray14, (byte) 100, 0);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray14, (-1), (int) (short) 100);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray4, byteArray20);
        byte[] byteArray24 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.remove(byteArray24, 0);
        java.lang.Byte[] byteArray32 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray32);
        byte[] byteArray36 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray38 = org.apache.commons.lang3.ArrayUtils.remove(byteArray36, 0);
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray33, byteArray36);
        byte[] byteArray41 = org.apache.commons.lang3.ArrayUtils.add(byteArray36, (byte) 1);
        byte[] byteArray44 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray41, (int) (short) 1, (int) '4');
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray26, byteArray44);
        byte[] byteArray46 = org.apache.commons.lang3.ArrayUtils.removeElements(byteArray4, byteArray26);
        try {
            byte[] byteArray48 = org.apache.commons.lang3.ArrayUtils.remove(byteArray26, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 26, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(byteArray46);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double[] doubleArray6 = new double[] { (-1), '#', 0.0d, 1.0d, (short) -1, (short) 10 };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 'a', (int) (byte) -1);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray6);
        try {
            double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray6, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        java.lang.Long[] longArray2 = new java.lang.Long[] { 1L, 100L };
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2, (long) (short) 0);
        java.lang.Long[] longArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray2);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6, (long) (short) -1);
        long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6, (long) 3);
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6, (long) 95);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray12);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 100);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray10, 5, (int) (short) 10);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray13);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        int[] intArray0 = null;
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.clone(intArray0);
        org.junit.Assert.assertNull(intArray1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                    ", "", (int) (byte) 1);
        int[] intArray8 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(intArray8, (int) (byte) 0);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray8);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray8);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.remove(intArray8, 2);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) strArray3, (java.lang.Object) intArray14, (int) (byte) -1);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "A", (int) (short) 100, 95);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) doubleArray2, '4');
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray2, (double) 1);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.040.0" + "'", str5.equals("1.040.0"));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, 0.0d, (int) ' ');
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) 100L);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(longArray7, (long) 24);
        long[] longArray14 = new long[] { (short) 0, 'a', 100 };
        long[] longArray16 = new long[] { (short) 10 };
        long[] longArray17 = new long[] {};
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray16, longArray17);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray18);
        long[] longArray23 = new long[] { (short) 0, 'a', 100 };
        long[] longArray25 = new long[] { (short) 10 };
        long[] longArray26 = new long[] {};
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray25, longArray26);
        long[] longArray28 = org.apache.commons.lang3.ArrayUtils.addAll(longArray23, longArray27);
        long[] longArray29 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray27);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray29);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray7, longArray29);
        long[] longArray32 = org.apache.commons.lang3.ArrayUtils.clone(longArray7);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertNotNull(longArray26);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(longArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(longArray32);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("23", "{-1,3,100,10,3,2}", "{-1,3,100,10,3,2");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "23" + "'", str3.equals("23"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        boolean[] booleanArray4 = new boolean[] { true, true, true, false };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray4, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray4, (int) ' ', 6);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray9);
        java.lang.Boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray9);
        boolean[] booleanArray18 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.add(booleanArray18, true);
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray18);
        boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.add(booleanArray18, (int) (byte) 1, true);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray9, booleanArray24);
        int int27 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray24, true);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1,-1,-1}", 90, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1,-1,-1}" + "'", str3.equals("1,-1,-1}"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0-1.01.01.0h", (java.lang.CharSequence) "01a001a79a0                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray8);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray8, (long) (byte) 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray11);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray11);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        char[] charArray2 = new char[] { ' ', ' ' };
        char[] charArray4 = new char[] { '#' };
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.add(charArray4, '#');
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray2, charArray4);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray4, '#', 24, 10);
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.subarray(charArray4, 90, (int) (byte) -1);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(charArray16);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        byte[] byteArray0 = null;
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray10 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray15 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray20 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[][] byteArray21 = new byte[][] { byteArray5, byteArray10, byteArray15, byteArray20 };
        byte[] byteArray28 = new byte[] { (byte) -1, (byte) 1, (byte) -1, (byte) 0, (byte) 10, (byte) 10 };
        byte[][] byteArray29 = new byte[][] { byteArray28 };
        byte[][] byteArray30 = org.apache.commons.lang3.ArrayUtils.removeElements(byteArray21, byteArray29);
        byte[] byteArray34 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray36 = org.apache.commons.lang3.ArrayUtils.remove(byteArray34, 0);
        java.lang.String[][] strArray37 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_ESCAPE();
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) byteArray36, (java.lang.Object) strArray37);
        byte[][] byteArray39 = org.apache.commons.lang3.ArrayUtils.add(byteArray21, (int) (byte) 0, byteArray36);
        byte[] byteArray41 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray36, (byte) 10);
        byte[] byteArray42 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray0, byteArray36);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertNotNull(byteArray42);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray22);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray18, floatArray22);
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.add(floatArray18, (float) 0);
        float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, 26, 1);
        float[] floatArray46 = new float[] { 'a' };
        float[] floatArray48 = new float[] { (byte) -1 };
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray46, floatArray48);
        float[] floatArray56 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray58 = new float[] { 'a' };
        float[] floatArray60 = new float[] { (byte) -1 };
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray58, floatArray60);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray56, floatArray58);
        float[] floatArray63 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray48, floatArray56);
        float[] floatArray66 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray56, 26, (int) '4');
        float[] floatArray67 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray44, floatArray56);
        float[] floatArray70 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray56, (int) (byte) 100, (int) (byte) 1);
        try {
            float[] floatArray72 = org.apache.commons.lang3.ArrayUtils.remove(floatArray70, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray70);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 0);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray7, 0.0d);
        double[] doubleArray15 = new double[] {};
        double[] doubleArray21 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray22 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray15, doubleArray21);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray15, (double) (short) 100, (int) (byte) 10);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray15);
        double[] doubleArray27 = null;
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray15, doubleArray27);
        double[] doubleArray29 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(doubleArray27);
        double[] doubleArray30 = new double[] {};
        double[] doubleArray36 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray37 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray30, doubleArray36);
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray37);
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray37, (double) 2, (int) '#', (double) (short) 10);
        double[] doubleArray43 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray37);
        int int45 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray37, (double) (byte) 10);
        double[] doubleArray46 = org.apache.commons.lang3.ArrayUtils.removeElements(doubleArray27, doubleArray37);
        double[] doubleArray47 = org.apache.commons.lang3.ArrayUtils.removeElements(doubleArray7, doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("23", "{1.0}");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "23" + "'", str2.equals("23"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "14-14-1", (java.lang.CharSequence) "a1", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray11, 26, (int) '4');
        java.lang.Float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray21);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.contains(floatArray21, (float) 3);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(floatArray21, 'a');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "                                                                                    0a97a100a10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double[] doubleArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        double[] doubleArray6 = new double[] { (-1), '#', 0.0d, 1.0d, (short) -1, (short) 10 };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 'a', (int) (byte) -1);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray6);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray6);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray6);
        boolean[] booleanArray16 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.add(booleanArray16, true);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, false, (int) (short) 0);
        boolean[] booleanArray29 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray31 = org.apache.commons.lang3.ArrayUtils.add(booleanArray29, true);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray31);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray31, false, (int) (short) 0);
        boolean[] booleanArray36 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray31);
        int int39 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, true, (int) ' ');
        boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray40);
        boolean[] booleanArray42 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray40);
        boolean[] booleanArray43 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray9, booleanArray42);
        boolean[] booleanArray50 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray52 = org.apache.commons.lang3.ArrayUtils.add(booleanArray50, true);
        boolean[] booleanArray53 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray50);
        boolean[] booleanArray60 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray62 = org.apache.commons.lang3.ArrayUtils.add(booleanArray60, true);
        boolean boolean63 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray62);
        int int66 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray62, false, (int) (short) 0);
        boolean[] booleanArray73 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray75 = org.apache.commons.lang3.ArrayUtils.add(booleanArray73, true);
        boolean boolean76 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray75);
        int int79 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray75, false, (int) (short) 0);
        boolean[] booleanArray80 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray62, booleanArray75);
        int int83 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray62, true, (int) ' ');
        boolean[] booleanArray84 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean boolean85 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray84);
        boolean[] booleanArray86 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray62, booleanArray84);
        boolean[] booleanArray87 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray53, booleanArray86);
        boolean[] booleanArray88 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray53);
        boolean[] booleanArray89 = org.apache.commons.lang3.ArrayUtils.removeElements(booleanArray43, booleanArray53);
        int int92 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray53, true, 0);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(booleanArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(booleanArray42);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertNotNull(booleanArray50);
        org.junit.Assert.assertNotNull(booleanArray52);
        org.junit.Assert.assertNotNull(booleanArray53);
        org.junit.Assert.assertNotNull(booleanArray60);
        org.junit.Assert.assertNotNull(booleanArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(booleanArray73);
        org.junit.Assert.assertNotNull(booleanArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(booleanArray80);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 6 + "'", int83 == 6);
        org.junit.Assert.assertNotNull(booleanArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(booleanArray86);
        org.junit.Assert.assertNotNull(booleanArray87);
        org.junit.Assert.assertNotNull(booleanArray88);
        org.junit.Assert.assertNotNull(booleanArray89);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 4 + "'", int92 == 4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        java.lang.Character[] charArray7 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray7, 'a');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "!", charArray9);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray9, 'a', (int) (byte) 0);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray3);
        long[] longArray6 = org.apache.commons.lang3.ArrayUtils.remove(longArray3, 0);
        long[] longArray10 = new long[] { (short) 0, 'a', 100 };
        long[] longArray12 = new long[] { (short) 10 };
        long[] longArray13 = new long[] {};
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray12, longArray13);
        long[] longArray15 = org.apache.commons.lang3.ArrayUtils.addAll(longArray10, longArray14);
        long[] longArray19 = new long[] { (short) 0, 'a', 100 };
        long[] longArray21 = new long[] { (short) 10 };
        long[] longArray22 = new long[] {};
        long[] longArray23 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray21, longArray22);
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.addAll(longArray19, longArray23);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.addAll(longArray10, longArray23);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray3, longArray23);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray23);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                                 34                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "34" + "'", str1.equals("34"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        float[] floatArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray0, (float) (short) -1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        java.lang.Byte[] byteArray18 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray18);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray18);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray18, (byte) 100);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray22, 10, 3);
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray22);
        java.lang.Byte[] byteArray32 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray32);
        java.lang.Byte[] byteArray34 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray32);
        byte[] byteArray35 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray34);
        byte[] byteArray36 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray35);
        byte[] byteArray38 = org.apache.commons.lang3.ArrayUtils.remove(byteArray36, 0);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertNotNull(byteArray38);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray6);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray6, 0);
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray11, true);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray13, true);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray13, false, 1);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        double[] doubleArray6 = new double[] { (-1), '#', 0.0d, 1.0d, (short) -1, (short) 10 };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 'a', (int) (byte) -1);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 100.0d, (int) (short) -1, (double) (byte) 0);
        java.lang.Double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        java.lang.Double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray0 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper1 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray0);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper2 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray0);
        java.io.Writer writer5 = null;
        try {
            int int6 = numericEntityUnescaper2.translate((java.lang.CharSequence) "aa4aaa a4a#", 11, writer5);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 11");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(oPTIONArray0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeEcmaScript("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeHtml4("{-1.0,-1.0,1.0,-1.0,1.0,1.0,-1.0}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{-1.0,-1.0,1.0,-1.0,1.0,1.0,-1.0}" + "'", str1.equals("{-1.0,-1.0,1.0,-1.0,1.0,1.0,-1.0}"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0a9hi!0a97", "  23");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray8);
        long[] longArray13 = new long[] { (short) 0, 'a', 100 };
        long[] longArray15 = new long[] { (short) 10 };
        long[] longArray16 = new long[] {};
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray15, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray13, longArray17);
        long[] longArray22 = new long[] { (short) 0, 'a', 100 };
        long[] longArray24 = new long[] { (short) 10 };
        long[] longArray25 = new long[] {};
        long[] longArray26 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray24, longArray25);
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.addAll(longArray22, longArray26);
        long[] longArray28 = org.apache.commons.lang3.ArrayUtils.addAll(longArray13, longArray26);
        long[] longArray31 = org.apache.commons.lang3.ArrayUtils.subarray(longArray13, 100, (int) (byte) 100);
        long[] longArray34 = org.apache.commons.lang3.ArrayUtils.subarray(longArray13, (int) 'a', (int) '#');
        org.apache.commons.lang3.ArrayUtils.reverse(longArray13);
        long[] longArray36 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray8, longArray13);
        int[] intArray42 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.contains(intArray42, (int) (byte) 0);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray42);
        java.lang.Object[] objArray46 = new java.lang.Object[] { false, boolean45 };
        java.lang.String str50 = org.apache.commons.lang3.StringUtils.join(objArray46, "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) '4', 0);
        long[] longArray54 = new long[] { (short) 0, 'a', 100 };
        long[] longArray56 = new long[] { (short) 10 };
        long[] longArray57 = new long[] {};
        long[] longArray58 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray56, longArray57);
        long[] longArray59 = org.apache.commons.lang3.ArrayUtils.addAll(longArray54, longArray58);
        long[] longArray63 = new long[] { (short) 0, 'a', 100 };
        long[] longArray65 = new long[] { (short) 10 };
        long[] longArray66 = new long[] {};
        long[] longArray67 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray65, longArray66);
        long[] longArray68 = org.apache.commons.lang3.ArrayUtils.addAll(longArray63, longArray67);
        long[] longArray69 = org.apache.commons.lang3.ArrayUtils.addAll(longArray54, longArray67);
        long[] longArray72 = org.apache.commons.lang3.ArrayUtils.subarray(longArray54, 100, (int) (byte) 100);
        long[] longArray75 = org.apache.commons.lang3.ArrayUtils.subarray(longArray54, (int) 'a', (int) '#');
        int int77 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray75, (long) (byte) 1);
        int int78 = org.apache.commons.lang3.ArrayUtils.indexOf(objArray46, (java.lang.Object) longArray75);
        long[] longArray79 = org.apache.commons.lang3.ArrayUtils.addAll(longArray8, longArray75);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertNotNull(longArray26);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(longArray31);
        org.junit.Assert.assertNotNull(longArray34);
        org.junit.Assert.assertNotNull(longArray36);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertNotNull(longArray54);
        org.junit.Assert.assertNotNull(longArray56);
        org.junit.Assert.assertNotNull(longArray57);
        org.junit.Assert.assertNotNull(longArray58);
        org.junit.Assert.assertNotNull(longArray59);
        org.junit.Assert.assertNotNull(longArray63);
        org.junit.Assert.assertNotNull(longArray65);
        org.junit.Assert.assertNotNull(longArray66);
        org.junit.Assert.assertNotNull(longArray67);
        org.junit.Assert.assertNotNull(longArray68);
        org.junit.Assert.assertNotNull(longArray69);
        org.junit.Assert.assertNotNull(longArray72);
        org.junit.Assert.assertNotNull(longArray75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertNotNull(longArray79);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "  23  ", (java.lang.CharSequence) "01a001a79a0                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("-1.0435.040.041.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0435.040.041.04-1.0410.0" + "'", str1.equals("-1.0435.040.041.04-1.0410.0"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray3, (short) 0);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray6, (short) (byte) 10, (int) (byte) 0);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray6, (short) (byte) 100);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1,-1,-1}", (java.lang.CharSequence) "a1", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "                     ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        java.lang.Byte[] byteArray10 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray10);
        byte[] byteArray14 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.remove(byteArray14, 0);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray11, byteArray14);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.add(byteArray14, (byte) 1);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray19, (int) (short) 1, (int) '4');
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray4, byteArray22);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(byteArray22, '4');
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join(byteArray22, '#');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10041" + "'", str25.equals("10041"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "100#1" + "'", str27.equals("100#1"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray6);
        boolean[] booleanArray16 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.add(booleanArray16, true);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, false, (int) (short) 0);
        boolean[] booleanArray29 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray31 = org.apache.commons.lang3.ArrayUtils.add(booleanArray29, true);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray31);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray31, false, (int) (short) 0);
        boolean[] booleanArray36 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray31);
        int int39 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, true, (int) ' ');
        boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray40);
        boolean[] booleanArray42 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray40);
        boolean[] booleanArray43 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray9, booleanArray42);
        boolean[] booleanArray44 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray9);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray44, false);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(booleanArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(booleanArray42);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertNotNull(booleanArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strArray3, (java.lang.Object[]) booleanArray4);
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray4);
        boolean[] booleanArray13 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.add(booleanArray13, true);
        boolean[] booleanArray16 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray13);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray13);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray13);
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray13, false);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray13, true, 100);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        char[] charArray4 = new char[] { '#', '#', '#', ' ' };
        char[] charArray8 = new char[] { 'a', ' ', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray8);
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.subarray(charArray4, 31, 0);
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.clone(charArray12);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray13);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        java.lang.Character[] charArray6 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6, 'a');
        java.lang.Character[] charArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray6);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6, ' ');
        java.lang.Object obj12 = null;
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) charArray6, obj12, 11);
        long[] longArray18 = new long[] { (short) 0, 'a', 100 };
        long[] longArray20 = new long[] { (short) 10 };
        long[] longArray21 = new long[] {};
        long[] longArray22 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray20, longArray21);
        long[] longArray23 = org.apache.commons.lang3.ArrayUtils.addAll(longArray18, longArray22);
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray23);
        long[] longArray26 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray23, (long) (byte) 0);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.join(longArray23, 'a', (int) 'a', (int) (byte) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray23);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) charArray6, (java.lang.Object) longArray23);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1a-1a-1", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "974100410410", (java.lang.CharSequence) "01a001a79a0                                                                                    ", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1 100", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray7);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray7, (int) (byte) 1);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (short) 10, (int) (byte) 0, (double) 0L);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray7, (double) (byte) 10);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) (short) 10, (double) (short) 1);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) 10, (double) 6);
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        java.lang.Byte[] byteArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_OBJECT_ARRAY;
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeJava("                                                                                      0A97A100A10   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                      0A97A100A10   " + "'", str1.equals("                                                                                      0A97A100A10   "));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10041", 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10041" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10041"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        java.lang.Float[] floatArray0 = new java.lang.Float[] {};
        float[] floatArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0, (float) ' ');
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray2);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 10);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper10 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray11 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] { unicodeEscaper10 };
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray12 = org.apache.commons.lang3.ArrayUtils.toArray(codePointTranslatorArray11);
        int[] intArray17 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(intArray17, (int) (byte) 0);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray17);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.add(intArray17, 10);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) codePointTranslatorArray12, (java.lang.Object) intArray17);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray17, (int) '4', 0);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.removeElements(intArray4, intArray17);
        int int29 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray4, 100);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(codePointTranslatorArray11);
        org.junit.Assert.assertNotNull(codePointTranslatorArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        java.lang.Long[] longArray2 = new java.lang.Long[] { 1L, 100L };
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2, (long) (short) 0);
        java.lang.Long[] longArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray2);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2, (long) 95);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        int[] intArray17 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(intArray17, (int) (byte) 0);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray17);
        java.lang.Integer[] intArray21 = new java.lang.Integer[] {};
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray21);
        int[] intArray23 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray22);
        int[] intArray28 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.contains(intArray28, (int) (byte) 0);
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray28);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray23, intArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray17, intArray23);
        float[] floatArray34 = org.apache.commons.lang3.ArrayUtils.removeAll(floatArray8, intArray23);
        int int37 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) (byte) 10, 95);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray22);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray18, floatArray22);
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.add(floatArray18, (float) 0);
        float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, 26, 1);
        float[] floatArray45 = org.apache.commons.lang3.ArrayUtils.clone(floatArray44);
        int[] intArray50 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.contains(intArray50, (int) (byte) 0);
        java.lang.String str54 = org.apache.commons.lang3.StringUtils.join(intArray50, '4');
        boolean boolean55 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray50);
        int int58 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray50, 0, 1);
        try {
            float[] floatArray59 = org.apache.commons.lang3.ArrayUtils.removeAll(floatArray45, intArray50);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "974100410410" + "'", str54.equals("974100410410"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 100);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, 10, 3);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray12);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray12, (int) (short) 10, (int) '4');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray16);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("------------------------------------------------------------------------------------AAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "------------------------------------------------------------------------------------AAA" + "'", str1.equals("------------------------------------------------------------------------------------AAA"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        org.apache.commons.lang3.text.translate.OctalUnescaper octalUnescaper0 = new org.apache.commons.lang3.text.translate.OctalUnescaper();
        java.io.Writer writer3 = null;
        int int4 = octalUnescaper0.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 6, writer3);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper5 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper6 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper7 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper8 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper9 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper10 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray11 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper5, unicodeUnescaper6, unicodeUnescaper7, unicodeUnescaper8, unicodeUnescaper9, unicodeUnescaper10 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray12 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray11);
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator13 = octalUnescaper0.with((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray12);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper14 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper15 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper16 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper17 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper18 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper19 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray20 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper14, unicodeUnescaper15, unicodeUnescaper16, unicodeUnescaper17, unicodeUnescaper18, unicodeUnescaper19 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray21 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray20);
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator22 = charSequenceTranslator13.with((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray21);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray11);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray12);
        org.junit.Assert.assertNotNull(charSequenceTranslator13);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray20);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray21);
        org.junit.Assert.assertNotNull(charSequenceTranslator22);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray8 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) 10);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray9);
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.add(shortArray12, (short) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray12);
        java.lang.Class<?> wildcardClass16 = shortArray12.getClass();
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1 100 1", (java.lang.CharSequence) "  23                      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray3);
        long[] longArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray3, (long) '4');
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) (short) 1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        char[] charArray3 = new char[] { 'a', 'a', ' ' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.remove(charArray3, (int) (byte) 1);
        char[] charArray10 = new char[] { '#', '#', '#', ' ' };
        char[] charArray14 = new char[] { 'a', ' ', '#' };
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.addAll(charArray10, charArray14);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray3, charArray14);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray17, 'a');
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray19, ' ');
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray14, charArray19);
        char[] charArray25 = org.apache.commons.lang3.ArrayUtils.subarray(charArray14, (int) (byte) 10, 95);
        char[] charArray29 = new char[] { 'a', 'a', ' ' };
        char[] charArray31 = org.apache.commons.lang3.ArrayUtils.remove(charArray29, (int) (byte) 1);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray31, 'a', (int) (short) 1);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray14, charArray31);
        try {
            java.lang.String str39 = org.apache.commons.lang3.StringUtils.join(charArray14, '4', 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1", "a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml4("1,-1,-1}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1,-1,-1}" + "'", str1.equals("1,-1,-1}"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray13 = new boolean[] { true, true, true, false };
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray13, false);
        boolean[] booleanArray22 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.add(booleanArray22, true);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray24);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray13, booleanArray24);
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray13);
        boolean[] booleanArray30 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray13, 26, (int) (short) 1);
        boolean[] booleanArray31 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray30);
        java.lang.String[] strArray34 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray35 = org.apache.commons.lang3.StringUtils.stripAll(strArray34);
        java.lang.Boolean[] booleanArray36 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strArray35, (java.lang.Object[]) booleanArray36);
        boolean[] booleanArray38 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray36);
        boolean[] booleanArray39 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray30, booleanArray38);
        boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray38);
        boolean[] booleanArray41 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray40);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray30);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(booleanArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(booleanArray38);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertNotNull(booleanArray41);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.remove(byteArray4, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray1, byteArray6);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray1, (byte) 10);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray5 = null;
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, 0, 0.0f);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray3, floatArray5);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray3);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.clone(floatArray3);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray11, (float) 10);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.clone(intArray14);
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.removeAll(floatArray11, intArray14);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        char[] charArray2 = new char[] { ' ', ' ' };
        char[] charArray4 = new char[] { '#' };
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.add(charArray4, '#');
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray2, charArray4);
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray4);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeCsv("1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0" + "'", str1.equals("1.0"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" ", "!                                                                                     0A97A100A10   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray8, (short) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray8);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray10);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.ISO8859_1_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        double[] doubleArray2 = null;
        double[] doubleArray3 = new double[] {};
        double[] doubleArray9 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray3, doubleArray9);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 26);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray3);
        java.lang.Double[] doubleArray20 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray20);
        double[] doubleArray22 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray21);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray22, (double) 2, (int) (byte) -1, (double) 0.0f);
        java.lang.Double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray22);
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray22, (double) (-1L), (double) (-1.0f));
        int int32 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) strArray1, (java.lang.Object) (-1.0f), (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        java.lang.Byte[] byteArray3 = new java.lang.Byte[] { (byte) 1, (byte) 10, (byte) -1 };
        java.lang.Byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray3);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray4, (byte) -1);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "10.04100.040.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeEcmaScript("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeEcmaScript("10041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10041" + "'", str1.equals("10041"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper2 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between(6, 6);
        org.junit.Assert.assertNotNull(unicodeEscaper2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        boolean[][][][] booleanArray0 = new boolean[][][][] {};
        java.lang.Integer[] intArray1 = new java.lang.Integer[] {};
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray1);
        int[] intArray3 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray2);
        int[] intArray8 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(intArray8, (int) (byte) 0);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray8);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray3, intArray11);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray11, 2);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.clone(intArray11);
        try {
            boolean[][][][] booleanArray16 = org.apache.commons.lang3.ArrayUtils.removeAll(booleanArray0, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(" ");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10010-1101", (java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "{{0.0},{0.0},{0.0},{0.0},{0.0}}", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray7);
        java.lang.Integer[] intArray12 = new java.lang.Integer[] {};
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray12);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray13);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.removeAll(doubleArray7, intArray13);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray15, (double) 95);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray22);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray18, floatArray22);
        float[] floatArray42 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray22, (int) (byte) -1, (int) ' ');
        float[] floatArray43 = org.apache.commons.lang3.ArrayUtils.clone(floatArray22);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(doubleArray7);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) (byte) 100, (double) '#');
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) doubleArray7, (java.lang.Object) "10#2#97#35#90#32#100");
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih0.1 0.1 0.1- 0.1 0.1- 0.1-h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", (java.lang.CharSequence) "{0,97,100,10}");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih0.1 0.1 0.1- 0.1 0.1- 0.1-h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", charSequence2.equals("h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih0.1 0.1 0.1- 0.1 0.1- 0.1-h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        java.lang.Byte[] byteArray3 = new java.lang.Byte[] { (byte) 1, (byte) 10, (byte) -1 };
        java.lang.Byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray3);
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray4);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray5, (byte) 0, 6);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray8);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray8, (long) (byte) 0);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray8, (long) 'a', 24);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, 1.0d, 10.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray0);
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(doubleArray0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray12, 'a');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "0a97a100a10                                                                                         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray14 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray19 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[][] byteArray20 = new byte[][] { byteArray4, byteArray9, byteArray14, byteArray19 };
        byte[] byteArray27 = new byte[] { (byte) -1, (byte) 1, (byte) -1, (byte) 0, (byte) 10, (byte) 10 };
        byte[][] byteArray28 = new byte[][] { byteArray27 };
        byte[][] byteArray29 = org.apache.commons.lang3.ArrayUtils.removeElements(byteArray20, byteArray28);
        byte[] byteArray33 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray35 = org.apache.commons.lang3.ArrayUtils.remove(byteArray33, 0);
        java.lang.String[][] strArray36 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_ESCAPE();
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) byteArray35, (java.lang.Object) strArray36);
        byte[][] byteArray38 = org.apache.commons.lang3.ArrayUtils.add(byteArray20, (int) (byte) 0, byteArray35);
        byte[] byteArray40 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray35, (byte) 10);
        java.lang.Byte[] byteArray46 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray47 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray46);
        byte[] byteArray50 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray52 = org.apache.commons.lang3.ArrayUtils.remove(byteArray50, 0);
        boolean boolean53 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray47, byteArray50);
        byte[] byteArray55 = org.apache.commons.lang3.ArrayUtils.add(byteArray50, (byte) 1);
        byte[] byteArray58 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray55, (int) (short) 1, (int) '4');
        int int60 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray55, (byte) 100);
        java.lang.String str62 = org.apache.commons.lang3.StringUtils.join(byteArray55, 'a');
        byte[] byteArray63 = org.apache.commons.lang3.ArrayUtils.removeElements(byteArray35, byteArray55);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertNotNull(byteArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertNotNull(byteArray58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "-1a100a1" + "'", str62.equals("-1a100a1"));
        org.junit.Assert.assertNotNull(byteArray63);
    }
}

