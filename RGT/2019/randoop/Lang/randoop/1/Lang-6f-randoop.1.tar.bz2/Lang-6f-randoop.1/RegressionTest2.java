import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "  23  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        char[] charArray7 = new char[] { '#', 'a', '#', 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                     ...", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("10,3,2}", (int) (short) 0, 24);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10,3,2}" + "'", str3.equals("10,3,2}"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI", "#a4a aaa4aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        java.lang.String str1 = org.apache.commons.lang3.text.translate.CharSequenceTranslator.hex((int) (short) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "64" + "'", str1.equals("64"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) 2, (int) '#', (double) (short) 10);
        java.lang.Double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray7);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray13);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) doubleArray13, 'a', 5, 90);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        java.lang.Float[] floatArray5 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) floatArray5, "                                                                                    0a97a100a10", (int) (short) 0, 0);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, (float) 'a');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeJava("10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10" + "'", str1.equals("10"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1a100a1", 0, 90);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        java.lang.Integer[] intArray4 = new java.lang.Integer[] {};
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray5);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray3, intArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(intArray6);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        float[] floatArray0 = null;
        try {
            float[] floatArray3 = org.apache.commons.lang3.ArrayUtils.add(floatArray0, 6, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray7, (byte) 0, (int) (short) -1);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray1, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 26);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray1);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray18);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray19);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray20, (double) 2, (int) (byte) -1, (double) 0.0f);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray20, (double) (-1), 6, (double) (-1L));
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        boolean[] booleanArray1 = new boolean[] { false };
        int int4 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray1, true, 1);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, 1.0d, 10.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray0);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray0, 11, (int) (short) 10);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray14, (double) (short) 1, (int) (byte) 10, (double) (short) -1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        long[][] longArray0 = null;
        long[] longArray5 = new long[] { (short) 0, 'a', 100 };
        long[] longArray7 = new long[] { (short) 10 };
        long[] longArray8 = new long[] {};
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray7, longArray8);
        long[] longArray10 = org.apache.commons.lang3.ArrayUtils.addAll(longArray5, longArray9);
        long[] longArray14 = new long[] { (short) 0, 'a', 100 };
        long[] longArray16 = new long[] { (short) 10 };
        long[] longArray17 = new long[] {};
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray16, longArray17);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray18);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.addAll(longArray5, longArray18);
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.clone(longArray20);
        long[] longArray22 = null;
        long[] longArray23 = org.apache.commons.lang3.ArrayUtils.addAll(longArray21, longArray22);
        java.lang.String str25 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) longArray21, "h-1.0 -1.0 1.0 -1.0 1.0 1.0h");
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray21);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray21, (long) 0);
        try {
            long[][] longArray29 = org.apache.commons.lang3.ArrayUtils.add(longArray0, (int) (short) 10, longArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "{0,97,100,10}" + "'", str25.equals("{0,97,100,10}"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("{0,97,100,10}", "                                                 34                                                 ", "97a100a10a10");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.ISO8859_1_UNESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "          ", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "-1a100a1", 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        java.lang.Integer[] intArray8 = new java.lang.Integer[] {};
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray8);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray9);
        int[] intArray15 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(intArray15, (int) (byte) 0);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray15);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray10, intArray18);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray4, intArray10);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(intArray10);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("97410041041040", "{-1,3,100,10,3,2", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.0");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.lang.Float[][][] floatArray0 = null;
        java.lang.Float[][][] floatArray3 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray0, 3, (int) (byte) 100);
        org.junit.Assert.assertNull(floatArray3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.040.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.040.0" + "'", str1.equals("1.040.0"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("0-1.01.01.0h", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0-1.01.01.0h" + "'", str2.equals("0-1.01.01.0h"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.String[] strArray4 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray9 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray14 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray19 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[][] strArray20 = new java.lang.String[][] { strArray4, strArray9, strArray14, strArray19 };
        java.lang.String[][] strArray21 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray20);
        org.apache.commons.lang3.text.translate.LookupTranslator lookupTranslator22 = new org.apache.commons.lang3.text.translate.LookupTranslator((java.lang.CharSequence[][]) strArray21);
        java.io.Writer writer25 = null;
        int int26 = lookupTranslator22.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (int) (byte) 0, writer25);
        java.io.Writer writer29 = null;
        int int30 = lookupTranslator22.translate((java.lang.CharSequence) "97a100a10a10", 31, writer29);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray3);
        float[] floatArray21 = new float[] { 'a' };
        float[] floatArray23 = new float[] { (byte) -1 };
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray21, floatArray23);
        float[] floatArray31 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray33 = new float[] { 'a' };
        float[] floatArray35 = new float[] { (byte) -1 };
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray33, floatArray35);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray31, floatArray33);
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray23, floatArray31);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray31, (float) 10, 100);
        float[] floatArray42 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray3, floatArray31);
        int int44 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray3, (float) 95);
        float[] floatArray46 = org.apache.commons.lang3.ArrayUtils.add(floatArray3, (float) 24);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(floatArray46);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray10 = new long[] { (short) 10 };
        long[] longArray11 = new long[] {};
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray10, longArray11);
        java.lang.Integer[] intArray13 = new java.lang.Integer[] {};
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray13);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray14);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray12, intArray15);
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray16, (long) (short) 0, 2);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray3, longArray16);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(longArray20);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray8 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) 10);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray9);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray3, 0, 95);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.add(shortArray15, (short) (byte) 100);
        java.lang.Short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray15);
        try {
            short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.remove(shortArray15, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray18);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 2);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.clone(intArray10);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        java.lang.CharSequence charSequence17 = null;
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "hi!");
        int int21 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence17, (java.lang.CharSequence[]) strArray20);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray20);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "5F", (java.lang.CharSequence[]) strArray20);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) intArray15, (java.lang.Object) boolean23);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray6);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, false);
        boolean[] booleanArray18 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.add(booleanArray18, true);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray20);
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray20, false, (int) (short) 0);
        boolean[] booleanArray31 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray33 = org.apache.commons.lang3.ArrayUtils.add(booleanArray31, true);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray33);
        int int37 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray33, false, (int) (short) 0);
        boolean[] booleanArray38 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray20, booleanArray33);
        boolean[] booleanArray39 = org.apache.commons.lang3.ArrayUtils.removeElements(booleanArray6, booleanArray38);
        try {
            boolean[] booleanArray41 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray39, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(booleanArray38);
        org.junit.Assert.assertNotNull(booleanArray39);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                                                      0a97a100a10  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("h-1.0 -1.0 1.0 -1.0 1.0 1.0h", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0h 1.0 -1.0 1.0 -1.0 h-1.0" + "'", str2.equals("1.0h 1.0 -1.0 1.0 -1.0 h-1.0"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        char[] charArray0 = null;
        java.lang.Character[] charArray7 = new java.lang.Character[] { '4', ' ', '#', '4', 'a', 'a' };
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray7);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.addAll(charArray0, charArray8);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        char[] charArray0 = null;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray0, '4');
        org.junit.Assert.assertNull(charArray2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray5);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray6, (int) ' ', (int) (byte) 10);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', 31, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0a97a100a10", "a#4#a# #4##", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "09710010" + "'", str3.equals("09710010"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 100);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray9, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        java.lang.Object[] objArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_OBJECT_ARRAY;
        boolean[] booleanArray5 = new boolean[] { true, true, true, false };
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray5, false);
        java.lang.Class<?> wildcardClass8 = booleanArray5.getClass();
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray5, false);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(objArray0, (java.lang.Object) false);
        org.junit.Assert.assertNotNull(objArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("#####", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(doubleArray7);
        try {
            double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray7, (-1), 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("09710010");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "09710010" + "'", str1.equals("09710010"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "{0,97,100,10}", charArray2);
        char[] charArray7 = new char[] { 'a', 'a', ' ' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.remove(charArray7, (int) (byte) 1);
        char[] charArray14 = new char[] { '#', '#', '#', ' ' };
        char[] charArray18 = new char[] { 'a', ' ', '#' };
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.addAll(charArray14, charArray18);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray7, charArray18);
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        char[] charArray23 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray21, 'a');
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray23, ' ');
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray18, charArray23);
        char[] charArray27 = org.apache.commons.lang3.ArrayUtils.addAll(charArray2, charArray18);
        boolean boolean28 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", charArray18);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeJava("0-1.01.01.0h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0-1.01.01.0h" + "'", str1.equals("0-1.01.01.0h"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        float[] floatArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray0, 100.0f, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "!", 10);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap4 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) strArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, '', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1", (java.lang.CharSequence) "                                             0 97 100 1                                             ", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        java.lang.Integer[] intArray8 = new java.lang.Integer[] {};
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray8);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray9);
        int[] intArray15 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(intArray15, (int) (byte) 0);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray15);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray10, intArray18);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray4, intArray10);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray22);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray22, (int) (short) 1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        char[] charArray5 = new char[] { '#', '#', '#', ' ' };
        char[] charArray9 = new char[] { 'a', ' ', '#' };
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.addAll(charArray5, charArray9);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray5, '#', 26);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0a9hi!0a97", charArray5);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(charArray5, 'a');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "A", (java.lang.CharSequence) "     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                                                                      0a97a100a10  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a97a100a10" + "'", str1.equals("0a97a100a10"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "hi!");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "{-1,3,100,10,3,2}", (java.lang.CharSequence[]) strArray3);
        java.lang.Integer[] intArray5 = new java.lang.Integer[] {};
        java.lang.Integer[][] intArray6 = new java.lang.Integer[][] { intArray5 };
        java.lang.Integer[][] intArray7 = org.apache.commons.lang3.ArrayUtils.toArray(intArray6);
        int[] intArray12 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(intArray12, (int) (byte) 0);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray12);
        java.lang.Integer[] intArray16 = new java.lang.Integer[] {};
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray16);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray17);
        int[] intArray23 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.contains(intArray23, (int) (byte) 0);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray23);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray18, intArray26);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray12, intArray18);
        java.lang.Integer[] intArray29 = org.apache.commons.lang3.ArrayUtils.toObject(intArray12);
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) intArray7, (java.lang.Object) intArray12, 4);
        int[] intArray32 = org.apache.commons.lang3.ArrayUtils.clone(intArray12);
        int int33 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) strArray3, (java.lang.Object) intArray12);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        char[] charArray3 = new char[] { 'a', 'a', ' ' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.remove(charArray3, (int) (byte) 1);
        char[] charArray10 = new char[] { '#', '#', '#', ' ' };
        char[] charArray14 = new char[] { 'a', ' ', '#' };
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.addAll(charArray10, charArray14);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray3, charArray14);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray17, 'a');
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray19, ' ');
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray14, charArray19);
        char[] charArray25 = org.apache.commons.lang3.ArrayUtils.subarray(charArray14, (int) (byte) 10, 95);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join(charArray25, ' ');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray1, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 26);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray1);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray18);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray19);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray20, (double) 2, (int) (byte) -1, (double) 0.0f);
        java.lang.Double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray20);
        java.lang.Double[] doubleArray26 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 100, 0);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, (-1), (int) (short) 100);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.add(byteArray6, 5, (byte) 0);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray15);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "97410041041040", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 2);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.clone(intArray10);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.clone(intArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(intArray15);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("h-1.0-1.01.0-1.01.01.0h", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h-1.0-1.01.0-1.01.01.0h" + "'", str2.equals("h-1.0-1.01.0-1.01.01.0h"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray5 = null;
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, 0, 0.0f);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray3, floatArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_UNESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isEmpty((java.lang.Object[]) strArray0);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isNotEmpty((java.lang.Comparable<java.lang.String>[]) strArray4);
        java.lang.Long[] longArray7 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_OBJECT_ARRAY;
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strArray4, (java.lang.Object[]) longArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.040.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("------------------------------------------------------------------------------------AAA", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "------------------------------------------------------------------------------------AAA" + "'", str2.equals("------------------------------------------------------------------------------------AAA"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih0.1 0.1 0.1- 0.1 0.1- 0.1-h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str1.equals("h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih0.1 0.1 0.1- 0.1 0.1- 0.1-h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (short) 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray6, 3, (short) (byte) -1);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray6, (short) (byte) 0);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1a-1a-1" + "'", str8.equals("1a-1a-1"));
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml3("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "{0,97,u00,u0}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "{0,97,u00,u0}");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "{-1,3,100,10,3,2");
            org.junit.Assert.fail("Expected exception of type java.util.regex.PatternSyntaxException; message: Illegal repetition\n{-1,3,100,10,3,2");
        } catch (java.util.regex.PatternSyntaxException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("{{0.0},{0.0},{0.0},{0.0},{0.0}}", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}" + "'", str3.equals("{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.apache.commons.lang3.StringUtils stringUtils0 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils1 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils2 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils3 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils4 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils5 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils[] stringUtilsArray6 = new org.apache.commons.lang3.StringUtils[] { stringUtils0, stringUtils1, stringUtils2, stringUtils3, stringUtils4, stringUtils5 };
        org.apache.commons.lang3.StringUtils[] stringUtilsArray7 = org.apache.commons.lang3.ArrayUtils.clone(stringUtilsArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) stringUtilsArray7, 'a');
        org.junit.Assert.assertNotNull(stringUtilsArray6);
        org.junit.Assert.assertNotNull(stringUtilsArray7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.040.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1 100", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("{-1,3,100,10,3,2", "aa4aaa a4a#", "97a100a10a10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{-1,3,100,10,3,2" + "'", str3.equals("{-1,3,100,10,3,2"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "h-1.0 -1.0 1.0 -1.0 1.0 1.0h", 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0", (java.lang.CharSequence) "0a97a100a10                                                                                         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "64", charSequence1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        char[] charArray1 = new char[] { '#' };
        char[] charArray3 = org.apache.commons.lang3.ArrayUtils.add(charArray1, '#');
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray3);
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.clone(charArray3);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 10);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        java.lang.Byte[] byteArray21 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray21);
        byte[] byteArray25 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.remove(byteArray25, 0);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray22, byteArray25);
        byte[] byteArray30 = org.apache.commons.lang3.ArrayUtils.add(byteArray25, (byte) 1);
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray30);
        byte[] byteArray32 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray9, byteArray30);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertNotNull(byteArray32);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        byte[] byteArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray0, (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "{-1,3,100,10,3,2", (java.lang.CharSequence) "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION0 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.semiColonOptional;
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray1 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray2 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper3 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray2);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION4 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        boolean boolean5 = numericEntityUnescaper3.isSet(oPTION4);
        java.lang.Enum<org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION>[] oPTIONEnumArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Enum<org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION>[]) oPTIONArray1, (java.lang.Enum<org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION>) oPTION4);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray7 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray8 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper9 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray8);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION10 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        boolean boolean11 = numericEntityUnescaper9.isSet(oPTION10);
        java.lang.Enum<org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION>[] oPTIONEnumArray12 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Enum<org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION>[]) oPTIONArray7, (java.lang.Enum<org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION>) oPTION10);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray13 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] { oPTION0, oPTION4, oPTION10 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray15 = org.apache.commons.lang3.ArrayUtils.remove(oPTIONArray13, 1);
        org.junit.Assert.assertTrue("'" + oPTION0 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.semiColonOptional + "'", oPTION0.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.semiColonOptional));
        org.junit.Assert.assertNotNull(oPTIONArray1);
        org.junit.Assert.assertNotNull(oPTIONArray2);
        org.junit.Assert.assertTrue("'" + oPTION4 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION4.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(oPTIONEnumArray6);
        org.junit.Assert.assertNotNull(oPTIONArray7);
        org.junit.Assert.assertNotNull(oPTIONArray8);
        org.junit.Assert.assertTrue("'" + oPTION10 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION10.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(oPTIONEnumArray12);
        org.junit.Assert.assertNotNull(oPTIONArray13);
        org.junit.Assert.assertNotNull(oPTIONArray15);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(floatArray6);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray6, (float) 1L);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.0", (java.lang.CharSequence) "###########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "10010-1101");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator0 = org.apache.commons.lang3.StringEscapeUtils.ESCAPE_HTML4;
        java.lang.String str2 = charSequenceTranslator0.translate((java.lang.CharSequence) "{0,97,100,10}                   ");
        org.junit.Assert.assertNotNull(charSequenceTranslator0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0,97,100,10}                   " + "'", str2.equals("{0,97,100,10}                   "));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray22);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray18, floatArray22);
        float[] floatArray42 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray22, (int) (byte) -1, (int) ' ');
        float[] floatArray44 = new float[] { 'a' };
        float[] floatArray46 = new float[] { (byte) -1 };
        boolean boolean47 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray44, floatArray46);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) (byte) -1, (java.lang.Object) floatArray46);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "0 97 100 10", (java.lang.CharSequence) "{0,97,100,10}");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "14-14-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml4("                                                                                    0a97a100a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                    0a97a100a10" + "'", str1.equals("                                                                                    0a97a100a10"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.Float[] floatArray0 = new java.lang.Float[] {};
        float[] floatArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0, (float) ' ');
        java.lang.Float[] floatArray3 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(floatArray0);
        java.lang.Float[] floatArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(floatArray0);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray14, (int) (short) 1, (int) '4');
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray14, (byte) 1);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray14, (byte) 10);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(byteArray14, ' ');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-1 100 1" + "'", str23.equals("-1 100 1"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1.0 -1.0 1.0 -1.0 1.0 1.0", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        java.lang.String[] strArray5 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str4.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 100);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, 10, 3);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray12);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray12, (byte) 10);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray12, (byte) 0, 11);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        java.lang.Integer[] intArray8 = new java.lang.Integer[] {};
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray8);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray9);
        int[] intArray15 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(intArray15, (int) (byte) 0);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray15);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray10, intArray18);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray4, intArray10);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 0);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray22, (int) (short) 1, 10);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray22, (int) (short) 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(doubleArray7);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray11, (double) 3);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        java.lang.Byte[] byteArray18 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray18);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray18);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray18, (byte) 100);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray22, 10, 3);
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray22);
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.join(byteArray26, '#');
        byte[] byteArray31 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray33 = org.apache.commons.lang3.ArrayUtils.remove(byteArray31, 0);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray26, byteArray31);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1#1#10#10#10#-1#1#10#10#10" + "'", str28.equals("-1#1#10#10#10#-1#1#10#10#10"));
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray3);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', 31, 0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 2);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray10);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.subarray(intArray10, 6, 10);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray17);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray17, (int) 'a');
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray8 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) 10);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray9);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(shortArray3, (short) (byte) 1);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray3, (short) (byte) 10);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(shortArray17, '4');
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray17, (short) (byte) 1);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray17);
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray17);
        short[] shortArray26 = org.apache.commons.lang3.ArrayUtils.removeElements(shortArray3, shortArray17);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(shortArray26);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.Byte[] byteArray3 = new java.lang.Byte[] { (byte) 1, (byte) 10, (byte) -1 };
        java.lang.Byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray3);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray4, (byte) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) byteArray4, "0a97a100a10                                                                                         ", 3, 0);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("34", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "34" + "'", str2.equals("34"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (short) 0);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, 3, (short) 10);
        java.lang.Short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        java.lang.Short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray11);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.0", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.01.01.01.01.01.01.01.01.01.01.0" + "'", str2.equals("1.01.01.01.01.01.01.01.01.01.01.0"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("-1a100a1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray7);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray7, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray10, (double) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                      0A97A100A10   ", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                      0A97A100A10   " + "'", str3.equals("                                                                                      0A97A100A10   "));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        char[] charArray4 = new char[] { '#', '#', '#', ' ' };
        char[] charArray8 = new char[] { 'a', ' ', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray8);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray9);
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.add(charArray10, '4');
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.subarray(charArray12, (int) '4', 0);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray15, ' ');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test118");
//        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_ESCAPE();
//        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
//        java.util.Map<java.lang.Object, java.lang.Object> objMap2 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) strArray1);
//        java.util.Map[] mapArray4 = new java.util.Map[1];
//        @SuppressWarnings("unchecked") java.util.Map<java.lang.Object, java.lang.Object>[] objMapArray5 = (java.util.Map<java.lang.Object, java.lang.Object>[]) mapArray4;
//        objMapArray5[0] = objMap2;
//        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(objMapArray5);
//        java.lang.Integer[] intArray15 = new java.lang.Integer[] { (-1), 3, 100, 10, 3, 2 };
//        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray15, (int) '4');
//        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray17, 2, 0);
//        try {
//            java.util.Map<java.lang.Object, java.lang.Object>[] objMapArray21 = org.apache.commons.lang3.ArrayUtils.removeAll(objMapArray5, intArray17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(strArray0);
//        org.junit.Assert.assertNotNull(strArray1);
//        org.junit.Assert.assertNotNull(objMap2);
//        org.junit.Assert.assertNotNull(mapArray4);
//        org.junit.Assert.assertNotNull(objMapArray5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{&gt;=>, &quot;=\", &amp;=&, &lt;=<}" + "'", str8.equals("{&gt;=>, &quot;=\", &amp;=&, &lt;=<}"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { (-1), 3, 100, 10, 3, 2 };
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray6, (int) '4');
        java.lang.Integer[] intArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml3("-1.0435.040.041.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0435.040.041.04-1.0410.0" + "'", str1.equals("-1.0435.040.041.04-1.0410.0"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray3);
        long[] longArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray3, (long) '4');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray3, (long) (short) 0, 26);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray3);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray3);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.add(longArray11, (long) '4');
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray13);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray14);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray4);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.subarray(intArray4, 2, (int) (byte) -1);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1a-1a-1", (int) (short) -1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("0 97 100 10", "  23  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 97 100 10" + "'", str2.equals("0 97 100 10"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                      0a97a100a10  ", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                      0a97a100a10  " + "'", str3.equals("                                                                                      0a97a100a10  "));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        java.lang.Integer[][] intArray1 = new java.lang.Integer[][] { intArray0 };
        java.lang.Integer[][] intArray2 = org.apache.commons.lang3.ArrayUtils.toArray(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        java.lang.Integer[] intArray11 = new java.lang.Integer[] {};
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray11);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray12);
        int[] intArray18 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.contains(intArray18, (int) (byte) 0);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray18);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray13, intArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray7, intArray13);
        java.lang.Integer[] intArray24 = org.apache.commons.lang3.ArrayUtils.toObject(intArray7);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) intArray2, (java.lang.Object) intArray7, 4);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.clone(intArray7);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(intArray7);
        java.lang.Integer[] intArray29 = new java.lang.Integer[] {};
        int[] intArray30 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray29);
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray30);
        int[] intArray36 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.contains(intArray36, (int) (byte) 0);
        int[] intArray39 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray36);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray31, intArray39);
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray39, 2);
        int[] intArray43 = org.apache.commons.lang3.ArrayUtils.clone(intArray39);
        int[] intArray44 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray39);
        int[] intArray45 = org.apache.commons.lang3.ArrayUtils.clone(intArray44);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray7, intArray44);
        java.lang.Integer[] intArray47 = new java.lang.Integer[] {};
        java.lang.Integer[][] intArray48 = new java.lang.Integer[][] { intArray47 };
        java.lang.Integer[][] intArray49 = org.apache.commons.lang3.ArrayUtils.toArray(intArray48);
        int[] intArray54 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean56 = org.apache.commons.lang3.ArrayUtils.contains(intArray54, (int) (byte) 0);
        int[] intArray57 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray54);
        java.lang.Integer[] intArray58 = new java.lang.Integer[] {};
        int[] intArray59 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray58);
        int[] intArray60 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray59);
        int[] intArray65 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean67 = org.apache.commons.lang3.ArrayUtils.contains(intArray65, (int) (byte) 0);
        int[] intArray68 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray65);
        boolean boolean69 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray60, intArray68);
        boolean boolean70 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray54, intArray60);
        java.lang.Integer[] intArray71 = org.apache.commons.lang3.ArrayUtils.toObject(intArray54);
        int int73 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) intArray49, (java.lang.Object) intArray54, 4);
        int[] intArray74 = org.apache.commons.lang3.ArrayUtils.clone(intArray54);
        boolean boolean75 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(intArray54);
        java.lang.Integer[] intArray76 = new java.lang.Integer[] {};
        int[] intArray77 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray76);
        int[] intArray78 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray77);
        int[] intArray83 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean85 = org.apache.commons.lang3.ArrayUtils.contains(intArray83, (int) (byte) 0);
        int[] intArray86 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray83);
        boolean boolean87 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray78, intArray86);
        int int89 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray86, 2);
        int[] intArray90 = org.apache.commons.lang3.ArrayUtils.clone(intArray86);
        int[] intArray91 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray86);
        int[] intArray92 = org.apache.commons.lang3.ArrayUtils.clone(intArray91);
        boolean boolean93 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray54, intArray91);
        java.lang.String str97 = org.apache.commons.lang3.StringUtils.join(intArray91, 'a', 26, (int) (short) 1);
        int[] intArray98 = org.apache.commons.lang3.ArrayUtils.removeElements(intArray7, intArray91);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1) + "'", int89 == (-1));
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "" + "'", str97.equals(""));
        org.junit.Assert.assertNotNull(intArray98);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                 34                                                 ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray22);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray18, floatArray22);
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.add(floatArray18, (float) 0);
        float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, 26, 1);
        float[] floatArray46 = new float[] { 'a' };
        float[] floatArray48 = new float[] { (byte) -1 };
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray46, floatArray48);
        float[] floatArray56 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray58 = new float[] { 'a' };
        float[] floatArray60 = new float[] { (byte) -1 };
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray58, floatArray60);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray56, floatArray58);
        float[] floatArray63 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray48, floatArray56);
        float[] floatArray66 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray56, 26, (int) '4');
        float[] floatArray67 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray44, floatArray56);
        float[] floatArray70 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray56, (int) (byte) 100, (int) (byte) 1);
        int int73 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray56, (float) (byte) -1, (int) ' ');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray70);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 3 + "'", int73 == 3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.String[] strArray4 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray9 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray14 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray19 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[][] strArray20 = new java.lang.String[][] { strArray4, strArray9, strArray14, strArray19 };
        java.lang.String[][] strArray21 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray20);
        org.apache.commons.lang3.text.translate.LookupTranslator lookupTranslator22 = new org.apache.commons.lang3.text.translate.LookupTranslator((java.lang.CharSequence[][]) strArray21);
        java.io.Writer writer25 = null;
        int int26 = lookupTranslator22.translate((java.lang.CharSequence) "1 100", 2, writer25);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        char[] charArray4 = new char[] { '#', '#', '#', ' ' };
        char[] charArray8 = new char[] { 'a', ' ', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray9, '4');
        try {
            char[] charArray13 = org.apache.commons.lang3.ArrayUtils.remove(charArray9, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 7");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray8 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) 10);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray9);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray3, 0, 95);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(shortArray3, (short) 1);
        short[] shortArray18 = null;
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray3, shortArray18);
        java.lang.Short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray18);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(shortArray20);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeXml("{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}" + "'", str1.equals("{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0971001", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0971001" + "'", str2.equals("0971001"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                      0A97A100A10   ", 99, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                      0A97A100A10   " + "'", str3.equals("                                                                                      0A97A100A10   "));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        float[] floatArray1 = new float[] { 90 };
        float[] floatArray3 = new float[] { 90 };
        float[] floatArray5 = new float[] { 90 };
        float[] floatArray7 = new float[] { 90 };
        float[] floatArray9 = new float[] { 90 };
        float[][] floatArray10 = new float[][] { floatArray1, floatArray3, floatArray5, floatArray7, floatArray9 };
        float[] floatArray12 = new float[] { 90 };
        float[] floatArray14 = new float[] { 90 };
        float[] floatArray16 = new float[] { 90 };
        float[] floatArray18 = new float[] { 90 };
        float[] floatArray20 = new float[] { 90 };
        float[][] floatArray21 = new float[][] { floatArray12, floatArray14, floatArray16, floatArray18, floatArray20 };
        float[] floatArray23 = new float[] { 90 };
        float[] floatArray25 = new float[] { 90 };
        float[] floatArray27 = new float[] { 90 };
        float[] floatArray29 = new float[] { 90 };
        float[] floatArray31 = new float[] { 90 };
        float[][] floatArray32 = new float[][] { floatArray23, floatArray25, floatArray27, floatArray29, floatArray31 };
        float[][][] floatArray33 = new float[][][] { floatArray10, floatArray21, floatArray32 };
        float[] floatArray37 = new float[] { (byte) 100, (short) -1 };
        float[] floatArray40 = new float[] { (byte) 100, (short) -1 };
        float[] floatArray43 = new float[] { (byte) 100, (short) -1 };
        float[][] floatArray44 = new float[][] { floatArray37, floatArray40, floatArray43 };
        float[][] floatArray46 = org.apache.commons.lang3.ArrayUtils.remove(floatArray44, 0);
        try {
            float[][][] floatArray47 = org.apache.commons.lang3.ArrayUtils.add(floatArray33, 6, floatArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray46);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        boolean[] booleanArray0 = null;
        java.lang.Boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray0);
        org.junit.Assert.assertNull(booleanArray1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray6, (byte) -1);
        java.lang.Integer[] intArray9 = new java.lang.Integer[] {};
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray9);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        int[] intArray16 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(intArray16, (int) (byte) 0);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray16);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray11, intArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray19, 2);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray19);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.subarray(intArray19, 6, 10);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.removeAll(byteArray8, intArray26);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(byteArray27);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "#a4a aaa4aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.apache.commons.lang3.text.translate.OctalUnescaper octalUnescaper0 = new org.apache.commons.lang3.text.translate.OctalUnescaper();
        java.io.Writer writer3 = null;
        int int4 = octalUnescaper0.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 6, writer3);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper5 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper6 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper7 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper8 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper9 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper10 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray11 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper5, unicodeUnescaper6, unicodeUnescaper7, unicodeUnescaper8, unicodeUnescaper9, unicodeUnescaper10 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray12 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray11);
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator13 = octalUnescaper0.with((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray12);
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray16 = org.apache.commons.lang3.ArrayUtils.subarray((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray12, (-1), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray11);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray12);
        org.junit.Assert.assertNotNull(charSequenceTranslator13);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray16);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aa4aaa a4a#", "1 100", (-1));
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aa4aaa a4a#" + "'", str4.equals("aa4aaa a4a#"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        char[] charArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray0, 'a', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeCsv("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        char[] charArray1 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "{0,97,100,10}", charArray1);
        char[] charArray6 = new char[] { 'a', 'a', ' ' };
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.remove(charArray6, (int) (byte) 1);
        char[] charArray13 = new char[] { '#', '#', '#', ' ' };
        char[] charArray17 = new char[] { 'a', ' ', '#' };
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.addAll(charArray13, charArray17);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray6, charArray17);
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray20, 'a');
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray22, ' ');
        char[] charArray25 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray17, charArray22);
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.addAll(charArray1, charArray17);
        java.lang.Character[] charArray27 = org.apache.commons.lang3.ArrayUtils.toObject(charArray26);
        char[] charArray29 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray26, '4');
        try {
            char[] charArray31 = org.apache.commons.lang3.ArrayUtils.remove(charArray26, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(charArray29);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.Long[] longArray2 = new java.lang.Long[] { 1L, 100L };
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray3, 0L);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        java.io.Serializable[][] serializableArray0 = null;
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_ESCAPE();
        java.lang.Object[][] objArray2 = org.apache.commons.lang3.ArrayUtils.toArray((java.lang.Object[][]) strArray1);
        java.io.Serializable[][] serializableArray3 = org.apache.commons.lang3.ArrayUtils.addAll(serializableArray0, (java.io.Serializable[][]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(serializableArray3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("a#4#a# #4##", "", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1), 1.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        java.lang.Integer[] intArray1 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray0);
        int[] intArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0, (int) (byte) 0);
        java.lang.Integer[] intArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray0);
        java.lang.Integer[] intArray5 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.Class<?>[] wildcardClassArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.reflect.Type[] typeArray3 = org.apache.commons.lang3.ArrayUtils.subarray((java.lang.reflect.Type[]) wildcardClassArray0, 0, 0);
        java.lang.Object[] objArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty((java.lang.Object[]) typeArray3);
        org.junit.Assert.assertNotNull(wildcardClassArray0);
        org.junit.Assert.assertNotNull(typeArray3);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", (java.lang.CharSequence) "10010-1101");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####H#####I#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####", (java.lang.CharSequence) "A", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (short) 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        int int9 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) shortArray4);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1a-1a-1" + "'", str8.equals("1a-1a-1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("64", "{1,-1,-1}");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "64" + "'", str2.equals("64"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "A", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, 0, (int) ' ');
        java.lang.Byte[] byteArray23 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray23);
        byte[] byteArray27 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray29 = org.apache.commons.lang3.ArrayUtils.remove(byteArray27, 0);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray24, byteArray27);
        byte[] byteArray32 = org.apache.commons.lang3.ArrayUtils.add(byteArray27, (byte) 10);
        byte[] byteArray33 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray9, byteArray32);
        java.lang.Byte[] byteArray39 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray40 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray39);
        byte[] byteArray41 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray39);
        byte[] byteArray43 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray39, (byte) 100);
        byte[] byteArray45 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray39, (byte) 1);
        int int48 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray45, (byte) 0, 3);
        byte[] byteArray49 = org.apache.commons.lang3.ArrayUtils.removeElements(byteArray9, byteArray45);
        try {
            byte[] byteArray51 = org.apache.commons.lang3.ArrayUtils.remove(byteArray49, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(byteArray49);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("-1 100 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 100 1" + "'", str1.equals("-1 100 1"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray8, (short) 10, 26);
        java.lang.Integer[] intArray12 = new java.lang.Integer[] {};
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray12);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray13);
        java.lang.Integer[] intArray15 = new java.lang.Integer[] {};
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray15);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray16);
        int[] intArray22 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.contains(intArray22, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray22);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray17, intArray25);
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray25, 2);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.clone(intArray25);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray14, intArray25);
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(intArray31);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray31, (int) (short) 0);
        int[] intArray36 = org.apache.commons.lang3.ArrayUtils.add(intArray31, (-1));
        int[] intArray37 = org.apache.commons.lang3.ArrayUtils.removeAll(intArray14, intArray31);
        short[] shortArray38 = org.apache.commons.lang3.ArrayUtils.removeAll(shortArray8, intArray14);
        try {
            short[] shortArray41 = org.apache.commons.lang3.ArrayUtils.add(shortArray8, (int) ' ', (short) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(shortArray38);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "1.0");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "{0,97,u00,u0}", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0 97 100 10", "0a97a100a10");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "1.0");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("h-1.0 -1.0 1.0 -1.0 1.0 1.0h", strArray9, strArray12);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) strArray9, (java.lang.Object) '#');
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1", strArray4, strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "h-1.0 -1.0 1.0 -1.0 1.0 1.0h" + "'", str13.equals("h-1.0 -1.0 1.0 -1.0 1.0 1.0h"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("          ", "------------------------------------------------------------------------------------AAA", "1.01.01.01.01.01.01.01.01.01.01.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) doubleArray2, '4');
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray2, (double) (-1L));
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper8 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper9 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray10 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper8, unicodeEscaper9 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator11 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray10);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper12 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper13 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray14 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper12, unicodeEscaper13 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator15 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray14);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper16 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper17 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray18 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper16, unicodeEscaper17 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator19 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray18);
        java.lang.String str21 = aggregateTranslator19.translate((java.lang.CharSequence) "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper22 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper23 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray24 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper22, unicodeEscaper23 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator25 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray24);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper26 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper27 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper28 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper29 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper30 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper31 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray32 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper26, unicodeUnescaper27, unicodeUnescaper28, unicodeUnescaper29, unicodeUnescaper30, unicodeUnescaper31 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray33 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray32);
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator34 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray32);
        org.apache.commons.lang3.text.translate.AggregateTranslator[] aggregateTranslatorArray35 = new org.apache.commons.lang3.text.translate.AggregateTranslator[] { aggregateTranslator11, aggregateTranslator15, aggregateTranslator19, aggregateTranslator25, aggregateTranslator34 };
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper36 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper37 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray38 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper36, unicodeEscaper37 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator39 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray38);
        java.lang.String str41 = aggregateTranslator39.translate((java.lang.CharSequence) "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper42 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper43 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray44 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper42, unicodeEscaper43 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator45 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray44);
        java.lang.CharSequence charSequence46 = null;
        java.lang.String str47 = aggregateTranslator45.translate(charSequence46);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper48 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper49 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper50 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper51 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper52 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper53 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray54 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper48, unicodeUnescaper49, unicodeUnescaper50, unicodeUnescaper51, unicodeUnescaper52, unicodeUnescaper53 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray55 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray54);
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator56 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray54);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper57 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper58 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray59 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper57, unicodeEscaper58 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator60 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray59);
        java.lang.String str62 = aggregateTranslator60.translate((java.lang.CharSequence) "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper63 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper64 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray65 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper63, unicodeEscaper64 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator66 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray65);
        java.lang.CharSequence charSequence67 = null;
        java.lang.String str68 = aggregateTranslator66.translate(charSequence67);
        org.apache.commons.lang3.text.translate.AggregateTranslator[] aggregateTranslatorArray69 = new org.apache.commons.lang3.text.translate.AggregateTranslator[] { aggregateTranslator39, aggregateTranslator45, aggregateTranslator56, aggregateTranslator60, aggregateTranslator66 };
        org.apache.commons.lang3.text.translate.AggregateTranslator[] aggregateTranslatorArray70 = org.apache.commons.lang3.ArrayUtils.removeElements(aggregateTranslatorArray35, aggregateTranslatorArray69);
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator71 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) aggregateTranslatorArray70);
        boolean boolean72 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) doubleArray2, (java.lang.Object[]) aggregateTranslatorArray70);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper74 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper75 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper76 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper77 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper78 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper79 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray80 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper74, unicodeUnescaper75, unicodeUnescaper76, unicodeUnescaper77, unicodeUnescaper78, unicodeUnescaper79 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray81 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray80);
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator82 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray81);
        java.lang.String str84 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) unicodeUnescaperArray81, ' ');
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator85 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray81);
        org.apache.commons.lang3.text.translate.AggregateTranslator[] aggregateTranslatorArray86 = org.apache.commons.lang3.ArrayUtils.add(aggregateTranslatorArray70, 0, aggregateTranslator85);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.040.0" + "'", str5.equals("1.040.0"));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray10);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray14);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray24);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray32);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray33);
        org.junit.Assert.assertNotNull(aggregateTranslatorArray35);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray44);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray54);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray55);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray59);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "" + "'", str62.equals(""));
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray65);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(aggregateTranslatorArray69);
        org.junit.Assert.assertNotNull(aggregateTranslatorArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray80);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray81);
        org.junit.Assert.assertNotNull(aggregateTranslatorArray86);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("!", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####h#####i#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        java.lang.Character[] charArray6 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6, 'a');
        java.lang.Character[] charArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charArray9, 'a', (int) '#', (int) (byte) 0);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray9, 'a');
        java.lang.Character[] charArray16 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray9);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray9);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray17);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        char[] charArray4 = new char[] { '#', '#', '#', ' ' };
        char[] charArray8 = new char[] { 'a', ' ', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray8);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray9);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray9);
        char[] charArray14 = org.apache.commons.lang3.ArrayUtils.add(charArray11, 0, '#');
        java.lang.Character[] charArray15 = org.apache.commons.lang3.ArrayUtils.toObject(charArray11);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray15);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "------------------------------------------------------------------------------------AAA", (java.lang.CharSequence) "23");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) 100, (short) -1, (short) 1 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) 1);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) 0);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) 100);
        java.lang.Integer[] intArray10 = new java.lang.Integer[] {};
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray10);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray11);
        int[] intArray17 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(intArray17, (int) (byte) 0);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray17);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray12, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray20, 2);
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.clone(intArray20);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray20);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) '#', 26);
        try {
            short[] shortArray29 = org.apache.commons.lang3.ArrayUtils.removeAll(shortArray9, intArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("0a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0A" + "'", str1.equals("0A"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray18, floatArray30);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(floatArray18);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(floatArray39);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray0 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper1 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray0);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray2 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper3 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray2);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION4 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        boolean boolean5 = numericEntityUnescaper3.isSet(oPTION4);
        boolean boolean6 = numericEntityUnescaper1.isSet(oPTION4);
        java.io.Writer writer9 = null;
        int int10 = numericEntityUnescaper1.translate((java.lang.CharSequence) " ", 0, writer9);
        java.io.Writer writer13 = null;
        int int14 = numericEntityUnescaper1.translate((java.lang.CharSequence) "u0061u0061u0034u0061u0061u0061u0020u0061u0034u0061u00232u0061u0061u0034u0061u0061u0061u0020u0061u0034u0061u00233u0061u0061u0034u0061u0061u0061u0020u0061u0034u0061u0023", 1, writer13);
        org.junit.Assert.assertNotNull(oPTIONArray0);
        org.junit.Assert.assertNotNull(oPTIONArray2);
        org.junit.Assert.assertTrue("'" + oPTION4 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION4.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("#a4a aaa4aa", "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a4a aaa4aa" + "'", str2.equals("#a4a aaa4aa"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (short) 0);
        java.lang.Integer[] intArray7 = new java.lang.Integer[] {};
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray7);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray8);
        int[] intArray14 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(intArray14, (int) (byte) 0);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray14);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray9, intArray17);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, 2);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.clone(intArray17);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray17);
        int[] intArray23 = org.apache.commons.lang3.ArrayUtils.clone(intArray22);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.add(intArray23, (int) (short) 100);
        try {
            short[] shortArray26 = org.apache.commons.lang3.ArrayUtils.removeAll(shortArray4, intArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1 100", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 95 + "'", int2 == 95);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("          ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        java.lang.Byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray5);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray7);
        java.lang.Byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray7);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10010-1101", (java.lang.CharSequence) "{-1,3,100,10,3,2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aa4aaa a4a#", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.Short[] shortArray1 = new java.lang.Short[] { (short) 1 };
        java.lang.Short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray1);
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray2);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.contains(shortArray3, (short) 0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray1 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] { unicodeEscaper0 };
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray2 = org.apache.commons.lang3.ArrayUtils.toArray(codePointTranslatorArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.add(intArray7, 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) codePointTranslatorArray2, (java.lang.Object) intArray7);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray7, (int) '4', 0);
        java.lang.Integer[] intArray17 = new java.lang.Integer[] {};
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray17);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray18);
        int[] intArray24 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.contains(intArray24, (int) (byte) 0);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray24);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray19, intArray27);
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray27, 2);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray27);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.subarray(intArray27, 6, 10);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray7, intArray34);
        org.junit.Assert.assertNotNull(codePointTranslatorArray1);
        org.junit.Assert.assertNotNull(codePointTranslatorArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper2 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between(5, (int) (short) 1);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper4 = org.apache.commons.lang3.text.translate.UnicodeEscaper.below((int) 'a');
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper7 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between((-1), 4);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper10 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between((-1), (int) ' ');
        org.apache.commons.lang3.text.translate.UnicodeEscaper[] unicodeEscaperArray11 = new org.apache.commons.lang3.text.translate.UnicodeEscaper[] { unicodeEscaper2, unicodeEscaper4, unicodeEscaper7, unicodeEscaper10 };
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper14 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between(5, (int) (short) 1);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper16 = org.apache.commons.lang3.text.translate.UnicodeEscaper.below((int) 'a');
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper19 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between((-1), 4);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper22 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between((-1), (int) ' ');
        org.apache.commons.lang3.text.translate.UnicodeEscaper[] unicodeEscaperArray23 = new org.apache.commons.lang3.text.translate.UnicodeEscaper[] { unicodeEscaper14, unicodeEscaper16, unicodeEscaper19, unicodeEscaper22 };
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper26 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between(5, (int) (short) 1);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper28 = org.apache.commons.lang3.text.translate.UnicodeEscaper.below((int) 'a');
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper31 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between((-1), 4);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper34 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between((-1), (int) ' ');
        org.apache.commons.lang3.text.translate.UnicodeEscaper[] unicodeEscaperArray35 = new org.apache.commons.lang3.text.translate.UnicodeEscaper[] { unicodeEscaper26, unicodeEscaper28, unicodeEscaper31, unicodeEscaper34 };
        org.apache.commons.lang3.text.translate.UnicodeEscaper[][] unicodeEscaperArray36 = new org.apache.commons.lang3.text.translate.UnicodeEscaper[][] { unicodeEscaperArray11, unicodeEscaperArray23, unicodeEscaperArray35 };
        java.lang.Boolean[] booleanArray41 = new java.lang.Boolean[] { false, false, false, false };
        java.lang.Boolean[] booleanArray42 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray41);
        float[] floatArray44 = new float[] { 'a' };
        float[] floatArray46 = new float[] { (byte) -1 };
        boolean boolean47 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray44, floatArray46);
        java.lang.Float[] floatArray48 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray44);
        int int50 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) booleanArray41, (java.lang.Object) floatArray44, 95);
        org.apache.commons.lang3.text.translate.UnicodeEscaper[][] unicodeEscaperArray51 = org.apache.commons.lang3.ArrayUtils.removeElement(unicodeEscaperArray36, (java.lang.Object) booleanArray41);
        boolean[] booleanArray53 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray41, false);
        org.junit.Assert.assertNotNull(unicodeEscaper2);
        org.junit.Assert.assertNotNull(unicodeEscaper4);
        org.junit.Assert.assertNotNull(unicodeEscaper7);
        org.junit.Assert.assertNotNull(unicodeEscaper10);
        org.junit.Assert.assertNotNull(unicodeEscaperArray11);
        org.junit.Assert.assertNotNull(unicodeEscaper14);
        org.junit.Assert.assertNotNull(unicodeEscaper16);
        org.junit.Assert.assertNotNull(unicodeEscaper19);
        org.junit.Assert.assertNotNull(unicodeEscaper22);
        org.junit.Assert.assertNotNull(unicodeEscaperArray23);
        org.junit.Assert.assertNotNull(unicodeEscaper26);
        org.junit.Assert.assertNotNull(unicodeEscaper28);
        org.junit.Assert.assertNotNull(unicodeEscaper31);
        org.junit.Assert.assertNotNull(unicodeEscaper34);
        org.junit.Assert.assertNotNull(unicodeEscaperArray35);
        org.junit.Assert.assertNotNull(unicodeEscaperArray36);
        org.junit.Assert.assertNotNull(booleanArray41);
        org.junit.Assert.assertNotNull(booleanArray42);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(unicodeEscaperArray51);
        org.junit.Assert.assertNotNull(booleanArray53);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "          ", (java.lang.CharSequence) "0a", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "{-1,3,100,10,3,2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray18, floatArray30);
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, 100, 5);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(floatArray41);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray8);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_UNESCAPE();
        org.apache.commons.lang3.text.translate.LookupTranslator lookupTranslator1 = new org.apache.commons.lang3.text.translate.LookupTranslator((java.lang.CharSequence[][]) strArray0);
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("A", "1.0h 1.0 -1.0 1.0 -1.0 h-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.Float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_OBJECT_ARRAY;
        float[] floatArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0, 0.0f);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####H#####I#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray0, false);
        boolean[] booleanArray9 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.add(booleanArray9, true);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray9);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray9, false);
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.removeElements(booleanArray0, booleanArray9);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray0, true);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI", "hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih0.1 0.1 0.1- 0.1 0.1- 0.1-h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", "aa4aaa a4a#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isNotEmpty((java.lang.Comparable<java.lang.String>[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        char[] charArray6 = new char[] { '#', '#', '#', ' ' };
        char[] charArray10 = new char[] { 'a', ' ', '#' };
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.addAll(charArray6, charArray10);
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray11);
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "         !", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "------------------------------------------------------------------------------------AAA", charArray11);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.remove(charArray11, (int) (byte) 1);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(charArray17);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        char[] charArray4 = new char[] { '#', '#', '#', ' ' };
        char[] charArray8 = new char[] { 'a', ' ', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray8, '#', (int) (byte) 10);
        char[] charArray13 = null;
        char[] charArray14 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray8, charArray13);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.subarray(charArray13, 0, 95);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNull(charArray17);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("#4#4#4 4a4 4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#4#4#4 4a4 4#" + "'", str1.equals("#4#4#4 4a4 4#"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "hi!");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper9 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper10 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray11 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper9, unicodeEscaper10 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator12 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray11);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) strArray6, (java.lang.Object) charSequenceTranslatorArray11, (int) '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("###########", strArray3, strArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "###########" + "'", str15.equals("###########"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray4 = new char[] { 'a', 'a', ' ' };
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.remove(charArray4, (int) (byte) 1);
        char[] charArray11 = new char[] { '#', '#', '#', ' ' };
        char[] charArray15 = new char[] { 'a', ' ', '#' };
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.addAll(charArray11, charArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray4, charArray15);
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray18, 'a');
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray20, ' ');
        char[] charArray23 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray15, charArray20);
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.subarray(charArray15, (int) (byte) 10, 95);
        boolean boolean27 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray26);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "97a100a10a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 26);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(doubleArray0);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) 95, (int) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("23", "", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4" + "'", str2.equals("4"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.clone(longArray18);
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.add(longArray18, (long) 95);
        long[] longArray23 = org.apache.commons.lang3.ArrayUtils.add(longArray18, (long) (short) -1);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertNotNull(longArray23);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("-", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-" + "'", str2.equals("-"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeXml("1 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1 " + "'", str1.equals("1 "));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray0, (float) 'a', (int) (byte) -1);
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray0, (float) 2);
        float[] floatArray6 = null;
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray0, floatArray6);
        java.lang.Float[] floatArray12 = new java.lang.Float[] { 0.0f, 0.0f, 10.0f, (-1.0f) };
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray13);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray13, (int) '4', 2);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray7, floatArray13);
        java.lang.String str20 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) floatArray18, "  23                      ");
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "{0.0,0.0,10.0,-1.0}" + "'", str20.equals("{0.0,0.0,10.0,-1.0}"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeXml("{&gt;=>, &quot;=\", &amp;=&, &lt;=<}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{>=>, \"=\", &=&, <=<}" + "'", str1.equals("{>=>, \"=\", &=&, <=<}"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray3);
        long[] longArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray3, (long) '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        try {
            long[] longArray11 = org.apache.commons.lang3.ArrayUtils.add(longArray6, 11, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10" + "'", str8.equals("10"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray22);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray18, floatArray22);
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.add(floatArray18, (float) 0);
        float[] floatArray43 = org.apache.commons.lang3.ArrayUtils.remove(floatArray18, 6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray43);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray3);
        long[] longArray6 = org.apache.commons.lang3.ArrayUtils.remove(longArray3, 0);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) '4');
        org.apache.commons.lang3.ArrayUtils.reverse(longArray6);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                                                                    ", "u0061u0061u0034u0061u0061u0061u0020u0061u0034u0061u00232u0061u0061u0034u0061u0061u0061u0020u0061u0034u0061u00233u0061u0061u0034u0061u0061u0061u0020u0061u0034u0061u0023");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "5F", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String str1 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("hi!                                                                                            ", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!                                                                                            " + "'", str2.equals("hi!                                                                                            "));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray8 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) 10);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray9);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(shortArray3, (short) (byte) 1);
        try {
            short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.add(shortArray3, 4, (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray7);
        java.lang.Integer[] intArray12 = new java.lang.Integer[] {};
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray12);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray13);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.removeAll(doubleArray7, intArray13);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray13, 'a', (int) ' ', 26);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray6);
        boolean[] booleanArray16 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.add(booleanArray16, true);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, false, (int) (short) 0);
        boolean[] booleanArray29 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray31 = org.apache.commons.lang3.ArrayUtils.add(booleanArray29, true);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray31);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray31, false, (int) (short) 0);
        boolean[] booleanArray36 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray31);
        int int39 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, true, (int) ' ');
        boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray40);
        boolean[] booleanArray42 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray40);
        boolean[] booleanArray43 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray9, booleanArray42);
        boolean[] booleanArray44 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray9);
        boolean[] booleanArray47 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray9, (int) 'a', 6);
        try {
            boolean[] booleanArray49 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray47, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 26, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(booleanArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(booleanArray42);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertNotNull(booleanArray44);
        org.junit.Assert.assertNotNull(booleanArray47);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 11, 6);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, 0.0d, (double) 31);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("h-1.0-1.01.0-1.01.01.0h", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h-1.0-1.01.0-1.01.01.0h" + "'", str2.equals("h-1.0-1.01.0-1.01.01.0h"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        java.lang.String[] strArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_STRING_ARRAY;
        java.lang.Comparable<java.lang.String>[] strComparableArray1 = null;
        java.lang.Comparable<java.lang.String>[] strComparableArray2 = org.apache.commons.lang3.ArrayUtils.addAll((java.lang.Comparable<java.lang.String>[]) strArray0, strComparableArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strComparableArray2, 'a', (int) (short) 1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strComparableArray2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        boolean[][] booleanArray0 = new boolean[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "                                                    ");
        java.lang.String[] strArray3 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 100);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, 10, 3);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray12, (byte) 0);
        java.lang.Integer[] intArray15 = new java.lang.Integer[] {};
        java.lang.Integer[][] intArray16 = new java.lang.Integer[][] { intArray15 };
        java.lang.Integer[][] intArray17 = org.apache.commons.lang3.ArrayUtils.toArray(intArray16);
        int[] intArray22 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.contains(intArray22, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray22);
        java.lang.Integer[] intArray26 = new java.lang.Integer[] {};
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray26);
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray27);
        int[] intArray33 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.contains(intArray33, (int) (byte) 0);
        int[] intArray36 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray33);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray28, intArray36);
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray22, intArray28);
        java.lang.Integer[] intArray39 = org.apache.commons.lang3.ArrayUtils.toObject(intArray22);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) intArray17, (java.lang.Object) intArray22, 4);
        java.lang.Integer[] intArray42 = org.apache.commons.lang3.ArrayUtils.toObject(intArray22);
        try {
            byte[] byteArray43 = org.apache.commons.lang3.ArrayUtils.removeAll(byteArray12, intArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10,3,2}", "10,3,2}", 24);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "          ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        java.lang.String[] strArray5 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_UNESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', 4, 11);
        boolean[] booleanArray12 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.add(booleanArray12, true);
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray12);
        boolean[] booleanArray22 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.add(booleanArray22, true);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray24);
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray24, false, (int) (short) 0);
        boolean[] booleanArray35 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray37 = org.apache.commons.lang3.ArrayUtils.add(booleanArray35, true);
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray37);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray37, false, (int) (short) 0);
        boolean[] booleanArray42 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray24, booleanArray37);
        int int45 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray24, true, (int) ' ');
        boolean[] booleanArray46 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean boolean47 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray46);
        boolean[] booleanArray48 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray24, booleanArray46);
        boolean[] booleanArray49 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray15, booleanArray48);
        boolean[] booleanArray50 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray15);
        int int52 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) strArray1, (java.lang.Object) booleanArray50, (int) 'a');
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(booleanArray35);
        org.junit.Assert.assertNotNull(booleanArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(booleanArray42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
        org.junit.Assert.assertNotNull(booleanArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(booleanArray48);
        org.junit.Assert.assertNotNull(booleanArray49);
        org.junit.Assert.assertNotNull(booleanArray50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        long[] longArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(longArray0, 10L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "            -1a100a             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.add(intArray2, (int) (short) -1);
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray2, 3, (int) 'a');
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("{0.0,0.0,10.0,-1.0}", "  1   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0.0,0.0,10.0,-1.0}" + "'", str2.equals("{0.0,0.0,10.0,-1.0}"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        java.lang.Integer[] intArray8 = new java.lang.Integer[] {};
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray8);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray9);
        int[] intArray15 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(intArray15, (int) (byte) 0);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray15);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray10, intArray18);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray4, intArray10);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 0);
        java.lang.Integer[] intArray23 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, 26);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, 1.0d, 10.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray0);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray0, 11, (int) (short) 10);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "1.0h 1.0 -1.0 1.0 -1.0 h-1.0", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("  23                      ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeHtml3("                                                                                      0A97A100A10   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                      0A97A100A10   " + "'", str1.equals("                                                                                      0A97A100A10   "));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        java.lang.Character[] charArray7 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray7, 'a');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "!", charArray9);
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.subarray(charArray9, (int) '#', (int) (short) 10);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(charArray13);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray3);
        float[] floatArray21 = new float[] { 'a' };
        float[] floatArray23 = new float[] { (byte) -1 };
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray21, floatArray23);
        float[] floatArray31 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray33 = new float[] { 'a' };
        float[] floatArray35 = new float[] { (byte) -1 };
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray33, floatArray35);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray31, floatArray33);
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray23, floatArray31);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray31, (float) 10, 100);
        float[] floatArray42 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray3, floatArray31);
        int int44 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray3, (float) 95);
        java.lang.String str46 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        boolean boolean47 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray3);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-1.0" + "'", str46.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray14, (int) (short) 1, (int) '4');
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray14, (byte) 1);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray14, (byte) 10);
        byte[] byteArray24 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.remove(byteArray24, 0);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.clone(byteArray26);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray14, byteArray26);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.join(byteArray14, '4', (int) (byte) 100, 3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("0971001");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0971001" + "'", str1.equals("0971001"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        java.lang.Integer[] intArray3 = new java.lang.Integer[] {};
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        int[] intArray10 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.contains(intArray10, (int) (byte) 0);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray13);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray13, 2);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.clone(intArray13);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray13);
        try {
            int[] intArray20 = org.apache.commons.lang3.ArrayUtils.remove(intArray2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        char[] charArray3 = new char[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.clone(floatArray3);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(floatArray19, ' ');
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.clone(floatArray19);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray22, 0.0f, 24);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-1.0" + "'", str21.equals("-1.0"));
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray14, 'a');
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(byteArray14, (byte) 0);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.toString(byteArray14, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1a100a1" + "'", str16.equals("-1a100a1"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.Short[] shortArray1 = new java.lang.Short[] { (short) 1 };
        java.lang.Short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray1);
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray2, (short) -1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray4);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                      0a97a100a10   ", (int) (byte) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                      0a97a100a10   " + "'", str3.equals("                                                                                      0a97a100a10   "));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("\\u0061\\u0061\\u0034\\u0061\\u0061\\u0061\\u0020\\u0061\\u0034\\u0061\\u0023");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\\u0061\\u0061\\u0034\\u0061\\u0061\\u0061\\u0020\\u0061\\u0034\\u0061\\u0023" + "'", str1.equals("\\u0061\\u0061\\u0034\\u0061\\u0061\\u0061\\u0020\\u0061\\u0034\\u0061\\u0023"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.Long[] longArray2 = new java.lang.Long[] { 1L, 100L };
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.contains(longArray3, (long) (byte) 10);
        long[] longArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray3);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(longArray6);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray2 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper0, unicodeEscaper1 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator3 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray2);
        java.lang.String str5 = aggregateTranslator3.translate((java.lang.CharSequence) "aa4aaa a4a#");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper6 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper7 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray8 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper6, unicodeEscaper7 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator9 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray8);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper10 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper11 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray12 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper10, unicodeEscaper11 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator13 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray12);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper14 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper15 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray16 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper14, unicodeEscaper15 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator17 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray16);
        java.lang.String str19 = aggregateTranslator17.translate((java.lang.CharSequence) "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper20 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper21 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray22 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper20, unicodeEscaper21 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator23 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray22);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper24 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper25 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper26 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper27 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper28 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper29 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray30 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper24, unicodeUnescaper25, unicodeUnescaper26, unicodeUnescaper27, unicodeUnescaper28, unicodeUnescaper29 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray31 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray30);
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator32 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray30);
        org.apache.commons.lang3.text.translate.AggregateTranslator[] aggregateTranslatorArray33 = new org.apache.commons.lang3.text.translate.AggregateTranslator[] { aggregateTranslator9, aggregateTranslator13, aggregateTranslator17, aggregateTranslator23, aggregateTranslator32 };
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper34 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper35 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray36 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper34, unicodeEscaper35 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator37 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray36);
        java.lang.String str39 = aggregateTranslator37.translate((java.lang.CharSequence) "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper40 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper41 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray42 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper40, unicodeEscaper41 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator43 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray42);
        java.lang.CharSequence charSequence44 = null;
        java.lang.String str45 = aggregateTranslator43.translate(charSequence44);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper46 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper47 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper48 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper49 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper50 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper51 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray52 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper46, unicodeUnescaper47, unicodeUnescaper48, unicodeUnescaper49, unicodeUnescaper50, unicodeUnescaper51 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray53 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray52);
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator54 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray52);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper55 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper56 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray57 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper55, unicodeEscaper56 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator58 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray57);
        java.lang.String str60 = aggregateTranslator58.translate((java.lang.CharSequence) "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper61 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper62 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray63 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper61, unicodeEscaper62 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator64 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray63);
        java.lang.CharSequence charSequence65 = null;
        java.lang.String str66 = aggregateTranslator64.translate(charSequence65);
        org.apache.commons.lang3.text.translate.AggregateTranslator[] aggregateTranslatorArray67 = new org.apache.commons.lang3.text.translate.AggregateTranslator[] { aggregateTranslator37, aggregateTranslator43, aggregateTranslator54, aggregateTranslator58, aggregateTranslator64 };
        org.apache.commons.lang3.text.translate.AggregateTranslator[] aggregateTranslatorArray68 = org.apache.commons.lang3.ArrayUtils.removeElements(aggregateTranslatorArray33, aggregateTranslatorArray67);
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator69 = aggregateTranslator3.with((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) aggregateTranslatorArray33);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "\\u0061\\u0061\\u0034\\u0061\\u0061\\u0061\\u0020\\u0061\\u0034\\u0061\\u0023" + "'", str5.equals("\\u0061\\u0061\\u0034\\u0061\\u0061\\u0061\\u0020\\u0061\\u0034\\u0061\\u0023"));
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray8);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray12);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray22);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray30);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray31);
        org.junit.Assert.assertNotNull(aggregateTranslatorArray33);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray52);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray53);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray57);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "" + "'", str60.equals(""));
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray63);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNotNull(aggregateTranslatorArray67);
        org.junit.Assert.assertNotNull(aggregateTranslatorArray68);
        org.junit.Assert.assertNotNull(charSequenceTranslator69);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        java.lang.String str1 = org.apache.commons.lang3.text.translate.CharSequenceTranslator.hex((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "64" + "'", str1.equals("64"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        boolean[] booleanArray2 = new boolean[] { true, true };
        boolean[] booleanArray5 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray2, 31, 5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray2, (int) '4', (-1));
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray18);
        java.lang.Integer[] intArray20 = new java.lang.Integer[] {};
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray20);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray21);
        java.lang.Integer[] intArray23 = new java.lang.Integer[] {};
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray23);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray24);
        int[] intArray30 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.contains(intArray30, (int) (byte) 0);
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray30);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray25, intArray33);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray33, 2);
        int[] intArray37 = org.apache.commons.lang3.ArrayUtils.clone(intArray33);
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray22, intArray33);
        int[] intArray39 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(intArray39);
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray39, (int) (short) 0);
        int[] intArray44 = org.apache.commons.lang3.ArrayUtils.add(intArray39, (-1));
        int[] intArray45 = org.apache.commons.lang3.ArrayUtils.removeAll(intArray22, intArray39);
        long[] longArray46 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray18, intArray39);
        int[] intArray48 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray39, (int) (byte) 10);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(longArray46);
        org.junit.Assert.assertNotNull(intArray48);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 'a');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("                     ...", strArray4, strArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "");
        boolean[] booleanArray20 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray22 = org.apache.commons.lang3.ArrayUtils.add(booleanArray20, true);
        boolean[] booleanArray23 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray20);
        boolean[] booleanArray30 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.add(booleanArray30, true);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray32);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray32, false, (int) (short) 0);
        boolean[] booleanArray43 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray45 = org.apache.commons.lang3.ArrayUtils.add(booleanArray43, true);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray45);
        int int49 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray45, false, (int) (short) 0);
        boolean[] booleanArray50 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray32, booleanArray45);
        int int53 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray32, true, (int) ' ');
        boolean[] booleanArray54 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean boolean55 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray54);
        boolean[] booleanArray56 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray32, booleanArray54);
        boolean[] booleanArray57 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray23, booleanArray56);
        boolean[] booleanArray62 = new boolean[] { true, true, true, false };
        boolean boolean64 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray62, false);
        boolean[] booleanArray71 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray73 = org.apache.commons.lang3.ArrayUtils.add(booleanArray71, true);
        boolean boolean74 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray73);
        boolean boolean75 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray62, booleanArray73);
        boolean[] booleanArray76 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray62);
        boolean[] booleanArray77 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray23, booleanArray76);
        boolean boolean78 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray77);
        boolean boolean79 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) strArray4, (java.lang.Object) boolean78);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "                     ..." + "'", str11.equals("                     ..."));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str13.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray30);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertNotNull(booleanArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(booleanArray50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
        org.junit.Assert.assertNotNull(booleanArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(booleanArray56);
        org.junit.Assert.assertNotNull(booleanArray57);
        org.junit.Assert.assertNotNull(booleanArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(booleanArray71);
        org.junit.Assert.assertNotNull(booleanArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(booleanArray76);
        org.junit.Assert.assertNotNull(booleanArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] { '#', '#', '#', ' ' };
        char[] charArray10 = new char[] { 'a', ' ', '#' };
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.addAll(charArray6, charArray10);
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray11);
        char[] charArray14 = org.apache.commons.lang3.ArrayUtils.add(charArray12, '4');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#####", charArray14);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray14, '#');
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.add(charArray14, '#');
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray14);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("a#4#a# #4##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a#4#a# #4##" + "'", str1.equals("a#4#a# #4##"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray0 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray1 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper2 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray1);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION3 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        boolean boolean4 = numericEntityUnescaper2.isSet(oPTION3);
        java.lang.Enum<org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION>[] oPTIONEnumArray5 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Enum<org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION>[]) oPTIONArray0, (java.lang.Enum<org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION>) oPTION3);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap6 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) oPTIONEnumArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, 'errorIfNoSemiColon', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(oPTIONArray0);
        org.junit.Assert.assertNotNull(oPTIONArray1);
        org.junit.Assert.assertTrue("'" + oPTION3 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION3.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(oPTIONEnumArray5);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray6);
        boolean[] booleanArray16 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.add(booleanArray16, true);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, false, (int) (short) 0);
        boolean[] booleanArray29 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray31 = org.apache.commons.lang3.ArrayUtils.add(booleanArray29, true);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray31);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray31, false, (int) (short) 0);
        boolean[] booleanArray36 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray31);
        int int39 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, true, (int) ' ');
        boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray40);
        boolean[] booleanArray42 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray40);
        boolean[] booleanArray43 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray9, booleanArray42);
        int int45 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray42, true);
        boolean[] booleanArray47 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray42, true);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(booleanArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(booleanArray42);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
        org.junit.Assert.assertNotNull(booleanArray47);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double[] doubleArray6 = new double[] { (-1), '#', 0.0d, 1.0d, (short) -1, (short) 10 };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 'a', (int) (byte) -1);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray6, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0435.040.041.04-1.0410.0" + "'", str12.equals("-1.0435.040.041.04-1.0410.0"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.Long[] longArray2 = new java.lang.Long[] { 1L, 100L };
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2, (long) (short) 0);
        java.lang.Long[] longArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray2);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6, (long) (short) -1);
        java.lang.Short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray9, (short) 10);
        short[] shortArray15 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray16 = org.apache.commons.lang3.ArrayUtils.clone(shortArray15);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray16, (short) 10);
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.clone(shortArray16);
        short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.clone(shortArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) shortArray11, (java.lang.Object) shortArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) longArray6, (java.lang.Object) boolean21);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeJava("#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####H#####I#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####H#####I#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####" + "'", str1.equals("#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####H#####I#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        java.lang.Byte[] byteArray0 = null;
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0, (byte) 10);
        org.junit.Assert.assertNull(byteArray2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "{-1,100}", "{{0.0},{0.0},{0.0},{0.0},{0.0}}", (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.0 -1.0 1.0 -1.0 1.0 1.0", "-1.0 -1.0 1.0 -1.0 1.0 1.0", 1);
        java.lang.Integer[] intArray4 = new java.lang.Integer[] {};
        java.lang.Integer[][] intArray5 = new java.lang.Integer[][] { intArray4 };
        java.lang.Integer[][] intArray6 = org.apache.commons.lang3.ArrayUtils.toArray(intArray5);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strArray3, (java.lang.Object[]) intArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.Object[] objArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}", (java.lang.CharSequence) "                                                                                    0a97a100a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        short[] shortArray0 = null;
        short[] shortArray4 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray5, (short) 10, 0);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray0, shortArray5);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        org.apache.commons.lang3.text.translate.OctalUnescaper octalUnescaper0 = new org.apache.commons.lang3.text.translate.OctalUnescaper();
        java.io.Writer writer3 = null;
        int int4 = octalUnescaper0.translate((java.lang.CharSequence) "h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih0.1 0.1 0.1- 0.1 0.1- 0.1-h!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", (int) '#', writer3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "#####", (java.lang.CharSequence) "h-1.0 -1.0 1.0 -1.0 1.0 1.0h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("            -1a100a             ", 99, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "            -1a100a             aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("            -1a100a             aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray4);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 2);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.clone(intArray10);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.add(intArray15, (int) (byte) 0);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.clone(intArray15);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) 2, (int) '#', (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 5);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray7, (double) (-1.0f), 0.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "hi!", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("{{0.0},{0.0},{0.0},{0.0},{0.0}}", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{{0.0},{0.0},{0.0},{0.0},{0.0}}" + "'", str2.equals("{{0.0},{0.0},{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { (-1), 3, 100, 10, 3, 2 };
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray6, (int) '4');
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray9);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.removeElements(intArray8, intArray9);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.subarray(intArray9, (int) 'a', 90);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.Long[] longArray2 = new java.lang.Long[] { 1L, 100L };
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2, (long) (short) 0);
        java.lang.Long[] longArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray2);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6, (long) (short) -1);
        java.lang.Character[] charArray15 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray15, 'a');
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) longArray6, (java.lang.Object) charArray17);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper0 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        java.io.Writer writer3 = null;
        try {
            int int4 = unicodeUnescaper0.translate((java.lang.CharSequence) "97410041041040", 24, writer3);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 24");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray14, (int) (short) 1, (int) '4');
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray14, (byte) 1);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray14, (byte) 10);
        byte[] byteArray24 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.remove(byteArray24, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray26);
        java.lang.Byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray26);
        byte[] byteArray29 = org.apache.commons.lang3.ArrayUtils.removeElements(byteArray14, byteArray26);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray29);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!                                                                                            ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "97a100a10a10", (java.lang.CharSequence) "10,3,2}");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        float[] floatArray0 = null;
        float[] floatArray3 = org.apache.commons.lang3.ArrayUtils.add(floatArray0, 0, 0.0f);
        java.lang.Float[] floatArray8 = new java.lang.Float[] { 0.0f, 0.0f, 10.0f, (-1.0f) };
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray8);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray9, (int) '4', 2);
        float[] floatArray14 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray9);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 100);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION10 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.semiColonRequired;
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) byteArray5, (java.lang.Object) oPTION10);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + oPTION10 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.semiColonRequired + "'", oPTION10.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.semiColonRequired));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        int[] intArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(intArray0);
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (int) (short) 0);
        try {
            int[] intArray6 = org.apache.commons.lang3.ArrayUtils.add(intArray0, 4, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 0);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray7, 0.0d);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray14, '#');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10.0#100.0#0.0#-1.0#10.0#0.0" + "'", str16.equals("10.0#100.0#0.0#-1.0#10.0#0.0"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("{-1,100}", "0 97 100 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1,100}" + "'", str2.equals("{-1,100}"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray4);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.subarray(intArray4, 2, (int) (byte) -1);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.subarray(intArray11, 5, 90);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10,3,2}", "64", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "10", (java.lang.CharSequence) "!", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("#####", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#####" + "'", str2.equals("#####"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { (-1), 3, 100, 10, 3, 2 };
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray6, (int) '4');
        java.lang.String str10 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) intArray6, "0a97a100a10");
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray6, 99);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{-1,3,100,10,3,2}" + "'", str10.equals("{-1,3,100,10,3,2}"));
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = org.apache.commons.lang3.text.translate.UnicodeEscaper.above((int) (short) 1);
        org.junit.Assert.assertNotNull(unicodeEscaper1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray3);
        float[] floatArray20 = null;
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray3, floatArray20);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.contains(floatArray3, (float) 31);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("  23  ", "{-1,3,100,10,3,2}");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        java.lang.Integer[] intArray4 = new java.lang.Integer[] {};
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray5);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray3, intArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray7, (long) (short) 0, 2);
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) '4');
        java.lang.Long[] longArray13 = org.apache.commons.lang3.ArrayUtils.toObject(longArray7);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray13);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.Short[] shortArray1 = new java.lang.Short[] { (short) 1 };
        java.lang.Short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray1);
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray2);
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray2);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (short) (byte) 10);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(shortArray6);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        int[] intArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml3("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    " + "'", str1.equals("                                                                                                    "));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', 0, (-1));
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.clone(longArray3);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(longArray9);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray7);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray0);
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray0, (double) 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) 2, (int) '#', (double) (short) 10);
        java.lang.Double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray7);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray13);
        int[] intArray15 = null;
        try {
            double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.removeAll(doubleArray14, intArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1 ", (java.lang.CharSequence) "23", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        org.apache.commons.lang3.StringEscapeUtils stringEscapeUtils0 = new org.apache.commons.lang3.StringEscapeUtils();
        org.apache.commons.lang3.StringEscapeUtils stringEscapeUtils1 = new org.apache.commons.lang3.StringEscapeUtils();
        org.apache.commons.lang3.StringEscapeUtils stringEscapeUtils2 = new org.apache.commons.lang3.StringEscapeUtils();
        org.apache.commons.lang3.StringEscapeUtils stringEscapeUtils3 = new org.apache.commons.lang3.StringEscapeUtils();
        org.apache.commons.lang3.StringEscapeUtils stringEscapeUtils4 = new org.apache.commons.lang3.StringEscapeUtils();
        org.apache.commons.lang3.StringEscapeUtils stringEscapeUtils5 = new org.apache.commons.lang3.StringEscapeUtils();
        org.apache.commons.lang3.StringEscapeUtils[] stringEscapeUtilsArray6 = new org.apache.commons.lang3.StringEscapeUtils[] { stringEscapeUtils0, stringEscapeUtils1, stringEscapeUtils2, stringEscapeUtils3, stringEscapeUtils4, stringEscapeUtils5 };
        org.apache.commons.lang3.StringEscapeUtils stringEscapeUtils7 = new org.apache.commons.lang3.StringEscapeUtils();
        org.apache.commons.lang3.StringEscapeUtils stringEscapeUtils8 = new org.apache.commons.lang3.StringEscapeUtils();
        org.apache.commons.lang3.StringEscapeUtils stringEscapeUtils9 = new org.apache.commons.lang3.StringEscapeUtils();
        org.apache.commons.lang3.StringEscapeUtils stringEscapeUtils10 = new org.apache.commons.lang3.StringEscapeUtils();
        org.apache.commons.lang3.StringEscapeUtils[] stringEscapeUtilsArray11 = new org.apache.commons.lang3.StringEscapeUtils[] { stringEscapeUtils7, stringEscapeUtils8, stringEscapeUtils9, stringEscapeUtils10 };
        org.apache.commons.lang3.StringEscapeUtils[] stringEscapeUtilsArray12 = org.apache.commons.lang3.ArrayUtils.addAll(stringEscapeUtilsArray6, stringEscapeUtilsArray11);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap13 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) stringEscapeUtilsArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, 'org.apache.commons.lang3.StringEscapeUtils@3cacea43', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stringEscapeUtilsArray6);
        org.junit.Assert.assertNotNull(stringEscapeUtilsArray11);
        org.junit.Assert.assertNotNull(stringEscapeUtilsArray12);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a', (int) (byte) 100, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 100);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 1);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray13);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        boolean[] booleanArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray0, false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        char[] charArray4 = new char[] { ' ', 'a', 'a', '4' };
        char[] charArray9 = new char[] { ' ', 'a', 'a', '4' };
        char[] charArray14 = new char[] { ' ', 'a', 'a', '4' };
        char[][] charArray15 = new char[][] { charArray4, charArray9, charArray14 };
        java.lang.Long[] longArray16 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_OBJECT_ARRAY;
        java.lang.Object[] objArray17 = org.apache.commons.lang3.ArrayUtils.nullToEmpty((java.lang.Object[]) longArray16);
        char[][] charArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray15, (java.lang.Object) objArray17);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(charArray18);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 10);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray14, (byte) 1, 24);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}", (java.lang.CharSequence) "{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                                                    0a97a100a10", "34");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "34" + "'", str2.equals("34"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        boolean[] booleanArray4 = new boolean[] { true, true, true, false };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray4, false);
        boolean[] booleanArray13 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.add(booleanArray13, true);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray4, booleanArray15);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray4);
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.add(booleanArray18, 1, true);
        boolean[] booleanArray23 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray21, 2);
        java.lang.Integer[] intArray24 = new java.lang.Integer[] {};
        java.lang.Integer[][] intArray25 = new java.lang.Integer[][] { intArray24 };
        java.lang.Integer[][] intArray26 = org.apache.commons.lang3.ArrayUtils.toArray(intArray25);
        int[] intArray31 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.contains(intArray31, (int) (byte) 0);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray31);
        java.lang.Integer[] intArray35 = new java.lang.Integer[] {};
        int[] intArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray35);
        int[] intArray37 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray36);
        int[] intArray42 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.contains(intArray42, (int) (byte) 0);
        int[] intArray45 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray42);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray37, intArray45);
        boolean boolean47 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray31, intArray37);
        java.lang.Integer[] intArray48 = org.apache.commons.lang3.ArrayUtils.toObject(intArray31);
        int int50 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) intArray26, (java.lang.Object) intArray31, 4);
        int[] intArray51 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray31);
        try {
            boolean[] booleanArray52 = org.apache.commons.lang3.ArrayUtils.removeAll(booleanArray21, intArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(intArray51);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray4);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(shortArray7);
        short[] shortArray9 = null;
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray9);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.removeElements(shortArray7, shortArray10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray11);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("64", "  23  ", 95);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "64" + "'", str3.equals("64"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.Character[] charArray6 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6, 'a');
        java.lang.Character[] charArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray6);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray9);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.clone(charArray10);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray11);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        java.lang.Integer[][] intArray1 = new java.lang.Integer[][] { intArray0 };
        java.lang.Integer[][] intArray2 = org.apache.commons.lang3.ArrayUtils.toArray(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        java.lang.Integer[] intArray11 = new java.lang.Integer[] {};
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray11);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray12);
        int[] intArray18 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.contains(intArray18, (int) (byte) 0);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray18);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray13, intArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray7, intArray13);
        java.lang.Integer[] intArray24 = org.apache.commons.lang3.ArrayUtils.toObject(intArray7);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) intArray2, (java.lang.Object) intArray7, 4);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray7);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        java.lang.Character[] charArray8 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray8, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", charArray10);
        java.lang.Integer[] intArray13 = new java.lang.Integer[] {};
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray13);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray14);
        int[] intArray20 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.contains(intArray20, (int) (byte) 0);
        int[] intArray23 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray20);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray15, intArray23);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray23, 2);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.clone(intArray23);
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray23);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.clone(intArray28);
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.add(intArray29, (int) (short) 100);
        try {
            char[] charArray32 = org.apache.commons.lang3.ArrayUtils.removeAll(charArray10, intArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                    ", 95);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double[] doubleArray0 = null;
        int[] intArray1 = null;
        try {
            double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.removeAll(doubleArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        java.lang.Object obj0 = null;
        java.lang.String str1 = org.apache.commons.lang3.ArrayUtils.toString(obj0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{}" + "'", str1.equals("{}"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.clone(floatArray3);
        float[] floatArray26 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray28 = new float[] { 'a' };
        float[] floatArray30 = new float[] { (byte) -1 };
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray28, floatArray30);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray26, floatArray28);
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.join(floatArray26, ' ');
        float[] floatArray36 = org.apache.commons.lang3.ArrayUtils.add(floatArray26, (float) 0L);
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.add(floatArray26, (float) (short) 100);
        int int40 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray38, 10.0f);
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray19, floatArray38);
        int int43 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray19, (float) (short) 100);
        float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.clone(floatArray19);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str34.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(floatArray44);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper0 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper1 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper2 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper3 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper4 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper5 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray6 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper0, unicodeUnescaper1, unicodeUnescaper2, unicodeUnescaper3, unicodeUnescaper4, unicodeUnescaper5 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray7 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray6);
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator8 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) unicodeUnescaperArray7, ' ');
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator11 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray7);
        char[] charArray14 = new char[] { ' ', ' ' };
        char[] charArray16 = new char[] { '#' };
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.add(charArray16, '#');
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray14, charArray16);
        java.lang.Object[] objArray20 = org.apache.commons.lang3.ArrayUtils.removeElement((java.lang.Object[]) unicodeUnescaperArray7, (java.lang.Object) charArray19);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray6);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray7);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray0 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray1 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] { oPTIONArray0 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray2 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper3 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray2);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray4 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper5 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray4);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION6 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        boolean boolean7 = numericEntityUnescaper5.isSet(oPTION6);
        boolean boolean8 = numericEntityUnescaper3.isSet(oPTION6);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION9 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION10 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray11 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] { oPTION6, oPTION9, oPTION10 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray12 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] { oPTIONArray11 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray13 = org.apache.commons.lang3.ArrayUtils.removeElements(oPTIONArray1, oPTIONArray12);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray14 = org.apache.commons.lang3.ArrayUtils.clone(oPTIONArray13);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) oPTIONArray14, ' ');
        org.junit.Assert.assertNotNull(oPTIONArray0);
        org.junit.Assert.assertNotNull(oPTIONArray1);
        org.junit.Assert.assertNotNull(oPTIONArray2);
        org.junit.Assert.assertNotNull(oPTIONArray4);
        org.junit.Assert.assertTrue("'" + oPTION6 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION6.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + oPTION9 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION9.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + oPTION10 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION10.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertNotNull(oPTIONArray11);
        org.junit.Assert.assertNotNull(oPTIONArray12);
        org.junit.Assert.assertNotNull(oPTIONArray13);
        org.junit.Assert.assertNotNull(oPTIONArray14);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper3 = org.apache.commons.lang3.text.translate.UnicodeEscaper.outsideOf(100, 4);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper6 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between((-1), (int) ' ');
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper9 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between((int) (byte) -1, (int) (short) 0);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper12 = org.apache.commons.lang3.text.translate.UnicodeEscaper.outsideOf(100, 4);
        org.apache.commons.lang3.text.translate.UnicodeEscaper[] unicodeEscaperArray13 = new org.apache.commons.lang3.text.translate.UnicodeEscaper[] { unicodeEscaper0, unicodeEscaper3, unicodeEscaper6, unicodeEscaper9, unicodeEscaper12 };
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(unicodeEscaperArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(unicodeEscaperArray13);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper17 = null;
        try {
            org.apache.commons.lang3.text.translate.UnicodeEscaper[] unicodeEscaperArray18 = org.apache.commons.lang3.ArrayUtils.add(unicodeEscaperArray13, 90, unicodeEscaper17);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 90, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(unicodeEscaper3);
        org.junit.Assert.assertNotNull(unicodeEscaper6);
        org.junit.Assert.assertNotNull(unicodeEscaper9);
        org.junit.Assert.assertNotNull(unicodeEscaper12);
        org.junit.Assert.assertNotNull(unicodeEscaperArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray7);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray7, (int) (byte) 1);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray7, 4, (int) ' ');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.ISO8859_1_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "1.040.0");
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        java.lang.Long[] longArray5 = new java.lang.Long[] { 1L, 100L, 10L, 100L, 10L };
        java.lang.Long[] longArray11 = new java.lang.Long[] { 1L, 100L, 10L, 100L, 10L };
        java.lang.Long[] longArray17 = new java.lang.Long[] { 1L, 100L, 10L, 100L, 10L };
        java.lang.Long[] longArray23 = new java.lang.Long[] { 1L, 100L, 10L, 100L, 10L };
        java.lang.Long[] longArray29 = new java.lang.Long[] { 1L, 100L, 10L, 100L, 10L };
        java.lang.Long[] longArray35 = new java.lang.Long[] { 1L, 100L, 10L, 100L, 10L };
        java.lang.Long[][] longArray36 = new java.lang.Long[][] { longArray5, longArray11, longArray17, longArray23, longArray29, longArray35 };
        java.lang.Integer[] intArray43 = new java.lang.Integer[] { (-1), 3, 100, 10, 3, 2 };
        int[] intArray45 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray43, (int) '4');
        int[] intArray46 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        boolean boolean47 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray46);
        int[] intArray48 = org.apache.commons.lang3.ArrayUtils.removeElements(intArray45, intArray46);
        try {
            java.lang.Long[][] longArray49 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray36, intArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertNotNull(longArray29);
        org.junit.Assert.assertNotNull(longArray35);
        org.junit.Assert.assertNotNull(longArray36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(intArray48);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "-1.0", (java.lang.CharSequence) "                                                   ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("{1,-1,-1}", "", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "0 97 100 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0, 'a');
        char[] charArray5 = new char[] { ' ', ' ' };
        char[] charArray7 = new char[] { '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray7, '#');
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray5, charArray7);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray2, charArray7);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                                                                      0a97a100a10   ", "", "{0,97,100,10}", 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                      0a97a100a10   " + "'", str4.equals("                                                                                      0a97a100a10   "));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1a-1a-1", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                                                                                      0a97a100a10  ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.0h 1.0 -1.0 1.0 -1.0 h-1.0", "            -1a100a             ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        java.lang.Float[][][] floatArray0 = new java.lang.Float[][][] {};
        java.lang.Float[][][] floatArray1 = org.apache.commons.lang3.ArrayUtils.clone(floatArray0);
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(floatArray0);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("#####", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#####" + "'", str3.equals("#####"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, 0, (int) ' ');
        java.lang.Byte[] byteArray23 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray23);
        byte[] byteArray27 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray29 = org.apache.commons.lang3.ArrayUtils.remove(byteArray27, 0);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray24, byteArray27);
        byte[] byteArray32 = org.apache.commons.lang3.ArrayUtils.add(byteArray27, (byte) 10);
        byte[] byteArray33 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray9, byteArray32);
        byte[] byteArray34 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray37 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, (int) (byte) 0, (int) (short) 0);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray37);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aa4aaa a4a#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa4aaa a4a#" + "'", str1.equals("aa4aaa a4a#"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        java.lang.Float[] floatArray5 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray1);
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.clone(floatArray1);
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) 11);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0971001", (java.lang.CharSequence) "-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        short[] shortArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(shortArray0, (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("{0,97,100,10}                   ", "1.01.01.01.01.01.01.01.01.01.01.0", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0,97,100,10}                   " + "'", str3.equals("{0,97,100,10}                   "));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray4);
        java.lang.Class<?> wildcardClass8 = intArray4.getClass();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = org.apache.commons.lang3.text.translate.UnicodeEscaper.below(24);
        java.io.Writer writer3 = null;
        boolean boolean4 = unicodeEscaper1.translate(31, writer3);
        org.junit.Assert.assertNotNull(unicodeEscaper1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("  1   ", "{-1,3,100,10,3,2", "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####h#####i#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  1   " + "'", str3.equals("  1   "));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray1, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 26);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray1);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray18);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray19);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray20, (double) 2, (int) (byte) -1, (double) 0.0f);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray25, doubleArray31);
        double[] doubleArray33 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray20, doubleArray31);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray31, (double) 2, 26);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray43 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray44 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray37, doubleArray43);
        int int47 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray44, (double) (byte) -1, (double) (byte) 1);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray44);
        double[] doubleArray49 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray31, doubleArray44);
        int int52 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray44, (double) (short) 100, 6);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "1 ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "09710010");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.clone(floatArray3);
        float[] floatArray26 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray28 = new float[] { 'a' };
        float[] floatArray30 = new float[] { (byte) -1 };
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray28, floatArray30);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray26, floatArray28);
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.join(floatArray26, ' ');
        float[] floatArray36 = org.apache.commons.lang3.ArrayUtils.add(floatArray26, (float) 0L);
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.add(floatArray26, (float) (short) 100);
        int int40 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray38, 10.0f);
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray19, floatArray38);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray19);
        java.lang.String str44 = org.apache.commons.lang3.StringUtils.join(floatArray19, '#');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str34.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "-1.0" + "'", str44.equals("-1.0"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeJava("            -1a100a             aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "            -1a100a             aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("            -1a100a             aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray6, (int) ' ', (int) (byte) 10);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#');
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray6, (float) 100L);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-1.0#-1.0#1.0#-1.0#1.0#1.0" + "'", str19.equals("-1.0#-1.0#1.0#-1.0#1.0#1.0"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("5F");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5F" + "'", str1.equals("5F"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        boolean[] booleanArray4 = new boolean[] { true, true, true, false };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray4, false);
        boolean[] booleanArray13 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.add(booleanArray13, true);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray4, booleanArray15);
        boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray4, false);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(booleanArray19);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray7, (short) -1, 24);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray7, (short) 0, 10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.0", "");
        java.lang.String str4 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) strArray2, "!                                                                                     0A97A100A10   ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{1.0}" + "'", str4.equals("{1.0}"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        boolean[] booleanArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray0, false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        java.lang.Integer[] intArray4 = new java.lang.Integer[] {};
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray5);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray3, intArray6);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(longArray7, (long) 1);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray7, (long) (byte) 10);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        java.lang.Character[] charArray6 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6, 'a');
        java.lang.Character[] charArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray6);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6, ' ');
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray11, ' ');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                    ", "!", "#a4a aaa4aa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                    " + "'", str3.equals("                                                    "));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        char[] charArray5 = new char[] { '#', '#', '#', ' ' };
        char[] charArray9 = new char[] { 'a', ' ', '#' };
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.addAll(charArray5, charArray9);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(charArray5);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (short) 0);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, 3, (short) 10);
        short[] shortArray10 = null;
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray9, shortArray10);
        java.lang.Integer[] intArray12 = new java.lang.Integer[] {};
        java.lang.Integer[][] intArray13 = new java.lang.Integer[][] { intArray12 };
        java.lang.Integer[][] intArray14 = org.apache.commons.lang3.ArrayUtils.toArray(intArray13);
        int[] intArray19 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(intArray19, (int) (byte) 0);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray19);
        java.lang.Integer[] intArray23 = new java.lang.Integer[] {};
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray23);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray24);
        int[] intArray30 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.contains(intArray30, (int) (byte) 0);
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray30);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray25, intArray33);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray19, intArray25);
        java.lang.Integer[] intArray36 = org.apache.commons.lang3.ArrayUtils.toObject(intArray19);
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) intArray14, (java.lang.Object) intArray19, 4);
        int[] intArray39 = org.apache.commons.lang3.ArrayUtils.clone(intArray19);
        try {
            short[] shortArray40 = org.apache.commons.lang3.ArrayUtils.removeAll(shortArray10, intArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("{>=>, \"=\", &=&, <=<}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{>=>, \"=\", &=&, <=<}" + "'", str1.equals("{>=>, \"=\", &=&, <=<}"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "#a4a aaa4aa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                      0a97a100a10  ", "{1.0}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (byte) 1, (double) 100L);
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray6, (double) 100.0f);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray8);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray8, (long) (byte) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray8, 'a');
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray8, 24, 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray16, 0L);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0a97a100a10" + "'", str13.equals("0a97a100a10"));
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("                                                    ", "{{0.0},{0.0},{0.0},{0.0},{0.0}}");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{{0.0},{0.0},{0.0},{0.0},{0.0}}" + "'", str2.equals("{{0.0},{0.0},{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 100);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        java.lang.Byte[] byteArray12 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray14 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray16 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray18 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray20 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray22 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[][] byteArray23 = new java.lang.Byte[][] { byteArray12, byteArray14, byteArray16, byteArray18, byteArray20, byteArray22 };
        java.lang.Byte[] byteArray25 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray27 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray29 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray31 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray33 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray35 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[][] byteArray36 = new java.lang.Byte[][] { byteArray25, byteArray27, byteArray29, byteArray31, byteArray33, byteArray35 };
        java.lang.Byte[] byteArray38 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray40 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray42 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray44 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray46 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray48 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[][] byteArray49 = new java.lang.Byte[][] { byteArray38, byteArray40, byteArray42, byteArray44, byteArray46, byteArray48 };
        java.lang.Byte[] byteArray51 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray53 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray55 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray57 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray59 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray61 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[][] byteArray62 = new java.lang.Byte[][] { byteArray51, byteArray53, byteArray55, byteArray57, byteArray59, byteArray61 };
        java.lang.Byte[] byteArray64 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray66 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray68 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray70 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray72 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray74 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[][] byteArray75 = new java.lang.Byte[][] { byteArray64, byteArray66, byteArray68, byteArray70, byteArray72, byteArray74 };
        java.lang.Byte[] byteArray77 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray79 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray81 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray83 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray85 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[] byteArray87 = new java.lang.Byte[] { (byte) -1 };
        java.lang.Byte[][] byteArray88 = new java.lang.Byte[][] { byteArray77, byteArray79, byteArray81, byteArray83, byteArray85, byteArray87 };
        java.lang.Byte[][][] byteArray89 = new java.lang.Byte[][][] { byteArray23, byteArray36, byteArray49, byteArray62, byteArray75, byteArray88 };
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper91 = org.apache.commons.lang3.text.translate.UnicodeEscaper.below((int) 'a');
        java.lang.Byte[][][] byteArray92 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray89, (java.lang.Object) 'a');
        int int94 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) byteArray5, (java.lang.Object) 'a', (int) '4');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertNotNull(byteArray49);
        org.junit.Assert.assertNotNull(byteArray51);
        org.junit.Assert.assertNotNull(byteArray53);
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertNotNull(byteArray57);
        org.junit.Assert.assertNotNull(byteArray59);
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertNotNull(byteArray62);
        org.junit.Assert.assertNotNull(byteArray64);
        org.junit.Assert.assertNotNull(byteArray66);
        org.junit.Assert.assertNotNull(byteArray68);
        org.junit.Assert.assertNotNull(byteArray70);
        org.junit.Assert.assertNotNull(byteArray72);
        org.junit.Assert.assertNotNull(byteArray74);
        org.junit.Assert.assertNotNull(byteArray75);
        org.junit.Assert.assertNotNull(byteArray77);
        org.junit.Assert.assertNotNull(byteArray79);
        org.junit.Assert.assertNotNull(byteArray81);
        org.junit.Assert.assertNotNull(byteArray83);
        org.junit.Assert.assertNotNull(byteArray85);
        org.junit.Assert.assertNotNull(byteArray87);
        org.junit.Assert.assertNotNull(byteArray88);
        org.junit.Assert.assertNotNull(byteArray89);
        org.junit.Assert.assertNotNull(unicodeEscaper91);
        org.junit.Assert.assertNotNull(byteArray92);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + (-1) + "'", int94 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray0 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray1 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] { oPTIONArray0 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray2 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper3 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray2);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray4 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper5 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray4);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION6 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        boolean boolean7 = numericEntityUnescaper5.isSet(oPTION6);
        boolean boolean8 = numericEntityUnescaper3.isSet(oPTION6);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION9 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION10 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray11 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] { oPTION6, oPTION9, oPTION10 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray12 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] { oPTIONArray11 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray13 = org.apache.commons.lang3.ArrayUtils.removeElements(oPTIONArray1, oPTIONArray12);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray14 = org.apache.commons.lang3.ArrayUtils.clone(oPTIONArray13);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEmpty((java.lang.Object[]) oPTIONArray14);
        org.junit.Assert.assertNotNull(oPTIONArray0);
        org.junit.Assert.assertNotNull(oPTIONArray1);
        org.junit.Assert.assertNotNull(oPTIONArray2);
        org.junit.Assert.assertNotNull(oPTIONArray4);
        org.junit.Assert.assertTrue("'" + oPTION6 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION6.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + oPTION9 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION9.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + oPTION10 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION10.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertNotNull(oPTIONArray11);
        org.junit.Assert.assertNotNull(oPTIONArray12);
        org.junit.Assert.assertNotNull(oPTIONArray13);
        org.junit.Assert.assertNotNull(oPTIONArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("10.0#100.0#0.0#-1.0#10.0#0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0#100.0#0.0#-1.0#10.0#0.0" + "'", str1.equals("10.0#100.0#0.0#-1.0#10.0#0.0"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.lang.String[] strArray4 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray9 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray14 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray19 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[][] strArray20 = new java.lang.String[][] { strArray4, strArray9, strArray14, strArray19 };
        java.lang.String[][] strArray21 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isEmpty((java.lang.Object[]) strArray20);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray14, (int) (short) 1, (int) '4');
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray14, (byte) 1);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray14, (byte) 10);
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray14, (byte) 1);
        int[] intArray24 = null;
        try {
            byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.removeAll(byteArray14, intArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(byteArray23);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0 97 100 1", "14-14-1", 10);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap4 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) strArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, '0 97 100 1', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10010-1101", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10010-1101" + "'", str3.equals("10010-1101"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "0 97 100 1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        float[] floatArray0 = null;
        float[] floatArray1 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray1, (float) 'a', (int) (byte) -1);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray1, (float) 2);
        float[] floatArray7 = null;
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray1, floatArray7);
        java.lang.Float[] floatArray13 = new java.lang.Float[] { 0.0f, 0.0f, 10.0f, (-1.0f) };
        float[] floatArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray13);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray14);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray14, (int) '4', 2);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray8, floatArray14);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray0, floatArray14);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        java.lang.Boolean[] booleanArray4 = new java.lang.Boolean[] { false, false, false, false };
        java.lang.Boolean[] booleanArray5 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray4);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) booleanArray4);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray4, true);
        java.lang.Integer[] intArray9 = new java.lang.Integer[] {};
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray9);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        int[] intArray16 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(intArray16, (int) (byte) 0);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray16);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray11, intArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray19, 2);
        int[] intArray23 = org.apache.commons.lang3.ArrayUtils.clone(intArray19);
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray19);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.clone(intArray24);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) (short) 100);
        try {
            boolean[] booleanArray28 = org.apache.commons.lang3.ArrayUtils.removeAll(booleanArray8, intArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("97410041041040", "         !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97410041041040" + "'", str2.equals("97410041041040"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        java.lang.Byte[] byteArray18 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray18);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray18);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray18, (byte) 100);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray22, 10, 3);
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray22);
        byte[] byteArray27 = null;
        byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray26, byteArray27);
        java.lang.Integer[] intArray29 = new java.lang.Integer[] {};
        int[] intArray30 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray29);
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray30);
        int[] intArray36 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.contains(intArray36, (int) (byte) 0);
        int[] intArray39 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray36);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray31, intArray39);
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray39, 2);
        int[] intArray43 = org.apache.commons.lang3.ArrayUtils.clone(intArray39);
        int[] intArray44 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray39);
        int[] intArray45 = org.apache.commons.lang3.ArrayUtils.clone(intArray44);
        int[] intArray47 = org.apache.commons.lang3.ArrayUtils.add(intArray45, (int) (short) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray45);
        try {
            byte[] byteArray49 = org.apache.commons.lang3.ArrayUtils.removeAll(byteArray27, intArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.Short[] shortArray1 = new java.lang.Short[] { (short) 1 };
        java.lang.Short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray1);
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray2);
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray2);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (short) (byte) 10);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray6);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "{>=>, \"=\", &=&, <=<}");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        char[] charArray3 = new char[] { 'a', 'a', ' ' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.remove(charArray3, (int) (byte) 1);
        char[] charArray10 = new char[] { '#', '#', '#', ' ' };
        char[] charArray14 = new char[] { 'a', ' ', '#' };
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.addAll(charArray10, charArray14);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray3, charArray14);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray17, 'a');
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray19, ' ');
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray14, charArray19);
        long[] longArray24 = new long[] { (short) 10 };
        long[] longArray25 = new long[] {};
        long[] longArray26 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray24, longArray25);
        java.lang.Integer[] intArray27 = new java.lang.Integer[] {};
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray27);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray28);
        long[] longArray30 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray26, intArray29);
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.clone(intArray29);
        char[] charArray32 = org.apache.commons.lang3.ArrayUtils.removeAll(charArray22, intArray31);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertNotNull(longArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(charArray32);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_UNESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        org.apache.commons.lang3.text.translate.LookupTranslator lookupTranslator2 = new org.apache.commons.lang3.text.translate.LookupTranslator((java.lang.CharSequence[][]) strArray1);
        org.apache.commons.lang3.text.translate.LookupTranslator lookupTranslator3 = new org.apache.commons.lang3.text.translate.LookupTranslator((java.lang.CharSequence[][]) strArray1);
        java.lang.CharSequence charSequence4 = null;
        java.io.Writer writer6 = null;
        try {
            int int7 = lookupTranslator3.translate(charSequence4, 95, writer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("{1.0}", "a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{1.0}" + "'", str2.equals("{1.0}"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) 2, (int) '#', (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 5);
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray7, 0.0d);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray23 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray17, doubleArray23);
        int int27 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray24, (double) (byte) -1, (double) (byte) 1);
        double[] doubleArray28 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray28);
        double[] doubleArray30 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray28);
        double[] doubleArray31 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray24, doubleArray28);
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray7, doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "a1", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) 100, (short) -1, (short) 1 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) 1);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) 0);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) 100);
        java.lang.Short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        char[] charArray5 = new char[] { '#', '#', '#', ' ' };
        char[] charArray9 = new char[] { 'a', ' ', '#' };
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.addAll(charArray5, charArray9);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray10);
        char[] charArray16 = new char[] { '#', '#', '#', ' ' };
        char[] charArray20 = new char[] { 'a', ' ', '#' };
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.addAll(charArray16, charArray20);
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray21);
        char[] charArray24 = org.apache.commons.lang3.ArrayUtils.add(charArray22, '4');
        char[] charArray25 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray10, charArray22);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(charArray10);
        boolean boolean27 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "{0,97,u00,u0}", charArray10);
        try {
            char[] charArray29 = org.apache.commons.lang3.ArrayUtils.remove(charArray10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 7");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.0", "");
        java.lang.Byte[] byteArray8 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray9, (byte) 100, 0);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) "", (java.lang.Object) byteArray9);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray9);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray9);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "{-1,3,100,10,3,2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.Character[] charArray6 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6, 'a');
        java.lang.Character[] charArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray6);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray9);
        java.lang.Character[] charArray16 = new java.lang.Character[] { '4', 'a', '4', '#', 'a' };
        java.lang.Character[] charArray17 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray16);
        java.lang.Character[] charArray18 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray16);
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray18);
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray10, charArray19);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(charArray20);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray22);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray18, floatArray22);
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.add(floatArray18, (float) 0);
        float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, 26, 1);
        int int46 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray44, (float) 2);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, 1.0d, 10.0d);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, 0.0d, (int) (byte) 1, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray0, (int) (byte) 10, 31);
        try {
            double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray17, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        boolean[] booleanArray4 = new boolean[] { true, true, true, false };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray4, false);
        boolean[] booleanArray13 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.add(booleanArray13, true);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray4, booleanArray15);
        boolean[] booleanArray24 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray26 = org.apache.commons.lang3.ArrayUtils.add(booleanArray24, true);
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray24);
        boolean[] booleanArray34 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray36 = org.apache.commons.lang3.ArrayUtils.add(booleanArray34, true);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray36);
        int int40 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray36, false, (int) (short) 0);
        boolean[] booleanArray47 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray49 = org.apache.commons.lang3.ArrayUtils.add(booleanArray47, true);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray49);
        int int53 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray49, false, (int) (short) 0);
        boolean[] booleanArray54 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray36, booleanArray49);
        int int57 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray36, true, (int) ' ');
        boolean[] booleanArray58 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean boolean59 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray58);
        boolean[] booleanArray60 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray36, booleanArray58);
        boolean[] booleanArray61 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray27, booleanArray60);
        boolean[] booleanArray62 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray27);
        boolean[] booleanArray65 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray27, 6, (int) (short) 100);
        boolean[] booleanArray66 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray65);
        boolean boolean67 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray15, booleanArray65);
        boolean boolean68 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray65);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray34);
        org.junit.Assert.assertNotNull(booleanArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(booleanArray47);
        org.junit.Assert.assertNotNull(booleanArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(booleanArray54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
        org.junit.Assert.assertNotNull(booleanArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(booleanArray60);
        org.junit.Assert.assertNotNull(booleanArray61);
        org.junit.Assert.assertNotNull(booleanArray62);
        org.junit.Assert.assertNotNull(booleanArray65);
        org.junit.Assert.assertNotNull(booleanArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, 0, (int) ' ');
        java.lang.Byte[] byteArray23 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray23);
        byte[] byteArray27 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray29 = org.apache.commons.lang3.ArrayUtils.remove(byteArray27, 0);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray24, byteArray27);
        byte[] byteArray32 = org.apache.commons.lang3.ArrayUtils.add(byteArray27, (byte) 10);
        byte[] byteArray33 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray9, byteArray32);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray32);
        int int36 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray32, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                      0a97a100a10  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                      0A97A100A10  " + "'", str1.equals("                                                                                      0A97A100A10  "));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("-1.0", 4, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0" + "'", str3.equals("-1.0"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.subarray(longArray3, 100, (int) (byte) 100);
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.subarray(longArray3, (int) 'a', (int) '#');
        long[] longArray28 = new long[] { (short) 0, 'a', 100 };
        long[] longArray30 = new long[] { (short) 10 };
        long[] longArray31 = new long[] {};
        long[] longArray32 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray30, longArray31);
        long[] longArray33 = org.apache.commons.lang3.ArrayUtils.addAll(longArray28, longArray32);
        long[] longArray37 = new long[] { (short) 0, 'a', 100 };
        long[] longArray39 = new long[] { (short) 10 };
        long[] longArray40 = new long[] {};
        long[] longArray41 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray39, longArray40);
        long[] longArray42 = org.apache.commons.lang3.ArrayUtils.addAll(longArray37, longArray41);
        long[] longArray43 = org.apache.commons.lang3.ArrayUtils.addAll(longArray28, longArray41);
        long[] longArray46 = org.apache.commons.lang3.ArrayUtils.subarray(longArray28, 100, (int) (byte) 100);
        long[] longArray49 = org.apache.commons.lang3.ArrayUtils.subarray(longArray28, (int) 'a', (int) '#');
        long[] longArray50 = org.apache.commons.lang3.ArrayUtils.addAll(longArray24, longArray28);
        boolean boolean51 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray24);
        long[] longArray52 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray24);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertNotNull(longArray31);
        org.junit.Assert.assertNotNull(longArray32);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertNotNull(longArray37);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertNotNull(longArray40);
        org.junit.Assert.assertNotNull(longArray41);
        org.junit.Assert.assertNotNull(longArray42);
        org.junit.Assert.assertNotNull(longArray43);
        org.junit.Assert.assertNotNull(longArray46);
        org.junit.Assert.assertNotNull(longArray49);
        org.junit.Assert.assertNotNull(longArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(longArray52);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.lang.Character[] charArray6 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6, 'a');
        java.lang.Character[] charArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray6);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray11, '#');
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray11, ' ');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "a#4#a# #4##" + "'", str13.equals("a#4#a# #4##"));
        org.junit.Assert.assertNotNull(charArray15);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml3("h-1.0-1.01.0-1.01.01.0h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h-1.0-1.01.0-1.01.01.0h" + "'", str1.equals("h-1.0-1.01.0-1.01.01.0h"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-", "10,3,2}", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeHtml3("974100410410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "974100410410" + "'", str1.equals("974100410410"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("-1.0435.040.041.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0435.040.041.04-1.0410.0" + "'", str1.equals("-1.0435.040.041.04-1.0410.0"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        double[] doubleArray6 = new double[] { (-1), '#', 0.0d, 1.0d, (short) -1, (short) 10 };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 'a', (int) (byte) -1);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 100.0d, (int) (short) -1, (double) (byte) 0);
        java.lang.Double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray6);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("{-1,3,100,10,3,2}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{-1,3,100,10,3,2}" + "'", str1.equals("{-1,3,100,10,3,2}"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        char[] charArray1 = new char[] {};
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "", charArray1);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray1);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isNotEmpty((java.lang.Comparable<java.lang.String>[]) strArray3);
        java.lang.Long[] longArray6 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_OBJECT_ARRAY;
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strArray3, (java.lang.Object[]) longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6);
        java.lang.Long[] longArray9 = org.apache.commons.lang3.ArrayUtils.toObject(longArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("         !", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444!" + "'", str3.equals("444444444!"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.lang.Object[] objArray0 = null;
        java.lang.Object obj1 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(objArray0, obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double[] doubleArray6 = new double[] { (-1), '#', 0.0d, 1.0d, (short) -1, (short) 10 };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 'a', (int) (byte) -1);
        java.lang.Integer[] intArray10 = new java.lang.Integer[] {};
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray10);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray11);
        int[] intArray17 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(intArray17, (int) (byte) 0);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray17);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray12, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray20, 2);
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.clone(intArray20);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray20);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.clone(intArray25);
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.add(intArray26, (int) (short) 100);
        try {
            double[] doubleArray29 = org.apache.commons.lang3.ArrayUtils.removeAll(doubleArray6, intArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = org.apache.commons.lang3.text.translate.UnicodeEscaper.above(99);
        org.junit.Assert.assertNotNull(unicodeEscaper1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1a-1a-1", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray8 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) 10);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray9);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray3, 0, 95);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(shortArray3, (short) 1);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                    ", "\\u0061\\u0061\\u0034\\u0061\\u0061\\u0061\\u0020\\u0061\\u0034\\u0061\\u0023");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("#");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 2);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.clone(intArray10);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.clone(intArray15);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.clone(intArray16);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray17);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray18);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0971001", "");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                                                                    0a97a100a10", "0-1.01.01.0h", "            -1a100a             aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                    0a97a100a10" + "'", str3.equals("                                                                                    0a97a100a10"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                    ", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "{0,97,100,10}                   ", (java.lang.CharSequence) "0a9hi!0a97");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("10.0#100.0#0.0#-1.0#10.0#0.0", "                                                                                      0a97a100a10  ", "0971001");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0#100.0#0.0#-1.0#10.0#0.0" + "'", str3.equals("10.0#100.0#0.0#-1.0#10.0#0.0"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray3, (short) 0);
        try {
            short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray3, (-1), (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.01.01.01.01.01.01.01.01.01.01.0", "hi!                                                                                            ", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("h-1.0-1.01.0-1.01.01.0h", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.0 -1.0 1.0 -1.0 1.0 1.0", "!", (int) (short) 100);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', (int) '#', (int) (short) 10);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                                    0a97a100a10", (java.lang.CharSequence[]) strArray4);
        java.lang.Class<?> wildcardClass10 = strArray4.getClass();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("a#4#a# #4##", 99, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray6);
        boolean[] booleanArray16 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.add(booleanArray16, true);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, false, (int) (short) 0);
        boolean[] booleanArray29 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray31 = org.apache.commons.lang3.ArrayUtils.add(booleanArray29, true);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray31);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray31, false, (int) (short) 0);
        boolean[] booleanArray36 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray31);
        int int39 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, true, (int) ' ');
        boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray40);
        boolean[] booleanArray42 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray40);
        boolean[] booleanArray43 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray9, booleanArray42);
        boolean[] booleanArray44 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray9);
        boolean[] booleanArray47 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray9, (int) 'a', 6);
        int int49 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray47, false);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(booleanArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(booleanArray42);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertNotNull(booleanArray44);
        org.junit.Assert.assertNotNull(booleanArray47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray3 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (int) (short) 100, (double) 26);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray0, 100, (int) (short) 100);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_ESCAPE();
        org.apache.commons.lang3.text.translate.LookupTranslator lookupTranslator1 = new org.apache.commons.lang3.text.translate.LookupTranslator((java.lang.CharSequence[][]) strArray0);
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.Integer[] intArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY;
        java.lang.Integer[] intArray1 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray6);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray6, 0);
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray11, true);
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray14);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                                                                    0a97a100a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("#a4a aaa4aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#a4a aaa4aa" + "'", str1.equals("#a4a aaa4aa"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "0a9hi!0a97", (java.lang.CharSequence) "{0,97,100,10}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        int[][][] intArray0 = new int[][][] {};
        int[] intArray7 = new int[] { (byte) 0, 10, (short) 0, (byte) 1, (byte) 0, (byte) -1 };
        int[] intArray14 = new int[] { (byte) 0, 10, (short) 0, (byte) 1, (byte) 0, (byte) -1 };
        int[] intArray21 = new int[] { (byte) 0, 10, (short) 0, (byte) 1, (byte) 0, (byte) -1 };
        int[][] intArray22 = new int[][] { intArray7, intArray14, intArray21 };
        int[][] intArray25 = org.apache.commons.lang3.ArrayUtils.subarray(intArray22, 100, 4);
        int[][][] intArray26 = org.apache.commons.lang3.ArrayUtils.add(intArray0, intArray22);
        int[][][] intArray27 = org.apache.commons.lang3.ArrayUtils.toArray(intArray0);
        int[][][] intArray30 = org.apache.commons.lang3.ArrayUtils.subarray(intArray27, (-1), (int) (short) 1);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4');
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray0, (short) (byte) 1);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray0);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray0, (short) 10);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("5F");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5F" + "'", str1.equals("5F"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray6);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray6, 0);
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray11, true);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray13, false);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray3);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0971001", "");
        try {
            int int3 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) "0971001");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("0a97a100a10                                                                                         ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray3);
        float[] floatArray21 = new float[] { 'a' };
        float[] floatArray23 = new float[] { (byte) -1 };
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray21, floatArray23);
        float[] floatArray31 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray33 = new float[] { 'a' };
        float[] floatArray35 = new float[] { (byte) -1 };
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray33, floatArray35);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray31, floatArray33);
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray23, floatArray31);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray31, (float) 10, 100);
        float[] floatArray42 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray3, floatArray31);
        float[] floatArray43 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(floatArray31);
        int int45 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray31, 0.0f);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper5 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper6 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray7 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper5, unicodeEscaper6 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator8 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray7);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) strArray2, (java.lang.Object) charSequenceTranslatorArray7, (int) '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceTranslatorArray7, "            -1a100a             ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray0 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray1 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] { oPTIONArray0 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray2 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper3 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray2);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray4 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper5 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray4);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION6 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        boolean boolean7 = numericEntityUnescaper5.isSet(oPTION6);
        boolean boolean8 = numericEntityUnescaper3.isSet(oPTION6);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION9 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION10 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray11 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] { oPTION6, oPTION9, oPTION10 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray12 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] { oPTIONArray11 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray13 = org.apache.commons.lang3.ArrayUtils.removeElements(oPTIONArray1, oPTIONArray12);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray14 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray15 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] { oPTIONArray14 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray16 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper17 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray16);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray18 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper19 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray18);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION20 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        boolean boolean21 = numericEntityUnescaper19.isSet(oPTION20);
        boolean boolean22 = numericEntityUnescaper17.isSet(oPTION20);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION23 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION24 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray25 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] { oPTION20, oPTION23, oPTION24 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray26 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] { oPTIONArray25 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray27 = org.apache.commons.lang3.ArrayUtils.removeElements(oPTIONArray15, oPTIONArray26);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray28 = org.apache.commons.lang3.ArrayUtils.removeElements(oPTIONArray13, oPTIONArray15);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) oPTIONArray13);
        org.junit.Assert.assertNotNull(oPTIONArray0);
        org.junit.Assert.assertNotNull(oPTIONArray1);
        org.junit.Assert.assertNotNull(oPTIONArray2);
        org.junit.Assert.assertNotNull(oPTIONArray4);
        org.junit.Assert.assertTrue("'" + oPTION6 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION6.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + oPTION9 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION9.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + oPTION10 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION10.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertNotNull(oPTIONArray11);
        org.junit.Assert.assertNotNull(oPTIONArray12);
        org.junit.Assert.assertNotNull(oPTIONArray13);
        org.junit.Assert.assertNotNull(oPTIONArray14);
        org.junit.Assert.assertNotNull(oPTIONArray15);
        org.junit.Assert.assertNotNull(oPTIONArray16);
        org.junit.Assert.assertNotNull(oPTIONArray18);
        org.junit.Assert.assertTrue("'" + oPTION20 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION20.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + oPTION23 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION23.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + oPTION24 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION24.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertNotNull(oPTIONArray25);
        org.junit.Assert.assertNotNull(oPTIONArray26);
        org.junit.Assert.assertNotNull(oPTIONArray27);
        org.junit.Assert.assertNotNull(oPTIONArray28);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "10010-1101");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray8, (short) 10, 26);
        short[] shortArray15 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray16 = org.apache.commons.lang3.ArrayUtils.clone(shortArray15);
        short[] shortArray20 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.clone(shortArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray21, (short) 10);
        short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray15, shortArray21);
        short[] shortArray26 = org.apache.commons.lang3.ArrayUtils.add(shortArray24, (short) 0);
        short[] shortArray27 = org.apache.commons.lang3.ArrayUtils.removeElements(shortArray8, shortArray26);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertNotNull(shortArray27);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        int[] intArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(intArray0);
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (int) (short) 0);
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.add(intArray0, (-1));
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 4);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        boolean[] booleanArray4 = new boolean[] { true, true, true, false };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray4, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray4, (int) ' ', 6);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(booleanArray9);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####H#####I#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray8 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) 10);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray9);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray3);
        java.lang.Character[] charArray20 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray20, 'a');
        java.lang.Character[] charArray23 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray20);
        short[] shortArray27 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray28 = org.apache.commons.lang3.ArrayUtils.clone(shortArray27);
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray28, (short) 10);
        java.lang.Short[] shortArray31 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray28);
        short[] shortArray32 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.contains(shortArray32, (short) 0);
        short[] shortArray35 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray28, shortArray32);
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray28, (short) 100, 5);
        int int39 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) charArray20, (java.lang.Object) shortArray28);
        short[] shortArray40 = org.apache.commons.lang3.ArrayUtils.removeElements(shortArray3, shortArray28);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(shortArray27);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(shortArray31);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(shortArray35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(shortArray40);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray0 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] {};
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray1 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] {};
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray2 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] {};
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray3 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] {};
        org.apache.commons.lang3.text.translate.CodePointTranslator[][] codePointTranslatorArray4 = new org.apache.commons.lang3.text.translate.CodePointTranslator[][] { codePointTranslatorArray0, codePointTranslatorArray1, codePointTranslatorArray2, codePointTranslatorArray3 };
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray5 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] {};
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray6 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] {};
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray7 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] {};
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray8 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] {};
        org.apache.commons.lang3.text.translate.CodePointTranslator[][] codePointTranslatorArray9 = new org.apache.commons.lang3.text.translate.CodePointTranslator[][] { codePointTranslatorArray5, codePointTranslatorArray6, codePointTranslatorArray7, codePointTranslatorArray8 };
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray10 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] {};
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray11 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] {};
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray12 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] {};
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray13 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] {};
        org.apache.commons.lang3.text.translate.CodePointTranslator[][] codePointTranslatorArray14 = new org.apache.commons.lang3.text.translate.CodePointTranslator[][] { codePointTranslatorArray10, codePointTranslatorArray11, codePointTranslatorArray12, codePointTranslatorArray13 };
        org.apache.commons.lang3.text.translate.CodePointTranslator[][][] codePointTranslatorArray15 = new org.apache.commons.lang3.text.translate.CodePointTranslator[][][] { codePointTranslatorArray4, codePointTranslatorArray9, codePointTranslatorArray14 };
        char[] charArray19 = new char[] { 'a', 'a', ' ' };
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.remove(charArray19, (int) (byte) 1);
        char[] charArray26 = new char[] { '#', '#', '#', ' ' };
        char[] charArray30 = new char[] { 'a', ' ', '#' };
        char[] charArray31 = org.apache.commons.lang3.ArrayUtils.addAll(charArray26, charArray30);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray19, charArray30);
        char[] charArray33 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        char[] charArray35 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray33, 'a');
        int int37 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray35, ' ');
        char[] charArray38 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray30, charArray35);
        char[] charArray39 = org.apache.commons.lang3.ArrayUtils.clone(charArray30);
        org.apache.commons.lang3.text.translate.CodePointTranslator[][][] codePointTranslatorArray40 = org.apache.commons.lang3.ArrayUtils.removeElement(codePointTranslatorArray15, (java.lang.Object) charArray39);
        org.junit.Assert.assertNotNull(codePointTranslatorArray0);
        org.junit.Assert.assertNotNull(codePointTranslatorArray1);
        org.junit.Assert.assertNotNull(codePointTranslatorArray2);
        org.junit.Assert.assertNotNull(codePointTranslatorArray3);
        org.junit.Assert.assertNotNull(codePointTranslatorArray4);
        org.junit.Assert.assertNotNull(codePointTranslatorArray5);
        org.junit.Assert.assertNotNull(codePointTranslatorArray6);
        org.junit.Assert.assertNotNull(codePointTranslatorArray7);
        org.junit.Assert.assertNotNull(codePointTranslatorArray8);
        org.junit.Assert.assertNotNull(codePointTranslatorArray9);
        org.junit.Assert.assertNotNull(codePointTranslatorArray10);
        org.junit.Assert.assertNotNull(codePointTranslatorArray11);
        org.junit.Assert.assertNotNull(codePointTranslatorArray12);
        org.junit.Assert.assertNotNull(codePointTranslatorArray13);
        org.junit.Assert.assertNotNull(codePointTranslatorArray14);
        org.junit.Assert.assertNotNull(codePointTranslatorArray15);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertNotNull(codePointTranslatorArray40);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.clone(longArray18);
        long[] longArray20 = null;
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.addAll(longArray19, longArray20);
        java.lang.String str23 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) longArray19, "h-1.0 -1.0 1.0 -1.0 1.0 1.0h");
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(longArray19, 'a');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{0,97,100,10}" + "'", str23.equals("{0,97,100,10}"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0a97a100a10" + "'", str25.equals("0a97a100a10"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "0a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "#4#4#4 4a4 4#", (java.lang.CharSequence) "974100410410", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        java.lang.Long[] longArray2 = new java.lang.Long[] { 1L, 100L };
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2, (long) (short) 0);
        java.lang.Long[] longArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray2);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray7, ' ');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1 100" + "'", str9.equals("1 100"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        char[] charArray4 = new char[] { '#', '#', ' ' };
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(charArray4);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.add(charArray4, '#');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "{0,97,100,10}", charArray7);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("-1 100 1", "0971001", "                                                    ", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 100 1" + "'", str4.equals("-1 100 1"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray6);
        boolean[] booleanArray16 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.add(booleanArray16, true);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, false, (int) (short) 0);
        boolean[] booleanArray29 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray31 = org.apache.commons.lang3.ArrayUtils.add(booleanArray29, true);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray31);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray31, false, (int) (short) 0);
        boolean[] booleanArray36 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray31);
        int int39 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, true, (int) ' ');
        boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray40);
        boolean[] booleanArray42 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray40);
        boolean[] booleanArray43 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray9, booleanArray42);
        boolean[] booleanArray50 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray52 = org.apache.commons.lang3.ArrayUtils.add(booleanArray50, true);
        boolean[] booleanArray53 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray50);
        boolean[] booleanArray60 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray62 = org.apache.commons.lang3.ArrayUtils.add(booleanArray60, true);
        boolean boolean63 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray62);
        int int66 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray62, false, (int) (short) 0);
        boolean[] booleanArray73 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray75 = org.apache.commons.lang3.ArrayUtils.add(booleanArray73, true);
        boolean boolean76 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray75);
        int int79 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray75, false, (int) (short) 0);
        boolean[] booleanArray80 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray62, booleanArray75);
        int int83 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray62, true, (int) ' ');
        boolean[] booleanArray84 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean boolean85 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray84);
        boolean[] booleanArray86 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray62, booleanArray84);
        boolean[] booleanArray87 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray53, booleanArray86);
        boolean[] booleanArray88 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray53);
        boolean[] booleanArray89 = org.apache.commons.lang3.ArrayUtils.removeElements(booleanArray43, booleanArray53);
        boolean[] booleanArray91 = org.apache.commons.lang3.ArrayUtils.add(booleanArray43, false);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(booleanArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(booleanArray42);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertNotNull(booleanArray50);
        org.junit.Assert.assertNotNull(booleanArray52);
        org.junit.Assert.assertNotNull(booleanArray53);
        org.junit.Assert.assertNotNull(booleanArray60);
        org.junit.Assert.assertNotNull(booleanArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(booleanArray73);
        org.junit.Assert.assertNotNull(booleanArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(booleanArray80);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 6 + "'", int83 == 6);
        org.junit.Assert.assertNotNull(booleanArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(booleanArray86);
        org.junit.Assert.assertNotNull(booleanArray87);
        org.junit.Assert.assertNotNull(booleanArray88);
        org.junit.Assert.assertNotNull(booleanArray89);
        org.junit.Assert.assertNotNull(booleanArray91);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        char[] charArray4 = new char[] { '#', '#', '#', ' ' };
        char[] charArray8 = new char[] { 'a', ' ', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray9, '#');
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray9, '4');
        try {
            char[] charArray15 = org.apache.commons.lang3.ArrayUtils.remove(charArray9, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 7");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray0, (float) 'a', (int) (byte) -1);
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray0, (float) 2);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray0, (float) ' ', 0);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) doubleArray2, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) doubleArray2, '4');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.040.0" + "'", str5.equals("1.040.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.040.0" + "'", str7.equals("1.040.0"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("{-1,3,100,10,3,2}", "-1a100a", 24);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "  1   ", (java.lang.CharSequence) "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        java.lang.Float[] floatArray0 = new java.lang.Float[] {};
        float[] floatArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0, (float) ' ');
        java.lang.Float[] floatArray3 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(floatArray0);
        float[] floatArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray3);
        float[] floatArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        char[] charArray4 = new char[] { 'a', 'a', ' ' };
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.remove(charArray4, (int) (byte) 1);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "  23                      ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray3, (short) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray3);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(shortArray3, (short) 10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper2 = org.apache.commons.lang3.text.translate.UnicodeEscaper.outsideOf((int) (byte) 10, (int) (byte) 1);
        java.lang.String str4 = unicodeEscaper2.translate((java.lang.CharSequence) "{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H{{0.0},{0.0},{0.0},{0.0},{0.0}}");
        org.junit.Assert.assertNotNull(unicodeEscaper2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D" + "'", str4.equals("\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u002D\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u002D\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0020\\u0031\\u002E\\u0030\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u0049\\u0021\\u0048\\u007B\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u002C\\u007B\\u0030\\u002E\\u0030\\u007D\\u007D"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("10,3,2}", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) 2, (int) '#', (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 5);
        java.lang.Double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray7);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) (-1.0f), 90);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        short[] shortArray0 = null;
        try {
            short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.remove(shortArray0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        byte[] byteArray0 = null;
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.add(byteArray0, (byte) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray0);
        org.junit.Assert.assertNotNull(byteArray2);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray8 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) 10);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray9);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray3);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray3, (short) (byte) 0);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shortArray15);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray23 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray25 = new float[] { 'a' };
        float[] floatArray27 = new float[] { (byte) -1 };
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray25, floatArray27);
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray23, floatArray25);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.join(floatArray23, ' ');
        float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.add(floatArray23, (float) 0L);
        float[] floatArray35 = org.apache.commons.lang3.ArrayUtils.add(floatArray23, (float) (short) 100);
        float[] floatArray37 = new float[] { 'a' };
        float[] floatArray39 = new float[] { (byte) -1 };
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray37, floatArray39);
        float[] floatArray47 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray49 = new float[] { 'a' };
        float[] floatArray51 = new float[] { (byte) -1 };
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray49, floatArray51);
        boolean boolean53 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray47, floatArray49);
        float[] floatArray54 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray39, floatArray47);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray39);
        float[] floatArray56 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray35, floatArray39);
        float[] floatArray57 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray6, floatArray39);
        java.lang.String str59 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) floatArray57, "                                                                                      0A97A100A10  ");
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str31.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "{-1.0,-1.0,1.0,-1.0,1.0,1.0,-1.0}" + "'", str59.equals("{-1.0,-1.0,1.0,-1.0,1.0,1.0,-1.0}"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                                                    0a97a100a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "01a001a79a0                                                                                    " + "'", str1.equals("01a001a79a0                                                                                    "));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        java.lang.Object obj0 = null;
        java.lang.String str2 = org.apache.commons.lang3.ArrayUtils.toString(obj0, "                                                                                      0A97A100A10   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                      0A97A100A10   " + "'", str2.equals("                                                                                      0A97A100A10   "));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 2);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.clone(intArray10);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.clone(intArray15);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.clone(intArray16);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray17);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray17, (int) (byte) 100);
        int[] intArray23 = org.apache.commons.lang3.ArrayUtils.add(intArray17, 3, 0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "0", (java.lang.CharSequence) "-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        short[] shortArray0 = null;
        short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray0, (short) (byte) 1);
        org.junit.Assert.assertNull(shortArray2);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1F", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.Double[] doubleArray0 = null;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, (double) 6);
        org.junit.Assert.assertNull(doubleArray2);
    }
}

