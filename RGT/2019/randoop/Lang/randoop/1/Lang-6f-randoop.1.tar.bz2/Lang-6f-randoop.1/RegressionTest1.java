import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        char[] charArray4 = new char[] { '#', '#', '#', ' ' };
        char[] charArray8 = new char[] { 'a', ' ', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ', (int) (short) 10, 6);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("-1a100a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a100a" + "'", str1.equals("-1a100a"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml3("-1a100a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a100a" + "'", str1.equals("-1a100a"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(floatArray8, 0.0f);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("         !", "34");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         !" + "'", str2.equals("         !"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.ISO8859_1_UNESCAPE();
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isNotEmpty((java.io.Serializable[]) strArray0);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        short[] shortArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 95, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeHtml4("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    " + "'", str1.equals("                                                                                                    "));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        float[] floatArray0 = null;
        int[] intArray5 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(intArray5, (int) (byte) 0);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray5);
        try {
            float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.removeAll(floatArray0, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("{-1,3,100,10,3,2}", 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{-1,3,100,10,3,2}" + "'", str3.equals("{-1,3,100,10,3,2}"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        java.lang.Integer[] intArray4 = new java.lang.Integer[] {};
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray5);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray3, intArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', (int) ' ', (-1));
        java.lang.Integer[] intArray12 = org.apache.commons.lang3.ArrayUtils.toObject(intArray6);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        boolean[] booleanArray4 = new boolean[] { true, true, true, false };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray4, false);
        boolean[] booleanArray13 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.add(booleanArray13, true);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray4, booleanArray15);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray4);
        int[] intArray23 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.contains(intArray23, (int) (byte) 0);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray23);
        java.lang.Integer[] intArray27 = new java.lang.Integer[] {};
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray27);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray28);
        int[] intArray34 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.contains(intArray34, (int) (byte) 0);
        int[] intArray37 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray34);
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray29, intArray37);
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray23, intArray29);
        int[] intArray41 = org.apache.commons.lang3.ArrayUtils.add(intArray23, 0);
        try {
            boolean[] booleanArray42 = org.apache.commons.lang3.ArrayUtils.removeAll(booleanArray18, intArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(intArray41);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                                    ", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     ..." + "'", str2.equals("                     ..."));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.util.Map<java.lang.Object, java.lang.Object> objMap2 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(objMap2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray14, 'a');
        int[] intArray17 = null;
        try {
            byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.removeAll(byteArray14, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1a100a1" + "'", str16.equals("-1a100a1"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.Short[] shortArray1 = new java.lang.Short[] { (short) 1 };
        java.lang.Short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray1);
        java.lang.Short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray2);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "#####", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        float[] floatArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("  23  ", (int) (byte) -1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  23  " + "'", str3.equals("  23  "));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        char[] charArray0 = null;
        char[] charArray1 = null;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray0, charArray1);
        org.junit.Assert.assertNull(charArray2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0 97 100 10", (int) 'a', "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hi!", (int) (byte) 10, "0a97a100a10                                                                                         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a9hi!0a97" + "'", str3.equals("0a9hi!0a97"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI", "0a97a100a10                                                                                         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1 100", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        java.lang.Integer[] intArray8 = new java.lang.Integer[] {};
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray8);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray9);
        int[] intArray15 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(intArray15, (int) (byte) 0);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray15);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray10, intArray18);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray4, intArray10);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 0);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.contains(intArray22, 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("{{0.0},{0.0},{0.0},{0.0},{0.0}}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{{0.0},{0.0},{0.0},{0.0},{0.0}}" + "'", str1.equals("{{0.0},{0.0},{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.Long[] longArray0 = null;
        long[] longArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray0, (long) 10);
        org.junit.Assert.assertNull(longArray2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (short) 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray6, (short) (byte) 100);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1a-1a-1" + "'", str8.equals("1a-1a-1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray1, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 26);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray1);
        java.lang.Integer[] intArray16 = new java.lang.Integer[] {};
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray16);
        try {
            double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.removeAll(doubleArray0, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (byte) 1, (double) 100L);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (short) -1, (int) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "  23  ", (java.lang.CharSequence) "                     ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("         !", (int) (short) -1, "0a97a100a10                                                                                         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         !" + "'", str3.equals("         !"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                    ", "                                                                                    0a97a100a10", 26);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        char[] charArray1 = new char[] {};
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "", charArray1);
        char[] charArray3 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray3, '4');
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("h-1.0 -1.0 1.0 -1.0 1.0 1.0h", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.Character[] charArray7 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray7, 'a');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "!", charArray9);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray9, '#', (int) ' ');
        char[] charArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray9);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(charArray14);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 10, (byte) 1, (byte) 10 };
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####h#####i#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: #####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####h#####i#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator0 = org.apache.commons.lang3.StringEscapeUtils.UNESCAPE_ECMASCRIPT;
        org.junit.Assert.assertNotNull(charSequenceTranslator0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.0 -1.0 1.0 -1.0 1.0 1.0", "-1.0 -1.0 1.0 -1.0 1.0 1.0", 1);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", strArray5, strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str8.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("0 97 100 10", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 97 100 10" + "'", str2.equals("0 97 100 10"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "-1a100a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("974100410410", 0, "{0,97,100,10}                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "974100410410" + "'", str3.equals("974100410410"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                    ", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("23", "                     ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "23" + "'", str2.equals("23"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.subarray(longArray3, 100, (int) (byte) 100);
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.subarray(longArray3, (int) 'a', (int) '#');
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray24, (long) (byte) 1);
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.join(longArray24, '4');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0a97a100a10", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a" + "'", str2.equals("0a"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                                    0A97A100A10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                                    0A97A100A10", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                      0A97A100A10   " + "'", str2.equals("                                                                                      0A97A100A10   "));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "1a-1a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.Byte[] byteArray1 = new java.lang.Byte[] { (byte) 0 };
        java.lang.Byte[][] byteArray2 = new java.lang.Byte[][] { byteArray1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray2);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "23", (java.lang.CharSequence) "  23  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray10);
        try {
            int[] intArray14 = org.apache.commons.lang3.ArrayUtils.add(intArray10, 11, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        char[] charArray3 = new char[] { 'a', 'a', ' ' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.remove(charArray3, (int) (byte) 1);
        char[] charArray10 = new char[] { '#', '#', '#', ' ' };
        char[] charArray14 = new char[] { 'a', ' ', '#' };
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.addAll(charArray10, charArray14);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray3, charArray14);
        int[] intArray17 = null;
        try {
            char[] charArray18 = org.apache.commons.lang3.ArrayUtils.removeAll(charArray14, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeEcmaScript("{-1,3,100,10,3,2}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{-1,3,100,10,3,2}" + "'", str1.equals("{-1,3,100,10,3,2}"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1.0 -1.0 1.0 -1.0 1.0 1.0", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) strArray2, (java.lang.Object) "a1", (int) '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str4.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 10);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper10 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray11 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] { unicodeEscaper10 };
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray12 = org.apache.commons.lang3.ArrayUtils.toArray(codePointTranslatorArray11);
        int[] intArray17 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(intArray17, (int) (byte) 0);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray17);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.add(intArray17, 10);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) codePointTranslatorArray12, (java.lang.Object) intArray17);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray17, (int) '4', 0);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.removeElements(intArray4, intArray17);
        try {
            int[] intArray30 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 11, 95);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(codePointTranslatorArray11);
        org.junit.Assert.assertNotNull(codePointTranslatorArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (short) 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray6, 3, (short) (byte) -1);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray11, (short) (byte) 10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1a-1a-1" + "'", str8.equals("1a-1a-1"));
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("#####", "                                                                                    0A97A100A10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#####" + "'", str2.equals("#####"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 100, 0);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, (-1), (int) (short) 100);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(byteArray12);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("974100410410", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                                    0a97a100a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.Float[] floatArray2 = new java.lang.Float[] { 1.0f, 10.0f };
        float[] floatArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray2, (float) 100L);
        try {
            float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.add(floatArray4, (int) '4', 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray8);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray8, (long) (byte) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray8, 'a', (int) 'a', (int) (byte) -1);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(longArray8, (-1L));
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.lang.Byte[] byteArray0 = null;
        java.lang.Byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0a97a100a10", "-1a100a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a97a100a10" + "'", str2.equals("0a97a100a10"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "hi!");
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray3 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper4 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray3);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strArray2, (java.lang.Object[]) oPTIONArray3);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray6 = org.apache.commons.lang3.ArrayUtils.clone(oPTIONArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) oPTIONArray3, " ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(oPTIONArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(oPTIONArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper0 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        java.io.Writer writer3 = null;
        try {
            int int4 = unicodeUnescaper0.translate((java.lang.CharSequence) "-1a100a", (int) (byte) 10, writer3);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 10");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "h-1.0-1.01.0-1.01.01.0h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray6, (byte) -1);
        java.lang.Integer[] intArray9 = new java.lang.Integer[] {};
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray9);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        int[] intArray16 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(intArray16, (int) (byte) 0);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray16);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray11, intArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray19, 2);
        int[] intArray23 = org.apache.commons.lang3.ArrayUtils.clone(intArray19);
        try {
            byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.removeAll(byteArray8, intArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.040.0", (java.lang.CharSequence) "h-1.0-1.01.0-1.01.01.0h");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper2 = org.apache.commons.lang3.text.translate.UnicodeEscaper.outsideOf(0, 4);
        org.junit.Assert.assertNotNull(unicodeEscaper2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        long[] longArray0 = null;
        try {
            long[] longArray3 = org.apache.commons.lang3.ArrayUtils.add(longArray0, (int) (byte) 10, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(floatArray6, 0.0f);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("34", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                 34                                                 " + "'", str2.equals("                                                 34                                                 "));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("0971001", "0 97 100 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) byteArray5);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        float[] floatArray0 = null;
        float[] floatArray2 = new float[] { 'a' };
        float[] floatArray4 = new float[] { (byte) -1 };
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray2, floatArray4);
        float[] floatArray12 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray14 = new float[] { 'a' };
        float[] floatArray16 = new float[] { (byte) -1 };
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray14, floatArray16);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray12, floatArray14);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray4, floatArray12);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray4);
        float[] floatArray27 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray29 = new float[] { 'a' };
        float[] floatArray31 = new float[] { (byte) -1 };
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray29, floatArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray27, floatArray29);
        java.lang.String str35 = org.apache.commons.lang3.StringUtils.join(floatArray27, ' ');
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.add(floatArray27, (float) 0L);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.add(floatArray27, (float) (short) 100);
        int int41 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray39, 10.0f);
        boolean boolean42 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray39);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray20);
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray0, floatArray20);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str35.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper0 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        java.lang.String str2 = unicodeUnescaper0.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        java.io.Writer writer5 = null;
        try {
            int int6 = unicodeUnescaper0.translate((java.lang.CharSequence) "0a", 5, writer5);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', (int) (short) -1, (int) (byte) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1 100", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 " + "'", str2.equals("1 "));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###########" + "'", str2.equals("###########"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray3, (long) 'a', (int) (short) 0);
        int[] intArray11 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray11, (int) (byte) 0);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray11);
        java.lang.Integer[] intArray15 = new java.lang.Integer[] {};
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray15);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray16);
        int[] intArray22 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.contains(intArray22, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray22);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray17, intArray25);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray11, intArray17);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.add(intArray11, 0);
        try {
            long[] longArray30 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray3, intArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray2 = new java.lang.String[] {};
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[] strArray4 = new java.lang.String[] {};
        java.lang.String[][] strArray5 = new java.lang.String[][] { strArray0, strArray1, strArray2, strArray3, strArray4 };
        java.lang.String[][][] strArray6 = new java.lang.String[][][] { strArray5 };
        byte[] byteArray10 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.remove(byteArray10, 0);
        java.lang.String[][] strArray13 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_ESCAPE();
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) byteArray12, (java.lang.Object) strArray13);
        try {
            java.lang.String[][][] strArray15 = org.apache.commons.lang3.ArrayUtils.add(strArray6, (int) 'a', strArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + "'", str1.equals("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray18, (long) 24);
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray18);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(longArray21);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double[] doubleArray0 = null;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) 1L);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        char[] charArray5 = new char[] { '#', '#', '#', ' ' };
        char[] charArray9 = new char[] { 'a', ' ', '#' };
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.addAll(charArray5, charArray9);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray9, '#', (int) (byte) 10);
        char[] charArray14 = null;
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray9, charArray14);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.040.0", charArray14);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray1, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 26);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray1);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("a1", "a1", "1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1a-1a-1", "-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a-1a-1" + "'", str2.equals("1a-1a-1"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 2);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.clone(intArray10);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.clone(intArray15);
        try {
            int[] intArray19 = org.apache.commons.lang3.ArrayUtils.add(intArray15, 24, 95);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 24, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("-1.0 -1.0 1.0 -1.0 1.0 1.0", "                     ...", "                                                                                    0a97a100a10", (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str4.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { (-1), 3, 100, 10, 3, 2 };
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray6, (int) '4');
        java.lang.String str10 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) intArray6, "0a97a100a10");
        java.lang.Integer[] intArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray6);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap12 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, '-1', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{-1,3,100,10,3,2}" + "'", str10.equals("{-1,3,100,10,3,2}"));
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("{-1,3,100,10,3,2}", (int) (short) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10,3,2}" + "'", str3.equals("10,3,2}"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                 34                                                 ", "h-1.0 -1.0 1.0 -1.0 1.0 1.0h", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray8 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) 10);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray9);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray12, (short) 10);
        short[] shortArray18 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.clone(shortArray18);
        short[] shortArray23 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.clone(shortArray23);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray24, (short) 10);
        short[] shortArray27 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray18, shortArray24);
        short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray18, 0, 95);
        short[] shortArray32 = org.apache.commons.lang3.ArrayUtils.add(shortArray30, (short) (byte) 100);
        short[] shortArray33 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray12, shortArray30);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(shortArray30);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(shortArray27);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertNotNull(shortArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                    0A97A100A10", (java.lang.CharSequence) "974100410410", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(" ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0a9hi!0a97", (java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1 ", "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 " + "'", str2.equals("1 "));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1 ", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  1   " + "'", str2.equals("  1   "));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                                    ", (int) (byte) 0, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.lang3.text.translate.OctalUnescaper octalUnescaper0 = new org.apache.commons.lang3.text.translate.OctalUnescaper();
        java.io.Writer writer3 = null;
        int int4 = octalUnescaper0.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 6, writer3);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper5 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper6 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper7 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper8 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper9 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper10 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray11 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper5, unicodeUnescaper6, unicodeUnescaper7, unicodeUnescaper8, unicodeUnescaper9, unicodeUnescaper10 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray12 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray11);
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator13 = octalUnescaper0.with((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray12);
        java.lang.CharSequence charSequence14 = null;
        java.io.Writer writer16 = null;
        try {
            int int17 = octalUnescaper0.translate(charSequence14, (int) (short) -1, writer16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray11);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray12);
        org.junit.Assert.assertNotNull(charSequenceTranslator13);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0 97 100 10", "0a97a100a10");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 97 100 10" + "'", str3.equals("0 97 100 10"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("#####", "0a");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.Integer[] intArray0 = null;
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        org.junit.Assert.assertNull(intArray1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "aa4aaa a4a#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        byte[] byteArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray6);
        boolean[] booleanArray16 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.add(booleanArray16, true);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, false, (int) (short) 0);
        boolean[] booleanArray29 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray31 = org.apache.commons.lang3.ArrayUtils.add(booleanArray29, true);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray31);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray31, false, (int) (short) 0);
        boolean[] booleanArray36 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray31);
        int int39 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, true, (int) ' ');
        boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray40);
        boolean[] booleanArray42 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray40);
        boolean[] booleanArray43 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray9, booleanArray42);
        boolean[] booleanArray45 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray9, true);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(booleanArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(booleanArray42);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertNotNull(booleanArray45);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (short) 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray6, 3, (short) (byte) -1);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray6, (short) (byte) 100, 6);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1a-1a-1" + "'", str8.equals("1a-1a-1"));
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        byte[] byteArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_ARRAY;
        org.junit.Assert.assertNotNull(byteArray0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("A", "23");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, 0, (int) ' ');
        java.lang.Byte[] byteArray23 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray23);
        byte[] byteArray27 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray29 = org.apache.commons.lang3.ArrayUtils.remove(byteArray27, 0);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray24, byteArray27);
        byte[] byteArray32 = org.apache.commons.lang3.ArrayUtils.add(byteArray27, (byte) 10);
        byte[] byteArray33 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray9, byteArray32);
        byte[] byteArray34 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray36 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray34, (byte) -1);
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray34, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI", (int) (byte) 100);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1a-1a-1", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                 34                                                 ", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90 + "'", int2 == 90);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.lang3.text.translate.OctalUnescaper octalUnescaper0 = new org.apache.commons.lang3.text.translate.OctalUnescaper();
        java.io.Writer writer3 = null;
        int int4 = octalUnescaper0.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 6, writer3);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper5 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper6 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper7 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper8 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper9 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper10 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray11 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper5, unicodeUnescaper6, unicodeUnescaper7, unicodeUnescaper8, unicodeUnescaper9, unicodeUnescaper10 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray12 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray11);
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator13 = octalUnescaper0.with((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray12);
        java.lang.String str15 = charSequenceTranslator13.translate((java.lang.CharSequence) "a1");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray11);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray12);
        org.junit.Assert.assertNotNull(charSequenceTranslator13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "a1" + "'", str15.equals("a1"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("-1.0 -1.0 1.0 -1.0 1.0 1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str1.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("-1a100a", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            -1a100a             " + "'", str2.equals("            -1a100a             "));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        char[] charArray0 = null;
        int[] intArray1 = null;
        try {
            char[] charArray2 = org.apache.commons.lang3.ArrayUtils.removeAll(charArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1 ", "0a9hi!0a97");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.040.0", "  1   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.040.0" + "'", str2.equals("1.040.0"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.lang.Float[] floatArray3 = new java.lang.Float[] { 10.0f, 10.0f, (-1.0f) };
        java.lang.Float[][] floatArray4 = new java.lang.Float[][] { floatArray3 };
        java.lang.Float[][] floatArray5 = org.apache.commons.lang3.ArrayUtils.toArray(floatArray4);
        long[] longArray7 = new long[] { (short) 10 };
        long[] longArray8 = new long[] {};
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray7, longArray8);
        java.lang.Integer[] intArray10 = new java.lang.Integer[] {};
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray10);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray11);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray9, intArray12);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray13, (long) (short) 0, 2);
        java.lang.Float[][] floatArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray5, (java.lang.Object) (short) 0);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-1.0 -1.0 1.0 -1.0 1.0 1.0", (java.lang.CharSequence) "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####h#####i#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.String str1 = org.apache.commons.lang3.text.translate.CharSequenceTranslator.hex(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0" + "'", str1.equals("0"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        long[] longArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_ARRAY;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray0);
        long[] longArray5 = new long[] { (short) 0, 'a', 100 };
        long[] longArray7 = new long[] { (short) 10 };
        long[] longArray8 = new long[] {};
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray7, longArray8);
        long[] longArray10 = org.apache.commons.lang3.ArrayUtils.addAll(longArray5, longArray9);
        long[] longArray14 = new long[] { (short) 0, 'a', 100 };
        long[] longArray16 = new long[] { (short) 10 };
        long[] longArray17 = new long[] {};
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray16, longArray17);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray18);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.addAll(longArray5, longArray18);
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.clone(longArray20);
        long[] longArray22 = null;
        long[] longArray23 = org.apache.commons.lang3.ArrayUtils.addAll(longArray21, longArray22);
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray0, longArray22);
        long[] longArray28 = new long[] { (short) 0, 'a', 100 };
        long[] longArray30 = new long[] { (short) 10 };
        long[] longArray31 = new long[] {};
        long[] longArray32 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray30, longArray31);
        long[] longArray33 = org.apache.commons.lang3.ArrayUtils.addAll(longArray28, longArray32);
        long[] longArray37 = new long[] { (short) 0, 'a', 100 };
        long[] longArray39 = new long[] { (short) 10 };
        long[] longArray40 = new long[] {};
        long[] longArray41 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray39, longArray40);
        long[] longArray42 = org.apache.commons.lang3.ArrayUtils.addAll(longArray37, longArray41);
        long[] longArray43 = org.apache.commons.lang3.ArrayUtils.addAll(longArray28, longArray41);
        long[] longArray44 = org.apache.commons.lang3.ArrayUtils.clone(longArray43);
        long[] longArray45 = null;
        long[] longArray46 = org.apache.commons.lang3.ArrayUtils.addAll(longArray44, longArray45);
        java.lang.String str48 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) longArray44, "h-1.0 -1.0 1.0 -1.0 1.0 1.0h");
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray44);
        long[] longArray50 = org.apache.commons.lang3.ArrayUtils.addAll(longArray0, longArray44);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertNotNull(longArray31);
        org.junit.Assert.assertNotNull(longArray32);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertNotNull(longArray37);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertNotNull(longArray40);
        org.junit.Assert.assertNotNull(longArray41);
        org.junit.Assert.assertNotNull(longArray42);
        org.junit.Assert.assertNotNull(longArray43);
        org.junit.Assert.assertNotNull(longArray44);
        org.junit.Assert.assertNotNull(longArray46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "{0,97,100,10}" + "'", str48.equals("{0,97,100,10}"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(longArray50);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("0 97 100 1", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                             0 97 100 1                                             " + "'", str2.equals("                                             0 97 100 1                                             "));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("{-1,3,100,10,3,2}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{-1,3,100,10,3,2" + "'", str1.equals("{-1,3,100,10,3,2"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                                                                    0a97a100a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 2);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.clone(intArray10);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(intArray15, 2);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(intArray15);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray7, (short) -1, 24);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(shortArray7);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper0 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper1 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper2 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper3 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper4 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper5 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray6 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper0, unicodeUnescaper1, unicodeUnescaper2, unicodeUnescaper3, unicodeUnescaper4, unicodeUnescaper5 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray7 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray6);
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator8 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray6);
        java.lang.Integer[] intArray9 = new java.lang.Integer[] {};
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray9);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        int[] intArray16 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(intArray16, (int) (byte) 0);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray16);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray11, intArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray19, 2);
        int[] intArray23 = org.apache.commons.lang3.ArrayUtils.clone(intArray19);
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray19);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.contains(intArray24, 2);
        try {
            org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray27 = org.apache.commons.lang3.ArrayUtils.removeAll(unicodeUnescaperArray6, intArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(unicodeUnescaperArray6);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("{{0.0},{0.0},{0.0},{0.0},{0.0}}", 0, "aa4aaa a4a#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{{0.0},{0.0},{0.0},{0.0},{0.0}}" + "'", str3.equals("{{0.0},{0.0},{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("A");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A" + "'", str1.equals("A"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1 ", 24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray8 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) 10);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray9);
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.add(shortArray12, (short) 0);
        try {
            short[] shortArray16 = org.apache.commons.lang3.ArrayUtils.remove(shortArray12, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 24, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray14);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, 0, (int) ' ');
        java.lang.Byte[] byteArray23 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray23);
        byte[] byteArray27 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray29 = org.apache.commons.lang3.ArrayUtils.remove(byteArray27, 0);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray24, byteArray27);
        byte[] byteArray32 = org.apache.commons.lang3.ArrayUtils.add(byteArray27, (byte) 10);
        byte[] byteArray33 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray9, byteArray32);
        byte[] byteArray34 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray36 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray34, (byte) -1);
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray36, (byte) 0, (int) '4');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("  1   ", "{-1,3,100,10,3,2}", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray4);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "974100410410" + "'", str8.equals("974100410410"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        int[] intArray7 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(intArray7, (int) (byte) 0);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray2, intArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 2);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray10);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, (int) (byte) 0);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray10);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.remove(intArray4, 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("0 97 100 10", "10", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        char[] charArray1 = new char[] { '#' };
        char[] charArray3 = org.apache.commons.lang3.ArrayUtils.add(charArray1, '#');
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.subarray(charArray3, (int) (short) 10, 0);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray3, ' ');
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####h#####i#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####", (java.lang.CharSequence) "0a97a100a10                                                                                         ", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray0, (int) (byte) 100, 1);
        boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean[] booleanArray7 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray4, (int) (byte) 100, 1);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray0, booleanArray7);
        try {
            boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray7, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1 ", (java.lang.CharSequence) "  23  ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.040.0", (java.lang.CharSequence) "###########", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) 2, (int) '#', (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 5);
        try {
            double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray7, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) 100, (short) -1, (short) 1 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) 1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) shortArray3, "10");
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10010-1101" + "'", str7.equals("10010-1101"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray8);
        float[] floatArray14 = null;
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray14);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("  23  ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  23  " + "'", str2.equals("  23  "));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("{-1,3,100,10,3,2", "974100410410", "1a-1a-1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) 100, (short) -1, (short) 1 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) 1);
        java.lang.Short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray3);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray6, (short) (byte) 10);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        int int0 = org.apache.commons.lang3.StringUtils.INDEX_NOT_FOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4');
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray0, (short) (byte) 1);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray0);
        short[] shortArray9 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.clone(shortArray9);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.removeElements(shortArray0, shortArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray11);
        int[] intArray17 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(intArray17, (int) (byte) 0);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray17);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.add(intArray17, 10);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper23 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray24 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] { unicodeEscaper23 };
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray25 = org.apache.commons.lang3.ArrayUtils.toArray(codePointTranslatorArray24);
        int[] intArray30 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.contains(intArray30, (int) (byte) 0);
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray30);
        int[] intArray35 = org.apache.commons.lang3.ArrayUtils.add(intArray30, 10);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) codePointTranslatorArray25, (java.lang.Object) intArray30);
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray30, (int) '4', 0);
        int[] intArray40 = org.apache.commons.lang3.ArrayUtils.removeElements(intArray17, intArray30);
        short[] shortArray41 = org.apache.commons.lang3.ArrayUtils.removeAll(shortArray11, intArray40);
        try {
            short[] shortArray44 = org.apache.commons.lang3.ArrayUtils.add(shortArray41, 90, (short) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 90, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(codePointTranslatorArray24);
        org.junit.Assert.assertNotNull(codePointTranslatorArray25);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(shortArray41);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '#', 100, (int) (byte) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                                                      0A97A100A10   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                      0a97a100a10   " + "'", str1.equals("                                                                                      0a97a100a10   "));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     " + "'", str2.equals("     "));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1 ", "1a-1a-1", "A");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.lang.Boolean[] booleanArray4 = new java.lang.Boolean[] { false, false, false, false };
        java.lang.Boolean[] booleanArray5 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray4);
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "-1.0 -1.0 1.0 -1.0 1.0 1.0", 90);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("0a97a100a10                                                                                         ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####h#####i#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####H#####I#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####" + "'", str1.equals("#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####H#####I#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_UNESCAPE();
        java.lang.Object[][] objArray1 = org.apache.commons.lang3.ArrayUtils.clone((java.lang.Object[][]) strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("{-1,3,100,10,3,2", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1,3,100,10,3,2" + "'", str2.equals("{-1,3,100,10,3,2"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray1, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 26);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray1);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray18);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray19);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray20, (double) 2, (int) (byte) -1, (double) 0.0f);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray25, doubleArray31);
        double[] doubleArray33 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray20, doubleArray31);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray31, (double) 2, 26);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray43 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray44 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray37, doubleArray43);
        int int47 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray44, (double) (byte) -1, (double) (byte) 1);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray44);
        double[] doubleArray49 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray31, doubleArray44);
        double[] doubleArray52 = org.apache.commons.lang3.ArrayUtils.add(doubleArray49, 10, (double) 'a');
        int int55 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray49, (double) 100, 2);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray8, '#', (int) (short) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-1a100a1", (java.lang.CharSequence) "0a9hi!0a97", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray6);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray6);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, 0);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strArray3, (java.lang.Object[]) booleanArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "10");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeCsv("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1a100a1", (java.lang.CharSequence) "{-1,3,100,10,3,2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "0a97a100a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray3, (long) 'a', (int) (short) 0);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray3, (long) 24, (int) (short) -1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper2 = org.apache.commons.lang3.text.translate.UnicodeEscaper.between(5, (int) (short) 1);
        org.junit.Assert.assertNotNull(unicodeEscaper2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI", "23");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (short) 100, (int) (byte) 10);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray0);
        double[] doubleArray12 = null;
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray0, doubleArray12);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator0 = org.apache.commons.lang3.StringEscapeUtils.ESCAPE_CSV;
        org.junit.Assert.assertNotNull(charSequenceTranslator0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                      0a97a100a10   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a97a100a10" + "'", str1.equals("0a97a100a10"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        short[] shortArray8 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) 10);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray9);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(shortArray12);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        char[] charArray3 = new char[] { 'a', 'a', ' ' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.remove(charArray3, (int) (byte) 1);
        char[] charArray10 = new char[] { '#', '#', '#', ' ' };
        char[] charArray14 = new char[] { 'a', ' ', '#' };
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.addAll(charArray10, charArray14);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray3, charArray14);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray17, 'a');
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray19, ' ');
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray14, charArray19);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray22, '#', (int) ' ');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        char[] charArray3 = new char[] { 'a', 'a', ' ' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.remove(charArray3, (int) (byte) 1);
        char[] charArray10 = new char[] { '#', '#', '#', ' ' };
        char[] charArray14 = new char[] { 'a', ' ', '#' };
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.addAll(charArray10, charArray14);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray3, charArray14);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray17, 'a');
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray19, ' ');
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.removeElements(charArray14, charArray19);
        java.lang.Integer[] intArray29 = new java.lang.Integer[] { (-1), 3, 100, 10, 3, 2 };
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray29, (int) '4');
        try {
            char[] charArray32 = org.apache.commons.lang3.ArrayUtils.removeAll(charArray14, intArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                    0a97a100a10", "          ", "                     ...");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("0 97 100 1", "         !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 97 100 1" + "'", str2.equals("0 97 100 1"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        java.lang.Integer[] intArray4 = new java.lang.Integer[] {};
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray5);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray3, intArray6);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.clone(intArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray6);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aa4aaa a4a#", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa4aaa a4a#" + "'", str2.equals("aa4aaa a4a#"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                             0 97 100 1                                             ", (int) (short) -1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                             0 97 100 1                                             " + "'", str3.equals("                                             0 97 100 1                                             "));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("10", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray8);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray8, (long) (byte) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray8, 'a', (int) 'a', (int) (byte) -1);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray8);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        int[] intArray6 = new int[] { (byte) 0, 10, (short) 0, (byte) 1, (byte) 0, (byte) -1 };
        int[] intArray13 = new int[] { (byte) 0, 10, (short) 0, (byte) 1, (byte) 0, (byte) -1 };
        int[] intArray20 = new int[] { (byte) 0, 10, (short) 0, (byte) 1, (byte) 0, (byte) -1 };
        int[][] intArray21 = new int[][] { intArray6, intArray13, intArray20 };
        int[][] intArray24 = org.apache.commons.lang3.ArrayUtils.subarray(intArray21, 100, 4);
        int[] intArray31 = new int[] { (byte) 0, 10, (short) 0, (byte) 1, (byte) 0, (byte) -1 };
        int[] intArray38 = new int[] { (byte) 0, 10, (short) 0, (byte) 1, (byte) 0, (byte) -1 };
        int[] intArray45 = new int[] { (byte) 0, 10, (short) 0, (byte) 1, (byte) 0, (byte) -1 };
        int[][] intArray46 = new int[][] { intArray31, intArray38, intArray45 };
        int[][] intArray49 = org.apache.commons.lang3.ArrayUtils.subarray(intArray46, 100, 4);
        int[][] intArray50 = org.apache.commons.lang3.ArrayUtils.addAll(intArray24, intArray49);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray50);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        long[] longArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(longArray0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("  23  ", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  23                      " + "'", str2.equals("  23                      "));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        char[] charArray1 = new char[] { '#' };
        char[] charArray3 = org.apache.commons.lang3.ArrayUtils.add(charArray1, '#');
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray1, ' ');
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        char[] charArray5 = new char[] { '#', '#', '#', ' ' };
        char[] charArray9 = new char[] { 'a', ' ', '#' };
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.addAll(charArray5, charArray9);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "            -1a100a             ", charArray11);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1a100a1", (java.lang.CharSequence) "                     ...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        boolean[] booleanArray4 = new boolean[] { true, true, true, false };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray4, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray4, (int) ' ', 6);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray9, true, (-1));
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("{0,97,100,10}                   ", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "{-1,3,100,10,3,2");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray7);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray7, (int) (byte) 1);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (short) 10, (int) (byte) 0, (double) 0L);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) ' ');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!", "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####H#####I#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####", 24);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                                      0A97A100A10   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                      0A97A100A10   " + "'", str1.equals("                                                                                      0A97A100A10   "));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.lang.Object obj0 = null;
        int[] intArray5 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(intArray5, (int) (byte) 0);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray5);
        try {
            boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isSameType(obj0, (java.lang.Object) intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 11, 6);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) (-1), (double) (-1));
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10,3,2}", (java.lang.CharSequence) "{-1,3,100,10,3,2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeEcmaScript("  23  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  23  " + "'", str1.equals("  23  "));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("#####", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "!", (java.lang.CharSequence) "-1a100a", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aa4aaa a4a#", "1a-1a-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeEcmaScript("10,3,2}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10,3,2}" + "'", str1.equals("10,3,2}"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                                                      0a97a100a10   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                      0a97a100a10  " + "'", str1.equals("                                                                                      0a97a100a10  "));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("{-1,3,100,10,3,2");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        boolean[] booleanArray4 = new boolean[] { true, true, true, false };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray4, false);
        boolean[] booleanArray13 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.add(booleanArray13, true);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray4, booleanArray15);
        int[] intArray22 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.contains(intArray22, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray22);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray22, 10);
        try {
            boolean[] booleanArray28 = org.apache.commons.lang3.ArrayUtils.removeAll(booleanArray4, intArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                    0a97a100a10", (int) ' ', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray4);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(byteArray4, (byte) 0);
        java.lang.Byte[] byteArray13 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray13);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray14, (byte) 100, 0);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray14, (-1), (int) (short) 100);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray4, byteArray20);
        try {
            byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.add(byteArray4, (-1), (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "-1a100a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray8);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.lang.String str1 = org.apache.commons.lang3.text.translate.CharSequenceTranslator.hex(95);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5F" + "'", str1.equals("5F"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        long[] longArray0 = null;
        long[] longArray2 = new long[] { (short) 10 };
        long[] longArray3 = new long[] {};
        long[] longArray4 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray2, longArray3);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray4);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray4, (long) '4');
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray4, (long) (short) 0, 26);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray4);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray0, longArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "5F", (java.lang.CharSequence) "         !");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator0 = org.apache.commons.lang3.StringEscapeUtils.ESCAPE_CSV;
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray1 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { charSequenceTranslator0 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator2 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray1);
        org.junit.Assert.assertNotNull(charSequenceTranslator0);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "#####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-1.0435.040.041.04-1.0410.0", "                                                                                      0a97a100a10  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("A");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A" + "'", str1.equals("A"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("{0,97,100,10}", "-1a100a1");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator0 = org.apache.commons.lang3.StringEscapeUtils.UNESCAPE_JAVA;
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray1 = null;
        try {
            org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator2 = charSequenceTranslator0.with(charSequenceTranslatorArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(charSequenceTranslator0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        byte[] byteArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(byteArray0, (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####H#####I#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####", "hi!                                                                                            ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "                                                                                      0a97a100a10   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("h-1.0-1.01.0-1.01.01.0h", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0-1.01.01.0h" + "'", str2.equals("0-1.01.01.0h"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                                                                                      0A97A100A10   ", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                                      0A97A100A10   " + "'", charSequence2.equals("                                                                                      0A97A100A10   "));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) 100, (short) -1, (short) 1 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) 1);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray5);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        long[] longArray0 = null;
        long[] longArray2 = new long[] { (short) 10 };
        long[] longArray3 = new long[] {};
        long[] longArray4 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray2, longArray3);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray4);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray4, (long) '4');
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray4, (long) (short) 0, 26);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(longArray4);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray0, longArray4);
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray0, longArray16);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeHtml3("0a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a" + "'", str1.equals("0a"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                                                                    0A97A100A10", "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####H#####I#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("     ", "1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     " + "'", str2.equals("     "));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        short[] shortArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray0, (short) 100, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("0a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a" + "'", str1.equals("0a"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0 97 100 10", 5, "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 97 100 10" + "'", str3.equals("0 97 100 10"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0 97 100 1", "5F");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "0a97a100a10                                                                                         ", (java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("-1a100a1", "10,3,2}");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a100a1" + "'", str2.equals("-1a100a1"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        char[] charArray3 = new char[] { 'a', 'a', ' ' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.remove(charArray3, (int) (byte) 1);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("{0,97,100,10}", "-1a100a1");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "{{0.0},{0.0},{0.0},{0.0},{0.0}}", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        boolean[] booleanArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray0, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "!", 10);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "-1.0 -1.0 1.0 -1.0 1.0 1.0");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("                                                                                      0a97a100a10   ", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 10 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeEcmaScript("0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0" + "'", str1.equals("0"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray6);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray6, 0);
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray11, true);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray11);
        boolean[] booleanArray15 = null;
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray11, booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double[] doubleArray6 = new double[] { (-1), '#', 0.0d, 1.0d, (short) -1, (short) 10 };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 'a', (int) (byte) -1);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 100.0d, (int) (short) -1, (double) (byte) 0);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator0 = org.apache.commons.lang3.StringEscapeUtils.UNESCAPE_JAVA;
        java.lang.String str2 = charSequenceTranslator0.translate((java.lang.CharSequence) "-1a100a1");
        java.lang.CharSequence charSequence3 = null;
        java.io.Writer writer4 = null;
        try {
            charSequenceTranslator0.translate(charSequence3, writer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Writer must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(charSequenceTranslator0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a100a1" + "'", str2.equals("-1a100a1"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray2 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper0, unicodeEscaper1 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator3 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray2);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper4 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper5 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray6 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper4, unicodeEscaper5 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator7 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray6);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper8 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper9 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray10 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper8, unicodeEscaper9 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator11 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray10);
        java.lang.String str13 = aggregateTranslator11.translate((java.lang.CharSequence) "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper14 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper15 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray16 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper14, unicodeEscaper15 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator17 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray16);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper18 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper19 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper20 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper21 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper22 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper23 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray24 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper18, unicodeUnescaper19, unicodeUnescaper20, unicodeUnescaper21, unicodeUnescaper22, unicodeUnescaper23 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray25 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray24);
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator26 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray24);
        org.apache.commons.lang3.text.translate.AggregateTranslator[] aggregateTranslatorArray27 = new org.apache.commons.lang3.text.translate.AggregateTranslator[] { aggregateTranslator3, aggregateTranslator7, aggregateTranslator11, aggregateTranslator17, aggregateTranslator26 };
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper28 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper29 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray30 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper28, unicodeEscaper29 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator31 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray30);
        java.lang.String str33 = aggregateTranslator31.translate((java.lang.CharSequence) "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper34 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper35 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray36 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper34, unicodeEscaper35 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator37 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray36);
        java.lang.CharSequence charSequence38 = null;
        java.lang.String str39 = aggregateTranslator37.translate(charSequence38);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper40 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper41 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper42 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper43 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper44 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper45 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray46 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper40, unicodeUnescaper41, unicodeUnescaper42, unicodeUnescaper43, unicodeUnescaper44, unicodeUnescaper45 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray47 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray46);
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator48 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray46);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper49 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper50 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray51 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper49, unicodeEscaper50 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator52 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray51);
        java.lang.String str54 = aggregateTranslator52.translate((java.lang.CharSequence) "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper55 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper56 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray57 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper55, unicodeEscaper56 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator58 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray57);
        java.lang.CharSequence charSequence59 = null;
        java.lang.String str60 = aggregateTranslator58.translate(charSequence59);
        org.apache.commons.lang3.text.translate.AggregateTranslator[] aggregateTranslatorArray61 = new org.apache.commons.lang3.text.translate.AggregateTranslator[] { aggregateTranslator31, aggregateTranslator37, aggregateTranslator48, aggregateTranslator52, aggregateTranslator58 };
        org.apache.commons.lang3.text.translate.AggregateTranslator[] aggregateTranslatorArray62 = org.apache.commons.lang3.ArrayUtils.removeElements(aggregateTranslatorArray27, aggregateTranslatorArray61);
        java.lang.String str63 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) aggregateTranslatorArray62);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray2);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray6);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray16);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray24);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray25);
        org.junit.Assert.assertNotNull(aggregateTranslatorArray27);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray36);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray46);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray47);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray57);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNotNull(aggregateTranslatorArray61);
        org.junit.Assert.assertNotNull(aggregateTranslatorArray62);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        boolean[] booleanArray4 = new boolean[] { true, true, true, false };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray4, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray4, (int) ' ', 6);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray9);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray9, true);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = org.apache.commons.lang3.text.translate.UnicodeEscaper.below(24);
        java.io.Writer writer3 = null;
        boolean boolean4 = unicodeEscaper1.translate((int) (byte) 100, writer3);
        org.junit.Assert.assertNotNull(unicodeEscaper1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray14 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray19 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[][] byteArray20 = new byte[][] { byteArray4, byteArray9, byteArray14, byteArray19 };
        byte[] byteArray27 = new byte[] { (byte) -1, (byte) 1, (byte) -1, (byte) 0, (byte) 10, (byte) 10 };
        byte[][] byteArray28 = new byte[][] { byteArray27 };
        byte[][] byteArray29 = org.apache.commons.lang3.ArrayUtils.removeElements(byteArray20, byteArray28);
        byte[] byteArray33 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray35 = org.apache.commons.lang3.ArrayUtils.remove(byteArray33, 0);
        java.lang.String[][] strArray36 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_ESCAPE();
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) byteArray35, (java.lang.Object) strArray36);
        byte[][] byteArray38 = org.apache.commons.lang3.ArrayUtils.add(byteArray20, (int) (byte) 0, byteArray35);
        java.lang.String str42 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) byteArray38, "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", 0, (int) (byte) 0);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double[] doubleArray6 = new double[] { (-1), '#', 0.0d, 1.0d, (short) -1, (short) 10 };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 'a', (int) (byte) -1);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0435.040.041.04-1.0410.0" + "'", str12.equals("-1.0435.040.041.04-1.0410.0"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeXml("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        char[] charArray1 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        char[] charArray3 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray1, 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "         !", charArray1);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.Short[] shortArray0 = null;
        java.lang.Short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray0);
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0, (short) (byte) -1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNull(shortArray3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray1, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 26);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray1);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray18);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray19);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray20, (double) 2, (int) (byte) -1, (double) 0.0f);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray25, doubleArray31);
        double[] doubleArray33 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray20, doubleArray31);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray31, (double) 2, 26);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray43 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray44 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray37, doubleArray43);
        int int47 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray44, (double) (byte) -1, (double) (byte) 1);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray44);
        double[] doubleArray49 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray31, doubleArray44);
        double[] doubleArray52 = org.apache.commons.lang3.ArrayUtils.add(doubleArray49, 10, (double) 'a');
        int int55 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray49, 10.0d, (double) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "  1   ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", (int) (short) 10);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("                     ...", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "                     ..." + "'", str6.equals("                     ..."));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("{-1,3,100,10,3,2}", "#####", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.lang.Character[] charArray6 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6, 'a');
        java.lang.Character[] charArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray6);
        java.lang.Character[] charArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray9);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml3("  1   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  1   " + "'", str1.equals("  1   "));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                     ...", (java.lang.CharSequence) "0971001");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double[] doubleArray6 = new double[] { (-1), '#', 0.0d, 1.0d, (short) -1, (short) 10 };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 'a', (int) (byte) -1);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, 0.0d);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) 90);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "0971001");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                                                      0A97A100A10   ", "!", (int) (short) -1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!                                                                                     0A97A100A10   " + "'", str4.equals("!                                                                                     0A97A100A10   "));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1 ", "h-1.0-1.01.0-1.01.01.0h", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "{0,97,100,10}", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                             0 97 100 1                                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "#####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 100);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 1);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray11);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 100, (int) (byte) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', 0, (-1));
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        long[] longArray1 = new long[] { (short) 10 };
        long[] longArray2 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray1, longArray2);
        java.lang.Integer[] intArray4 = new java.lang.Integer[] {};
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray5);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeAll(longArray3, intArray6);
        long[] longArray11 = new long[] { (short) 0, 'a', 100 };
        long[] longArray13 = new long[] { (short) 10 };
        long[] longArray14 = new long[] {};
        long[] longArray15 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray13, longArray14);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.addAll(longArray11, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(longArray16);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray16, (long) (byte) 0);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(longArray16, 'a');
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.subarray(longArray16, 24, 0);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.addAll(longArray7, longArray24);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray25);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0a97a100a10" + "'", str21.equals("0a97a100a10"));
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray25);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray2 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] { unicodeEscaper1 };
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray3 = org.apache.commons.lang3.ArrayUtils.toArray(codePointTranslatorArray2);
        int[] intArray8 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(intArray8, (int) (byte) 0);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray8);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray8, 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) codePointTranslatorArray3, (java.lang.Object) intArray8);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.remove(intArray8, (int) (short) 0);
        try {
            short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeAll(shortArray0, intArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(codePointTranslatorArray2);
        org.junit.Assert.assertNotNull(codePointTranslatorArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeJava("34");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "34" + "'", str1.equals("34"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        char[] charArray0 = null;
        try {
            char[] charArray2 = org.apache.commons.lang3.ArrayUtils.remove(charArray0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "  1   ", (java.lang.CharSequence) "                     ...", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper0 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper1 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper2 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper3 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper4 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper5 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray6 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper0, unicodeUnescaper1, unicodeUnescaper2, unicodeUnescaper3, unicodeUnescaper4, unicodeUnescaper5 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray7 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(unicodeUnescaperArray7);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray6);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray1, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 26);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray1);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray18);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray19);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray20, (double) 2, (int) (byte) -1, (double) 0.0f);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray31 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray25, doubleArray31);
        double[] doubleArray33 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray20, doubleArray31);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray31, (double) (byte) 100);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " ", 31, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.lang3.text.translate.LookupTranslator[] lookupTranslatorArray0 = null;
        org.apache.commons.lang3.text.translate.OctalUnescaper octalUnescaper1 = new org.apache.commons.lang3.text.translate.OctalUnescaper();
        java.io.Writer writer4 = null;
        int int5 = octalUnescaper1.translate((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 6, writer4);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper6 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper7 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper8 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper9 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper10 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper11 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray12 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper6, unicodeUnescaper7, unicodeUnescaper8, unicodeUnescaper9, unicodeUnescaper10, unicodeUnescaper11 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray13 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray12);
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator14 = octalUnescaper1.with((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray13);
        org.apache.commons.lang3.text.translate.LookupTranslator[] lookupTranslatorArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(lookupTranslatorArray0, (java.lang.Object) charSequenceTranslator14);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray12);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray13);
        org.junit.Assert.assertNotNull(charSequenceTranslator14);
        org.junit.Assert.assertNull(lookupTranslatorArray15);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("5F", (int) (byte) 100, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5F" + "'", str3.equals("5F"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "{-1,3,100,10,3,2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeEcmaScript("###########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###########" + "'", str1.equals("###########"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "10,3,2}", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1a-1a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a-1a-1" + "'", str1.equals("1a-1a-1"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("0 97 100 10HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, 1.0d, 10.0d);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L, 26, (double) 95);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1 ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("  23                      ", "hi!                                                                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  23                      " + "'", str2.equals("  23                      "));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("          ", "A");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "{{0.0},{0.0},{0.0},{0.0},{0.0}}", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0a97a100a10", "aa4aaa a4a#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("0 97 100 10", "                                                                                    0A97A100A10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 97 100 10" + "'", str2.equals("0 97 100 10"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1a-1a-1", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator0 = org.apache.commons.lang3.StringEscapeUtils.UNESCAPE_HTML4;
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper1 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper2 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper3 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper4 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper5 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper6 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray7 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper1, unicodeUnescaper2, unicodeUnescaper3, unicodeUnescaper4, unicodeUnescaper5, unicodeUnescaper6 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray8 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray7);
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator9 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) unicodeUnescaperArray8, ' ');
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator12 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray8);
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray13 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { aggregateTranslator12 };
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator14 = charSequenceTranslator0.with(charSequenceTranslatorArray13);
        org.junit.Assert.assertNotNull(charSequenceTranslator0);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray7);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray8);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray13);
        org.junit.Assert.assertNotNull(charSequenceTranslator14);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("  1   ", "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####H#####I#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  1   " + "'", str3.equals("  1   "));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("5F", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5F" + "'", str2.equals("5F"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray21 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray23 = new float[] { 'a' };
        float[] floatArray25 = new float[] { (byte) -1 };
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray23, floatArray25);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray21, floatArray23);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.join(floatArray21, '4', (int) '#', (int) (byte) 1);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray6, floatArray21);
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.join(floatArray32, '4');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "0 97 100 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        char[] charArray0 = null;
        char[] charArray1 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray0);
        org.junit.Assert.assertNotNull(charArray1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper0 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper1 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray2 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper0, unicodeEscaper1 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator3 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray2);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper4 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper5 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray6 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper4, unicodeEscaper5 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator7 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray6);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper8 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper9 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray10 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper8, unicodeEscaper9 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator11 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray10);
        java.lang.String str13 = aggregateTranslator11.translate((java.lang.CharSequence) "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper14 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper15 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray16 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper14, unicodeEscaper15 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator17 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray16);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper18 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper19 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper20 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper21 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper22 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper23 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray24 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper18, unicodeUnescaper19, unicodeUnescaper20, unicodeUnescaper21, unicodeUnescaper22, unicodeUnescaper23 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray25 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray24);
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator26 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray24);
        org.apache.commons.lang3.text.translate.AggregateTranslator[] aggregateTranslatorArray27 = new org.apache.commons.lang3.text.translate.AggregateTranslator[] { aggregateTranslator3, aggregateTranslator7, aggregateTranslator11, aggregateTranslator17, aggregateTranslator26 };
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper28 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper29 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray30 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper28, unicodeEscaper29 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator31 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray30);
        java.lang.String str33 = aggregateTranslator31.translate((java.lang.CharSequence) "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper34 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper35 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray36 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper34, unicodeEscaper35 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator37 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray36);
        java.lang.CharSequence charSequence38 = null;
        java.lang.String str39 = aggregateTranslator37.translate(charSequence38);
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper40 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper41 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper42 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper43 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper44 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper unicodeUnescaper45 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper();
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray46 = new org.apache.commons.lang3.text.translate.UnicodeUnescaper[] { unicodeUnescaper40, unicodeUnescaper41, unicodeUnescaper42, unicodeUnescaper43, unicodeUnescaper44, unicodeUnescaper45 };
        org.apache.commons.lang3.text.translate.UnicodeUnescaper[] unicodeUnescaperArray47 = org.apache.commons.lang3.ArrayUtils.clone(unicodeUnescaperArray46);
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator48 = new org.apache.commons.lang3.text.translate.AggregateTranslator((org.apache.commons.lang3.text.translate.CharSequenceTranslator[]) unicodeUnescaperArray46);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper49 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper50 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray51 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper49, unicodeEscaper50 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator52 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray51);
        java.lang.String str54 = aggregateTranslator52.translate((java.lang.CharSequence) "");
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper55 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper56 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CharSequenceTranslator[] charSequenceTranslatorArray57 = new org.apache.commons.lang3.text.translate.CharSequenceTranslator[] { unicodeEscaper55, unicodeEscaper56 };
        org.apache.commons.lang3.text.translate.AggregateTranslator aggregateTranslator58 = new org.apache.commons.lang3.text.translate.AggregateTranslator(charSequenceTranslatorArray57);
        java.lang.CharSequence charSequence59 = null;
        java.lang.String str60 = aggregateTranslator58.translate(charSequence59);
        org.apache.commons.lang3.text.translate.AggregateTranslator[] aggregateTranslatorArray61 = new org.apache.commons.lang3.text.translate.AggregateTranslator[] { aggregateTranslator31, aggregateTranslator37, aggregateTranslator48, aggregateTranslator52, aggregateTranslator58 };
        org.apache.commons.lang3.text.translate.AggregateTranslator[] aggregateTranslatorArray62 = org.apache.commons.lang3.ArrayUtils.removeElements(aggregateTranslatorArray27, aggregateTranslatorArray61);
        java.lang.String str63 = org.apache.commons.lang3.StringUtils.join(aggregateTranslatorArray27);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray2);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray6);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray16);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray24);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray25);
        org.junit.Assert.assertNotNull(aggregateTranslatorArray27);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray36);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray46);
        org.junit.Assert.assertNotNull(unicodeUnescaperArray47);
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
        org.junit.Assert.assertNotNull(charSequenceTranslatorArray57);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNotNull(aggregateTranslatorArray61);
        org.junit.Assert.assertNotNull(aggregateTranslatorArray62);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("-1.0435.040.041.04-1.0410.0", "", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeCsv("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                     ...", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0, ' ');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "0 97 100 10", (java.lang.CharSequence) "  1   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.lang.Long[] longArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_OBJECT_ARRAY;
        long[] longArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray0, (long) '#');
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray0);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray1, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 26);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray1);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray18);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray19);
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, 0, 10.0d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.lang.Integer[] intArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY;
        java.lang.Integer[] intArray1 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray0);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) intArray1, '4');
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0a97a100a10", "                                                                                    0a97a100a10");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.lang.String[] strArray4 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray9 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray14 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray19 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[][] strArray20 = new java.lang.String[][] { strArray4, strArray9, strArray14, strArray19 };
        java.lang.String[][] strArray21 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray20);
        org.apache.commons.lang3.text.translate.LookupTranslator lookupTranslator22 = new org.apache.commons.lang3.text.translate.LookupTranslator((java.lang.CharSequence[][]) strArray21);
        org.apache.commons.lang3.text.translate.LookupTranslator lookupTranslator23 = new org.apache.commons.lang3.text.translate.LookupTranslator((java.lang.CharSequence[][]) strArray21);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strArray21);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray18, floatArray30);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.contains(floatArray18, (float) 6);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 1);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_ESCAPE();
        java.lang.Object[] objArray1 = org.apache.commons.lang3.ArrayUtils.nullToEmpty((java.lang.Object[]) strArray0);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "hi!                                                                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("{0,97,100,10}                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0,97,100,10}" + "'", str1.equals("{0,97,100,10}"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0971001", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "0 97 100 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(byteArray5, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4');
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray0, (short) (byte) 1);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray0);
        short[] shortArray9 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.clone(shortArray9);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.removeElements(shortArray0, shortArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray11, (short) 0);
        try {
            short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.remove(shortArray11, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("97410041041040");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97410041041040" + "'", str1.equals("97410041041040"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", ' ');
        java.lang.String[] strArray3 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "hi!                                                                                            ", (java.lang.CharSequence) "1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray0 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray1 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] { oPTIONArray0 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray2 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper3 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray2);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray4 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper5 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray4);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION6 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        boolean boolean7 = numericEntityUnescaper5.isSet(oPTION6);
        boolean boolean8 = numericEntityUnescaper3.isSet(oPTION6);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION9 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION10 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray11 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] { oPTION6, oPTION9, oPTION10 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray12 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] { oPTIONArray11 };
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[][] oPTIONArray13 = org.apache.commons.lang3.ArrayUtils.removeElements(oPTIONArray1, oPTIONArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isNotEmpty((java.io.Serializable[][]) oPTIONArray1);
        org.junit.Assert.assertNotNull(oPTIONArray0);
        org.junit.Assert.assertNotNull(oPTIONArray1);
        org.junit.Assert.assertNotNull(oPTIONArray2);
        org.junit.Assert.assertNotNull(oPTIONArray4);
        org.junit.Assert.assertTrue("'" + oPTION6 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION6.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + oPTION9 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION9.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + oPTION10 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION10.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertNotNull(oPTIONArray11);
        org.junit.Assert.assertNotNull(oPTIONArray12);
        org.junit.Assert.assertNotNull(oPTIONArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "  1   ", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.lang.String str1 = org.apache.commons.lang3.text.translate.CharSequenceTranslator.hex(31);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1F" + "'", str1.equals("1F"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, 0.0d, (int) ' ');
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray0);
        try {
            double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("          ", "", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("0a9hi!0a97", "!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a9hi!0a97" + "'", str2.equals("0a9hi!0a97"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray4);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.remove(intArray4, 2);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 10);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { 100.0d, 0.0d, 100.0d, 10.0d };
        double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray4);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray5, 0.0d, (double) 0.0f);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "     ", 26);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray4);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(shortArray7);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray7, 'a', (int) (short) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "0 97 100 1", (java.lang.CharSequence) "{{0.0},{0.0},{0.0},{0.0},{0.0}}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.apache.commons.lang3.text.translate.EntityArrays entityArrays0 = new org.apache.commons.lang3.text.translate.EntityArrays();
        org.apache.commons.lang3.text.translate.EntityArrays[] entityArraysArray1 = new org.apache.commons.lang3.text.translate.EntityArrays[] { entityArrays0 };
        try {
            org.apache.commons.lang3.text.translate.EntityArrays[] entityArraysArray3 = org.apache.commons.lang3.ArrayUtils.remove(entityArraysArray1, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 26, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(entityArraysArray1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeHtml4("0a97a100a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a97a100a10" + "'", str1.equals("0a97a100a10"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("10010-1101");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10010-1101" + "'", str1.equals("10010-1101"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.escapeXml("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "A", (java.lang.CharSequence) "aa4aaa a4a#", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "0a", "\\u0061\\u0061\\u0034\\u0061\\u0061\\u0061\\u0020\\u0061\\u0034\\u0061\\u0023");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + "'", str1.equals("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        int[] intArray17 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(intArray17, (int) (byte) 0);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray17);
        java.lang.Integer[] intArray21 = new java.lang.Integer[] {};
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray21);
        int[] intArray23 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray22);
        int[] intArray28 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.contains(intArray28, (int) (byte) 0);
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray28);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray23, intArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray17, intArray23);
        float[] floatArray34 = org.apache.commons.lang3.ArrayUtils.removeAll(floatArray8, intArray23);
        try {
            java.lang.String str38 = org.apache.commons.lang3.StringUtils.join(intArray23, '4', 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(floatArray34);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray8, false, (int) (short) 0);
        boolean[] booleanArray19 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.add(booleanArray19, true);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray21);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray21, false, (int) (short) 0);
        boolean[] booleanArray26 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray21);
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray8, true, (int) ' ');
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray8);
        int int32 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray8, true);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.0 -1.0 1.0 -1.0 1.0 1.0", "-1.0 -1.0 1.0 -1.0 1.0 1.0", 1);
        java.lang.Integer[] intArray4 = new java.lang.Integer[] {};
        java.lang.Integer[][] intArray5 = new java.lang.Integer[][] { intArray4 };
        java.lang.Integer[][] intArray6 = org.apache.commons.lang3.ArrayUtils.toArray(intArray5);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strArray3, (java.lang.Object[]) intArray6);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap8 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, '[Ljava.lang.Integer;@4b1d5901', has a length less than 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 10);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray9, '#', 0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray6);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, false);
        java.lang.Boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray6);
        java.lang.Character[] charArray20 = new java.lang.Character[] { 'a', '4', 'a', ' ', '4', '#' };
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray20, 'a');
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "!", charArray22);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray22, '#', (int) ' ');
        char[] charArray27 = org.apache.commons.lang3.ArrayUtils.clone(charArray22);
        try {
            java.io.Serializable[] serializableArray28 = org.apache.commons.lang3.ArrayUtils.add((java.io.Serializable[]) booleanArray12, (java.io.Serializable) charArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayStoreException; message: [C");
        } catch (java.lang.ArrayStoreException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(charArray27);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                    0A97A100A10", "                                                                                    0a97a100a10", "-1.0435.040.041.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "------------------------------------------------------------------------------------AAA" + "'", str3.equals("------------------------------------------------------------------------------------AAA"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        float[] floatArray2 = new float[] { 100, 10L };
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', (int) (short) -1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 0);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray7, 0.0d);
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) 1.0f);
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray14, (double) 26, (double) 5);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0 97 100 1", "hi!                                                                                            ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("{0,97,100,10}", "a1", "\\u0061\\u0061\\u0034\\u0061\\u0061\\u0061\\u0020\\u0061\\u0034\\u0061\\u0023");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0,97,u00,u0}" + "'", str3.equals("{0,97,u00,u0}"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        long[] longArray0 = null;
        long[] longArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray0, longArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("  23                      ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  23                      " + "'", str2.equals("  23                      "));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("{-1,3,100,10,3,2}", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1,3,100,10,3,2}" + "'", str2.equals("{-1,3,100,10,3,2}"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                    ", "", (int) (byte) 1);
        int[] intArray8 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(intArray8, (int) (byte) 0);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray8);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray8);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.remove(intArray8, 2);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) strArray3, (java.lang.Object) intArray14, (int) (byte) -1);
        java.lang.Integer[] intArray17 = new java.lang.Integer[] {};
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray17);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray18);
        int[] intArray24 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.contains(intArray24, (int) (byte) 0);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray24);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray19, intArray27);
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray27, 2);
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.clone(intArray27);
        int[] intArray32 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray27);
        try {
            int[] intArray33 = org.apache.commons.lang3.ArrayUtils.removeAll(intArray14, intArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) 'a', (int) (short) -1);
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (-1L), (double) 26);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 'a');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("                     ...", strArray4, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "                     ..." + "'", str11.equals("                     ..."));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str12.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                                                                      0A97A100A10   ", "------------------------------------------------------------------------------------AAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                      0A97A100A10   " + "'", str2.equals("                                                                                      0A97A100A10   "));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "0a97a100a10                                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray5, (byte) 1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "                                             0 97 100 1                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + "'", str2.equals("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!hi!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.lang.Object[] objArray0 = null;
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.ISO8859_1_ESCAPE();
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(objArray0, (java.lang.Object) strArray1, 10);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        char[] charArray4 = new char[] { '#', '#', ' ' };
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "974100410410", charArray4);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10,3,2}", (int) (short) 100, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strArray3, (java.lang.Object[]) booleanArray4);
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray4);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, (int) ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "            -1a100a             ", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", '4');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach(" ", strArray3, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + " " + "'", str9.equals(" "));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray7 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray1, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray1, (double) 26);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray1);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray18);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray19);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray20, (double) 2, (int) (byte) -1, (double) 0.0f);
        java.lang.Double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray20);
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray20, (double) (-1L), (double) (-1.0f));
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.join(doubleArray20, 'a');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1.0a0.0" + "'", str30.equals("1.0a0.0"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                 34                                                 ", (java.lang.CharSequence) "10010-1101");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("            -1a100a             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a100a" + "'", str1.equals("-1a100a"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "5F");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                   " + "'", str1.equals("                                                   "));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        float[] floatArray0 = null;
        float[] floatArray1 = null;
        float[] floatArray2 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray0, floatArray1);
        org.junit.Assert.assertNull(floatArray2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("     ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     " + "'", str2.equals("     "));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        long[] longArray0 = null;
        try {
            long[] longArray2 = org.apache.commons.lang3.ArrayUtils.remove(longArray0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence) "-1.0435.040.041.04-1.0410.0", 95);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.remove(byteArray4, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray1, byteArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 10, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0" + "'", str1.equals("0"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(doubleArray7);
        int[] intArray16 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(intArray16, (int) (byte) 0);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray16);
        java.lang.Integer[] intArray20 = new java.lang.Integer[] {};
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray20);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray21);
        int[] intArray27 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.contains(intArray27, (int) (byte) 0);
        int[] intArray30 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray27);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray22, intArray30);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray16, intArray22);
        java.lang.Integer[] intArray33 = org.apache.commons.lang3.ArrayUtils.toObject(intArray16);
        try {
            double[] doubleArray34 = org.apache.commons.lang3.ArrayUtils.removeAll(doubleArray7, intArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####H#####I#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####", (java.lang.CharSequence) "-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        char[] charArray1 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1.0", charArray1);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "97410041041040");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "  1   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                    0A97A100A10", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("974100410410");
        java.lang.Object[] objArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray0, (int) (byte) 100, 1);
        int[] intArray8 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(intArray8, (int) (byte) 0);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray8);
        java.lang.Integer[] intArray12 = new java.lang.Integer[] {};
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray12);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray13);
        int[] intArray19 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(intArray19, (int) (byte) 0);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray19);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray14, intArray22);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray8, intArray14);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.add(intArray8, 0);
        int int29 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray26, (int) (short) 1, 10);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.join(intArray26, '4');
        try {
            boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.removeAll(booleanArray3, intArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "97410041041040" + "'", str31.equals("97410041041040"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("  1   ", '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "-");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "  1   " + "'", str4.equals("  1   "));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10, 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "14-14-1" + "'", str9.equals("14-14-1"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.lang.Character[] charArray0 = new java.lang.Character[] {};
        char[] charArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        char[] charArray5 = new char[] { '#', '#', '#', ' ' };
        char[] charArray9 = new char[] { 'a', ' ', '#' };
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.addAll(charArray5, charArray9);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray10);
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.add(charArray11, '4');
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray11, ' ', (-1));
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0 97 100 10", charArray11);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray11, '4');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "#4#4#4 4a4 4#" + "'", str19.equals("#4#4#4 4a4 4#"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 1, (int) (byte) 100, (double) (short) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 26);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(doubleArray0);
        try {
            double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (int) (short) 1, (double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                     ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                     ..." + "'", str1.equals("                     ..."));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        java.lang.Double[] doubleArray1 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray4, 11, 11);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.lang.Short[] shortArray0 = null;
        java.lang.Short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray0);
        short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNull(shortArray2);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("\\u0061\\u0061\\u0034\\u0061\\u0061\\u0061\\u0020\\u0061\\u0034\\u0061\\u0023", "23", "                     ...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray6 = new double[] { 10, 100.0f, 0.0d, (-1.0d), (short) 10 };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) (byte) -1, (double) (byte) 1);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 11, 6);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                                                    0a97a100a10", (java.lang.CharSequence) "h-1.0 -1.0 1.0 -1.0 1.0 1.0h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        java.lang.Integer[] intArray8 = new java.lang.Integer[] {};
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray8);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray9);
        int[] intArray15 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(intArray15, (int) (byte) 0);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray15);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray10, intArray18);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray4, intArray10);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 0);
        java.lang.Integer[] intArray23 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        try {
            java.lang.String str27 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 4, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray9 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray14 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[] byteArray19 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        byte[][] byteArray20 = new byte[][] { byteArray4, byteArray9, byteArray14, byteArray19 };
        byte[] byteArray27 = new byte[] { (byte) -1, (byte) 1, (byte) -1, (byte) 0, (byte) 10, (byte) 10 };
        byte[][] byteArray28 = new byte[][] { byteArray27 };
        byte[][] byteArray29 = org.apache.commons.lang3.ArrayUtils.removeElements(byteArray20, byteArray28);
        byte[] byteArray33 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray35 = org.apache.commons.lang3.ArrayUtils.remove(byteArray33, 0);
        java.lang.String[][] strArray36 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_ESCAPE();
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) byteArray35, (java.lang.Object) strArray36);
        byte[][] byteArray38 = org.apache.commons.lang3.ArrayUtils.add(byteArray20, (int) (byte) 0, byteArray35);
        byte[] byteArray40 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray35, (byte) 10);
        int int42 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray40, (byte) 10);
        int int45 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray40, (byte) 100, (int) 'a');
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.lang.String[] strArray4 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray9 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray14 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[] strArray19 = new java.lang.String[] { "1a-1a-1", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", "{0,97,100,10}                   ", "                                                                                                    " };
        java.lang.String[][] strArray20 = new java.lang.String[][] { strArray4, strArray9, strArray14, strArray19 };
        java.lang.String[][] strArray21 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray20);
        try {
            java.lang.String str25 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray20, '#', (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strArray21);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 1.0d, 0.0d };
        double[] doubleArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray2);
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isEmpty((java.lang.Object[]) doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml4("0971001");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0971001" + "'", str1.equals("0971001"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        java.lang.String str17 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) byteArray9, "  23  ");
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{-1,100}" + "'", str17.equals("{-1,100}"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 100);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, 10, 3);
        try {
            byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray12);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "A", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0 -1.0 1.0 -1.0 1.0 1.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray0, (float) 'a', (int) (byte) -1);
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray0, (float) 2);
        float[] floatArray6 = null;
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(floatArray0, floatArray6);
        try {
            float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.remove(floatArray7, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.0 -1.0 1.0 -1.0 1.0 1.0", "-1.0 -1.0 1.0 -1.0 1.0 1.0", 1);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", strArray5, strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str8.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H-1.0 -1.0 1.0 -1.0 1.0 1.0HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("!444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1a-1a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("  1   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringEscapeUtils.unescapeHtml4("0a9hi!0a97");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a9hi!0a97" + "'", str1.equals("0a9hi!0a97"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("{0,97,100,10}                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0,97,100,10}                   " + "'", str1.equals("{0,97,100,10}                   "));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        float[] floatArray1 = new float[] { 'a' };
        float[] floatArray3 = new float[] { (byte) -1 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray1, floatArray3);
        float[] floatArray11 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray13 = new float[] { 'a' };
        float[] floatArray15 = new float[] { (byte) -1 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray11, floatArray13);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray3, floatArray11);
        float[] floatArray20 = new float[] { 'a' };
        float[] floatArray22 = new float[] { (byte) -1 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray22);
        float[] floatArray30 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray32 = new float[] { 'a' };
        float[] floatArray34 = new float[] { (byte) -1 };
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray32, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray32);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray30);
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray18, floatArray30);
        float[] floatArray39 = null;
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray18, floatArray39);
        float[] floatArray42 = org.apache.commons.lang3.ArrayUtils.add(floatArray18, (float) (short) 0);
        int int44 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray42, 100.0f);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "     ", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1F", (int) (short) 10, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        long[] longArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_ARRAY;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray0);
        long[] longArray5 = new long[] { (short) 0, 'a', 100 };
        long[] longArray7 = new long[] { (short) 10 };
        long[] longArray8 = new long[] {};
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray7, longArray8);
        long[] longArray10 = org.apache.commons.lang3.ArrayUtils.addAll(longArray5, longArray9);
        long[] longArray14 = new long[] { (short) 0, 'a', 100 };
        long[] longArray16 = new long[] { (short) 10 };
        long[] longArray17 = new long[] {};
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray16, longArray17);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray18);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.addAll(longArray5, longArray18);
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.clone(longArray20);
        long[] longArray22 = null;
        long[] longArray23 = org.apache.commons.lang3.ArrayUtils.addAll(longArray21, longArray22);
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray0, longArray22);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray24, (long) 10);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                                                                      0A97A100A10   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                      0A97A100A10   " + "'", str1.equals("                                                                                      0A97A100A10   "));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.lang.Float[] floatArray4 = new java.lang.Float[] { 0.0f, 0.0f, 10.0f, (-1.0f) };
        float[] floatArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray5);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray5, (int) '4', 2);
        int[] intArray14 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(intArray14, (int) (byte) 0);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray14);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.add(intArray14, 10);
        org.apache.commons.lang3.text.translate.UnicodeEscaper unicodeEscaper20 = new org.apache.commons.lang3.text.translate.UnicodeEscaper();
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray21 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] { unicodeEscaper20 };
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray22 = org.apache.commons.lang3.ArrayUtils.toArray(codePointTranslatorArray21);
        int[] intArray27 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.contains(intArray27, (int) (byte) 0);
        int[] intArray30 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray27);
        int[] intArray32 = org.apache.commons.lang3.ArrayUtils.add(intArray27, 10);
        int int33 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) codePointTranslatorArray22, (java.lang.Object) intArray27);
        int int36 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray27, (int) '4', 0);
        int[] intArray37 = org.apache.commons.lang3.ArrayUtils.removeElements(intArray14, intArray27);
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.removeAll(floatArray9, intArray37);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(codePointTranslatorArray21);
        org.junit.Assert.assertNotNull(codePointTranslatorArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(floatArray38);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        boolean[] booleanArray6 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        boolean[] booleanArray13 = new boolean[] { true, true, true, false };
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray13, false);
        boolean[] booleanArray22 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.add(booleanArray22, true);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray24);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray13, booleanArray24);
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray13);
        boolean[] booleanArray30 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray13, 26, (int) (short) 1);
        boolean[] booleanArray31 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray30);
        java.lang.String[] strArray34 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String[] strArray35 = org.apache.commons.lang3.StringUtils.stripAll(strArray34);
        java.lang.Boolean[] booleanArray36 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strArray35, (java.lang.Object[]) booleanArray36);
        boolean[] booleanArray38 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray36);
        boolean[] booleanArray39 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray30, booleanArray38);
        boolean[] booleanArray41 = org.apache.commons.lang3.ArrayUtils.add(booleanArray30, true);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray30);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(booleanArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(booleanArray38);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertNotNull(booleanArray41);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("0971001", "1a-1a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0971001" + "'", str2.equals("0971001"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.apache.commons.lang3.text.translate.CharSequenceTranslator charSequenceTranslator0 = org.apache.commons.lang3.StringEscapeUtils.ESCAPE_HTML4;
        java.lang.String str2 = charSequenceTranslator0.translate((java.lang.CharSequence) " ");
        org.junit.Assert.assertNotNull(charSequenceTranslator0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("{-1,3,100,10,3,2}", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("aa4aaa a4a#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#a4a aaa4aa" + "'", str1.equals("#a4a aaa4aa"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("23", "", "\\u0061\\u0061\\u0034\\u0061\\u0061\\u0061\\u0020\\u0061\\u0034\\u0061\\u0023");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "u0061u0061u0034u0061u0061u0061u0020u0061u0034u0061u00232u0061u0061u0034u0061u0061u0061u0020u0061u0034u0061u00233u0061u0061u0034u0061u0061u0061u0020u0061u0034u0061u0023" + "'", str3.equals("u0061u0061u0034u0061u0061u0061u0020u0061u0034u0061u00232u0061u0061u0034u0061u0061u0061u0020u0061u0034u0061u00233u0061u0061u0034u0061u0061u0061u0020u0061u0034u0061u0023"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray4);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(byteArray4, (byte) 0);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray4, (byte) 1, 31);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("{-1,3,100,10,3,2}", "                                                                                      0a97a100a10  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{-1,3,100,10,3,2}" + "'", str2.equals("{-1,3,100,10,3,2}"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####h#####i#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####!#####", "-1.0 -1.0 1.0 -1.0 1.0 1.0", "!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0971001", "");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(shortArray4);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(shortArray7, (short) 10);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray7, (short) 1, (int) (byte) 100);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        char[] charArray2 = new char[] {};
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "", charArray2);
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(charArray2);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10,3,2}", charArray4);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, 'a');
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(charArray4);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(longArray7, (long) 24);
        long[] longArray14 = new long[] { (short) 0, 'a', 100 };
        long[] longArray16 = new long[] { (short) 10 };
        long[] longArray17 = new long[] {};
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray16, longArray17);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray18);
        long[] longArray23 = new long[] { (short) 0, 'a', 100 };
        long[] longArray25 = new long[] { (short) 10 };
        long[] longArray26 = new long[] {};
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray25, longArray26);
        long[] longArray28 = org.apache.commons.lang3.ArrayUtils.addAll(longArray23, longArray27);
        long[] longArray29 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray27);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray29);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray7, longArray29);
        long[] longArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, 0L);
        java.lang.String str35 = org.apache.commons.lang3.StringUtils.join(longArray33, '4');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertNotNull(longArray26);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(longArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10" + "'", str35.equals("10"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.lang3.ArrayUtils.remove(intArray0, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 24, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        long[] longArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_ARRAY;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray0);
        long[] longArray5 = new long[] { (short) 0, 'a', 100 };
        long[] longArray7 = new long[] { (short) 10 };
        long[] longArray8 = new long[] {};
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray7, longArray8);
        long[] longArray10 = org.apache.commons.lang3.ArrayUtils.addAll(longArray5, longArray9);
        long[] longArray14 = new long[] { (short) 0, 'a', 100 };
        long[] longArray16 = new long[] { (short) 10 };
        long[] longArray17 = new long[] {};
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray16, longArray17);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray18);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.addAll(longArray5, longArray18);
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.clone(longArray20);
        long[] longArray22 = null;
        long[] longArray23 = org.apache.commons.lang3.ArrayUtils.addAll(longArray21, longArray22);
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray0, longArray22);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.clone(longArray24);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray25);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("#####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#####" + "'", str1.equals("#####"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("{0,97,u00,u0}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0,97,u00,u0}" + "'", str1.equals("{0,97,u00,u0}"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        float[] floatArray2 = new float[] { (byte) 100, (short) -1 };
        float[] floatArray5 = new float[] { (byte) 100, (short) -1 };
        float[] floatArray8 = new float[] { (byte) 100, (short) -1 };
        float[][] floatArray9 = new float[][] { floatArray2, floatArray5, floatArray8 };
        float[][] floatArray11 = org.apache.commons.lang3.ArrayUtils.remove(floatArray9, 0);
        float[][] floatArray12 = org.apache.commons.lang3.ArrayUtils.toArray(floatArray11);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        float[] floatArray6 = new float[] { (short) -1, (-1.0f), 1.0f, (-1L), 1, 1.0f };
        float[] floatArray8 = new float[] { 'a' };
        float[] floatArray10 = new float[] { (byte) -1 };
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray6, floatArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) (short) 100);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.clone(floatArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray18, (float) 6, 26);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 -1.0 1.0 -1.0 1.0 1.0" + "'", str14.equals("-1.0 -1.0 1.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        java.lang.Object obj0 = new java.lang.Object();
        boolean[] booleanArray5 = new boolean[] { true, true, true, false };
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray5, false);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameType(obj0, (java.lang.Object) false);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        long[] longArray0 = null;
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.subarray(longArray0, 1, 2);
        org.junit.Assert.assertNull(longArray3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        boolean[] booleanArray0 = null;
        boolean[] booleanArray7 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.add(booleanArray7, true);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray9);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray9, false, (int) (short) 0);
        boolean[] booleanArray20 = new boolean[] { false, false, false, false, true, true };
        boolean[] booleanArray22 = org.apache.commons.lang3.ArrayUtils.add(booleanArray20, true);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(booleanArray22);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray22, false, (int) (short) 0);
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray9, booleanArray22);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray0, booleanArray27);
        boolean[] booleanArray29 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(booleanArray29);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray0 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper1 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray0);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] oPTIONArray2 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION[] {};
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper numericEntityUnescaper3 = new org.apache.commons.lang3.text.translate.NumericEntityUnescaper(oPTIONArray2);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION4 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon;
        boolean boolean5 = numericEntityUnescaper3.isSet(oPTION4);
        boolean boolean6 = numericEntityUnescaper1.isSet(oPTION4);
        org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION oPTION7 = org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.semiColonRequired;
        boolean boolean8 = numericEntityUnescaper1.isSet(oPTION7);
        org.junit.Assert.assertNotNull(oPTIONArray0);
        org.junit.Assert.assertNotNull(oPTIONArray2);
        org.junit.Assert.assertTrue("'" + oPTION4 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon + "'", oPTION4.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + oPTION7 + "' != '" + org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.semiColonRequired + "'", oPTION7.equals(org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION.semiColonRequired));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.remove(byteArray2, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray4);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(byteArray4, (byte) 0);
        java.lang.Byte[] byteArray13 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray13);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray14, (byte) 100, 0);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray14, (-1), (int) (short) 100);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray4, byteArray20);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray21);
        try {
            java.lang.String str24 = org.apache.commons.lang3.StringUtils.toString(byteArray21, "{0,97,100,10}");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: {0,97,100,10}");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray22);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double[] doubleArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 24, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray0 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] {};
        org.apache.commons.lang3.text.translate.CodePointTranslator[] codePointTranslatorArray1 = new org.apache.commons.lang3.text.translate.CodePointTranslator[] {};
        org.apache.commons.lang3.text.translate.CodePointTranslator[][] codePointTranslatorArray2 = new org.apache.commons.lang3.text.translate.CodePointTranslator[][] { codePointTranslatorArray0, codePointTranslatorArray1 };
        org.apache.commons.lang3.text.translate.CodePointTranslator[][] codePointTranslatorArray3 = org.apache.commons.lang3.ArrayUtils.clone(codePointTranslatorArray2);
        org.junit.Assert.assertNotNull(codePointTranslatorArray0);
        org.junit.Assert.assertNotNull(codePointTranslatorArray1);
        org.junit.Assert.assertNotNull(codePointTranslatorArray2);
        org.junit.Assert.assertNotNull(codePointTranslatorArray3);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "!", (java.lang.CharSequence) "-");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "!" + "'", charSequence2.equals("!"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        short[] shortArray3 = new short[] { (byte) 1, (byte) -1, (byte) -1 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10, 0);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray4);
        try {
            short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, 95, (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 95, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray8);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1.0", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aa4aaa a4a#", (java.lang.CharSequence) "\\u0061\\u0061\\u0034\\u0061\\u0061\\u0061\\u0020\\u0061\\u0034\\u0061\\u0023");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("10,3,2}", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0a", (int) (short) 1, "97410041041040");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a" + "'", str3.equals("0a"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.0", "");
        java.lang.Byte[] byteArray8 = new java.lang.Byte[] { (byte) -1, (byte) 1, (byte) 10, (byte) 10, (byte) 10 };
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray9, (byte) 100, 0);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(byteArray9);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) "", (java.lang.Object) byteArray9);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray9);
        int[] intArray21 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.contains(intArray21, (int) (byte) 0);
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray21);
        java.lang.Integer[] intArray25 = new java.lang.Integer[] {};
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray25);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray26);
        int[] intArray32 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.contains(intArray32, (int) (byte) 0);
        int[] intArray35 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray32);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray27, intArray35);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray21, intArray27);
        int[] intArray39 = org.apache.commons.lang3.ArrayUtils.add(intArray21, 0);
        java.lang.Integer[] intArray40 = org.apache.commons.lang3.ArrayUtils.toObject(intArray39);
        try {
            byte[] byteArray41 = org.apache.commons.lang3.ArrayUtils.removeAll(byteArray9, intArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "{0,97,u00,u0}");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        long[] longArray3 = new long[] { (short) 0, 'a', 100 };
        long[] longArray5 = new long[] { (short) 10 };
        long[] longArray6 = new long[] {};
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray5, longArray6);
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray7);
        long[] longArray12 = new long[] { (short) 0, 'a', 100 };
        long[] longArray14 = new long[] { (short) 10 };
        long[] longArray15 = new long[] {};
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.removeElements(longArray14, longArray15);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray16);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray3, longArray16);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray18, 0L, (int) (short) -1);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "1", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray1);
        try {
            int[] intArray4 = org.apache.commons.lang3.ArrayUtils.remove(intArray2, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "{0,97,100,10}                   ", (java.lang.CharSequence) "1a-1a-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.0", "                                                                                      0A97A100A10   ", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h-1.0-1.01.0-1.01.01.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        int[] intArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, 10, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        int[] intArray4 = new int[] { 'a', (short) 100, (short) 10, (byte) 10 };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 0);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray4);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(intArray4);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isNotEmpty(intArray8);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        char[] charArray0 = null;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.lang.Byte[] byteArray3 = new java.lang.Byte[] { (byte) 1, (byte) 10, (byte) -1 };
        java.lang.Byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray3);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.nullToEmpty(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray4, (byte) 0);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray4);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
    }
}

