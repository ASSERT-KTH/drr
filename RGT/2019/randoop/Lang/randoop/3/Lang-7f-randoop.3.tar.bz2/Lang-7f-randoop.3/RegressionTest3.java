import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "###", (java.lang.CharSequence) "vav/fd/dfvs/_v/6v597zmv4_v31rq2v");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "...F4V1...", (java.lang.CharSequence) "1#", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/Users/sophie/Documents/defects4j/tmp/run_randoop...", "noitaroproCelcarO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop..." + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop..."));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) ".", (java.lang.CharSequence) "1041004-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.lwawt.macosx.lwctoolkit");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "vav/fd/dfvs/_v/6v597zmv4_v31rq2v", (java.lang.CharSequence) "10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1tnemnorivnE emitnuR ES )MT(avaJ10 100 -1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        float[] floatArray0 = new float[] {};
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.9");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1#1#100#10", (java.lang.CharSequence) "10http://java.oracle.com/14http://java.oracle.com/3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "a:aaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("en");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("...F4V1...", strArray2, strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "...F4V1..." + "'", str4.equals("...F4V1..."));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("###########################4####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###########################4####" + "'", str1.equals("###########################4####"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "M c OS X", (java.lang.CharSequence) "-1410045241", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("100.0A100.0A10.0A0.0A97.0A35.0", 1, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "00.0A1" + "'", str3.equals("00.0A1"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "100.0 100.0 10.0 0.0 97.0 35.0", (java.lang.CharSequence) "!/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "100.0 100.0 10.0 0.0 97.0 35.0" + "'", charSequence2.equals("100.0 100.0 10.0 0.0 97.0 35.0"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("vav/fd/dfvs/_v/6v597zmv4_v31rq2v");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, 5, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        long[] longArray4 = new long[] { (-1), (byte) 100, 52L, (short) 1 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        java.lang.Class<?> wildcardClass10 = longArray4.getClass();
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1#100#52#1" + "'", str9.equals("-1#100#52#1"));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1#/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739", "1.0#32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739" + "'", str2.equals("1#/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 35L, (float) (byte) -1, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sun.lwawt.macosx.lwctoolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("http://java.oracle.com/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("0.9", "0.0a3.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1#-1#10#10#52", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java HotSpot(TM) 64-Bit Server VM", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("0", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10a100a-1", "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("                                                1#10", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                1#10" + "'", str2.equals("                                                1#10"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "\n", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("####4#####");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###4#####\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a', (int) (short) -1, (int) (short) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        double[] doubleArray6 = new double[] { 100.0d, 100.0d, 10.0f, (short) 0, 'a', '#' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', 33, 4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100.0a100.0a10.0a0.0a97.0a35.0" + "'", str8.equals("100.0a100.0a10.0a0.0a97.0a35.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0 100.0 10.0 0.0 97.0 35.0" + "'", str10.equals("100.0 100.0 10.0 0.0 97.0 35.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100.0#100.0#10.0#0.0#97.0#35.0" + "'", str16.equals("100.0#100.0#10.0#0.0#97.0#35.0"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1 1 100 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1 1 100 10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("UTF-8", "JAVA HOTSPOT(TM) 64-BIT SERVER VM", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "           ", (java.lang.CharSequence) "M c OS ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "-1#10#100", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1 100 52 1", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 52 100 1" + "'", str2.equals("1 52 100 1"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "java(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environment", "-1a100a52a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#                                                                                                   ", (java.lang.CharSequence) "0410");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.2", "hi!", 100);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "sophie");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "0.0a1.0", 0);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray12);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12);
        java.lang.String[] strArray22 = new java.lang.String[] { "1.0hi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!10.14.3", "1.2", ":", "Java HotSpot(TM) 64-Bit Server VM", "sun.lwawt.macosx.LWCToolkit" };
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.split("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "HI!");
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray22, strArray25);
        java.lang.String[] strArray28 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0");
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray28, '4', (int) (short) 0, (int) (byte) 1);
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("x86_64", strArray25, strArray28);
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.replaceEach(".", strArray12, strArray25);
        java.lang.String str36 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray25, '4');
        java.lang.String[] strArray38 = org.apache.commons.lang3.StringUtils.stripAll(strArray25, "100.0A100.0A10.0A0.0A97.0A35.0");
        int int39 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray25);
        java.lang.String str40 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0 10", strArray4, strArray25);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "51.0" + "'", str32.equals("51.0"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "x86_64" + "'", str33.equals("x86_64"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "." + "'", str34.equals("."));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str36.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0 10" + "'", str40.equals("0 10"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', 69, (-1));
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1#", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#" + "'", str2.equals("1#"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7" + "'", str2.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                   ");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "100.0a100.0a10.0a0.0a97.0a35.0", (java.lang.CharSequence) "java(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environment", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "10http://java.oracle.com/14http://java.oracle.com/3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0410", (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 410L + "'", long2 == 410L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "vav/fd/dfvs/_v/6v597zmv4_v31rq2v", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "vav/fd/dfvs/_v/6v597zmv4_v31rq2v" + "'", charSequence2.equals("vav/fd/dfvs/_v/6v597zmv4_v31rq2v"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10." + "'", str1.equals("10."));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2v", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) -1, (short) 1410);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-1 100 52 1", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1 100 52 1" + "'", str3.equals("-1 100 52 1"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "100.0#100.0#10.0#0.0#97.0#35.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "24.80-b11", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-1#100#52#1", "aaaa:aaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#100#52#1" + "'", str2.equals("-1#100#52#1"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 33, 0.0f, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "1041004-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) ".");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                               HI!                                               ", "                                                1#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               HI!                                               " + "'", str2.equals("                                               HI!                                               "));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.0hi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!10.14.3", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 11, 17.0d, 1.7d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7d + "'", double3 == 1.7d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("#1#100#    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#1#100#   " + "'", str1.equals("#1#100#   "));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/t/VG0000RF4V1X2V2QR13V_4VMZ795V6/V_/SVFD/DF/VAV", (java.lang.CharSequence) "0 10", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophie", "####4#####", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("100r0A100r0A10r0A0r0A97r0A35r0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100R0a100R0a10R0a0R0a97R0a35R0" + "'", str1.equals("100R0a100R0a10R0a0R0a97R0a35R0"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:24.80-b11/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/", 44, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                                                                 1.2", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 1.2" + "'", str3.equals("                                                                                                 1.2"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("vav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2v");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "a:aaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "-##2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        float[] floatArray1 = new float[] { (short) 10 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#', (int) (short) 1, (int) (short) 1410);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2v");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "100R0a100R0a10R0a0R0a97R0a35R0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0a-1a10a52a1", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle(" ", "Java HotSpot(TM) 64-Bit Server VM", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "noitaroproC elcarO", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(" OS X", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) " 1 100 52 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "-##2#aaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaa", (int) 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############################################aaa###############################################" + "'", str3.equals("###############################################aaa###############################################"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "-1#100#52#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10http://java.oracle.com/14http://java.oracle.com/3", 'a');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "mixed/mode", 10);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739", strArray3, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 7 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Platform API Specification", 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "00.0A1", (java.lang.CharSequence) "UTF-8", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 44, (long) 11, 410L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 11L + "'", long3 == 11L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("-1410045241", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1410045241" + "'", str2.equals("-1410045241"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0" + "'", str1.equals("0"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("en", "noitaroproC elcarO", "1.0hi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!10.14.3");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("14-1410410452");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "14-1410410452" + "'", str1.equals("14-1410410452"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                               HI!                                               ", 10, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                             ..." + "'", str3.equals("...                             ..."));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("-14104100", 6, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1410045241", (java.lang.CharSequence) "0.0a3.0", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1 52 100 1", (int) '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444441 52 100 1" + "'", str3.equals("4444444444444444444444444444444444444444441 52 100 1"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("x86_64");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x86_64\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 69);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                     " + "'", str2.equals("                                                                     "));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("hi!", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) 1, (byte) 100, (byte) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "-1#100#52#1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: -1#100#52#1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1 1 100 10" + "'", str6.equals("1 1 100 10"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.0hi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0HI!/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/HI!100HI!0HI!0HI!10.14.3" + "'", str1.equals("1.0HI!/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/HI!100HI!0HI!0HI!10.14.3"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("JAVA HOTSPOT(TM) 64-BIT SERVER VM", "10.", 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str3.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("###############################################aaa###############################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###############################################aaa###############################################" + "'", str1.equals("###############################################aaa###############################################"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("-1 100 52 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 100 52 1" + "'", str1.equals("-1 100 52 1"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/T/vg0000rf4v1x2v2qr13v_4vmz795v6/v_/svfd/df/vav");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("#1#0#0#", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "0.0a1.0", 0);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray15 = new java.lang.String[] { "1.0hi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!10.14.3", "1.2", ":", "Java HotSpot(TM) 64-Bit Server VM", "sun.lwawt.macosx.LWCToolkit" };
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.split("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "HI!");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray15, strArray18);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0");
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray21, '4', (int) (short) 0, (int) (byte) 1);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("x86_64", strArray18, strArray21);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEach(".", strArray5, strArray18);
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray18, '4');
        java.lang.String[] strArray31 = org.apache.commons.lang3.StringUtils.stripAll(strArray18, "100.0A100.0A10.0A0.0A97.0A35.0");
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray31);
        java.lang.Class<?> wildcardClass33 = strArray31.getClass();
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "51.0" + "'", str25.equals("51.0"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "x86_64" + "'", str26.equals("x86_64"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "." + "'", str27.equals("."));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str29.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str32.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("10.14.3", 11, 33);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.00..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/0..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.31000..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.300..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.300..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.310.14.3", "5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.00..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/0..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.31000..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.300..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.300..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.310.14.3" + "'", str2.equals("1.00..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/0..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.31000..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.300..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.300..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.310.14.3"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.0a3.0", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("sun.lwawt.macosx.CPrinterJo", "0.0a1.0", "1 52 100 1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("x86_64", "aaaa:aaaaa");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "1.2");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("####4####", strArray1, strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "####4####" + "'", str7.equals("####4####"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', 12, (int) '#');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("mixed/mode", "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob", "-1#100#52#1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed/mode" + "'", str3.equals("mixed/mode"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "                                               HI!                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "###", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "###" + "'", charSequence2.equals("###"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("-##2", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-##2" + "'", str2.equals("-##2"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!", "100", (int) (byte) 1);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence[]) strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "00.0A1");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!" + "'", str8.equals("!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hi!", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        long[] longArray4 = new long[] { (-1), (byte) 100, 52L, (short) 1 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#100#52#1" + "'", str7.equals("-1#100#52#1"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaa", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa" + "'", str2.equals("aaa"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "###############################################aaa###############################################", (java.lang.CharSequence) "1#-1#10#1...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "en", (java.lang.CharSequence) "!/...", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("100r0A100r0A10r0A0r0A97r0A35r0", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100r0A100..." + "'", str2.equals("100r0A100..."));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("java(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environment", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environment" + "'", str3.equals("java(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environmentsun.lwawt.macosx.CPrinterJobjava(tm) se runtime environment"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (-1), "-1#100#52#1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "100#10#52#-1", " 1 100 52 1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk .7.1_81.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk .7.1_81.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("...                             ...", "10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...                             ..." + "'", str2.equals("...                             ..."));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(410L, (long) 10, (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 410L + "'", long3 == 410L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.0#32.0", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0#32.0" + "'", str2.equals(".0#32.0"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("5", "sun.lwawt.macosx.lwctoolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5" + "'", str2.equals("5"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1 1 100 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1 1 100 10" + "'", str1.equals("1 1 100 10"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:24.80-b11/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/", "                                                                                                 1.2", "100.0#100.0#10.0#0.0#97.0#35.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1#-1#10#10#52", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#-1#10#10#52" + "'", str2.equals("1#-1#10#10#52"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1#-1#10#10#52", 6, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1#-1#10#10#52" + "'", str3.equals("1#-1#10#10#52"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "100.0#100.0#10.0#0.0#97.0#35.0", (java.lang.CharSequence) "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        short[] shortArray1 = new short[] { (short) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 97, (int) (byte) 0);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', (int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("10http://java.oracle.com/14http://java.oracle.com/3", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava.oracle.com/14http://java.oracle.com/3" + "'", str2.equals("ava.oracle.com/14http://java.oracle.com/3"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("-14-14-1410", "-##2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-14-14-1410" + "'", str2.equals("-14-14-1410"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("-1#10#100", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#10#100" + "'", str2.equals("-1#10#100"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "0.0 3.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1 100 52 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a:aaaa", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/t/VG0000RF4V1X2V2QR13V_4VMZ795V6/V_/SVFD/DF/VAV");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                   .", (int) (byte) 100, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "noitaroproCelcarO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjo", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("00.0A1", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "00.0A1" + "'", str3.equals("00.0A1"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        java.lang.String[] strArray7 = new java.lang.String[] { "1.0hi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!10.14.3", "1.2", ":", "Java HotSpot(TM) 64-Bit Server VM", "sun.lwawt.macosx.LWCToolkit" };
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "HI!");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray7, strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray13, '4', (int) (short) 0, (int) (byte) 1);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("x86_64", strArray10, strArray13);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "                                   ");
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "51.0" + "'", str17.equals("51.0"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "x86_64" + "'", str18.equals("x86_64"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str21.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "0a-1a10a52a1", 100);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/v#r/folders/_v/6v#97zmn4_v3#cq#n#x#n4fc#gn/T/" + "'", str5.equals("/v#r/folders/_v/6v#97zmn4_v3#cq#n#x#n4fc#gn/T/"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("0.0a3.0", "#                                                                                                   ", (int) (byte) 100, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#                                                                                                   " + "'", str4.equals("#                                                                                                   "));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0 10", "JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM10.JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 7, (float) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 7.0f + "'", float3 == 7.0f);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                   ", "...                             ...", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "###", (java.lang.CharSequence) "aaa", 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.0hi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!10.14.3", "aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0hi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!10.14.3" + "'", str2.equals("1.0hi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!10.14.3"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("100r0A100r0A10r0A0r0A97r0A35r0", "tnemnorivnE emitnuR ES )MT(avaJ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100r0A100r0A10r0A0r0A97r0A35r0" + "'", str3.equals("100r0A100r0A10r0A0r0A97r0A35r0"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1410");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1410L + "'", long1 == 1410L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("100r0A100r0A10r0A0r0A97r0A35r0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("-##2#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#2##-" + "'", str1.equals("#2##-"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "HI", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.0hi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!10.14.3", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "51.0", 10, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("...F4V1...", "10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...F4V1..." + "'", str2.equals("...F4V1..."));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("4444444444444444444444444444444444444444441 52 100 1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" 52 100 1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1.0#32.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("s/_v/", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s/_v/" + "'", str2.equals("s/_v/"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "10.", (java.lang.CharSequence) "!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Platform API Specification", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("...F4V1...", "############");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...F4V1..." + "'", str2.equals("...F4V1..."));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                1#10");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "M c OS ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444444444444444444444444444444444444444441 52 100 1", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444441 52 100 1" + "'", str3.equals("4444444444444444444444444444444444444444441 52 100 1"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.00..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/0..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.31000..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.300..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.300..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.310.14.3", (java.lang.CharSequence) "#2##-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 11, 4L, 11L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 11L + "'", long3 == 11L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", (java.lang.CharSequence) "-1#100#52#1", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 'a', 0.0d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "!/...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("10.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1 100 52 1", "", "!/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!", 33);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1 100 52 1" + "'", str4.equals("1 100 52 1"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "100.0#100.0#10.0#0.0#97.0#35.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0#100.0#10.0#0.0#97.0#35.0" + "'", str2.equals("100.0#100.0#10.0#0.0#97.0#35.0"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        char[] charArray8 = new char[] { 'a', ' ', 'a', '4', '4', 'a' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', (int) (short) 100, (int) (byte) -1);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x86_64", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.0#32.0", charArray8);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a# #a#4#4#a" + "'", str16.equals("a# #a#4#4#a"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("############", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############" + "'", str2.equals("############"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100404104040");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 12L, (float) (short) -1, (float) 6);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 12.0f + "'", float3 == 12.0f);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "                            0410                                                                 ");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 3, (long) (short) 1, (long) 33);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 33L + "'", long3 == 33L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd(":", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("0.0a3.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("0..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0..HI!/VAR/FOLDERS/_V/6V97ZMN4_V30CQNX0N4FC....GN/T/HI!0..HI!.HI!.HI!0..04.3" + "'", str1.equals("0..HI!/VAR/FOLDERS/_V/6V97ZMN4_V30CQNX0N4FC....GN/T/HI!0..HI!.HI!.HI!0..04.3"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("#2##-", (float) 44);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 44.0f + "'", float2 == 44.0f);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!" + "'", str2.equals("!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                     ", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 12, 10L, (long) 7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "vav/fd/dfvs/_v/6v597zmv4_v31rq2v", (java.lang.CharSequence) "...                             ...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        short[] shortArray1 = new short[] { (short) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', 319, 12);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "1#-1#10#10#52", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1#-1#10#10#52" + "'", charSequence2.equals("1#-1#10#10#52"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1#1#1#", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1041004-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("Sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("51.0", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("10.", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10." + "'", str2.equals("10."));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 11, (long) 97, (long) (short) 1410);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1410L + "'", long3 == 1410L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1#1#1#", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#1#1#" + "'", str2.equals("1#1#1#"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(" OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OSX" + "'", str1.equals("OSX"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "noitaroproCelcarO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) (short) 10, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                1#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("############");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "############" + "'", str1.equals("############"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        double[] doubleArray1 = new double[] { (byte) 100 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 32, (int) (short) 1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 7, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("100r0A100...", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100r0A100..." + "'", str2.equals("100r0A100..."));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("10.0", "-14104100");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        char[] charArray10 = new char[] { 'a', ' ', 'a', '4', '4', 'a' };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray10, '4', (int) (short) 100, (int) (byte) -1);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x86_64", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1#-1#10#10#52", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-14-14-1410", charArray10);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(":", ' ');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "a# #a#4#4#a");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Sun.lwawt.macosx.cprinterjo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.cprinterjo" + "'", str1.equals("Sun.lwawt.macosx.cprinterjo"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) 1, (byte) 100, (byte) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1 1 100 10" + "'", str6.equals("1 1 100 10"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("http://java.oracle.com/", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http//java.oracle.com/" + "'", str2.equals("http//java.oracle.com/"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        int[] intArray3 = new int[] { (byte) 10, (short) 100, (-1) };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100a-1" + "'", str8.equals("10a100a-1"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        double[] doubleArray0 = new double[] {};
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739", (java.lang.CharSequence) "52", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("-1#100#52#1", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.0HI!/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/HI!100HI!0HI!0HI!10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0HI!/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/HI!100HI!0HI!0HI!10.14.3" + "'", str1.equals("1.0HI!/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/HI!100HI!0HI!0HI!10.14.3"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "/Users/sophie/Documents/defects4j/tmp/run_randoop...");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("0..HI!/VAR/FOLDERS/_V/6V97ZMN4_V30CQNX0N4FC....GN/T/HI!0..HI!.HI!.HI!0..04.3", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0..HI!/VAR/FOLDERS/_V/6V97ZMN4_V30CQNX0N4FC....GN/T/HI!0..HI!.HI!.HI!0..04.3" + "'", str2.equals("0..HI!/VAR/FOLDERS/_V/6V97ZMN4_V30CQNX0N4FC....GN/T/HI!0..HI!.HI!.HI!0..04.3"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                     ", "mixed/mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("a a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a a" + "'", str1.equals("a a"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "", (java.lang.CharSequence) "noitaroproCelcarO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("############");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "############" + "'", str1.equals("############"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("                                   ", "", (int) '#');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("...F4V1...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...f4v1..." + "'", str1.equals("...f4v1..."));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10http://java.oracle.com/14http://java.oracle.com/3", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 12, 97L, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav", "                                                                                                   .", "1410");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav" + "'", str3.equals("/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1410", "tionachine Specifical Ma VirtuavaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" ", "1#-1#10#10#52");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "0.0a1.0", 0);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String[] strArray19 = new java.lang.String[] { "1.0hi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!10.14.3", "1.2", ":", "Java HotSpot(TM) 64-Bit Server VM", "sun.lwawt.macosx.LWCToolkit" };
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.split("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "HI!");
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray19, strArray22);
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0");
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray25, '4', (int) (short) 0, (int) (byte) 1);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("x86_64", strArray22, strArray25);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.replaceEach(".", strArray9, strArray22);
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray22, '4');
        java.lang.String[] strArray35 = org.apache.commons.lang3.StringUtils.stripAll(strArray22, "100.0A100.0A10.0A0.0A97.0A35.0");
        java.lang.Class<?> wildcardClass36 = strArray35.getClass();
        java.lang.String str37 = org.apache.commons.lang3.StringUtils.replaceEach("                            0410", strArray3, strArray35);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "51.0" + "'", str29.equals("51.0"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "x86_64" + "'", str30.equals("x86_64"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "." + "'", str31.equals("."));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str33.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/0410" + "'", str37.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/0410"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("aaaa:aaaaa", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaa:aaaaa" + "'", str2.equals("aaaa:aaaaa"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("vav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2v");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"vav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2v\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:24.80-b11/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/", "100.0#100.0#10.0#0.0#97.0#35.0", "fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2vvav/fd/dfvs/_v/6v597zmv4_v31rq2v");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo", 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1#10", "                            0410", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10" + "'", str3.equals("1#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("###", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   " + "'", str3.equals("   "));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:. is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                     ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0.0a1.0                                                                                             ", (java.lang.CharSequence) "###########################4####");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1 1 100 10", 44, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 1 100 10                                  " + "'", str3.equals("1 1 100 10                                  "));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "-##2#aaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:24.80-b11/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/", (double) 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("noitaroproCelcarO", 69);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    noitaroproCelcarO" + "'", str2.equals("                                                    noitaroproCelcarO"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1#1#1#", (int) (byte) 100, 319);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "/v#r/folders/_v/6v#97zmn4_v3#cq#n#x#n4fc#gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray3 = new char[] { 'a', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ');
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a a" + "'", str5.equals("a a"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "aaa" + "'", str8.equals("aaa"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("en");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) 1, (byte) 100, (byte) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "1 1 100 10                                  ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1 1 100 10                                  ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1 1 100 10" + "'", str6.equals("1 1 100 10"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1#1#100#10" + "'", str8.equals("1#1#100#10"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0 10", "-14-14-1410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 10" + "'", str2.equals("0 10"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1041004-1", "-14104100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd(".0#32.0", "-##2#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0#32.0" + "'", str2.equals(".0#32.0"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "/T/vg0000rf4v1x2v2qr13v_4vmz795v6/v_/svfd/df/vav");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47 + "'", int2 == 47);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-1#100#52#1", 12, "...                             ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1#100#52#1." + "'", str3.equals("-1#100#52#1."));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Sun.lwawt.macosx.cprinterjo", "OSX");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(12.0f, 17.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 100, (byte) 100, (byte) 100, (byte) 100, (byte) 1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("############", 47, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaa############aaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaa############aaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "#1#100#   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1#10", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#10" + "'", str2.equals("1#10"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "noitaroproC elcarO", (java.lang.CharSequence) "0a-1a10a52a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "-##2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                            " + "'", str1.equals("                            "));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_64", 8, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("14-1410410452");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1#100#52#1", (java.lang.CharSequence) "0.0A3.0", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.0HI!/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/HI!100HI!0HI!0HI!10.14.3", (int) (byte) -1, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0HI!/VA..." + "'", str3.equals("1.0HI!/VA..."));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) '#', (float) 1410L, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1410.0f + "'", float3 == 1410.0f);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("0a-1a10a52a1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a-1a10a52a1" + "'", str2.equals("0a-1a10a52a1"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("mixed mode", "");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1#-1#10#10#52", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "####4#####", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.lwawt.macosx.CPrinterJo");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.lwawt.macosx.CPrinterJo");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("1#10", strArray2, strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1#10" + "'", str4.equals("1#10"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "aaaa:aaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) ".");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1a100a52a1", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("          ", "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "   ", (java.lang.CharSequence) "tionachine Specifical Ma VirtuavaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 0L, (float) (-1L), (float) 47);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 47.0f + "'", float3 == 47.0f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "                                                                                                   .", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("mixed mode", "/Users/sophie/Documents/defects4j/tmp/run_randoop...", "-1#100#52#1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1#-1#10#1...");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1410", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0, (double) (short) 1, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                               HI!                                               ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("en");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) (short) 100, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EN" + "'", str1.equals("EN"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                   .", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("0.043.0", "                                               HI!                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.043.0" + "'", str2.equals("0.043.0"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie", 7, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "###############################################aaa###############################################", (java.lang.CharSequence) " OS X", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.0HI!/VA...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 100, (float) 17, 6.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '#', (double) ' ', (double) 33);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(410L, (long) (short) 1410, (long) (short) 1410);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1410L + "'", long3 == 1410L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1#", (java.lang.CharSequence) "#                                                                                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "0.0 3.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 0.0 3.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0410" + "'", str4.equals("0410"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0 10" + "'", str7.equals("0 10"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.7.0_80-B15", "0a-1a10a52a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a-1a10a52a1" + "'", str2.equals("0a-1a10a52a1"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "1#1#100#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (short) 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/E..." + "'", str3.equals("...e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/E..."));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "####4#####", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(":", "############", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:" + "'", str3.equals(":############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:############:"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 8, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("EN", "1410", "aaa1 100 52 1", 17);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "EN" + "'", str4.equals("EN"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("M c OS ", "0..HI!/VAR/FOLDERS/_V/6V97ZMN4_V30CQNX0N4FC....GN/T/HI!0..HI!.HI!.HI!0..04.3", "####4####");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " c  " + "'", str3.equals(" c  "));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100.0a100.0a10.0a0.0a97.0a35.0", " 1 100 52 1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "0", (java.lang.CharSequence) "0..HI!/VAR/FOLDERS/_V/6V97ZMN4_V30CQNX0N4FC....GN/T/HI!0..HI!.HI!.HI!0..04.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0.0A3.0", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#1#100#   ", (java.lang.CharSequence) "1.7.0_80", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                            0410", "100404104040", "1 -1 10 10 52");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                            0410" + "'", str3.equals("                            0410"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("#1#100#    ", 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#1#100#    " + "'", str3.equals("#1#100#    "));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#" + "'", str1.equals("1#"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "###");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:24.80-b11/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/", "JAVA HOTSPOT(TM) 64-BIT SERVER VM", 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VMsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:24.80-b11/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/" + "'", str4.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VMsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:24.80-b11/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("a# #a#4#4#a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) -1, (byte) -1, (byte) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-14-14-1410" + "'", str6.equals("-14-14-1410"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                1#10", (java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        long[] longArray5 = new long[] { (short) 1, (short) -1, 10, 10, 52L };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', (int) (short) 100, (int) (byte) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray5, '4');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', (int) (byte) 100, (int) ' ');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1#-1#10#10#52" + "'", str11.equals("1#-1#10#10#52"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "14-1410410452" + "'", str13.equals("14-1410410452"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(319, (int) (byte) -1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 319 + "'", int3 == 319);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "####4#####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("-1#100#52#1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/v#r/folders/_v/6v#97zmn4_v3#cq#n#x#n4fc#gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) -1, 0, 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("-##2#", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a# #a#4#4#a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-##2#" + "'", str3.equals("-##2#"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("100#10#52#-1", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#10#52#-1" + "'", str2.equals("100#10#52#-1"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("#1#100#    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1#10", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#101#101#101#10" + "'", str2.equals("1#101#101#101#10"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Documents/defects4j/tmp/run_randoop...", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        short[] shortArray1 = new short[] { (short) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', (int) ' ', (int) (byte) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 12, 0);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', (-1), 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("http://java.oracle.com/", "00.0A1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sun.lwawt.macosx.CPrinterJo", "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str2.equals("sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(12.0d, (double) 4, (double) 4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "0.0a1.0", (java.lang.CharSequence) "4444444444444444444444444444444444444444441 52 100 1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                    noitaroproCelcarO", "0..HI!/VAR/FOLDERS/_V/6V97ZMN4_V30CQNX0N4FC....GN/T/HI!0..HI!.HI!.HI!0..04.3", "1410");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "noitaroproCelcarO", (java.lang.CharSequence) "10a100a-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100r0A100...", (java.lang.CharSequence) "x86_64", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "...                             ...", (java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("...e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/E...", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("100#10#52#-1", (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1", (java.lang.CharSequence) "-1#100#52#1.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "a:aaaa", (java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("-14104100", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-14104100" + "'", str2.equals("-14104100"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.0#32.0", "100.0 100.0 10.0 0.0 97.0 35.0");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1#1#100#10", (java.lang.CharSequence) "00.0A1", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "!/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!", "1 1 100 10                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(":", 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("#1#100#10", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#1#100#10" + "'", str2.equals("#1#100#10"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1#/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 65 + "'", int3 == 65);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "OSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.0HI!/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/HI!100HI!0HI!0HI!10.14.3", (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(100.0d, (double) 8, (double) 7L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("HIAHI HIaHI", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(".0#32.0", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0#32.0" + "'", str2.equals(".0#32.0"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "s/_v/", (java.lang.CharSequence) "a a", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9" + "'", str3.equals("0.9"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "HI!", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa" + "'", str1.equals("aa"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.CPrinterJob", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("x86_64", "100.0a100.0a10.0a0.0a97.0a35.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("52", "M c OS ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52" + "'", str2.equals("52"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "-##2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "0.0 3.0", (java.lang.CharSequence) "-1#100#52#1", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("HI");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.0hi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!10.14.3");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 79 + "'", int1 == 79);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1a10", 31, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                           1a10" + "'", str3.equals("                           1a10"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                           1a10", 44);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44 + "'", int2 == 44);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "0a-1a10a52a1");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/" + "'", str4.equals("/"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("-##2#aaaaaaa", "HI", 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaa" + "'", str3.equals("-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaa"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaa", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10a100a-1", (int) (short) -1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a100a-1" + "'", str3.equals("10a100a-1"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1410", (java.lang.CharSequence) "/v#r/folders/_v/6v#97zmn4_v3#cq#n#x#n4fc#gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "-1#100#52#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaaa:aaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        int[] intArray5 = new int[] { (short) -1, 10, 100 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        short[] shortArray9 = new short[] { (short) 0 };
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray9);
        java.lang.Object[] objArray12 = new java.lang.Object[] { 1.0d, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", int6, 0L, short10, "10.14.3" };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(objArray12, "hi!");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(objArray12, "0..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.3");
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(objArray12, "en", (int) (short) 100, (int) '#');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.0hi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!10.14.3" + "'", str14.equals("1.0hi!/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!100hi!0hi!0hi!10.14.3"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.00..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/0..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.31000..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.300..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.300..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.310.14.3" + "'", str16.equals("1.00..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.3/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/0..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.31000..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.300..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.300..hi!/var/folders/_v/6v97zmn4_v30cqnx0n4fc....gn/T/hi!0..hi!.hi!.hi!0..04.310.14.3"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "00.0A1", (java.lang.CharSequence) " ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-B15", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 319);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aa aa", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa aa" + "'", str2.equals("aa aa"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("#1#100#10", "1#1#1#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#1#100#10" + "'", str2.equals("#1#100#10"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJO" + "'", str1.equals("SUN.LWAWT.MACOSX.CPRINTERJO"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "100r0A100r0A10r0A0r0A97r0A35r0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http//java.oracle.com/", (java.lang.CharSequence) "1.0HI!/VA...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sun.awt.CGraphicsEnvironment", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("JAVA HOTSPOT(TM) 64-BIT SERVER VMsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:24.80-b11/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VMsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:24.80-b11/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:" + "'", str1.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VMsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:24.80-b11/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("...f4v1...", (int) (short) 100, "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lw...f4v1..." + "'", str3.equals("sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lw...f4v1..."));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0.9", (int) ' ', "/Users/sophie/Documents/defects4j/tmp/run_randoop...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defec0.9" + "'", str3.equals("/Users/sophie/Documents/defec0.9"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java Platform API Specification", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n" + "'", str2.equals("n"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1#/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1 1 100 10                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "                                               HI!                                               ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        char[] charArray2 = new char[] { '#' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray2, '4', 0, 0);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#" + "'", str4.equals("#"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                   ", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split(" 1 100 52 1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50002_1560276739", "aaaa:aaaaa", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("n", "10 100 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n" + "'", str2.equals("n"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaaHI-##2#aaaaaaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(65, (int) (short) 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("100R0a100R0a10R0a0R0a97R0a35R0", "Java(TM) SE Runtime Environment", ".0#32.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100R0a100R0a10R0a0R0a97R0a35R0" + "'", str3.equals("100R0a100R0a10R0a0R0a97R0a35R0"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "...e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/E...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("100.0#100.0#10.0#0.0#97.0#35.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0#100.0#10.0#0.0#97.0#35.0" + "'", str1.equals("100.0#100.0#10.0#0.0#97.0#35.0"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        short[] shortArray1 = new short[] { (short) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 0, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("a a", "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a a" + "'", str2.equals("a a"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "1 52 100 1", (java.lang.CharSequence) "100");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1 52 100 1" + "'", charSequence2.equals("1 52 100 1"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("vav/fd/dfvs/_v/6v597zmv4_v31rq2v");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VAV/FD/DFVS/_V/6V597ZMV4_V31RQ2V" + "'", str1.equals("VAV/FD/DFVS/_V/6V597ZMV4_V31RQ2V"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "####4#####", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "ava.oracle.com/14http://java.oracle.com/3", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("10a100a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10A100A-1" + "'", str1.equals("10A100A-1"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10                            04101#10", charSequence1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaaa:aaaaa", 16, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4, (int) (short) 10, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("a a", 3, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a a" + "'", str3.equals("a a"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4444444444444444444444444444444444444444441 52 100 1", "HI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("00.0A1", "tnemnorivnE emitnuR ES )MT(avaJ", 47);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1" + "'", str3.equals("00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1tnemnorivnE emitnuR ES )MT(avaJ00.0A1"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        int[] intArray3 = new int[] { (short) -1, 10, 100 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', 33, 5);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10.14.3", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }
}

