import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hie", (int) (short) 10, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Lihie/Lib" + "'", str3.equals("/Lihie/Lib"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("01100-1", "51.051.053", 33);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "01100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-1" + "'", str3.equals("01100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-1"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 0, (long) 5, (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '#', 28, 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(":", ".");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "oRACLE cORPORATION", (java.lang.CharSequence) "/Lihie/Lib");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.41004095E11f, (float) 10L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                               sophie                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (short) 100, 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("100a1a-1a1", 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) -1, "##4#4#a##");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "100.0a-1.0a100.0a0.0a52.0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRAC");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRAC" + "'", str1.equals("1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRAC"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                                               sophie                                               ", (java.lang.CharSequence) "...R");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        short[] shortArray4 = new short[] { (short) 0, (byte) 1, (short) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "04141004-1" + "'", str7.equals("04141004-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        short[] shortArray5 = new short[] { (short) 0, (short) -1, (short) 1, (short) -1, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(27, 214, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("51.0", "####################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + "'", str1.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) ".:4v4j/bil/rsu/:snoisnetxe/4v4j/yr4rbil/metsys/:snoisnetxe/4v4j/yr4rbil/krowten/:snoisnetxe/4v4j/yr4rbil/:snoisnetxe/4v4j/yr4rbil/eihpos/sresu/p/run_r7ndoop.pl_51595_1560278762", (java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                             ", "1.7.0_80", "174497");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                             " + "'", str3.equals("                                                                                             "));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        short[] shortArray5 = new short[] { (short) 0, (short) -1, (short) 1, (short) -1, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 52, 0);
        short short16 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0#-1#1#-1#-1" + "'", str8.equals("0#-1#1#-1#-1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0 -1 1 -1 -1" + "'", str11.equals("0 -1 1 -1 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 1 + "'", short16 == (short) 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0#-1#1#-1#-1" + "'", str18.equals("0#-1#1#-1#-1"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#", "", (int) ' ');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51595_1560278762/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51595_1560278762/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51595_1560278762/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("xtensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:", "3", "PrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "xtensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:" + "'", str3.equals("xtensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:.", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("US", "01100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("MV revreS");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("0", "0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0" + "'", str1.equals("100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("      ", (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("UTF8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF8" + "'", str1.equals("UTF8"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51595_1560278762/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "04141004-1", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(51.0d, (double) 3, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("#-1#");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        int[] intArray1 = new int[] { '4' };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', (int) (byte) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52" + "'", str3.equals("52"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100#-1#10", (int) (byte) 100, "4444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#-1#104444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("100#-1#104444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) ".:4v4j/bil/rsu/:snoisnetxe/4v4j/yr4rbil/metsys/:snoisnetxe/4v4j/yr4rbil/krowten/:snoisnetxe/4v4j/yr4rbil/:snoisnetxe/4v4j/yr4rbil/eihpos/sresu/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 143 + "'", int1 == 143);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "R...", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJOB" + "'", str1.equals("SUN.LWAWT.MACOSX.CPRINTERJOB"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 1, (int) (short) 0, 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Use#-1#10", "51.", "SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Use#-1#10" + "'", str3.equals("/Use#-1#10"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0 -1 1 -1 -1", 23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa###############################/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa###############################/" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa###############################/"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        java.lang.CharSequence charSequence4 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray9 = new char[] { 'a', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence5, charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.6", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                    ", (int) (short) -1, "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                    " + "'", str3.equals("                    "));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("     0#-1#1#-1#-1           ", "1a1", "100#-1#104444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("xtensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:", (int) (short) 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "xtensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:" + "'", str3.equals("xtensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "51.0#");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "51.0#" + "'", charSequence2.equals("51.0#"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("-1 1 10 1 10 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 1 10 1 10 100" + "'", str1.equals("-1 1 10 1 10 100"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1a", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        1a" + "'", str2.equals("        1a"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "10.14.3", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("100a1a-1a1", "100#-1#104444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a1a-1a1" + "'", str2.equals("100a1a-1a1"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) ".R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...", (java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) (byte) 100, 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', 22, 10);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Users/sophie/Documents/defectsj/tmp/run_r7ndoop.pl_51595_1560278762", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa###############################/", "100a1a-1a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_r7ndoop.pl_51595_1560278762" + "'", str3.equals("/Users/sophie/Documents/defectsj/tmp/run_r7ndoop.pl_51595_1560278762"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.7.0_80-b15", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                             794471                                              ", 5, "/Users/sophie/Documents/defectsj/tmp/run_r7ndoop.pl_51595_1560278762");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                             794471                                              " + "'", str3.equals("                                             794471                                              "));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "04-1414-14-1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("               sophie               ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               sophie               " + "'", str2.equals("               sophie               "));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 24, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MV revreS tiB-46 )MT(topStoH avaJ" + "'", str1.equals("MV revreS tiB-46 )MT(topStoH avaJ"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444444444444444444444444444", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51595_1560278762", "");
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray3, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "US" + "'", str5.equals("US"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a1" + "'", str1.equals("1a1"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0a-1a1a...wawt.macosx.CP", ".:4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a-1a1a...wawt.macosx.CP" + "'", str2.equals("0a-1a1a...wawt.macosx.CP"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("100a1a-1a1", ".R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...", "        1a", (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100a1a-1a1" + "'", str4.equals("100a1a-1a1"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("0 -1 1 -1 -1", "http:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 -1 1 -1 -1" + "'", str2.equals("0 -1 1 -1 -1"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java Platform API Specification", 174);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                               sophie                                     ...");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.851.821.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("               sophie               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:" + "'", str2.equals("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "##4#4#a##", (java.lang.CharSequence) "04-1414-14-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie", "                                                                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("100414-141", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00414-141" + "'", str2.equals("00414-141"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "Mac OS Xen                                                  ", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) ".", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRAC", "US", "class [Ljava.lang.Object;class [Ljava.lang.String;class [Bclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRAC" + "'", str3.equals("1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRAC"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/", (int) (byte) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/" + "'", str3.equals("###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("0a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        float[] floatArray6 = new float[] { 0.0f, 0.0f, 100.0f, (short) 100, 1, 0L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str8.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str10.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("MV revreS tiB-46 )MT(topStoH avaJUTF-8", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "a#4#a##", (java.lang.CharSequence) "US", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100" + "'", str2.equals("1A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Corporation", (int) (short) 100, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("Oracle Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("a44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a44" + "'", str1.equals("a44"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51595_1560278762");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1                                                    ", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1                                                    " + "'", str3.equals("1                                                    "));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "...R");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween(".R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...", ".", "###############################/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0 1 100 -1e", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" ###################################################", '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("######################", 'a');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.851.821.8", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 52 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("3", 93);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3" + "'", str2.equals("3"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "a44", (java.lang.CharSequence) " ", 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sun.awt.CGraphicsEnvironment", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        long[] longArray6 = new long[] { (short) -1, (short) 1, 10, 1L, (short) 10, 100L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(3, (int) (short) 0, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("########", "...R", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "########" + "'", str3.equals("########"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "51.051.053", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                en                                                  ", (java.lang.CharSequence) "                                               sophie                                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRAC");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ".:4v4j/bil/rsu/:snoisnetxe/4v4j/yr4rbil/metsys/:snoisnetxe/4v4j/yr4rbil/krowten/:snoisnetxe/4v4j/yr4rbil/:snoisnetxe/4v4j/yr4rbil/eihpos/sresu/", 214, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "04-1414-14-1", "4444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("0a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-1", "Java(TM) SE Runtime Environmen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-1" + "'", str2.equals("0a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-1"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("0 1 100 -1e");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 1 100 -1e" + "'", str1.equals("0 1 100 -1e"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("R...aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0a-1a1a...", 93);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Oracle Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "####################");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 23, 0.0f, (float) 5L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.51.51.51.51.51.51.51.51.51.", "100414-141");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("04141004-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "04141004-1" + "'", str1.equals("04141004-1"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R..", 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("                                                    ", "###############################/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############################/" + "'", str2.equals("###############################/"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("0a-1a1a...", "SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a-1a1a..." + "'", str2.equals("0a-1a1a..."));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0", (java.lang.CharSequence) "un.lwawt.macosx.CPrinterJob51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100414-141", "                                                                                            Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0, "noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("hie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "MV revreS ", "0#-1#1#-1#-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '#', 27, (int) (byte) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("oR...", 10, "a#4#a##");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a#4#aoR..." + "'", str3.equals("a#4#aoR..."));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("################################################51.0################################################", "#-1#10");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray2, strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.Class<?> wildcardClass8 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0", (java.lang.CharSequence) "3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("100.0 -1.0 100.0 0.0 52.0");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', 24, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 24");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("               sophie               ", "1a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        float[] floatArray6 = new float[] { 0.0f, 0.0f, 100.0f, (short) 100, 1, 0L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#', 33, 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4', 214, 97);
        float float20 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', 0, (int) (byte) 0);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str8.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str11.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 100.0f + "'", float20 == 100.0f);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("51.0#", "-1 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0#" + "'", str2.equals("51.0#"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("#-1#10", "0 1 100 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#-1#10" + "'", str2.equals("#-1#10"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("     0#-1#1#-1#-1           ", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     0#-1#1#-1#-1           " + "'", str2.equals("     0#-1#1#-1#-1           "));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase(".R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R..." + "'", str1.equals(".R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R..."));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 174L, (float) 97, (float) 143);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 174.0f + "'", float3 == 174.0f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "10A1A1A10A100", (java.lang.CharSequence) "     0#-1#1#-1#-1           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  ", (java.lang.CharSequence) "174110.0551.052");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1440 + "'", int2 == 1440);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "01100-1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3" + "'", str1.equals("3"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Lihie/Lib", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Lihie/Lib" + "'", str2.equals("/Lihie/Lib"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "1.4", 22);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("1.8", 'a');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "8.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("hi!", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("0a-1a1a-1a-1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("....................................................");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...................................................." + "'", str1.equals("...................................................."));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        " + "'", str2.equals("        "));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                en                                                  ", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                en                                                  " + "'", str2.equals("                                                en                                                  "));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        short[] shortArray4 = new short[] { (short) 100, (byte) 1, (byte) -1, (byte) 1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#', (int) (short) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a1a-1a1" + "'", str9.equals("100a1a-1a1"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 93);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("################################################51.0################################################", "", 0);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "52", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ' ', 0, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "################################################51.0################################################" + "'", str11.equals("################################################51.0################################################"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "3", (java.lang.CharSequence) "                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("794471", 174, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library794471" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library794471"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("http:", (double) 214);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 214.0d + "'", double2 == 214.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaa", (java.lang.CharSequence) ".");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRAC", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("US", 35, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444US44444444444444444" + "'", str3.equals("4444444444444444US44444444444444444"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("MV revreS");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0", (java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 800 + "'", int2 == 800);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        char[] charArray1 = new char[] {};
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Platform API Specification", charArray1);
        java.lang.Class<?> wildcardClass3 = charArray1.getClass();
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100414-141", "en                                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "a#4#a##");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "a 4 a #", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "a#4#a##", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("                      51.51.5hi!", "                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      51.51.5hi!" + "'", str2.equals("                      51.51.5hi!"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "oR...", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charSequence1, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("           0#-1#1#-1#-1            ", "#", 100);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                    ", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                    " + "'", str2.equals("                    "));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        int[] intArray1 = new int[] { '4' };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 0, (int) (short) 1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52" + "'", str3.equals("52"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52" + "'", str8.equals("52"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa###############################/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("########################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "########################" + "'", str1.equals("########################"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                en                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("MV revreS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MV revreS" + "'", str1.equals("MV revreS"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.8");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.6", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("174497", "Oracle Corporation", "1a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "174497" + "'", str3.equals("174497"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10a1a1a10a100", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0.0 0.0 100.0 100.0 1.0 0.0", 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 214, 0L, (long) 20);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.851.821.8", "141004100410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.851.821.8" + "'", str2.equals("1.851.821.8"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51595_1560278762");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "32.043.04-1.04100.0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a#4#aoR...", (java.lang.CharSequence) "1.8", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10a100a1a10a10a0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                                                             ", "                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "a#4#a##", "##########");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("     0#-1#1#-1#-1           ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1           #-1#1#-1#     0" + "'", str2.equals("-1           #-1#1#-1#     0"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a100" + "'", str1.equals("1a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a100"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("0 1 100 -1", 27, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("01100-1", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp(".");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "." + "'", str1.equals("."));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (-1L), (float) (byte) 100, (float) 3L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 10, (byte) 0, (byte) 1, (byte) 100, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 27, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 27");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("174497");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sun.lwawt.macosx.LWCToolkit", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.7", "R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aa51.51.51.51.51.51.51.51.51.51.R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR", "1.7.0_80-b15");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("##########");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#########\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Usrs/sph/Dcunts/fcts4j/tp/run_ranp.pl_51595_1560278762", ".R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...", "10a1a1a10a100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Usrs/sph/Dcunts/fcts4j/tp/run_ranp.pl_51595_1560278762" + "'", str3.equals("/Usrs/sph/Dcunts/fcts4j/tp/run_ranp.pl_51595_1560278762"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("100414-141");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100414-141" + "'", str1.equals("100414-141"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(".:4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".:4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/" + "'", str2.equals(".:4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1a1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "                    ", (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1004-1410", "0a1a0a1a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "hie", (java.lang.CharSequence) "####################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("4", 163);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                 4                                                                                 " + "'", str2.equals("                                                                                 4                                                                                 "));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(" R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R..", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R.." + "'", str2.equals(" R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R.."));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("0#1#100#-1", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJ", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "R...", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "sun.lwawt.macosx.LWCToolkit", "####################################################################################################");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1a1", 0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("....................................................", (int) (short) 1, "1A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...................................................." + "'", str3.equals("...................................................."));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("####################");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("####################################################################################################", 24, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########################################################################" + "'", str3.equals("#########################################################################"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:.", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/..." + "'", str2.equals("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/..."));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:." + "'", str1.equals("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:."));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("0 -1 1 -1 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 -1 1 -1 -1" + "'", str1.equals("0 -1 1 -1 -1"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("0a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-1", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a-1a1a..." + "'", str2.equals("0a-1a1a..."));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa###############################/", 0, "                                               sophie                                               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa###############################/" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa###############################/"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJUTF-8", 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:.", 100, 33);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("#########################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("MV revreS tiB-46 )MT(topStoH avaJ");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("oR...", strArray2, strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "oR..." + "'", str4.equals("oR..."));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("-1           #-1#1#-1#     0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#-1#10", (java.lang.CharSequence) "100a1a-1a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "http:", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("8.1", "Java Virtual Machine Specification", "100a1a-1a1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "US", (int) (byte) 100);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.4", (java.lang.CharSequence[]) strArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "US", (java.lang.CharSequence[]) strArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1004-1410", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) " ", (java.lang.CharSequence) "04141004-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "en                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "java Platform API Specification", (int) (short) -1);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "   #    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                ", (int) (byte) 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                " + "'", str3.equals("                                "));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("8.1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("UTF8", (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("################################################51.0################################################", '4');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "100414-141", 8, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Use#-1#10", "oR...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "un.lwawt.macosx.CPrinterJob51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("0a1a0a1a1", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 0a1a0a1a1" + "'", str2.equals(" 0a1a0a1a1"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0100.0 -1.0", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R..", 0, 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sop", 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sop" + "'", str3.equals("/Users/sop"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0a1a0a1a1", 143);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("un.lwawt.macosx.CPrinterJob", "51.51.5hi!", "51.");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1                                                    ", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) 100, (byte) 100, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "44444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 44444444444444444444444444444444");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "141004100410" + "'", str7.equals("141004100410"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "", "10A1A1A10A100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 33);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "           0#-1#1#-1#-1            ", (java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaa", (java.lang.CharSequence) "10a100a1a10a10a0", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "-1 1 10 1 10 100", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (java.lang.CharSequence) "     0#-1#1#-1#-1           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) -1, 0, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                                    ", 100);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("100.0 -1.0 100.0 0.0 52.0100.0 -1.0", "http:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0 -1.0 100.0 0.0 52.0100.0 -1.0" + "'", str2.equals("100.0 -1.0 100.0 0.0 52.0100.0 -1.0"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0#-1#1#-1#-1", "100#-1#104444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10a100a1a10a10a0", (java.lang.CharSequence) "                                               sophie                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (java.lang.CharSequence) "Java(TM) SE Runtime Environmen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.851.821.8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#-1#10", "wawt.macosx.CPrinterJob", (int) (short) 100);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "a#4#aoR...", 2, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "a#4#aoR...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) ".:4v4j/bil/rsu/:snoisnetxe/4v4j/yr4rbil/metsys/:snoisnetxe/4v4j/yr4rbil/krowten/:snoisnetxe/4v4j/yr4rbil/:snoisnetxe/4v4j/yr4rbil/eihpos/sresu/p/run_r7ndoop.pl_51595_1560278762", (java.lang.CharSequence) "/Usrs/sph/Dcunts/fcts4j/tp/run_ranp.pl_51595_1560278762");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: hi! is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                               sophie                                     ...", (java.lang.CharSequence) "10a100a1a10a10a0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                    ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("01100-1", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("a#4#aoR...", "", 174);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "794471", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "                                               sophie                                     ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                           ", 214, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("3", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http:", (java.lang.CharSequence) "                                                                                             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "141a1.0a10a1004-14", (java.lang.CharSequence) "###############################/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "141a1.0a10a1004-14" + "'", charSequence2.equals("141a1.0a10a1004-14"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("#", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("-1#1#10#1#10#100", 163);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#1#10#1#10#100" + "'", str2.equals("-1#1#10#1#10#100"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        long[] longArray2 = new long[] { (-1), (byte) 1 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 'a', (float) '#', (float) 11);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("174497");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "174497" + "'", str1.equals("174497"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mode mixed", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) '4');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "####################################################################################################", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51595_1560278762/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("5\n.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5\n." + "'", str1.equals("5\n."));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 1440);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("01100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-1", (long) 24);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24L + "'", long2 == 24L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("100.0a-1.0a100.0a0.0a52.0", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0a100.0a0.0a52.0" + "'", str2.equals("-1.0a100.0a0.0a52.0"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aa51.51.51.51.51.51.51.51.51.51.R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR", (java.lang.CharSequence) "04141004-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "04-1414-14-1", (java.lang.CharSequence) "-1           #-1#1#-1#     0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0", (java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1.0f), (double) 3L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.6", "                                                                                                   #");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("100#-1#104444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#-1#104444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("100#-1#104444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("               sophie               ", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               sophie               " + "'", str2.equals("               sophie               "));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie", "0a-1a1a-1a-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("#", 3, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100L, (float) 24, (float) 7);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, 13, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "-1 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.7f + "'", float1 == 1.7f);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("10a100a1a10a10a0", (int) (byte) -1, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a100a1a..." + "'", str3.equals("10a100a1a..."));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "141004100410", (java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java(TM) SE Runtime Environmen", "MV REVRES", "               sophie               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environmen" + "'", str3.equals("Java(TM) SE Runtime Environmen"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51595_1560278762");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("class [Ljava.lang.Object;aclass [Ljava.lang.String;aclass [Baclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7.0_80-b15", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1a1.0a10a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a1.0a10a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sophie", "1.7.0_80-b15", 8);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.0", "hie", 22);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("########################", strArray5, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sop", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "########################" + "'", str10.equals("########################"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10a100a1a10a10a0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("class [Ljava.lang.Object;class [Ljava.lang.String;class [Bclass [Ljava.lang.String;", (int) ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.Object;class [Ljava.lang.String;class [Bclass [Ljava.lang.String;" + "'", str3.equals("class [Ljava.lang.Object;class [Ljava.lang.String;class [Bclass [Ljava.lang.String;"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "##4#4#a##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/...", (java.lang.CharSequence) "                                               sophie                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Platform API Specification", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "################################################51.0################################################", charArray3);
        java.lang.Class<?> wildcardClass6 = charArray3.getClass();
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        short[] shortArray4 = new short[] { (short) 0, (byte) 1, (short) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', (int) (short) 10, 214);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 1 100 -1" + "'", str8.equals("0 1 100 -1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0#1#100#-1" + "'", str11.equals("0#1#100#-1"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "32.043.04-1.04100.0", (java.lang.CharSequence) "04-1414-14-1", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("141004100410");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 10, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        float[] floatArray1 = new float[] { 100.0f };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4', (int) '4', (int) '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0" + "'", str10.equals("100.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1           #-1#1#-1#     0", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.8", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "a44", (java.lang.CharSequence) "#-1#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("5\n.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".\n5" + "'", str1.equals(".\n5"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", charSequence2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        short[] shortArray5 = new short[] { (short) 0, (short) -1, (short) 1, (short) -1, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 52, 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', (int) (byte) 100, 8);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0#-1#1#-1#-1" + "'", str8.equals("0#-1#1#-1#-1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0 -1 1 -1 -1" + "'", str11.equals("0 -1 1 -1 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "################################################51.0################################################", (java.lang.CharSequence) "0#1#0#1#1", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("   #    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                               sophie                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Java(TM) SE Runtime Environmen");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("100.0 -1.0 100.0 0.0 52.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library794471");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library794471\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 174, 28.0d, (double) 22L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 22.0d + "'", double3 == 22.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java(TM) SE Runtime Environment", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                en                                                  ", ".");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Oracle Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a100", (java.lang.CharSequence) "\n", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJUTF-8", (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        float[] floatArray1 = new float[] { 100.0f };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4', (int) '4', (int) '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0" + "'", str10.equals("100.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.0" + "'", str13.equals("100.0"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("32.043.04-1.04100.0", "01100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.043.04-1.04100.0" + "'", str2.equals("32.043.04-1.04100.0"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sop", 33, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) -1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1004-1410", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1004-1410" + "'", str2.equals("1004-1410"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "04-1414-14-1", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("###############################/", "UTF8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############################/" + "'", str2.equals("###############################/"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 0, 4.4444447E9f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.4444447E9f + "'", float3 == 4.4444447E9f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        float[] floatArray6 = new float[] { 0.0f, 0.0f, 100.0f, (short) 100, 1, 0L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#', 0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str8.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str11.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) (byte) 100, 0);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte18 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 1 + "'", byte15 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 1 + "'", byte16 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 0 + "'", byte17 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) 0 + "'", byte18 == (byte) 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("51.", (float) 163);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 51.0f + "'", float2 == 51.0f);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("a 4 a #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a 4 a #\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10a1a1a10a100", (java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaPlatformAPISpecification" + "'", str1.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10a1a1a10a100", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library794471");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library794471" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library794471"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "52", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                                    ", " R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library794471");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("################################################51.0################################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("######################");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "MV revreS tiB-46 )MT(topStoH avaJUTF-8");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa###############################/", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "     0#-1#1#-1#-1           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("100414-141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/", (java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0 1 100 -1e", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "     0#-1#1#-1#-1           ", (java.lang.CharSequence) "                                                                                             ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "     0#-1#1#-1#-1           " + "'", charSequence2.equals("     0#-1#1#-1#-1           "));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "oRACLE cORPORATION", (java.lang.CharSequence) "4444444444444444US44444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "10a1a1a10a100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Mac OS Xen                                                  ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("a 4 a #");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4", (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("               sophie               ", "sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                               sophie                                     ...", (java.lang.CharSequence) "1.7", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.6", 7, 20);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.6" + "'", str3.equals("1.6"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("hie", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    hie     " + "'", str2.equals("    hie     "));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.CPrinterJob", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        double[][][] doubleArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(doubleArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "en                                                  ", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "           0#-1#1#-1#-1            ", ".\n5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0" + "'", str1.equals("100.0"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("\n", "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:", "Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  ", 7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\n" + "'", str4.equals("\n"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "100 1 -1 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "100 1 -1 1", (java.lang.CharSequence) "1.6", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) (byte) 100, 0);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', 0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 1 + "'", byte15 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 1 + "'", byte16 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 0 + "'", byte17 == (byte) 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0100.0 -1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger(".");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100.0", 22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("100.0 -1.0 100.0 0.0 52.0100.0 -1.0", "1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0 -1.0 100.0 0.0 52.0100.0 -1.0" + "'", str2.equals("100.0 -1.0 100.0 0.0 52.0100.0 -1.0"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1a1", (java.lang.CharSequence) "UTF8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "0#1#0#1#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("141004100410", (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.41004095E11f + "'", float2 == 1.41004095E11f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...R", "1a", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "                                                                                             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100.0", (java.lang.CharSequence) "/Use#-1#10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("MV REVRES", 20, "0.0 0.0 100.0 100.0 1.0 0.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0 0.0 100MV REVRES" + "'", str3.equals("0.0 0.0 100MV REVRES"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "3", (java.lang.CharSequence) "                                               sophie                                     ...", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/...", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("44444444444444444444444444444444", 800, "##4#4#a##");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####444444444444444444444444444444444" + "'", str3.equals("##4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####444444444444444444444444444444444"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0a-1a1a...wawt.macosx.CP", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "10a100a1a...", (java.lang.CharSequence) "1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRAC", 174);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "oR...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1                                                    ", "/Users/sop", "hi!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                      51.51.5hi!", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0#1#100#-1", "51.51.5hi!");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("51.0#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0#" + "'", str1.equals("51.0#"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0#1#100#-1", "wawt.macosx.CPrinterJob", 163);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("               sophie               ", 800);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               sophie               " + "'", str2.equals("               sophie               "));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("################################################51.0################################################", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################################51.0################################################" + "'", str2.equals("################################################51.0################################################"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.3", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("        1a", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "a#4#aoR...", "04141004-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100#-1#104444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("R...", "                                                en                                                  ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "en", (java.lang.CharSequence) "174#97");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100414-141", "########", 27);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("##########", "##########", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "en                                                  ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("mode mixed", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "100414-141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        long[] longArray6 = new long[] { (short) -1, (short) 1, 10, 1L, (short) 10, 100L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.Class<?> wildcardClass8 = longArray6.getClass();
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        java.lang.Class<?> wildcardClass12 = strArray11.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray13 = new java.lang.reflect.GenericDeclaration[] { wildcardClass8, wildcardClass12 };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray13);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(genericDeclarationArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "class [Jclass [Ljava.lang.String;" + "'", str14.equals("class [Jclass [Ljava.lang.String;"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10a100a1a10a10a0", "en                                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("5\n.", "class [Jclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 1a is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("0a-1a1a...wawt.macosx.CP", "mixed mode", "UTF8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a-1a1a...wawt.macosx.CP" + "'", str3.equals("0a-1a1a...wawt.macosx.CP"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.3", (java.lang.CharSequence) "##4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10a1a1a10a100", "0a-1a1a...wawt.macosx.CP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "   #    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("100.0#-1.0#100.0#0.0#52.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hie", "   #    ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "##4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("0a-1a1a...wawt.macosx.CP", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a-1a1a...wawt.macosx.CP" + "'", str2.equals("0a-1a1a...wawt.macosx.CP"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Lihie/Lib", "/Users/sophie");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100a1a-1a1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:.", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:." + "'", str2.equals("sions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:."));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("R...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "R..." + "'", str1.equals("R..."));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("a44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A44" + "'", str1.equals("A44"));
    }
}

