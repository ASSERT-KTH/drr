import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("    hie     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10a100a1a10a10a0", (java.lang.CharSequence) "10 100 1 10 10 0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sun.lwawt.macosx.cprinterjob", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.mac" + "'", str2.equals("sun.lwawt.mac"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "04...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#javaplatformapispecifica#####################################################################", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "8.1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        double[] doubleArray5 = new double[] { 100.0f, (-1L), (byte) 100, (short) 0, 52 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 -1.0 100.0 0.0 52.0" + "'", str7.equals("100.0 -1.0 100.0 0.0 52.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0a-1.0a100.0a0.0a52.0" + "'", str9.equals("100.0a-1.0a100.0a0.0a52.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0 -1.0 100.0 0.0 52.0" + "'", str11.equals("100.0 -1.0 100.0 0.0 52.0"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("MV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVR", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "R" + "'", str2.equals("R"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/", (java.lang.CharSequence) "Server VM", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("           0#-1#1#-1#-1            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"           0#-1#1#-1#-1            \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.0", "hie", 22);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "0#-1#1#-1#-1");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "hie");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "51.0" + "'", str5.equals("51.0"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "51.0" + "'", str8.equals("51.0"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a100", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.7f, (float) 12, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.51.51.51.51.51.51.51.51.51.", "");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 93, 174);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 93");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("rsed", "32#0#3#0#-##0##00#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rsed" + "'", str2.equals("rsed"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("0 1 100 -1            ", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 1 100 -1            " + "'", str2.equals("0 1 100 -1            "));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRA", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRA" + "'", str2.equals("1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRA"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 5, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "###################################", (java.lang.CharSequence) "/Lihie/Lib");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJUTF-8              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java Platform API Specification" + "'", str1.equals("java Platform API Specification"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ".3", (java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "MV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRES");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) (byte) 100, 0);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 97, 1);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 1 + "'", byte15 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray5 = new char[] { 'a', '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 20, 10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, '4');
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.9", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "a44" + "'", str13.equals("a44"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#-1#10");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) ":", (java.lang.CharSequence) "##");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 7, 10L, (long) 7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "141004100410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("  #04141004-1  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#04141004-1" + "'", str1.equals("#04141004-1"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("174497.3", "", 800, 23);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "174497.3" + "'", str4.equals("174497.3"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 10, (byte) 1, (byte) 1, (byte) 0, (byte) -1 };
        byte[] byteArray13 = new byte[] { (byte) -1, (byte) 10, (byte) 1, (byte) 1, (byte) 0, (byte) -1 };
        byte[] byteArray20 = new byte[] { (byte) -1, (byte) 10, (byte) 1, (byte) 1, (byte) 0, (byte) -1 };
        byte[] byteArray27 = new byte[] { (byte) -1, (byte) 10, (byte) 1, (byte) 1, (byte) 0, (byte) -1 };
        byte[] byteArray34 = new byte[] { (byte) -1, (byte) 10, (byte) 1, (byte) 1, (byte) 0, (byte) -1 };
        byte[] byteArray41 = new byte[] { (byte) -1, (byte) 10, (byte) 1, (byte) 1, (byte) 0, (byte) -1 };
        byte[][] byteArray42 = new byte[][] { byteArray6, byteArray13, byteArray20, byteArray27, byteArray34, byteArray41 };
        byte[][][] byteArray43 = new byte[][][] { byteArray42 };
        java.lang.String str44 = org.apache.commons.lang3.StringUtils.join(byteArray43);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertNotNull(byteArray43);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("100.0 -1.0 100.0 0.0 52.0100.0 -1.0", "                                                                                             ", "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0 -1.0 100.0 0.0 52.0100.0 -1.0" + "'", str3.equals("100.0 -1.0 100.0 0.0 52.0100.0 -1.0"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100#-1#104444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Exten");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "32.043.04-1.04100.0", (java.lang.CharSequence) "141a1.0a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java V rtual Mach n  Sp c f cat  n", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("#-1#1#######################-1#1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        int[] intArray1 = new int[] { '4' };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 0, (int) (short) 1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', 20, (int) (short) 0);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52" + "'", str3.equals("52"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52" + "'", str8.equals("52"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100414-141", "################################################51.0################################################");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4" + "'", str4.equals("4"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        float[] floatArray1 = new float[] { 100.0f };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', 163, 12);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("10a1a1a10a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10a1a1a10a100" + "'", str1.equals("10a1a1a10a100"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("oRACLE cORPORATION", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE cORPORATION" + "'", str2.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("        1A");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "        1A" + "'", str1.equals("        1A"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("     http:", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("51.51.5hi!", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.51.5hi!" + "'", str2.equals("51.51.5hi!"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("     174497");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "174497" + "'", str1.equals("174497"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "PrinterJob", (java.lang.CharSequence) "....R.....", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        short[] shortArray4 = new short[] { (short) 100, (byte) 1, (byte) -1, (byte) 1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a1a-1a1" + "'", str9.equals("100a1a-1a1"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "                                                en                                                  ", (java.lang.CharSequence) "                      51.51.5HI!");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                en                                                  " + "'", charSequence2.equals("                                                en                                                  "));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "100a1a-1a1", (java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("04141004-1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                                                                                                                     0#1#100#-1", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                     0#1#100#-1" + "'", str2.equals("                                                                                                                                     0#1#100#-1"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.CharSequence charSequence4 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray9 = new char[] { 'a', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence5, charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("-1 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.051.053", "#-1#1#######################-1#1", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "100#-1#10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("        1A", 143, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        1A" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        1A"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("04...", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04..." + "'", str2.equals("04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04..."));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("####################################################################################################", "####################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "-1 1 10 1 10 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "100 1 -1 1", (java.lang.CharSequence[]) strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "     0#-1#1#-1#-1           ", 8, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                                 4                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/...", (int) (byte) 0, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("javaplatformapispecifica", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        1A");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "javaplatformapispecifica" + "'", str2.equals("javaplatformapispecifica"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("4444444444444444US44444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444US4444444444444444" + "'", str1.equals("4444444444444444US4444444444444444"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                                ##", (java.lang.CharSequence) "oR...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-141410414104100", (java.lang.CharSequence) "aa#a a#a4aa", 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "141a1.0a10", (java.lang.CharSequence) "sions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("100.0 -1", 98);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0 -1                                                                                          " + "'", str2.equals("100.0 -1                                                                                          "));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "1.851.821.8", (int) (short) 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JavaPlatformAPISpecifica", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "mixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("R", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        double[] doubleArray5 = new double[] { 100.0f, (-1L), (byte) 100, (short) 0, 52 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 5, (int) (short) 0);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double15 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double16 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 -1.0 100.0 0.0 52.0" + "'", str7.equals("100.0 -1.0 100.0 0.0 52.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100.0#-1.0#100.0#0.0#52.0" + "'", str14.equals("100.0#-1.0#100.0#0.0#52.0"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        float[] floatArray1 = new float[] { 100.0f };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', 15, 13);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0" + "'", str7.equals("100.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("R...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "r..." + "'", str1.equals("r..."));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                                                            Mac OS X", "174#97", 794471);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        short[] shortArray4 = new short[] { (short) 100, (byte) 1, (byte) -1, (byte) 1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100 1 -1 1" + "'", str10.equals("100 1 -1 1"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("32.0#3.0#-1.0#100.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("#################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "141a1.0a10a1004-14");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18 + "'", int1 == 18);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("100#-1#10", '4');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "44444444444444444444444444444444", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("#JAVAPLATFORMAPISPECIFICA#####################################################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa###############################/", (java.lang.CharSequence) "###########################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73 + "'", int2 == 73);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "en                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRA", 794471, 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/USERS/SOPHIE/LIBR4RY/J4V4/EXTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:.", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0 1 100 -1e", "1.7.0_80", (int) 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0 1 100 -1e" + "'", str5.equals("0 1 100 -1e"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "3", (java.lang.CharSequence) "100.0 -1                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        double[] doubleArray4 = new double[] { ' ', 3, (byte) -1, (short) 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32.0 3.0 -1.0 100.0" + "'", str10.equals("32.0 3.0 -1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "32.043.04-1.04100.0" + "'", str12.equals("32.043.04-1.04100.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "04141004-1", "                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        java.lang.CharSequence charSequence4 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray9 = new char[] { 'a', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence5, charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 4 a #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "0a1a0a1a1", 800);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "R...aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        int[] intArray1 = new int[] { '4' };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52" + "'", str3.equals("52"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52" + "'", str6.equals("52"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "52" + "'", str11.equals("52"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("        1A", "0", ".:4v4j/bil/rsu/:snoisnetxe/4v4j/yr4rbil/metsys/:snoisnetxe/4v4j/yr4rbil/krowten/:snoisnetxe/4v4j/yr4rbil/:snoisnetxe/4v4j/yr4rbil/eihpos/sresu/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "        1A" + "'", str3.equals("        1A"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "0#-1#1#-1#-1", (int) (byte) 10);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("51.", 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Oracle Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str8.equals("Oracle Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("java Platform API Specification", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle Corporation", "1a1");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "US", (int) (byte) 100);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "#");
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "US", (int) (byte) 100);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray16, "#");
        int int19 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray16);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray9, strArray16);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Mac OS X", strArray3, strArray9);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str20.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Mac OS X" + "'", str21.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("  #04141004-1  ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("wawt.macosx.CPrinterJob", 9, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-1           #-1#1#-1#     0", charSequence1, 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        char[] charArray10 = new char[] { 'a', '4', 'a', '#' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100#-1#10", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmna_v31cq2n2x1nafc0000gn/T/", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "141004100410", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("################################################51.0################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################################################51.0################################################" + "'", str1.equals("################################################51.0################################################"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1#1#10#1#10#100", (java.lang.CharSequence) "-1 1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "0 1 100 -1e");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        int[] intArray2 = new int[] { (short) -1, (-1) };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "################################################51.0################################################", (java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("100#3#24#163#1", (double) 174L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 174.0d + "'", double2 == 174.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("....................................................", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "..................................................." + "'", str2.equals("..................................................."));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(".", "", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern(".:4v4j/bil/rsu/:snoisnetxe/4v4j/yr4rbil/metsys/:snoisnetxe/4v4j/yr4rbil/krowten/:snoisnetxe/4v4j/yr4rbil/:snoisnetxe/4v4j/yr4rbil/eihpos/sresu/", "jav...", "100414-141");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".:4v4j/bil/rsu/:snoisnetxe/4v4j/yr4rbil/metsys/:snoisnetxe/4v4j/yr4rbil/krowten/:snoisnetxe/4v4j/yr4rbil/:snoisnetxe/4v4j/yr4rbil/eihpos/sresu/" + "'", str3.equals(".:4v4j/bil/rsu/:snoisnetxe/4v4j/yr4rbil/metsys/:snoisnetxe/4v4j/yr4rbil/krowten/:snoisnetxe/4v4j/yr4rbil/:snoisnetxe/4v4j/yr4rbil/eihpos/sresu/"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("a 4 a #", "10a100a1a...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a 4 a #" + "'", str2.equals("a 4 a #"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", ".:4v4j/bil/rsu/:snoisnetxe/4v4j/yr4rbil/metsys/:snoisnetxe/4v4j/yr4rbil/krowten/:snoisnetxe/4v4j/yr4rbil/:snoisnetxe/4v4j/yr4rbil/eihpos/sresu/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Platform API Specification", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "################################################51.0################################################", charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ".", charArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray3, '#');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("01100-", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("        1A", "aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        1A" + "'", str2.equals("        1A"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "a1a-1a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("class [Ljava.lang.Object;aclass [Ljava.lang.String;aclass [Baclass [Ljava.lang.String;", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.Object[] objArray4 = new java.lang.Object[] { 1, "1a1.0a10a100", (-1), "" };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(objArray4, '4', (-1), (-1));
        java.lang.Class<?> wildcardClass9 = objArray4.getClass();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) " #########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "R...aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "en", (java.lang.CharSequence) "0#-1#1#-1#-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "32#0#3#0#-##0##00#0", "########");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(10L, 0L, (long) 800);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 800L + "'", long3 == 800L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#-1#10####", "-1 1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#javaplatformapispecifica#####################################################################", 0, 794471);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        long[] longArray6 = new long[] { (short) -1, (short) 1, 10, 1L, (short) 10, 100L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', (int) ' ', 5);
        long long16 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1 1 10 1 10 100" + "'", str10.equals("-1 1 10 1 10 100"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("printerjo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "printerj" + "'", str1.equals("printerj"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "100 1 -1 ", 800);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1440, 6, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1440 + "'", int3 == 1440);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("A44", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A44" + "'", str2.equals("A44"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        float[] floatArray6 = new float[] { 0.0f, 0.0f, 100.0f, (short) 100, 1, 0L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4', 214, 143);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str8.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "PrinterJo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Exten", (java.lang.CharSequence) ":4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 214, "JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51" + "'", str3.equals("JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charSequence1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) (byte) 100, 0);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "10a1a1a10a100");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 10a1a1a10a100");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 1 + "'", byte15 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 0 + "'", byte16 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 0 + "'", byte17 == (byte) 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "MV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVR");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("4444444444", "/USERS/SOPHIE/LIBR4RY/J4V4/EXTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444" + "'", str2.equals("4444444444"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "UTF8", (java.lang.CharSequence) "MV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVR");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                    ", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0 1 100 -1            ");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "", 214, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                                                                                 4                                                                                 ", charSequence1, 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) ".....R...R...R...R...R...R..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                               sophie                                               ", "SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               sophie                                               " + "'", str2.equals("                                               sophie                                               "));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        java.lang.CharSequence charSequence4 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray9 = new char[] { 'a', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence5, charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0a-1a1a-1a-1", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4a#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        char[] charArray9 = new char[] { 'a', '4', 'a', '#' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100#-1#10", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JavaPlatformAPISpecification", charArray9);
        java.lang.Class<?> wildcardClass15 = charArray9.getClass();
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOB", 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Jav...                                                                                            ", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) ".:4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0#1#100#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#1#100#-1" + "'", str1.equals("0#1#100#-1"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#################################################################################################", (java.lang.CharSequence) "###########################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "A44");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("3");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 3 + "'", short1 == (short) 3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "rsed", (java.lang.CharSequence) "###############################/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "rsed" + "'", charSequence2.equals("rsed"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100414-141", "################################################51.0################################################");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44-4" + "'", str3.equals("44-4"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split(".............MV REVRES.............");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "   1744970.0     174497100.0     174497100.0     1744971.0     1744970.0", (java.lang.CharSequence) "1.4                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 140 + "'", int2 == 140);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oR...");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', (int) (short) 10, 9);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "32.0a3.0a-1.0a100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("10 100 1 10 10 ", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 100 1 10 10 " + "'", str2.equals("10 100 1 10 10 "));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("a 4 a #");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "-1 1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) " 0a1a0a1a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("en                                                  ", 93, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("en                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 5, (short) 7, (short) 4);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 7 + "'", short3 == (short) 7);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1a11a11a11aprinterjo", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1", "               sophie               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1" + "'", str2.equals("100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.8", "01100-1", 214);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray5 = new char[] { 'a', '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "32.0a3.0a-1.0a100.0", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04..." + "'", str1.equals("04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04..."));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-1 1 10 1 10 100", (java.lang.CharSequence) "100#3#24#163#1#####", 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("0#-1#1#-1#-1", "4444444444444444US4444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#-1#1#-1#-1" + "'", str2.equals("0#-1#1#-1#-1"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "PrinterJob", (java.lang.CharSequence) "100.0A-1.0A100.0A0.0A52.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Ex/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Ex");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "                                             794471                                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " ", 100, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("JavaPlatformAPISpecifica");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaPlatformAPISpecifica" + "'", str1.equals("JavaPlatformAPISpecifica"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("javaplatformapispecifica");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 142 + "'", int1 == 142);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "10a1a1a10a100", 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern(" ################################################### 100 1 10 10 0", "                      51.51.5hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " ################################################### 100 1 10 10 0" + "'", str2.equals(" ################################################### 100 1 10 10 0"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java Virtual Machine Specification", "0 1 100 -1            ", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "-1 1 10 1 10 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("141a1.0a10a1004-14");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("00414-141", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00414-141" + "'", str2.equals("00414-141"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-1           #-1#1#-1#     0", (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0 1 100 -1            ", "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Ex/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Ex");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) ":4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/", (java.lang.CharSequence) "Oracle ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.String str4 = javaVersion1.toString();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        boolean boolean8 = javaVersion1.atLeast(javaVersion6);
        java.lang.String str9 = javaVersion6.toString();
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.5" + "'", str9.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 174, 35);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4');
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 25, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 25");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0a1a0a1a1" + "'", str12.equals("0a1a0a1a1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "041404141" + "'", str18.equals("041404141"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("######################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "MV REVR");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "01100-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("44444444444444444444444444444444444444444", "/USERS/SOPHIE/LIBR4RY/J4V4/EXTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("en                                                  ", "Oracle ", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en                                                  " + "'", str3.equals("en                                                  "));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "a 4 a #", 27, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(8, 93, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "10A1A1A10A100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Documents/defectsj/tmp/run_r7ndoop.pl_51595_1560278762", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaa", 5, 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "100#-1#10", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        java.lang.Class<?> wildcardClass7 = javaVersion4.getClass();
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        java.lang.String str9 = javaVersion4.toString();
        boolean boolean10 = javaVersion1.atLeast(javaVersion4);
        java.lang.Class<?> wildcardClass11 = javaVersion1.getClass();
        java.lang.String str12 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9" + "'", str3.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.3" + "'", str9.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.9" + "'", str12.equals("0.9"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1#1#10#1#10#100", (java.lang.CharSequence) "aa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "...R");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob", (java.lang.CharSequence) "1.4                                                                                                                                                                ", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                                                             ", 93, 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("-1.0a100.0a0.0a52.0", "MV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVR", 174);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0a100.0a0.0a52.0" + "'", str3.equals("-1.0a100.0a0.0a52.0"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "01100-1", (java.lang.CharSequence) "#-1#1#######################-1#1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("...R", 18, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("#", "", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#" + "'", str3.equals("#"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        double[] doubleArray5 = new double[] { 100.0f, (-1L), (byte) 100, (short) 0, 52 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', (int) '#', 3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double15 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 98, (int) (short) 10);
        double double22 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 -1.0 100.0 0.0 52.0" + "'", str7.equals("100.0 -1.0 100.0 0.0 52.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100.0a-1.0a100.0a0.0a52.0" + "'", str14.equals("100.0a-1.0a100.0a0.0a52.0"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100.04-1.04100.040.0452.0" + "'", str17.equals("100.04-1.04100.040.0452.0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.0d) + "'", double22 == (-1.0d));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("0 1 0 1 1", "aa...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R.", "class [Ljava.lang.Object;aclass [Ljava.lang.String;aclass [Baclass [Ljava.lang.String;");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("-1 #-1#1#-1# 0", "0a-1a1a-1a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 #-1#1#-1# 0" + "'", str2.equals("-1 #-1#1#-1# 0"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        1A", ".:4v4j/bil/rsu/:snoisnetxe/4v4j/yr4rbil/metsys/:snoisnetxe/4v4j/yr4rbil/krowten/:snoisnetxe/4v4j/yr4rbil/:snoisnetxe/4v4j/yr4rbil/eihpos/sresu/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        1A" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        1A"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("#-1#10####");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#-1#10####\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("44444444444444444444444444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7", 28, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.74444444444444444444444444" + "'", str3.equals("1.74444444444444444444444444"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("#-1#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#-1#" + "'", str1.equals("#-1#"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "#-1#10####", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) (byte) 100, 0);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ');
        byte byte19 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 1 + "'", byte15 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 1 + "'", byte16 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0 1 0 1 1" + "'", str18.equals("0 1 0 1 1"));
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) 0 + "'", byte19 == (byte) 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                    \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "174497.3", (java.lang.CharSequence) "44-4", 1440);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.2", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "US", (int) (byte) 100);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jav...                                                                                            ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/", "52");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("  #04141004-1  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  #04141004-1  " + "'", str1.equals("  #04141004-1  "));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("51.0#", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0#" + "'", str2.equals("51.0#"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1                                                    ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("0 1 0 1 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 1 0 1 1" + "'", str1.equals("0 1 0 1 1"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("51.51.51.51.51.51.51.51.51.51.", "141004100410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.51.51.51.51.51.51.51.51.51." + "'", str2.equals("51.51.51.51.51.51.51.51.51.51."));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("               sophie               ", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Ex/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Ex", "1#-1#1#-1", "0141-40011.81.81.81.81.81.8");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("   #    ", "Oracle Corporation");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "#-1#1#######################-1#1", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 30 + "'", int4 == 30);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1           #-1#1#-1#     0", (java.lang.CharSequence) "..R...R..");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(".:4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "           0-11-1-1            ", (java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1/var/folders/_v/6v597zmna_v31cq2n2x1nafc0000gn/T/1.0/var/folders/_v/6v597zmna_v31cq2n2x1nafc0000gn/T/10/var/folders/_v/6v597zmna_v31cq2n2x1nafc0000gn/T/100");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1a1-a1a001");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100.0a-1.0a100.0a0.0a52.0", "8.1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("0 1 100 -1", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "51.51.5HI!", (java.lang.CharSequence) "100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        int[] intArray2 = new int[] { 174, 'a' };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', (int) (byte) 100, 22);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 174 + "'", int3 == 174);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "174#97" + "'", str9.equals("174#97"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 174 + "'", int11 == 174);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("MV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVR", (int) (short) 4, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVR" + "'", str3.equals("MV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVR"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "7", charSequence1, 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 6, 0L, 143L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                             ", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "100.0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("....r.........r.........r.........r.........r.........r.........r.........r.........r......r.........r.........r.........r.........r.........r.........r.........r.........r..", "174");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "....r.........r.........r.........r.........r.........r.........r.........r.........r......r.........r.........r.........r.........r.........r.........r.........r.........r.." + "'", str2.equals("....r.........r.........r.........r.........r.........r.........r.........r.........r......r.........r.........r.........r.........r.........r.........r.........r.........r.."));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(97.0d, (double) 10, (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-1 1 10 1 10 100", (java.lang.CharSequence) "MV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRES");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("MV revreS tiB-46 )MT(topStoH avaJ", 93, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMV revreS tiB-46 )MT(topStoH avaJaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMV revreS tiB-46 )MT(topStoH avaJaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                                en                                                  ", "100.04-1.04100.040.0452.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100#3#24#163#1#####", " R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R..", 13);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "x86_64", charSequence1, 1440);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        org.apache.commons.lang3.StringUtils stringUtils0 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils1 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils2 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils3 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils4 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils5 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils[] stringUtilsArray6 = new org.apache.commons.lang3.StringUtils[] { stringUtils0, stringUtils1, stringUtils2, stringUtils3, stringUtils4, stringUtils5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray6);
        org.junit.Assert.assertNotNull(stringUtilsArray6);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("un.lwawt.macosx.CPrinterJob");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "http:");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "0#1#0#1#1");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "un444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444lwaw444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444macosx444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444C444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Printer444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Job" + "'", str7.equals("un444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444lwaw444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444macosx444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444C444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Printer444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Job"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRA", "##4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRA" + "'", str2.equals("1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRA"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("printerj", 20L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("mode mixed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mode mixed" + "'", str1.equals("Mode mixed"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("141a1.0a10a1004-14", 3, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "141a1.0a10a1004-14" + "'", str3.equals("141a1.0a10a1004-14"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("US", "");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "###############################/");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0a1a0a1a1", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "MV REVR");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Oracle Corporatio", 214);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                     Oracle Corporatio" + "'", str2.equals("                                                                                                                                                                                                     Oracle Corporatio"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "r...", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(" ", "                        ", 3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1a1-a1a001");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        short[] shortArray5 = new short[] { (short) 0, (short) -1, (short) 1, (short) -1, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 25, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 25");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 -1 1 -1 -1" + "'", str8.equals("0 -1 1 -1 -1"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("####################################################################################################", "                                               sophie                                     ...", 12);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5);
        java.lang.String[] strArray7 = null;
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "####################################################################################################" + "'", str6.equals("####################################################################################################"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        long[] longArray4 = new long[] { 5, 52, (short) 1, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A1.0A10" + "'", str2.equals("A1.0A10"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "100#3#24#163#1#####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("0.0     1744970.0     174497100.0     174497100.0     1744971.0     1744970.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mode mixed", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "51.", (java.lang.CharSequence) "#########################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos" + "'", str1.equals("eihpos"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "        1a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaa", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa" + "'", str3.equals("aaaaaaaaaa"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("0a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-" + "'", str1.equals("0a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(35, 13, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        long[] longArray6 = new long[] { (short) -1, (short) 1, 10, 1L, (short) 10, 100L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', (int) (short) 4, 0);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-141410414104100" + "'", str12.equals("-141410414104100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("10a100a1a10a10a0", "10 100 1 10 10 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a100a1a10a10a0" + "'", str2.equals("10a100a1a10a10a0"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java V rtual Mach n  Sp c f cat  n", "2678720651_59515_lp.poodn7r_nur/p/users/sophie/libr4ry/j4v4/extensions:/libr4ry/j4v4/extensions:/network/libr4ry/j4v4/extensions:/system/libr4ry/j4v4/extensions:/usr/lib/j4v4:.", (int) (short) 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java V rtual Mach n  Sp c f cat  n2678720651_59515_lp.poodn7r_nur/p/users/sophie/libr4ry/j4v4/extensions:/libr4ry/j4v4/extensions:/network/libr4ry/j4v4/extensions:/system/libr4ry/j4v4/extensions:/usr/lib/j4v4:.Java V rtual Mach n  Sp c f cat  n2678720651_59515_lp.poodn7r_nur/p/users/sophie/libr4ry/j4v4/extensions:/libr4ry/j4v4/extensions:/network/libr4ry/j4v4/extensions:/system/libr4ry/j4v4/extensions:/usr/lib/j4v4:.Java V rtual Mach n  Sp c f cat  n" + "'", str3.equals("Java V rtual Mach n  Sp c f cat  n2678720651_59515_lp.poodn7r_nur/p/users/sophie/libr4ry/j4v4/extensions:/libr4ry/j4v4/extensions:/network/libr4ry/j4v4/extensions:/system/libr4ry/j4v4/extensions:/usr/lib/j4v4:.Java V rtual Mach n  Sp c f cat  n2678720651_59515_lp.poodn7r_nur/p/users/sophie/libr4ry/j4v4/extensions:/libr4ry/j4v4/extensions:/network/libr4ry/j4v4/extensions:/system/libr4ry/j4v4/extensions:/usr/lib/j4v4:.Java V rtual Mach n  Sp c f cat  n"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("1a1.0a10a100", "wawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a1.0a10a100" + "'", str2.equals("1a1.0a10a100"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 0, 0.0f, (float) 93);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 93.0f + "'", float3 == 93.0f);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "un.lwawt.macosx.CPrinterJob", (int) (short) 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("04141004-1", "1a", "class [Jclass [Ljava.lang.String;");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "51.051.053", (java.lang.CharSequence) "wawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("MV revreS");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "7", (java.lang.CharSequence) "jav...", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "0#-1#1#-1#-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        double[] doubleArray5 = new double[] { 100.0f, (-1L), (byte) 100, (short) 0, 52 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.Class<?> wildcardClass10 = doubleArray5.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 -1.0 100.0 0.0 52.0" + "'", str7.equals("100.0 -1.0 100.0 0.0 52.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0a-1.0a100.0a0.0a52.0" + "'", str9.equals("100.0a-1.0a100.0a0.0a52.0"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100.0#-1.0#100.0#0.0#52.0" + "'", str12.equals("100.0#-1.0#100.0#0.0#52.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100.0a-1.0a100.0a0.0a52.0" + "'", str14.equals("100.0a-1.0a100.0a0.0a52.0"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("A1.0A10");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4a#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4a#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4a#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("100a1a-1a1", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a1a-1a1" + "'", str2.equals("100a1a-1a1"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', 18, 4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0#1#0#1#1" + "'", str12.equals("0#1#0#1#1"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 1 + "'", byte14 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java Platform API Specification", "...................................................");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                      en                                                  ", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        " + "'", str2.equals("                        "));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("51.51.51.51.51.51.51.51.51.51.", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51595_1560278762/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) (byte) 100, 0);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 0, (int) (byte) -1);
        byte byte20 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 163, 8);
        byte byte25 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str27 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 1 + "'", byte15 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + byte20 + "' != '" + (byte) 0 + "'", byte20 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + byte25 + "' != '" + (byte) 1 + "'", byte25 == (byte) 1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "32.0#3.0#-1.0#100.0", 0, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("-141410414104100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-141410414104100" + "'", str1.equals("-141410414104100"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/...", (int) (short) -1, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/..." + "'", str3.equals("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/..."));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4a#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sun.lwawt.macosx.CPrinterJob", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1004-1410", "51.0#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1004-14" + "'", str2.equals("1004-14"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        char[] charArray10 = new char[] { 'a', '4', 'a', '#' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100#-1#10", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmna_v31cq2n2x1nafc0000gn/T/", charArray10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ');
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ".:4v4j/bil/rsu/:snoisnetxe/4v4j/yr4rbil/metsys/:snoisnetxe/4v4j/yr4rbil/krowten/:snoisnetxe/4v4j/yr4rbil/:snoisnetxe/4v4j/yr4rbil/eihpos/sresu/p/run_r7ndoop.pl_51595_1560278762", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "a 4 a #" + "'", str17.equals("a 4 a #"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10a100a1a10a10a0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10100110100" + "'", str2.equals("10100110100"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1a0a1a1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("51.51.51.51.51.51.51.51.51.51.", "##", "0.0 0.0 100MV REVRES");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("aa#a a#a4aa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                 Mac OS X", (java.lang.CharSequence) "                                                                                 4                                                                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray8 = new char[] { 'a', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny(charSequence4, charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                            Mac OS X", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                 4                                                                                 ", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "        ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 93 + "'", int12 == 93);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("#-1#", "7", 27);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "-1 1 10 1 10 100", 11, (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 794471, 99);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 1 + "'", byte12 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 1 + "'", byte13 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "041404141" + "'", str19.equals("041404141"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("      ", (int) (short) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "      " + "'", str3.equals("      "));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate(" ", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("R", "4444444444444444US4444444444444444", "0a1a0a1a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "R" + "'", str3.equals("R"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("oRACLE cORPORATION", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE cORPORATION" + "'", str2.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("100#3#24#163#1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#3#24#163#1" + "'", str1.equals("100#3#24#163#1"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0" + "'", charSequence2.equals("100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("01100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("rsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RSED" + "'", str1.equals("RSED"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("100.0", "1.8", "1.851.821.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("oR...", "        1a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        1a" + "'", str2.equals("        1a"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("174#97");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1004-1410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "100#3#24#163#1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10A1A1A10A100", (java.lang.CharSequence) "        1a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "MV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVR", charSequence1, 800);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "US", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("##4#4#a##", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##4#4#4##" + "'", str3.equals("##4#4#4##"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("00414-141");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "00414-141" + "'", str1.equals("00414-141"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("class [Jclass [Ljava.lang.String;", "                                                en                                                  ", (int) (short) 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("100414-141", '#');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        float[] floatArray6 = new float[] { 0.0f, 0.0f, 100.0f, (short) 100, 1, 0L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#', 33, 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4', 214, 97);
        float float20 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float21 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float22 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float23 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        try {
            java.lang.String str29 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#', (int) (byte) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str8.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str11.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 100.0f + "'", float20 == 100.0f);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 100.0f + "'", float23 == 100.0f);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0.0a0.0a100.0a100.0a1.0a0.0" + "'", str25.equals("0.0a0.0a100.0a100.0a1.0a0.0"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("00414-141", "#################################################################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) (byte) 100, 0);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "                                                                                                                                                                                                     Oracle Corporatio");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                                                                                                                                                                                      Oracle Corporatio");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 1 + "'", byte15 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 0 + "'", byte16 == (byte) 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 3, (long) 142, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1 1", "10 1 1 10 100", 174);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", "Server VM");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("##4#4#a##", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "##4#4#a##" + "'", str8.equals("##4#4#a##"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.7.0_80", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "        1A", "04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("04141004-1", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "04141004-1" + "'", str2.equals("04141004-1"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "-1           #-1#1#-1#     0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "-1 #-1#1#-1# 0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: -1 #-1#1#-1# 0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 1 + "'", byte12 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 1 + "'", byte13 == (byte) 1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "java Platform API Specification", "CRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "52", (java.lang.CharSequence) "###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/", 794471);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                 Mac OS X", (java.lang.CharSequence) "#javaplatformapispecifica#####################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("MV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VM" + "'", str1.equals("RVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VMRVER VM"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("-1#1#10#1#10#100", "sun.awt.CGraphicsEnvironment", "51.051.053");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        java.lang.String str8 = javaVersion6.toString();
        boolean boolean9 = javaVersion3.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean12 = javaVersion10.atLeast(javaVersion11);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean14 = javaVersion11.atLeast(javaVersion13);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean18 = javaVersion16.atLeast(javaVersion17);
        boolean boolean19 = javaVersion13.atLeast(javaVersion17);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean22 = javaVersion20.atLeast(javaVersion21);
        boolean boolean23 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion21);
        java.lang.String str24 = javaVersion21.toString();
        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion26 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean27 = javaVersion25.atLeast(javaVersion26);
        boolean boolean28 = javaVersion21.atLeast(javaVersion26);
        boolean boolean29 = javaVersion17.atLeast(javaVersion21);
        org.apache.commons.lang3.JavaVersion javaVersion30 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean31 = javaVersion21.atLeast(javaVersion30);
        boolean boolean32 = javaVersion3.atLeast(javaVersion21);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.9" + "'", str8.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1.4" + "'", str24.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion26 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion26.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + javaVersion30 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion30.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("http://java.oracle.com/", "1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "MV REVR", (int) (short) 7, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("en", "10 100 1 10 10 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "100#-1#10", 0);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("32.043.04-1.04100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.043.04-1.04100.0" + "'", str1.equals("32.043.04-1.04100.0"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi" + "'", str2.equals("hi"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("a44", "10 100 1 10 10 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a44" + "'", str2.equals("a44"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) (byte) 100, 0);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 0, (int) (byte) -1);
        byte byte20 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 163, 8);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 1 + "'", byte15 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + byte20 + "' != '" + (byte) 0 + "'", byte20 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0 1 0 1 1" + "'", str26.equals("0 1 0 1 1"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMV revreS tiB-46 )MT(topStoH avaJaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("-1           #-1#1#-1#     0", "Java V rtual Mach n  Sp c f cat  n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1           #-1#1#-1#     0" + "'", str2.equals("-1           #-1#1#-1#     0"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "04...", 163);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "0#1#0#1#1", (java.lang.CharSequence) "0#1#0#1#1");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0#1#0#1#1" + "'", charSequence2.equals("0#1#0#1#1"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51595_1560278762/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "########################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0a-1a1a...wawt.macosx.CP", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray6 = new char[] { 'a', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "   #   ", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 11, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###########" + "'", str3.equals("###########"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        float[] floatArray1 = new float[] { 100.0f };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0" + "'", str7.equals("100.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1a0a1a1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Jav...                                                                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("100 1 -1 ", 100, 163);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "0 1 100 -1e");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("794471", "Oracle#-1#Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("100414-141", '#');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51595_1560278762", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "##", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 33L, (double) 20L, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 33.0d + "'", double3 == 33.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(800L, (long) (byte) 100, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("100.0 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0 -1" + "'", str1.equals("100.0 -1"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "RSED", (java.lang.CharSequence) "51.0#", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("100.0#-1.0#100.0#0.0#52.0", 0, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0#-..." + "'", str3.equals("100.0#-..."));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 23, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left(".R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".R...R...R...R...R...R..." + "'", str2.equals(".R...R...R...R...R...R..."));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "###########", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R.." + "'", str1.equals("R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R.."));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R..");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1004-14");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1004-14" + "'", str1.equals("1004-14"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0141-40011.81.81.81.81.81.8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", " ###################################################");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "..R...R..");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        char[] charArray10 = new char[] { 'a', '4', 'a', '#' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100#-1#10", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmna_v31cq2n2x1nafc0000gn/T/", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1a", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#javaplatformapispecifica#####################################################################", 1440);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/USERS/SOPHIE/LIBR4RY/J4V4/EXTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBR4RY/J4V4/EXTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:." + "'", str1.equals("/USERS/SOPHIE/LIBR4RY/J4V4/EXTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:."));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "#########################################################################", 19);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "0.25A0.0A0.001A0.1-A0.001", 100, 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        char[] charArray9 = new char[] { 'a', '4', 'a', '#' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100#-1#10", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmna_v31cq2n2x1nafc0000gn/T/", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a 4 a #" + "'", str16.equals("a 4 a #"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "a 4 a #" + "'", str18.equals("a 4 a #"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("   #   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   #  " + "'", str1.equals("   #  "));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaa", "CRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION", 0, 214);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION" + "'", str4.equals("CRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 99, (long) 140, (long) 174);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 174L + "'", long3 == 174L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "44-4", (java.lang.CharSequence) "100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":", "");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "US", (int) (byte) 100);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "#");
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray3, strArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1a1.0a10a100");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + ":" + "'", str13.equals(":"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + ":" + "'", str15.equals(":"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("un.lwawt.macosx.CPrinterJob51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.5");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("32.03.0-1.0100.0", 13, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32.03.0-1.0100.0" + "'", str3.equals("32.03.0-1.0100.0"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                      041404141                                                                                                       ", (java.lang.CharSequence) "0#-1#1#-1#-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("           0#-1#1#-1#-1            ", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 0#-1#1#-1#-1            " + "'", str2.equals(" 0#-1#1#-1#-1            "));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 163);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                   " + "'", str2.equals("                                                                                                                                                                   "));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("US", (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                      51.51.5hi!", "100#3#24#163#1#####");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                           ", "Java V rtual Mach n  Sp c f cat  n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 163, (long) 800, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 800L + "'", long3 == 800L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 140);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aa...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R.", "JAVAPLATFORMAPISPECIFICA", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("   #   ", "hie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   #   " + "'", str2.equals("   #   "));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  ", charSequence1, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("0141-4001", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0141-4001" + "'", str2.equals("0141-4001"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        short[] shortArray5 = new short[] { (short) 0, (short) -1, (short) 1, (short) -1, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0a-1a1a-1a-1" + "'", str9.equals("0a-1a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0a-1a1a-1a-1" + "'", str12.equals("0a-1a1a-1a-1"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0.0 0.0 100.0 100.0 1.0 0.0", 214, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Oracle#-1#Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1.4", 794471, 24);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle#-1#Corporation4441.4" + "'", str4.equals("Oracle#-1#Corporation4441.4"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "     0#-1#1#-1#-1          ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("0a1a0a1a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a1a0a1a1" + "'", str1.equals("0a1a0a1a1"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("0#1#100#-1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#1#100#-1" + "'", str2.equals("0#1#100#-1"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4444444444444444US44444444444444444", "##");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444US44444444444444444" + "'", str3.equals("4444444444444444US44444444444444444"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                ##", "un444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444lwaw444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444macosx444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444C444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Printer444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Job");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("5 .");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5 ." + "'", str1.equals("5 ."));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("R...aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "R...aa" + "'", str1.equals("R...aa"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "100#3#24#163#1#####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("sun.lwawt.macosx.cprinterjob", "10 100 1 10 10 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("a1a-1a1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("oRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION" + "'", str2.equals("oRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10a100a1a10a10a0", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a100a1a10a10a0" + "'", str3.equals("10a100a1a10a10a0"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100A1A-1A1", (java.lang.CharSequence) "1a1-a1a001");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        float[] floatArray6 = new float[] { 0.0f, 0.0f, 100.0f, (short) 100, 1, 0L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str8.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.0a0.0a100.0a100.0a1.0a0.0" + "'", str10.equals("0.0a0.0a100.0a100.0a1.0a0.0"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "100.0#-...", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 4 a #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("-141410414104100", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-141410414104100" + "'", str3.equals("-141410414104100"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) ".:4V4J/BIL/RSU/:SNOISNETXE/4V4J/YR4RBIL/METSYS/:SNOISNETXE/4V4J/YR4RBIL/KROWTEN/:SNOISNETXE/4V4J/YR4RBIL/:SNOISNETXE/4V4J/YR4RBIL/EIHPOS/SRESU/P/RUN_R7NDOOP.PL_51595_1560278762");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("sun.awt.CGraphicsEnvironment", "     0#-1#1#-1#-1          ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 3, (short) 7, (short) 5);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 7 + "'", short3 == (short) 7);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("MV REVRES");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Oracle Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("Oracle Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 174);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "....R.....", 142, 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US", "10a100a1a...", 163);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Oracle ");
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "US" + "'", str5.equals("US"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "MV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRES", (java.lang.CharSequence) "100.0", 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("un.lwawt.macosx.CPrinterJob51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.5", "4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "un.lwawt.macosx.CPrinterJob51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.5" + "'", str2.equals("un.lwawt.macosx.CPrinterJob51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.5"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        long[] longArray4 = new long[] { 5, 52, (short) 1, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) (short) 5, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob", (java.lang.CharSequence) "0.0     1744970.0     174497100.0     174497100.0     1744971.0     1744970.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100.0A-1.0A100.0A0.0A52.0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4a#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "un.lwawt.macosx.CPrinterJob", 140);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        long[] longArray6 = new long[] { (short) -1, (short) 1, 10, 1L, (short) 10, 100L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.Class<?> wildcardClass8 = longArray6.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        java.lang.Class<?> wildcardClass11 = longArray6.getClass();
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 8, (int) (short) 3);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1 1 10 1 10 100" + "'", str10.equals("-1 1 10 1 10 100"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "04-1414-14-1", (java.lang.CharSequence) "100.0a-1.0a100.0a0.0a52.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10a100a1a...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaaaaaaaaaa     174497aaaaaaaaaaa", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a     174497aaaaaaaaaaa" + "'", str2.equals("a     174497aaaaaaaaaaa"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.41004095E11f, 1.0f, 13.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "####################", 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "174a97");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("01100-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "01100-1" + "'", str1.equals("01100-1"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("....R.....", (short) 7);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 7 + "'", short2 == (short) 7);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("4444444444", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 140);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444" + "'", str3.equals("4444444444"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "....r.........r.........r.........r.........r.........r.........r.........r.........r......r.........r.........r.........r.........r.........r.........r.........r.........r..", (java.lang.CharSequence) "a44", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/", "#-1#10####", "0 -1 1 -1 -1", 27);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/" + "'", str4.equals("###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("141a1.0a10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }
}

