import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest11 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test001");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test002");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("44444444444444444444444444444444444444444", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie", 142, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie                                                                                                                                 " + "'", str3.equals("/Users/sophie                                                                                                                                 "));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("a 4", "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a 4" + "'", str2.equals("a 4"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test005");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Oracle ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test006");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library794471", (java.lang.CharSequence) "Java V rtual Mach n  Sp c f cat  n", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test007");
        short[] shortArray4 = new short[] { (short) 100, (byte) 1, (byte) -1, (byte) 1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', 15, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 15");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a1a-1a1" + "'", str7.equals("100a1a-1a1"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0, "class [Jclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test009");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 15L, (float) (-1L), 800.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 800.0f + "'", float3 == 800.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test010");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                      51.51.5hi!", (java.lang.CharSequence) "Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test011");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10a100a1a10a10a0", (java.lang.CharSequence[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test012");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test013");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM", 0.9f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.9f + "'", float2 == 0.9f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("R...aa###########################################################################################", "-1#1#10#1#10#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "R...aa###########################################################################################" + "'", str2.equals("R...aa###########################################################################################"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test015");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("           0#-1#1#-1#-1            ", "#", 100);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "R...", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "");
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "           0-11-1-1            " + "'", str7.equals("           0-11-1-1            "));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test016");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "Mode mixed", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test017");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aa", "/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test018");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence5 = null;
        java.lang.CharSequence charSequence6 = null;
        char[] charArray10 = new char[] { 'a', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny(charSequence6, charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence5, charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a', 23, (int) (short) 1);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray10);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "jav...", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("MV revreS tiB-46 )MT(topStoH avaJ", (int) (byte) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MV revreS tiB-46 )MT(topStoH avaJ" + "'", str3.equals("MV revreS tiB-46 )MT(topStoH avaJ"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test020");
        double[] doubleArray3 = new double[] { 214.0f, 7.0d, 140 };
        double[] doubleArray7 = new double[] { 214.0f, 7.0d, 140 };
        double[][] doubleArray8 = new double[][] { doubleArray3, doubleArray7 };
        double[] doubleArray12 = new double[] { 214.0f, 7.0d, 140 };
        double[] doubleArray16 = new double[] { 214.0f, 7.0d, 140 };
        double[][] doubleArray17 = new double[][] { doubleArray12, doubleArray16 };
        double[] doubleArray21 = new double[] { 214.0f, 7.0d, 140 };
        double[] doubleArray25 = new double[] { 214.0f, 7.0d, 140 };
        double[][] doubleArray26 = new double[][] { doubleArray21, doubleArray25 };
        double[][][] doubleArray27 = new double[][][] { doubleArray8, doubleArray17, doubleArray26 };
        double[] doubleArray31 = new double[] { 214.0f, 7.0d, 140 };
        double[] doubleArray35 = new double[] { 214.0f, 7.0d, 140 };
        double[][] doubleArray36 = new double[][] { doubleArray31, doubleArray35 };
        double[] doubleArray40 = new double[] { 214.0f, 7.0d, 140 };
        double[] doubleArray44 = new double[] { 214.0f, 7.0d, 140 };
        double[][] doubleArray45 = new double[][] { doubleArray40, doubleArray44 };
        double[] doubleArray49 = new double[] { 214.0f, 7.0d, 140 };
        double[] doubleArray53 = new double[] { 214.0f, 7.0d, 140 };
        double[][] doubleArray54 = new double[][] { doubleArray49, doubleArray53 };
        double[][][] doubleArray55 = new double[][][] { doubleArray36, doubleArray45, doubleArray54 };
        double[] doubleArray59 = new double[] { 214.0f, 7.0d, 140 };
        double[] doubleArray63 = new double[] { 214.0f, 7.0d, 140 };
        double[][] doubleArray64 = new double[][] { doubleArray59, doubleArray63 };
        double[] doubleArray68 = new double[] { 214.0f, 7.0d, 140 };
        double[] doubleArray72 = new double[] { 214.0f, 7.0d, 140 };
        double[][] doubleArray73 = new double[][] { doubleArray68, doubleArray72 };
        double[] doubleArray77 = new double[] { 214.0f, 7.0d, 140 };
        double[] doubleArray81 = new double[] { 214.0f, 7.0d, 140 };
        double[][] doubleArray82 = new double[][] { doubleArray77, doubleArray81 };
        double[][][] doubleArray83 = new double[][][] { doubleArray64, doubleArray73, doubleArray82 };
        double[][][][] doubleArray84 = new double[][][][] { doubleArray27, doubleArray55, doubleArray83 };
        java.lang.String str85 = org.apache.commons.lang3.StringUtils.join(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray84);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("MV REVRES", 142);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MV REVRES" + "'", str2.equals("MV REVRES"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test022");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "javaplatformapispecifica");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Oracle Corporatio", (java.lang.CharSequence) "Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test024");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 36, (long) 800, (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test025");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("#####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#####" + "'", str1.equals("#####"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test026");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("      ", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("100.04-1.04100.040.0452.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.04-1.04100.040.0452.0" + "'", str1.equals("100.04-1.04100.040.0452.0"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test028");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("100#-1#104444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test029");
        float[] floatArray6 = new float[] { 0.0f, 0.0f, 100.0f, (short) 100, 1, 0L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str8.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str11.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test030");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Or cle#-1#Corpor tion4441.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Or cle#-1#Corpor tion4441.4" + "'", str1.equals("Or cle#-1#Corpor tion4441.4"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test031");
        int[] intArray1 = new int[] { '4' };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52" + "'", str3.equals("52"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52" + "'", str7.equals("52"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test032");
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) 100, (byte) 100, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (short) 3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "141004100410" + "'", str7.equals("141004100410"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1 100 100" + "'", str12.equals("1 100 100"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("MV revreS ", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("174");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "174" + "'", str1.equals("174"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test035");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                             794471                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 19, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test037");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (byte) 10, " ################################################### 100 1 10 10 0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test038");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("un444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444lwaw444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444macosx444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444C444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Printer444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Job");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"un444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444lwaw444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444macosx444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444C444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Printer444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Job\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test039");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "r...", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test040");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "10A1A1A10A100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test041");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(100L, (long) 163, (long) 143);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 163L + "'", long3 == 163L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test042");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "100.0 -1.0 100.0 0.0 52.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test043");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        1A");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test044");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "44444444444444444444444444444444", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test045");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("un.lwawt.macosx.CPrinterJob");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "US", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "               sophie               ", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "US", (int) (byte) 100);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "1a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a100");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "/Users/sop");
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.split("MV revreS ", 'a');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                    ", strArray13, strArray20);
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.stripAll(strArray13);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEach("#", strArray5, strArray22);
        boolean boolean24 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "17", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "                                                    " + "'", str21.equals("                                                    "));
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "#" + "'", str23.equals("#"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test046");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "041404141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre", 18, 30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...lMchines/jdk1.7.0_80.jdk..." + "'", str3.equals("...lMchines/jdk1.7.0_80.jdk..."));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test048");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test049");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "100#-1#10", 0);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "MV REVR", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray11 = null;
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("51.0#", strArray5, strArray11);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "51.0#" + "'", str12.equals("51.0#"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Libr4ry/J4v4/Exte", "a 4 a #                                                                                                                                                            ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Libr4ry/J4v4/Exte" + "'", str3.equals("/Users/sophie/Libr4ry/J4v4/Exte"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("5 .");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5 ." + "'", str1.equals("5 ."));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test052");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.cprinterjob", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test053");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-1", "                                               sophie                                     ...");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) ".....R...R...R...R...R...R..", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test054");
        long[] longArray6 = new long[] { (short) -1, (short) 1, 10, 1L, (short) 10, 100L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', 9, 0);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test055");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("0141-40011.81.81.81.81.81.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1." + "'", str1.equals("1."));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA", "01100-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA" + "'", str2.equals("JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test058");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "XTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test059");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("4444444444444444US44444444444444444", "0 -1 1 -1 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444US44444444444444444" + "'", str2.equals("4444444444444444US44444444444444444"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test061");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Oracle ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test062");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 1 + "'", byte12 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0#1#0#1#1" + "'", str14.equals("0#1#0#1#1"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test063");
        java.lang.CharSequence charSequence4 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray9 = new char[] { 'a', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence5, charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "51.51.51.51.51.51.51.51.51.51.", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaa", charArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "a 4" + "'", str18.equals("a 4"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test064");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                      51.51.5HI!", (java.lang.CharSequence) "0#-1#1#-1#-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test065");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("un444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444lwaw444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444macosx444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444C444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Printer444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Job", 794471L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 794471L + "'", long2 == 794471L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test066");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(35.0f, (float) 19, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test067");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" x86_64");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test068");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("     0#-1#1#-1#-1               0#-1#1#-1#-1               0#-1#1#-1#-1          ....................................................     0#-1#1#-1#-1               0#-1#1#-1#-1               0#-1#1#-1#-1          ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test069");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                                    ");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test070");
        long[] longArray2 = new long[] { (-1), (byte) 1 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', (int) (short) 5, 73);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1 1" + "'", str6.equals("-1 1"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test071");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "....R.........R.........R.........R.........R.........R.........R.........R.........R......R.........R.........R.........R.........R.........R.........R.........R.........R..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("JavaPlatformAPISpecifica", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test073");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "100a1a-1a", (java.lang.CharSequence) "44444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test074");
        long[] longArray6 = new long[] { (short) -1, (short) 1, 10, 1L, (short) 10, 100L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) '4', 32);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test075");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/USERS/SOPHIE/LIBR4RY/J4V4/EXTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:", 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test076");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRA", (int) '4', (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("             x86_64", 141);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             x86_64                                                                                                                          " + "'", str2.equals("             x86_64                                                                                                                          "));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test078");
        org.apache.commons.lang3.JavaVersion[] javaVersionArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(javaVersionArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("....R.....", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "..." + "'", str2.equals("..."));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test080");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("     174497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     174497" + "'", str3.equals("     174497"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test081");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#-1#", "");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) 'a', (int) (short) 7);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test082");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRA", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test083");
        long[] longArray2 = new long[] { 19, (byte) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', 800, (int) (short) 100);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 19L + "'", long4 == 19L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.851.821.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test086");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(13.0f, 1.41004095E11f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.41004095E11f + "'", float3 == 1.41004095E11f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test087");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("01100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("JAVAPLATFORMAPISPECIFICA", "Mode mixed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test090");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "   ", (java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a001");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a001" + "'", str1.equals("1a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a001"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Exten");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test093");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1440, (float) 143L, (float) 22);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 22.0f + "'", float3 == 22.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test094");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 143, 13);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 1 + "'", byte12 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test095");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4444444444444444US4444444444444444", (java.lang.CharSequence) "#############################################################################################################################################", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test096");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(174, 25, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 174 + "'", int3 == 174);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("174a97", "Oracle Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "174a97" + "'", str2.equals("174a97"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("###############################/", (int) ' ', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############################/" + "'", str3.equals("###############################/"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test099");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1/var/folders/_v/6v597zmna_v31cq2n2x1nafc0000gn/T/1.0/var/folders/_v/6v597zmna_v31cq2n2x1nafc0000gn/T/10/var/folders/_v/6v597zmna_v31cq2n2x1nafc0000gn/T/100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1/VAR/FOLDERS/_V/6V597ZMNA_V31CQ2N2X1NAFC0000GN/T/1.0/VAR/FOLDERS/_V/6V597ZMNA_V31CQ2N2X1NAFC0000GN/T/10/VAR/FOLDERS/_V/6V597ZMNA_V31CQ2N2X1NAFC0000GN/T/100" + "'", str1.equals("1/VAR/FOLDERS/_V/6V597ZMNA_V31CQ2N2X1NAFC0000GN/T/1.0/VAR/FOLDERS/_V/6V597ZMNA_V31CQ2N2X1NAFC0000GN/T/10/VAR/FOLDERS/_V/6V597ZMNA_V31CQ2N2X1NAFC0000GN/T/100"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Oracle Corporation", "RSED");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test101");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (short) 1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test102");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "100#-1#10", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "0#-1#1#-1#-1", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "141004100410");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, 'a');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test103");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1/VAR/FOLDERS/_V/6V597ZMNA_V31CQ2N2X1NAFC0000GN/T/1.0/VAR/FOLDERS/_V/6V597ZMNA_V31CQ2N2X1NAFC0000GN/T/10/VAR/FOLDERS/_V/6V597ZMNA_V31CQ2N2X1NAFC0000GN/T/100");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "0#-1#1#-1#-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test106");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 4 a #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test107");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '#', 2, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test108");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("SUN.LWAWT.MACOSX.CPRINTERJOB");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SUN.LWAWT.MACOSX.CPRINTERJOB\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test109");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test110");
        byte[] byteArray3 = new byte[] { (byte) 100, (byte) -1, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        java.lang.Class<?> wildcardClass6 = byteArray3.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 3, (int) (short) 1);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100#-1#10" + "'", str5.equals("100#-1#10"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test111");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Oracle Corporatio", (java.lang.CharSequence) "1a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a001");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("51.51.51.51.51.51.51.51.51.51.", ".\n5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.51.51.51.51.51.51.51.51.51." + "'", str2.equals("51.51.51.51.51.51.51.51.51.51."));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test113");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) ":ptth");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("2.0#3.0#-1.0#100.", "        1a", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast(".:4v4j/bil/rsu/:snoisnetxe/4v4j/yr4rbil/metsys/:snoisnetxe/4v4j/yr4rbil/krowten/:snoisnetxe/4v4j/yr4rbil/:snoisnetxe/4v4j/yr4rbil/eihpos/sresu/p/run_r7ndoop.pl_51595_1560278762", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test116");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "", (int) ' ');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "0a1a0a1a1", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test117");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("5 .", (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("class#[Ljava.lang.Object;aclass#[Ljava.lang.String;aclass#[Baclass#[Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CLASS#[LJAVA.LANG.OBJECT;ACLASS#[LJAVA.LANG.STRING;ACLASS#[BACLASS#[LJAVA.LANG.STRING;" + "'", str1.equals("CLASS#[LJAVA.LANG.OBJECT;ACLASS#[LJAVA.LANG.STRING;ACLASS#[BACLASS#[LJAVA.LANG.STRING;"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("printerj", "Mode mixed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "printerj" + "'", str2.equals("printerj"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.7.0_80-b15", "#-1#10####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test121");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test122");
        double[] doubleArray4 = new double[] { ' ', 3, (byte) -1, (short) 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32.0#3.0#-1.0#100.0" + "'", str10.equals("32.0#3.0#-1.0#100.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test123");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), 800L, (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test124");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 1, 3.0f, 98.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 98.0f + "'", float3 == 98.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("5 .", 20, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444445 .444444444" + "'", str3.equals("444444445 .444444444"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test126");
        long[] longArray6 = new long[] { (short) -1, (short) 1, 10, 1L, (short) 10, 100L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test127");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                                      041404141                                                                                                       ", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("-1 1 10 1 10 100", "################################################51.0################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 1 10 1 10 100" + "'", str2.equals("-1 1 10 1 10 100"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test129");
        double[] doubleArray4 = new double[] { ' ', 3, (byte) -1, (short) 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 10, 6);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double15 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', (int) (byte) 1, (int) (byte) 1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "32.043.04-1.04100.0" + "'", str14.equals("32.043.04-1.04100.0"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "32.0a3.0a-1.0a100.0" + "'", str17.equals("32.0a3.0a-1.0a100.0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Oracle Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444", ".:4v4j/bil/rsu/:snoisnetxe/4v4j/yr4rbil/metsys/:snoisnetxe/4v4j/yr4rbil/krowten/:snoisnetxe/4v4j/yr4rbil/:snoisnetxe/4v4j/yr4rbil/eihpos/sresu/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test131");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("   ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcMlutriVvJ/vJ/yrrbiL/" + "'", str1.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcMlutriVvJ/vJ/yrrbiL/"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test133");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test134");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test135");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "0 -1 1 -1 -1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test136");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("     0#-1#1#-1#-1           ", "100 1 -1 1", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test137");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100#-1#104444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 794471, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test138");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "    hie     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test139");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "noitacificepS IPA mroftalP avaJ" + "'", charSequence2.equals("noitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test140");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Java(TM) SE Runtime Environmen", (java.lang.CharSequence) "", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test141");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test142");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 141, 141L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                en                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                  ne                                                " + "'", str1.equals("                                                  ne                                                "));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("174a97", "1 100 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "74a97" + "'", str2.equals("74a97"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("US", "printerjo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test146");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) '#', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 35, 85);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test148");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("100.0#-...", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test149");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library794471", (java.lang.CharSequence) "                                                                                                      041404141                                                                                                       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test150");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "100#-1#10", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "MV REVR", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test151");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("##", "", 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "######################" + "'", str3.equals("######################"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("174110.0551.052");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "174110.0551.052" + "'", str1.equals("174110.0551.052"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test153");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", ".", 36);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("#########################################################################", "100 1 -1 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#########################################################################" + "'", str2.equals("#########################################################################"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("14.48", 33, "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444414.4844444444444444" + "'", str3.equals("4444444444444414.4844444444444444"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test156");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(".............MV REVRES.............");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test157");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100 1 -1 ", 13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test158");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) (byte) 100, 0);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 0, (int) (byte) -1);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 1 + "'", byte15 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test159");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("################################################51.0################################################");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test160");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle Corporatio", "                                                                                                                                     0#1#100#-1", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporatio" + "'", str1.equals("Oracle Corporatio"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test162");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.4                                                                                                                                                                ", "5");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test163");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMV revreS tiB-46 )MT(topStoH avaJaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 11, 28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMV revreS tiB-46 )MT(topStoH avaJaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMV revreS tiB-46 )MT(topStoH avaJaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R..", ".R...R...R...R...R...R...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "R..R..R..R...R...R...R.." + "'", str2.equals("R..R..R..R...R...R...R.."));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test165");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("#-1#", "aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#-1#" + "'", str2.equals("#-1#"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("a1a-1a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a1a-1a1" + "'", str1.equals("a1a-1a1"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test168");
        int[] intArray1 = new int[] { '4' };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 0, (int) (short) 1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52" + "'", str3.equals("52"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52" + "'", str8.equals("52"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test169");
        int[] intArray2 = new int[] { 174, 'a' };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', (int) (byte) 100, 22);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', 8, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 174 + "'", int3 == 174);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "174#97" + "'", str9.equals("174#97"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 174 + "'", int10 == 174);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test170");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "52");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test171");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AAAAAAAA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test172");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("hie");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test173");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.8");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("52", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52" + "'", str2.equals("52"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test175");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test176");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 100, (byte) 1, (byte) 10, (byte) 10, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa###############################/");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa###############################/");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a100a1a10a10a0" + "'", str9.equals("10a100a1a10a10a0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10 100 1 10 10 0" + "'", str11.equals("10 100 1 10 10 0"));
    }
}

