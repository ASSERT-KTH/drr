import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest10 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test001");
        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 100, (byte) 1, (byte) 10, (byte) 10, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "class [Jclass [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: class [Jclass [Ljava.lang.String;");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test002");
        float[] floatArray6 = new float[] { 0.0f, 0.0f, 100.0f, (short) 100, 1, 0L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', (int) (byte) 0, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str8.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test003");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.5", (double) (short) 7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5d + "'", double2 == 1.5d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test004");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 6.0f, 1.7000000476837158d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test005");
        byte[] byteArray3 = new byte[] { (byte) 100, (byte) -1, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        java.lang.Class<?> wildcardClass6 = byteArray3.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 3, (int) (short) 1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', 20, (int) (short) 10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100#-1#10" + "'", str5.equals("100#-1#10"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100#-1#10" + "'", str16.equals("100#-1#10"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "100A1A-1A1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.2", "100.0A-1.0A100.0A0.0A52.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test008");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", "/Users/sophie/Documents/defectsj/tmp/run_r7ndoop.pl_51595_1560278762", 99);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("oRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION" + "'", str2.equals("oRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION/Users/sopoRACLE cORPORATION"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test010");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("R", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test011");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 23, (long) 1440, (long) 2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1440L + "'", long3 == 1440L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test012");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 140, (float) 20, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("100 1 -1 ", "MV revreS tiB-46 )MT(topStoH ava");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 1 -1 " + "'", str2.equals("100 1 -1 "));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("un/5", "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", 25);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "un/5" + "'", str3.equals("un/5"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test015");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "su0 1 0 1 1su", "5 .");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test016");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle(".:4V4J/BIL/RSU/:SNOISNETXE/4V4J/YR4RBIL/METSYS/:SNOISNETXE/4V4J/YR4RBIL/KROWTEN/:SNOISNETXE/4V4J/YR4RBIL/:SNOISNETXE/4V4J/YR4RBIL/EIHPOS/SRESU/P/RUN_R7NDOOP.PL_51595_1560278762", "10 100 1 10 10 ", 13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".:4V4J/BIL/RSU/:SNOISNETXE/4V4J/YR4RBIL/METSYS/:SNOISNETXE/4V4J/YR4RBIL/KROWTEN/:SNOISNETXE/4V4J/YR4RBIL/:SNOISNETXE/4V4J/YR4RBIL/EIHPOS/SRESU/P/RUN_R7NDOOP.PL_51595_1560278762" + "'", str3.equals(".:4V4J/BIL/RSU/:SNOISNETXE/4V4J/YR4RBIL/METSYS/:SNOISNETXE/4V4J/YR4RBIL/KROWTEN/:SNOISNETXE/4V4J/YR4RBIL/:SNOISNETXE/4V4J/YR4RBIL/EIHPOS/SRESU/P/RUN_R7NDOOP.PL_51595_1560278762"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test018");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test019");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 99, 140);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test020");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "###########", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test021");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "US", (int) (byte) 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "#");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "US", (int) (byte) 100);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, "#");
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray12);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray5, strArray12);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str16.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "44444444444444444444444444444", "printerj");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test023");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Corporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test024");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("           0#-1#1#-1#-1            ", "#", 100);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "MV revreS");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                                                                                      041404141                                                                                                       ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test026");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("http://java.oracle.com/", ".R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...", 30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/.R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...http://java.oracle.com/"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test027");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] { 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                            Mac OS X", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#-1#10", charArray7);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', 93, (int) '4');
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 0, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 93 + "'", int11 == 93);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test028");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] { 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                            Mac OS X", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#-1#10", charArray7);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', 93, (int) '4');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 1440, (int) (short) 5);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', (int) 'a', 10);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 93 + "'", int11 == 93);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("MV revreS tiB-46 )MT(topStoH avaJUTF-8", "174", "               sophie               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MV revreS tiB-46 )MT(topStoH avaJUTF-8" + "'", str3.equals("MV revreS tiB-46 )MT(topStoH avaJUTF-8"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test030");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/USERS/SOPHIE/LIBR4RY/J4V4/EXTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test031");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                                                                                     0#1#100#-1", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51595_1560278762/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test032");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("041404141", "mixed mode", "Mode mixed");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test033");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "-1 1 10 1 10 100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test034");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre", 30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test035");
        float[] floatArray6 = new float[] { 0.0f, 0.0f, 100.0f, (short) 100, 1, 0L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#', 33, 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4', 214, 97);
        float float20 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float21 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float22 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float23 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float24 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float25 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str8.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str11.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 100.0f + "'", float20 == 100.0f);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 100.0f + "'", float23 == 100.0f);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 100.0f + "'", float24 == 100.0f);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("##4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####444444444444444444444444444444444" + "'", str1.equals("##4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####4#4#a####444444444444444444444444444444444"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(".", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test038");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("########################", "                                               sophie                                               ", 98);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "jav...");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "########################" + "'", str5.equals("########################"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test039");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 1, (byte) 1, (byte) 10, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', 4, 0);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10a1a1a10a100" + "'", str7.equals("10a1a1a10a100"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#1#1#10#100" + "'", str10.equals("10#1#1#10#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10#1#1#10#100" + "'", str12.equals("10#1#1#10#100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10a1a1a10a100" + "'", str14.equals("10a1a1a10a100"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("100A1A-1A1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100A1A-1A1" + "'", str1.equals("100A1A-1A1"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test041");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                            Mac OS X", "/Users/sophie/Libr4ry/J4v4/Exte", 800);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test042");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("01100-1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test043");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                        ", (java.lang.CharSequence) "UTF8", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("0141-4001", "MV revreS tiB-46 )MT(topStoH avaJ", "51.0#");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:.", "                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:." + "'", str2.equals("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:."));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test047");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("     0#-1#1#-1#-1           ");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                               sophie                                     ...", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 85 + "'", int3 == 85);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("en                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("en                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("s/sophie/Documents/defects4j/tmp/run_randoop.pl", 19, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "s/sophie/Documents/defects4j/tmp/run_randoop.pl" + "'", str3.equals("s/sophie/Documents/defects4j/tmp/run_randoop.pl"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("174#97", "0a1a0a1a1", 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#97" + "'", str3.equals("174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#97"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test051");
        double[] doubleArray5 = new double[] { 100.0f, (-1L), (byte) 100, (short) 0, 52 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.Class<?> wildcardClass11 = doubleArray5.getClass();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 -1.0 100.0 0.0 52.0" + "'", str7.equals("100.0 -1.0 100.0 0.0 52.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test052");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test053");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Oracle#-1#Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444", 36, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("-1           #-1#1#-1#     0", "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1           #-1#1#-1#     0" + "'", str2.equals("-1           #-1#1#-1#     0"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("http://java.oracle.com/", "-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("en                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.551.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("en                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test057");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.", (java.lang.CharSequence) "R...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test058");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation0141-40010141-40010141-40010141-40010141-40010141-40010141-40010141-40010141-4001", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 4 a #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test059");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa###############################/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("R...", "####################################################################################################", "-141410414104100");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("100.0#-...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0#-..." + "'", str1.equals("100.0#-..."));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test062");
        int[] intArray1 = new int[] { '4' };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52" + "'", str3.equals("52"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52" + "'", str6.equals("52"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("a 4 a #", 163);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a 4 a #                                                                                                                                                            " + "'", str2.equals("a 4 a #                                                                                                                                                            "));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1#-1#1#-1", "R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aa51.51.51.51.51.51.51.51.51.51.R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aa51.51.51.51.51.51.51.51.51.51.R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR" + "'", str2.equals("R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aa51.51.51.51.51.51.51.51.51.51.R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test065");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51595_1560278762", 97, 163);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test066");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "        ", 85);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################################################################" + "'", str2.equals("#################################################################################################"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("CRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION", 174, "1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION" + "'", str3.equals("CRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION/Uslrs/sCrCRA LEeaORPORATION"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test069");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("     http:", "-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1", "aa#a a#a4aa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test070");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.6", "8.1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test071");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Oracle Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "4444444444444444US44444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test072");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                en                                                  ", "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test073");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mac OS X", (int) (byte) 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test074");
        short[] shortArray4 = new short[] { (short) 0, (byte) 1, (short) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#', 794471, 7);
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short16 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 1 100 -1" + "'", str8.equals("0 1 100 -1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 100 + "'", short15 == (short) 100);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) -1 + "'", short16 == (short) -1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test075");
        float[] floatArray6 = new float[] { 0.0f, 0.0f, 100.0f, (short) 100, 1, 0L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str8.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test076");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test077");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test078");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "jav...                                                                                            ", "5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.5\n.551.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test079");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) " ###################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Usrs/sph/Dcunts/fcts4j/tp/run_ranp.pl_51595_1560278762", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test081");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("5\n", "#JAVAPLATFORMAPISPECIFICA#####################################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                      51.51.5hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                      51.51.5hi!" + "'", str1.equals("                      51.51.5hi!"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test083");
        int[] intArray2 = new int[] { 174, 'a' };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', (int) (short) 0, 0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 174 + "'", int3 == 174);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "174497" + "'", str5.equals("174497"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test084");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                            Mac OS X", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test085");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "100#-1#104444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "100#3#24#163#1#####");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test086");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test087");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test088");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "mixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("44444444444444444444444444444444444444444", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444444444"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test090");
        char[] charArray6 = new char[] { '#', '4', '4', 'a', '#' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "oRACLE cORPORATION", charArray6);
        java.lang.Class<?> wildcardClass8 = charArray6.getClass();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test091");
        short[] shortArray5 = new short[] { (short) 0, (short) -1, (short) 1, (short) -1, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) '4', 0);
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short16 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short17 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 1 + "'", short8 == (short) 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0#-1#1#-1#-1" + "'", str15.equals("0#-1#1#-1#-1"));
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 1 + "'", short16 == (short) 1);
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) -1 + "'", short17 == (short) -1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test092");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("s/sophie/Documents/defects4j/tmp/run_randoop.pl", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test093");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("100.04-1.04100.040.0452.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.04-1.04100.040.0452.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-1", "1004-1410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-1" + "'", str2.equals("0a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-1"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test095");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("UTF8");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                                             ", "4444444444444444444444JavaPlatformAPISpecification44444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                             " + "'", str2.equals("                                                                                             "));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test097");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "#-1#10", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "     0#-1#1#-1#-1           ");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/" + "'", str5.equals("/"));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test098");
        float[] floatArray6 = new float[] { 0.0f, 0.0f, 100.0f, (short) 100, 1, 0L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#', 33, 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4', 214, 97);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str8.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str11.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0.0a0.0a100.0a100.0a1.0a0.0" + "'", str21.equals("0.0a0.0a100.0a100.0a1.0a0.0"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str23.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test099");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) " 0a1a0a1a1", (java.lang.CharSequence) "                                                en                                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test100");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test101");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "0141-4001", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0141-4001" + "'", charSequence2.equals("0141-4001"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test102");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("aaaaaaaaaaa     174497aaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test103");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                                            Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0 1 100 -1e", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 1 100 -1e" + "'", str2.equals("0 1 100 -1e"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test105");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("######################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "######################" + "'", str1.equals("######################"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test106");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("java Platform API Specification", 3, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java Platform API Specification" + "'", str3.equals("java Platform API Specification"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("100 1 -1 1", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100 1 -1 1" + "'", str3.equals("100 1 -1 1"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(":4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/", 52, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/" + "'", str3.equals(":4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test109");
        double[] doubleArray5 = new double[] { 100.0f, (-1L), (byte) 100, (short) 0, 52 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 5, (int) (short) 0);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double15 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double16 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 -1.0 100.0 0.0 52.0" + "'", str7.equals("100.0 -1.0 100.0 0.0 52.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100.0#-1.0#100.0#0.0#52.0" + "'", str14.equals("100.0#-1.0#100.0#0.0#52.0"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test110");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "US", (int) (byte) 100);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "#");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "US", (int) (byte) 100);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray13, "#");
        int int16 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray13);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray6, strArray13);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http:", "4444444444", 28);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Mac OS Xen                                                  ", strArray6, strArray21);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray21, 'a');
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str17.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Mac OS Xen                                                  " + "'", str22.equals("Mac OS Xen                                                  "));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "http:" + "'", str24.equals("http:"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test111");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.3", (java.lang.CharSequence) "4444444444444444444444JavaPlatformAPISpecification44444444444444444444444", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1/var/foldUTF81/var/fold", "eihpos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1/var/foldUTF81/var/fold" + "'", str2.equals("1/var/foldUTF81/var/fold"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("###################################", 12, "eihpos");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################" + "'", str3.equals("###################################"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("noitacificepS IPA mroftalP avaJ", 140);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJ" + "'", str2.equals("noitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test115");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                    ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test116");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "en", (java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test117");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("     0#-1#1#-1#-1           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#-1#1#-1#-1" + "'", str1.equals("0#-1#1#-1#-1"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test118");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("01100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-1", ".\n5");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test119");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100.0a-1.0a100.0a0.0a52.0", "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test120");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "174a97", (java.lang.CharSequence) "1/var/foldUTF81/var/fold");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test121");
        short[] shortArray5 = new short[] { (short) 0, (short) -1, (short) 1, (short) -1, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0#-1#1#-1#-1" + "'", str8.equals("0#-1#1#-1#-1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 1 + "'", short12 == (short) 1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test122");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":", "");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "US", (int) (byte) 100);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("51.", strArray4, strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#970a1a0a1a1174#97", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "51." + "'", str9.equals("51."));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test123");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) (byte) 100, 0);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 0, (int) (byte) -1);
        byte byte20 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte21 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte22 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte23 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte24 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 1 + "'", byte15 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + byte20 + "' != '" + (byte) 0 + "'", byte20 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte21 + "' != '" + (byte) 1 + "'", byte21 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte22 + "' != '" + (byte) 0 + "'", byte22 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte23 + "' != '" + (byte) 1 + "'", byte23 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte24 + "' != '" + (byte) 1 + "'", byte24 == (byte) 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test124");
        int[] intArray1 = new int[] { '4' };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52" + "'", str3.equals("52"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52" + "'", str7.equals("52"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test125");
        double[] doubleArray4 = new double[] { ' ', 3, (byte) -1, (short) 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', 100, 20);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 20, 6);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test126");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "                                                                                                      041404141                                                                                                       ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                                                                                       041404141                                                                                                       ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0#1#0#1#1" + "'", str12.equals("0#1#0#1#1"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 1 + "'", byte14 == (byte) 1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test127");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray0, doubleArray1, doubleArray2, doubleArray3, doubleArray4 };
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9, doubleArray10 };
        double[] doubleArray12 = new double[] {};
        double[] doubleArray13 = new double[] {};
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[] doubleArray16 = new double[] {};
        double[][] doubleArray17 = new double[][] { doubleArray12, doubleArray13, doubleArray14, doubleArray15, doubleArray16 };
        double[] doubleArray18 = new double[] {};
        double[] doubleArray19 = new double[] {};
        double[] doubleArray20 = new double[] {};
        double[] doubleArray21 = new double[] {};
        double[] doubleArray22 = new double[] {};
        double[][] doubleArray23 = new double[][] { doubleArray18, doubleArray19, doubleArray20, doubleArray21, doubleArray22 };
        double[] doubleArray24 = new double[] {};
        double[] doubleArray25 = new double[] {};
        double[] doubleArray26 = new double[] {};
        double[] doubleArray27 = new double[] {};
        double[] doubleArray28 = new double[] {};
        double[][] doubleArray29 = new double[][] { doubleArray24, doubleArray25, doubleArray26, doubleArray27, doubleArray28 };
        double[] doubleArray30 = new double[] {};
        double[] doubleArray31 = new double[] {};
        double[] doubleArray32 = new double[] {};
        double[] doubleArray33 = new double[] {};
        double[] doubleArray34 = new double[] {};
        double[][] doubleArray35 = new double[][] { doubleArray30, doubleArray31, doubleArray32, doubleArray33, doubleArray34 };
        double[][][] doubleArray36 = new double[][][] { doubleArray5, doubleArray11, doubleArray17, doubleArray23, doubleArray29, doubleArray35 };
        java.lang.String str37 = org.apache.commons.lang3.StringUtils.join(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test128");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("174497", "####################", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "hi");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "174497" + "'", str5.equals("174497"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test129");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("0a-1a1a...wawt.macosx.CP");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java V rtual Mach n  Sp c f cat  n2678720651_59515_lp.poodn7r_nur/p/users/sophie/libr4ry/j4v4/extensions:/libr4ry/j4v4/extensions:/network/libr4ry/j4v4/extensions:/system/libr4ry/j4v4/extensions:/usr/lib/j4v4:.Java V rtual Mach n  Sp c f cat  n2678720651_59515_lp.poodn7r_nur/p/users/sophie/libr4ry/j4v4/extensions:/libr4ry/j4v4/extensions:/network/libr4ry/j4v4/extensions:/system/libr4ry/j4v4/extensions:/usr/lib/j4v4:.Java V rtual Mach n  Sp c f cat  n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java V rtual Mach n  Sp c f cat  n2678720651_59515_lp.poodn7r_nur/p/users/sophie/libr4ry/j4v4/extensions:/libr4ry/j4v4/extensions:/network/libr4ry/j4v4/extensions:/system/libr4ry/j4v4/extensions:/usr/lib/j4v4:.Java V rtual Mach n  Sp c f cat  n2678720651_59515_lp.poodn7r_nur/p/users/sophie/libr4ry/j4v4/extensions:/libr4ry/j4v4/extensions:/network/libr4ry/j4v4/extensions:/system/libr4ry/j4v4/extensions:/usr/lib/j4v4:.Java V rtual Mach n  Sp c f cat  n" + "'", str1.equals("Java V rtual Mach n  Sp c f cat  n2678720651_59515_lp.poodn7r_nur/p/users/sophie/libr4ry/j4v4/extensions:/libr4ry/j4v4/extensions:/network/libr4ry/j4v4/extensions:/system/libr4ry/j4v4/extensions:/usr/lib/j4v4:.Java V rtual Mach n  Sp c f cat  n2678720651_59515_lp.poodn7r_nur/p/users/sophie/libr4ry/j4v4/extensions:/libr4ry/j4v4/extensions:/network/libr4ry/j4v4/extensions:/system/libr4ry/j4v4/extensions:/usr/lib/j4v4:.Java V rtual Mach n  Sp c f cat  n"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test131");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.5", "#-1#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test132");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("####################################################################################################", "                                               sophie                                     ...", 12);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5);
        java.lang.String[] strArray7 = null;
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "/Users/sophie/Libr4ry/J4v4/Exte");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "####################################################################################################" + "'", str6.equals("####################################################################################################"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "####################################################################################################" + "'", str11.equals("####################################################################################################"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("  #04141004-1  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#04141004-1" + "'", str1.equals("#04141004-1"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test134");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion0.getClass();
        java.lang.String str4 = javaVersion0.toString();
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str6 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        java.lang.String str11 = javaVersion8.toString();
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean14 = javaVersion12.atLeast(javaVersion13);
        boolean boolean15 = javaVersion8.atLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean18 = javaVersion16.atLeast(javaVersion17);
        boolean boolean19 = javaVersion8.atLeast(javaVersion16);
        boolean boolean20 = javaVersion0.atLeast(javaVersion16);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.3" + "'", str4.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.3" + "'", str6.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.4" + "'", str11.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("32#0#3#0#-##0##00#", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test136");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("jav...                                                                                            ", "10a1a1a10a100", 794471);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test138");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("52", 163, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test139");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-10a-1a1a-1a-");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("32.0#3.0#-1.0#100.", "0 1 100 -1", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32.0#3.0#-1.0#100." + "'", str3.equals("32.0#3.0#-1.0#100."));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("32.0 3.0 -1.0 100.0", "wawt.macosx.CPrinterJob", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32.0 3.0 -1.0 100.0" + "'", str3.equals("32.0 3.0 -1.0 100.0"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test142");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test143");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test144");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/USERS/SOPHIE/LIBR4RY/J4V4/EXTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:", (java.lang.CharSequence) "Orcle Corportion4444444444444444444444444444444444444444444444444444444444444444444444444444444444", 163);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test145");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "MV REVR");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("JAVAPLATFORMAPISPECIFICA", "Oracle#-1#Corporation4441.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVAPLATFORMAPISPECIFICA" + "'", str2.equals("JAVAPLATFORMAPISPECIFICA"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test147");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "01100-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test148");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test149");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("jav...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jav..." + "'", str1.equals("jav..."));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test150");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) ":4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 141);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#############################################################################################################################################" + "'", str2.equals("#############################################################################################################################################"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test153");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Libra...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("32.0#3.0#-1.0#100.0", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0#3.0#-1.0#100.0" + "'", str2.equals("32.0#3.0#-1.0#100.0"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test155");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "US", (int) (byte) 100);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("un.lwawt.macosx.CPrinterJob");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "US", (int) (byte) 100);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "1a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a100");
        boolean boolean16 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray13);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.0", strArray8, strArray13);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", strArray5, strArray13);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0#1#0#1#1", (java.lang.CharSequence[]) strArray13);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray13);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "51.0" + "'", str17.equals("51.0"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + "'", str18.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("#04141004-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#04141004-1" + "'", str1.equals("#04141004-1"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test158");
        double[] doubleArray5 = new double[] { 100.0f, (-1L), (byte) 100, (short) 0, 52 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', (int) (short) 1, 1440);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 -1.0 100.0 0.0 52.0" + "'", str7.equals("100.0 -1.0 100.0 0.0 52.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test159");
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence5 = null;
        java.lang.CharSequence charSequence6 = null;
        char[] charArray10 = new char[] { 'a', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny(charSequence6, charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence5, charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                            Mac OS X", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100#-1#10", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100", charArray10);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0141-40011.81.81.81.81.81.8", charArray10);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray10, '4', 174, (int) (byte) 100);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 93 + "'", int14 == 93);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test160");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "0141-4001");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Orcle Corportion4444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "orcle corportion4444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("orcle corportion4444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test162");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "5\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test163");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("100.0 -1.0 100.0 0.0 52.0", (int) 'a', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width with offset is 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test164");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "01100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-151.051.05301100-1", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("0#1#0#1#1", "32.0 3.0 -1.0 100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#1#0#1#1" + "'", str2.equals("0#1#0#1#1"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("-1 1 10 1 10 100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 1 10 1 10 100" + "'", str2.equals("-1 1 10 1 10 100"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("4444444444444444444444444444444444444444444444444444444444444444444444444444444444noitroproC elcrO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444noitroproc elcro" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444noitroproc elcro"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test168");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "un444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444lwaw444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444macosx444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444C444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Printer444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Job", (java.lang.CharSequence) "....................................................", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test169");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0 -1 1 -1 -1", "Jav...                                                                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(" ", "printerj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test171");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "...R");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test173");
        short[] shortArray4 = new short[] { (short) 100, (byte) 1, (byte) -1, (byte) 1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test174");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1a11a11a11aprinterjo", (java.lang.CharSequence) "100.0A-1.0A100.0A0.0A52.0", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test175");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1a1.0a10a100");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test176");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("174497", "####################", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "174497" + "'", str5.equals("174497"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                            Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSX" + "'", str1.equals("MacOSX"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test178");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "sun.lwawt.macosx.CPrinterJob", "           0#-1#1#-1#-1            ");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "oRACLE cORPORATION", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test179");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "           0-11-1-1            ", (java.lang.CharSequence) " #########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          " + "'", str1.equals("          "));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test181");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test182");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(141, 100, 800);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 800 + "'", int3 == 800);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("44444444444444444444444444444444", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test184");
        char[] charArray8 = new char[] { '4', ' ', '4', ' ', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', 0, 1);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "8.1", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4" + "'", str14.equals("4"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test185");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444JavaPlatformAPISpecification44444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test186");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("un/5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "un/5" + "'", str1.equals("un/5"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("su0 1 0 1 1su", "0.0 0.0 100MV REVRES");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "su0 1 0 1 1su" + "'", str2.equals("su0 1 0 1 1su"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test188");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "-1 1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("174", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "17" + "'", str2.equals("17"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R.." + "'", str1.equals("R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R...R.."));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("r...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "r..." + "'", str1.equals("r..."));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test193");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("un.lwawt.macosx.CPrinterJob", (double) 33);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 33.0d + "'", double2 == 33.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                               sophie                                               ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               sophie                                               " + "'", str2.equals("                                               sophie                                               "));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.7.0_80", "###########################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test196");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test197");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) -1, (-1), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test198");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("100#-1#10");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("#-1#10");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("###########", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 6 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test199");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation", "US");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "#########################################################################", 19);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("      ", strArray9, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("     0#-1#1#-1#-1           ", strArray5, strArray9);
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "  #04141004-1  ", (java.lang.CharSequence[]) strArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '4');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "      " + "'", str14.equals("      "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "     0#-1#1#-1#-1           " + "'", str15.equals("     0#-1#1#-1#-1           "));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "/" + "'", str18.equals("/"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test200");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "aaaaaaaaaaaaa", (java.lang.CharSequence) "   #   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test201");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test202");
        short[] shortArray4 = new short[] { (short) 100, (byte) 1, (byte) -1, (byte) 1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100414-141" + "'", str9.equals("100414-141"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0#1#100#-1", 36, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test204");
        float[] floatArray1 = new float[] { 100.0f };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0" + "'", str7.equals("100.0"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test205");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.0 0.0 100MV REVRES", (java.lang.CharSequence) "32.0#3.0#-1.0#100.0", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test206");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1", "#############################################################################################################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test207");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) ".............MV REVRES.............                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test208");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test210");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 6L, (long) 141);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 141L + "'", long3 == 141L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test211");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                             794471                                              ", (java.lang.CharSequence) "aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test212");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ################################################### 100 1 10 10 0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("        10", "MV revreS ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        10" + "'", str2.equals("        10"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test214");
        float[] floatArray6 = new float[] { 0.0f, 0.0f, 100.0f, (short) 100, 1, 0L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str8.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str10.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str14.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test215");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/", 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 3300);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test217");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie", "100.0A-1.0A100.0A0.0A52.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test218");
        char[] charArray8 = new char[] { '#', '4', '4', 'a', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "oRACLE cORPORATION", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10A1A1A10A100", charArray8);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ', 0, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "##4#4#a##" + "'", str12.equals("##4#4#a##"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test219");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, charSequence1, 141);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("xtensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:" + "'", str1.equals("XTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test221");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("44444444444444444444444444444444", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("3", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3" + "'", str3.equals("3"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test223");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "....R.....", charSequence1, (int) (short) 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test224");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "                                                                                            Mac OS X", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test225");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test226");
        java.lang.CharSequence charSequence7 = null;
        java.lang.CharSequence charSequence8 = null;
        char[] charArray12 = new char[] { 'a', '4' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny(charSequence8, charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence7, charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "00414-141", charArray12);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                               sophie                                     ...", charArray12);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "##4#4#a##             ", charArray12);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ".\n5", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("44444444444444444444444444444444                                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444                                                                  " + "'", str1.equals("44444444444444444444444444444444                                                                  "));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test228");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51595_1560278762/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 1, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test229");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.8");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "4444444444444444US44444444444444444", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "14.48" + "'", str5.equals("14.48"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("jav...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jav..." + "'", str1.equals("jav..."));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test231");
        long[] longArray1 = new long[] { 174 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 174L + "'", long2 == 174L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "174" + "'", str4.equals("174"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 174L + "'", long5 == 174L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test232");
        double[] doubleArray5 = new double[] { 100.0f, (-1L), (byte) 100, (short) 0, 52 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 5, (int) (short) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 -1.0 100.0 0.0 52.0" + "'", str7.equals("100.0 -1.0 100.0 0.0 52.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.0 -1.0 100.0 0.0 52.0" + "'", str13.equals("100.0 -1.0 100.0 0.0 52.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test233");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("     174497", 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a001" + "'", str1.equals("1a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a0011a1-a1a001"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test235");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1", 73, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test236");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "10100110100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("-1 #-1#1#-1# 0", "#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 #-1#1#-1# 0" + "'", str2.equals("-1 #-1#1#-1# 0"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test238");
        int[] intArray1 = new int[] { '4' };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52" + "'", str3.equals("52"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test239");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("44444444444444444444444444444", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test240");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("printerjo");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "100.0#-...");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "printerjo" + "'", str3.equals("printerjo"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test241");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "a 4 a #                                                                                                                                                            ", (java.lang.CharSequence) "XTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test242");
        long[] longArray6 = new long[] { (short) -1, (short) 1, 10, 1L, (short) 10, 100L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1a1a10a1a10a100" + "'", str11.equals("-1a1a10a1a10a100"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                   " + "'", str2.equals("                   "));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test244");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "Mode mixed", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("100.0#-...", "MV revreS tiB-46 )MT(topStoH avaJUTF-8              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0#-..." + "'", str2.equals("100.0#-..."));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("10 100 1 10 10 ", "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10 100 1 10 10 /Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:10 100 1 10 10 /Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:10 100 1 10 10 " + "'", str3.equals("10 100 1 10 10 /Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:10 100 1 10 10 /Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:10 100 1 10 10 "));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test247");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("class [Jclass [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class [Jclass [Ljava.lang.String;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test248");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 7, (float) 33L, (float) 33);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 7.0f + "'", float3 == 7.0f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("100#-1#104444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "0.0     1744970.0     174497100.0     174497100.0     1744971.0     1744970.0", "51.0#");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test250");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "", (int) ' ', 27);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test251");
        int[] intArray2 = new int[] { 174, 'a' };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', (int) (byte) 100, 22);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 174 + "'", int3 == 174);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "174 97" + "'", str10.equals("174 97"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "174 97" + "'", str14.equals("174 97"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test252");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 10L, (long) 20);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 20L + "'", long3 == 20L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test253");
        float[] floatArray1 = new float[] { 100.0f };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0" + "'", str7.equals("100.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test254");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("51.51.5HI!", ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "51.51.5HI!" + "'", str4.equals("51.51.5HI!"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test255");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.51.51.51.51.51.51.51.51.51.", "");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test256");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4444444444444444444444JavaPlatformAPISpecification44444444444444444444444", "Java(TM) SE Runtime Environmen");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test257");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Oracle#-1#Corporation4441.4", (java.lang.CharSequence) "JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51JAVAPLATFORMAPISPECIFICA                      51.51.5HI!JAVAPLATFORMAPISPECIFICA                      51.51", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test258");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("http:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":ptth" + "'", str1.equals(":ptth"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 140, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                            " + "'", str3.equals("                                                                                                                                            "));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test260");
        byte[] byteArray3 = new byte[] { (byte) 100, (byte) -1, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ', (int) ' ', (int) ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100#-1#10" + "'", str5.equals("100#-1#10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test261");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "7");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "174110.0551.052", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test262");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "0.0a0.0a100.0a100.0a1.0a0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test263");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 10, (short) 7);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa..." + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa..."));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test265");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.7", (int) (short) 100, 163);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test266");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test267");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52L, 0.0d, (double) 2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test268");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test269");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "en                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test270");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100#3#24#163#1#####", 20, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#3#24#163#1##### " + "'", str3.equals("100#3#24#163#1##### "));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.74444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.74444444444444444444444444" + "'", str1.equals("1.74444444444444444444444444"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test272");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "                                ", 33);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test273");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 800, (double) ' ', (double) 20L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 800.0d + "'", double3 == 800.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sun.lwawt.macosx.CPrinterJob", "1A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100" + "'", str2.equals("1A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test276");
        char[] charArray10 = new char[] { '4', ' ', '4', ' ', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "               sophie               ", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "un.lwawt.macosx.CPrinterJob51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.5", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Lihie/Lib", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100 1 -1 ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.74444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7444444444444444444444444" + "'", str1.equals("1.7444444444444444444444444"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test279");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("oRACLE cORPORATION", (int) (short) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oRACLE cORPORATION" + "'", str3.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test280");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("...-#0.001");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test281");
        char[] charArray7 = new char[] { 'a', '4', 'a', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100#-1#10", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444", charArray7);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test282");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0141-4001", (java.lang.CharSequence) "0#1#0#1#1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test283");
        double[] doubleArray5 = new double[] { 100.0f, (-1L), (byte) 100, (short) 0, 52 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 -1.0 100.0 0.0 52.0" + "'", str7.equals("100.0 -1.0 100.0 0.0 52.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0 -1.0 100.0 0.0 52.0" + "'", str10.equals("100.0 -1.0 100.0 0.0 52.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test284");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "##4#4#4##", (java.lang.CharSequence) "                                                                                 4                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test285");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/...", charSequence1, 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test286");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java V rtual Mach n  Sp c f cat  n", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1040410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test288");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JAVAPLATFORMAPISPECIFICA", (java.lang.CharSequence) "10 1 1 10 100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("44444444444444444444444444444444                                                                  ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4a#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444                                                                  " + "'", str2.equals("44444444444444444444444444444444                                                                  "));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.3", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test291");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "en                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "10a100a1a...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aa51.51.51.51.51.51.51.51.51.51.R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aa51.51.51.51.51.51.51.51.51.51.R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR" + "'", str1.equals("R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aa51.51.51.51.51.51.51.51.51.51.R...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR...aaR"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test294");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 3, (short) 7, (short) 7);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 3 + "'", short3 == (short) 3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test296");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("51.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test297");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4a#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "######################", ".R...R...R...R...R...R...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test298");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "class [Jclass [Ljava.lang.String;", (java.lang.CharSequence) "1040410", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100", ".\n5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100" + "'", str2.equals("A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test300");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "5 .", (java.lang.CharSequence) "1a11a11a11aprinterjo");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("8.1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMV revreS tiB-46 )MT(topStoH avaJaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8.1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("8.1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test303");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(" ################################################### 100 1 10 10 0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test304");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "0#-1#1#-1#-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "14.48");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("4444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444" + "'", str1.equals("4444444444"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_r7ndoop.pl_51595_1560278762", (java.lang.CharSequence) "32#0#3#0#-##0##00#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test307");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                           ", "Java V rtual Mach n  Sp c f cat  n");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("        1a", 100, 1440);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test309");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation", "US");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "#########################################################################", 19);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("      ", strArray10, strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("     0#-1#1#-1#-1           ", strArray6, strArray10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 4 a #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray10);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray10);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "      " + "'", str15.equals("      "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "     0#-1#1#-1#-1           " + "'", str16.equals("     0#-1#1#-1#-1           "));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("10a1a1a10a100", "                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a1a1a10a100" + "'", str2.equals("10a1a1a10a100"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test311");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                                                                                              ", (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test312");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/", 99);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "MV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRES", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test313");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.3", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "1.7.0_80");
        java.lang.String[] strArray7 = null;
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("174497", strArray4, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " x86_64", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.3" + "'", str6.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "174497" + "'", str8.equals("174497"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test314");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("javaplatformapispecifica", (short) 7);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 7 + "'", short2 == (short) 7);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test315");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("174497", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("001a01a1a01a1a1-", "1.7444444444444444444444444", "HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "001a01a1a01a1a1-" + "'", str3.equals("001a01a1a01a1a1-"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test317");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification", "   #  ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test318");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/...", '4');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("hi!", "1a1", "794471");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test320");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                      51.51.5hi!");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Exte", (java.lang.CharSequence[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("SUN.LWAWT.MACOSX.CPRINTERJOB", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJOB" + "'", str3.equals("SUN.LWAWT.MACOSX.CPRINTERJOB"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test322");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 3, (double) 51.0f, (double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.0d + "'", double3 == 51.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test323");
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray8 = new char[] { 'a', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny(charSequence4, charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("100a1a-1a", "           0-11-1-1            ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a1a-1a" + "'", str3.equals("100a1a-1a"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test325");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("....................................................", "");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...................................................." + "'", str3.equals("...................................................."));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("class[Ljava.lang.Object;class[Ljava.lang.String;class[Bclass[Ljava.lang.String;", "################################################51.0################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test327");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("0#1#0#1#1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#1#0#1#1" + "'", str1.equals("0#1#0#1#1"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("     0#-1#1#-1#-1           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "     0#-1#1#-1#-1           " + "'", str1.equals("     0#-1#1#-1#-1           "));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "0 1 0 1 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "10a100a1a...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test331");
        int[] intArray1 = new int[] { '4' };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52" + "'", str3.equals("52"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52" + "'", str6.equals("52"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52" + "'", str8.equals("52"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sophie", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test333");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 10, 5L, (long) 163);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("32.0#3.0#-1.0#100.", (int) (short) 1, 141);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2.0#3.0#-1.0#100." + "'", str3.equals("2.0#3.0#-1.0#100."));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(".:4V4J/BIL/RSU/:SNOISNETXE/4V4J/YR4RBIL/METSYS/:SNOISNETXE/4V4J/YR4RBIL/KROWTEN/:SNOISNETXE/4V4J/YR4RBIL/:SNOISNETXE/4V4J/YR4RBIL/EIHPOS/SRESU/P/RUN_R7NDOOP.PL_51595_1560278762", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".:4V4J/BIL/RSU/:SNOISNETXE/4V4J/YR4RBIL/METSYS/:SNOISNETXE/4V4J/YR4RBIL/KROWTEN/:SNOISNETXE/4V4J/YR4RBIL/:SNOISNETXE/4V4J/YR4RBIL/EIHPOS/SRESU/P/RUN_R7NDOOP.PL_51595_1560278762" + "'", str2.equals(".:4V4J/BIL/RSU/:SNOISNETXE/4V4J/YR4RBIL/METSYS/:SNOISNETXE/4V4J/YR4RBIL/KROWTEN/:SNOISNETXE/4V4J/YR4RBIL/:SNOISNETXE/4V4J/YR4RBIL/EIHPOS/SRESU/P/RUN_R7NDOOP.PL_51595_1560278762"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test336");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "######################", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test337");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMV revreS tiB-46 )MT(topStoH avaJaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test338");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Oracle Corporation0141-40010141-40010141-40010141-40010141-40010141-40010141-40010141-40010141-4001", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4a#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test339");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 3, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test340");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test341");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "MV REVR", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test342");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 28, 6.0f, 214.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 214.0f + "'", float3 == 214.0f);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test343");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "10 1 1 10 100", (java.lang.CharSequence) "                                                                                                                                                                                                     Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test344");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("####################################################################################################", "141a1.0a10a1004-14", 800);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                 4                                                                                 ", (int) (short) 10, "     0#-1#1#-1#-1               0#-1#1#-1#-1               0#-1#1#-1#-1          ....................................................     0#-1#1#-1#-1               0#-1#1#-1#-1               0#-1#1#-1#-1          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                 4                                                                                 " + "'", str3.equals("                                                                                 4                                                                                 "));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test346");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 33, 28);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                                                                                                                     0#1#100#-1", "             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test348");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("   #   ", "", 97);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "MV REVR");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test349");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                                                                                                                                     0#1#100#-1", ":4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/", "Oracle#-1#Corporation4441.4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                     0#1#100#-1" + "'", str3.equals("                                                                                                                                     0#1#100#-1"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("un.lwawt.macosx.CPrinterJob51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.5", "10.14.3", "100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1100a1a-1a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "un.lwawt.macosx.CPrinterJob51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.5" + "'", str3.equals("un.lwawt.macosx.CPrinterJob51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.5"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "100a-1a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test352");
        short[] shortArray4 = new short[] { (short) 0, (byte) 1, (short) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "04141004-1" + "'", str7.equals("04141004-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "MacOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test354");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Oracle Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test355");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test356");
        java.math.BigDecimal[][][] bigDecimalArray0 = new java.math.BigDecimal[][][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray0);
        org.junit.Assert.assertNotNull(bigDecimalArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test357");
        double[] doubleArray5 = new double[] { 100.0f, (-1L), (byte) 100, (short) 0, 52 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.Class<?> wildcardClass10 = doubleArray5.getClass();
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 -1.0 100.0 0.0 52.0" + "'", str7.equals("100.0 -1.0 100.0 0.0 52.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0a-1.0a100.0a0.0a52.0" + "'", str9.equals("100.0a-1.0a100.0a0.0a52.0"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.0 -1.0 100.0 0.0 52.0" + "'", str13.equals("100.0 -1.0 100.0 0.0 52.0"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test358");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.4", "####################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test359");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("0a-1a1a...", "Oracle Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1a1.0a10a100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a-1a1a..." + "'", str3.equals("0a-1a1a..."));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("32#0#3#0#-##0##00#0", "1.7oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRA", "Mac OS Xen                                                  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32#0#3#0#-##0##00#0" + "'", str3.equals("32#0#3#0#-##0##00#0"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test362");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1/var/folders/_v/6v597zmna_v31cq2n2x1nafc0000gn/T/1.0/var/folders/_v/6v597zmna_v31cq2n2x1nafc0000gn/T/10/var/folders/_v/6v597zmna_v31cq2n2x1nafc0000gn/T/100", "0.25A0.0A0.001A0.1-A0.001");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("...................................................", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "..................................................." + "'", str2.equals("..................................................."));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "0#1#100#-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#1#100#-1" + "'", str2.equals("0#1#100#-1"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test365");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "class[Ljava.lang.Object;class[Ljava.lang.String;class[Bclass[Ljava.lang.String;", 35, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test366");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob", "00414-141", 0);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str4.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart(":ptth", "/Users/sophie/Libr4ry/J4v4/Exte");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":ptth" + "'", str2.equals(":ptth"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "1#1#0#1#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                                                                                                                                   ", 214, 140);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("un.lwawt.macosx.CPrinterJob51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.5", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test371");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "100.04-1.04100.040.0452.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                   ", 3, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                   " + "'", str3.equals("                   "));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("JavaPlatformAPISpecification", 30, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaPlatformAPISpecification##" + "'", str3.equals("JavaPlatformAPISpecification##"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                                 Mac OS X", 4, (int) (short) 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   " + "'", str3.equals("   "));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", 36, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + "'", str3.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("JavaPlatformAPISpecification", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaPlatformAPISpecification" + "'", str2.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("HTTP://JAVA.ORACLE.COM/", "1.7444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7444444444444444444444444" + "'", str2.equals("1.7444444444444444444444444"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test378");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                                en                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test379");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 18, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                  " + "'", str3.equals("                  "));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "######################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                                                                                                                                     Oracle Corporatio", "   #    ", "#################################################################################################");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "sun.lwawt.mac");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test383");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1a1", "sun.awt.CGraphicsEnvironment", 10);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1a1");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("########", "noitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "########" + "'", str2.equals("########"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test385");
        float[] floatArray1 = new float[] { 100.0f };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', 163, 12);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("HTTP://JAVA.ORACLE.COM/", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HTTP://JAVA.ORACLE.COM/" + "'", str2.equals("HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test387");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Platform API Specification", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "################################################51.0################################################", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ".", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0#-1#1#-1#-", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("##4#4#a##", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                             ##4#4#a##                                              " + "'", str2.equals("                                             ##4#4#a##                                              "));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test389");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 11, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test390");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/UTF-8###############################/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test391");
        byte[] byteArray3 = new byte[] { (byte) 100, (byte) -1, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        java.lang.Class<?> wildcardClass6 = byteArray3.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 3, (int) (short) 1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "Java(TM) SE Runtime Environmen");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Java(TM) SE Runtime Environmen");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100#-1#10" + "'", str5.equals("100#-1#10"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1004-1410" + "'", str12.equals("1004-1410"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100#-1#10" + "'", str14.equals("100#-1#10"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("1a1.0a10a100", "-141410414104100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a1.0a10a100" + "'", str2.equals("1a1.0a10a100"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test393");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0a-1a1a...wawt.macosx.CP");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test394");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("class [Jclass [Ljava.lang.String;", "JavaPlatformAPISpecification##", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", (-1), 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test397");
        long[] longArray6 = new long[] { (short) -1, (short) 1, 10, 1L, (short) 10, 100L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1 1 10 1 10 100" + "'", str11.equals("-1 1 10 1 10 100"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Jav...                                                                                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Jav..." + "'", str1.equals("Jav..."));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test399");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification0 1 100 -1            Java Virtual Machine Specification", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test401");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "0a1a0a1a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test402");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("MV REVRES", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test403");
        int[] intArray2 = new int[] { 174, 'a' };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', 93, 27);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', (int) (byte) 10, 10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 174 + "'", int3 == 174);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "174497" + "'", str5.equals("174497"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "174a97" + "'", str11.equals("174a97"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "174497" + "'", str17.equals("174497"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test404");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        java.lang.String str6 = javaVersion4.toString();
        boolean boolean7 = javaVersion1.atLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7" + "'", str6.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test405");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                    ", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test406");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOB", (java.lang.CharSequence) "174 97", (int) (short) 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0100.0 -1.0 100.0 0.0 52.0", "                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  " + "'", str2.equals("                  "));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0.0 0.0 100.0 100.0 1.0 0.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0 0.0 100.0 100.0 1.0 0.0" + "'", str2.equals("0.0 0.0 100.0 100.0 1.0 0.0"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test409");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("un.lwawt.macosx.CPrinterJob");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "http:");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                 4                                                                                 ", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "class [Ljava.lang.Object;class [Ljava.lang.String;class [Bclass [Ljava.lang.String;", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("oRACLE cORPORATION", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oRACLE cORPORATION" + "'", str3.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test411");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("100A1A-1A1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100A1A-1A1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaaaaaa     174497aaaaaaaaaaa", "100#-1#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaa     174497aaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaa     174497aaaaaaaaaaa"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test413");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("100a1a-1a1", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test414");
        double[] doubleArray4 = new double[] { ' ', 3, (byte) -1, (short) 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 10, 6);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 22, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 22");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test415");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("un/5", "44a");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test416");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("#-1#", "7", 27);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "########", (java.lang.CharSequence[]) strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(".:4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/", strArray5, strArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJ", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + ".:4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/" + "'", str12.equals(".:4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1004-1410", "a#4#aoR...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1004-1410" + "'", str2.equals("1004-1410"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test418");
        long[] longArray6 = new long[] { (short) -1, (short) 1, 10, 1L, (short) 10, 100L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1 1 10 1 10 100" + "'", str10.equals("-1 1 10 1 10 100"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1 1 10 1 10 100" + "'", str14.equals("-1 1 10 1 10 100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-141410414104100" + "'", str16.equals("-141410414104100"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("     174497", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     174497" + "'", str2.equals("     174497"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("        1A", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        1A" + "'", str2.equals("        1A"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test421");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0a1a0a1a1" + "'", str12.equals("0a1a0a1a1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "041404141" + "'", str14.equals("041404141"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0 1 0 1 1" + "'", str16.equals("0 1 0 1 1"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test422");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Exten");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test423");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("MV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVRMV REVR", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test424");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("un.lwawt.macosx.CPrinterJob");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "US", (int) (byte) 100);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "1a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a100");
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray9);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.0", strArray4, strArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "mode mixed", (java.lang.CharSequence[]) strArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '#');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "51.51.5hi!", (java.lang.CharSequence[]) strArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '#', 35, (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "51.0" + "'", str13.equals("51.0"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/...", "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test426");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1 1 10 1 10 100", (java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test427");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10#1#1#10#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (short) 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#####" + "'", str2.equals("#####"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test429");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger(".............MV REVRES.............                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".............MV REVRES.............                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test430");
        char[] charArray6 = new char[] {};
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Platform API Specification", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "################################################51.0################################################", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ".", charArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 214, (int) ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.6", charArray6);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "PrinterJo", charArray6);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "javaplatformapispecifica", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("5\n.", "4444444444444444US44444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5\n." + "'", str2.equals("5\n."));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test432");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "US", (int) (byte) 100);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "1a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a1001a1.0a10a100");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence[]) strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test433");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "Oracle#-1#Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("....r.........r.........r.........r.........r.........r.........r.........r.........r......r.........r.........r.........r.........r.........r.........r.........r.........r..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "....r.........r.........r.........r.........r.........r.........r.........r.........r......r.........r.........r.........r.........r.........r.........r.........r.........r.." + "'", str1.equals("....r.........r.........r.........r.........r.........r.........r.........r.........r......r.........r.........r.........r.........r.........r.........r.........r.........r.."));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(".:4V4J/BIL/RSU/:SNOISNETXE/4V4J/YR4RBIL/METSYS/:SNOISNETXE/4V4J/YR4RBIL/KROWTEN/:SNOISNETXE/4V4J/YR4RBIL/:SNOISNETXE/4V4J/YR4RBIL/EIHPOS/SRESU/P/RUN_R7NDOOP.PL_51595_1560278762", "noitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJnoitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".:4V4J/BIL/RSU/:SNOISNETXE/4V4J/YR4RBIL/METSYS/:SNOISNETXE/4V4J/YR4RBIL/KROWTEN/:SNOISNETXE/4V4J/YR4RBIL/:SNOISNETXE/4V4J/YR4RBIL/EIHPOS/SRESU/P/RUN_R7NDOOP.PL_51595_1560278762" + "'", str2.equals(".:4V4J/BIL/RSU/:SNOISNETXE/4V4J/YR4RBIL/METSYS/:SNOISNETXE/4V4J/YR4RBIL/KROWTEN/:SNOISNETXE/4V4J/YR4RBIL/:SNOISNETXE/4V4J/YR4RBIL/EIHPOS/SRESU/P/RUN_R7NDOOP.PL_51595_1560278762"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test436");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4, 0, 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test437");
        char[] charArray9 = new char[] { '4', ' ', '4', ' ', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', 0, 1);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "##4#4#a##             ", charArray9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4" + "'", str15.equals("4"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1-1 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test439");
        long[] longArray6 = new long[] { (short) -1, (short) 1, 10, 1L, (short) 10, 100L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', (int) (byte) 10, 6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        long long15 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1 1 10 1 10 100" + "'", str14.equals("-1 1 10 1 10 100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test440");
        java.lang.CharSequence charSequence4 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray9 = new char[] { 'a', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence5, charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A1001A1.0A10A100", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "3", charArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "a 4" + "'", str18.equals("a 4"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04..." + "'", str2.equals("...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04...04..."));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                             ##4#4#a##                                              ", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                             ##4#4#a##                                              " + "'", str2.equals("                                             ##4#4#a##                                              "));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test443");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray8 = new char[] { 'a', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny(charSequence4, charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                            Mac OS X", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray8);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', (int) (short) 1, 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 93 + "'", int12 == 93);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test444");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Exten", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                      51.51.5hi!", 93);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!" + "'", str2.equals("                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!                      51.51.5hi!"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("44444444444444444444444444444444", "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test447");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                           ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test448");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("            ", "     http:");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "            " + "'", str3.equals("            "));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test449");
        double[] doubleArray4 = new double[] { ' ', 3, (byte) -1, (short) 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', 33, 22);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("01100-", " ###################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "01100-" + "'", str2.equals("01100-"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test451");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n5\n.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test452");
        float[] floatArray1 = new float[] { 100.0f };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100.0" + "'", str5.equals("100.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Lihie/Lib", "1#1#0#1#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Lihie/Lib" + "'", str2.equals("/Lihie/Lib"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test454");
        java.lang.CharSequence charSequence3 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray8 = new char[] { 'a', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny(charSequence4, charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ".:4v4j/bil/rsu/:snoisnetxe/4v4j/yr4rbil/metsys/:snoisnetxe/4v4j/yr4rbil/krowten/:snoisnetxe/4v4j/yr4rbil/:snoisnetxe/4v4j/yr4rbil/eihpos/sresu/p/run_r7ndoop.pl_51595_1560278762", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test455");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.3", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test456");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test457");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("           0-11-1-1            ", "x86_64");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test458");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("un/5");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test459");
        double[] doubleArray4 = new double[] { ' ', 3, (byte) -1, (short) 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32.0 3.0 -1.0 100.0" + "'", str10.equals("32.0 3.0 -1.0 100.0"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test460");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("   #   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "10a100a1a10a10a0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test462");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        boolean boolean8 = javaVersion3.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str10 = javaVersion9.toString();
        java.lang.String str11 = javaVersion9.toString();
        java.lang.String str12 = javaVersion9.toString();
        boolean boolean13 = javaVersion3.atLeast(javaVersion9);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.2" + "'", str10.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.2" + "'", str11.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.2" + "'", str12.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test463");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle ", "", 174);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "MV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRESMV REVRES", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test464");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "                      51.51.5hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Use#-1#10", "http:", "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j...R");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Use#-1#10" + "'", str3.equals("/Use#-1#10"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test466");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("r...", "printerjo", "Mode mixed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "r..." + "'", str3.equals("r..."));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test467");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0 -1 1 -1 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test468");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        1A");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        1A\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test469");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("XTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:", 99, "44a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "XTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:" + "'", str3.equals("XTENSIONS:/LIBR4RY/J4V4/EXTENSIONS:/NETWORK/LIBR4RY/J4V4/EXTENSIONS:/SYSTEM/LIBR4RY/J4V4/EXTENSIONS:/USR/LIB/J4V4:"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test470");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test471");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100#3#24#163#1#####", 163, 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("class [Ljava.lang.Object;aclass [Ljava.lang.String;aclass [Baclass [Ljava.lang.String;", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class#[Ljava.lang.Object;aclass#[Ljava.lang.String;aclass#[Baclass#[Ljava.lang.String;" + "'", str3.equals("class#[Ljava.lang.Object;aclass#[Ljava.lang.String;aclass#[Baclass#[Ljava.lang.String;"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("#-1#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#-1#10" + "'", str1.equals("#-1#10"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test474");
        double[] doubleArray4 = new double[] { ' ', 3, (byte) -1, (short) 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#', 100, (int) (short) 4);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "32.0 3.0 -1.0 100.0" + "'", str15.equals("32.0 3.0 -1.0 100.0"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test475");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("0.0 0.0 100MV REVRES");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0#0.0#100MV#REVRES" + "'", str3.equals("0.0#0.0#100MV#REVRES"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test476");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 36, (double) 24);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 36.0d + "'", double3 == 36.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test477");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                             ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test478");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "44-4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test479");
        java.lang.Object[][] objArray0 = new java.lang.Object[][] {};
        java.lang.Object[][] objArray1 = new java.lang.Object[][] {};
        java.lang.Object[][] objArray2 = new java.lang.Object[][] {};
        java.lang.Object[][] objArray3 = new java.lang.Object[][] {};
        java.lang.Object[][][] objArray4 = new java.lang.Object[][][] { objArray0, objArray1, objArray2, objArray3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(objArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[][]) objArray4);
        org.junit.Assert.assertNotNull(objArray0);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "794471", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444noitroproC elcrO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test481");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(":4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/", "##", ".");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/" + "'", str3.equals(":4v4j/bil/rsu/:snoisnetxE/4v4J/yr4rbiL/metsyS/:snoisnetxE/4v4J/yr4rbiL/krowteN/:snoisnetxE/4v4J/yr4rbiL/:snoisnetxE/4v4J/yr4rbiL/eihpos/sresU/"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test482");
        long[] longArray4 = new long[] { 5, 52, (short) 1, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.Class<?> wildcardClass10 = longArray4.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "545241432" + "'", str12.equals("545241432"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test483");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "8.1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test484");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("MV revreS ", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aa#a a#a4aa", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test485");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test486");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sop");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "100 1 -1 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test488");
        int[] intArray1 = new int[] { '4' };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', 1, 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52" + "'", str3.equals("52"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52" + "'", str6.equals("52"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "52" + "'", str15.equals("52"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test489");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(".", 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test490");
        double[] doubleArray4 = new double[] { ' ', 3, (byte) -1, (short) 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32.0 3.0 -1.0 100.0" + "'", str10.equals("32.0 3.0 -1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "32.043.04-1.04100.0" + "'", str12.equals("32.043.04-1.04100.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test491");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "174110.0551.052", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test492");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100.0#-...", charSequence1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  Mac OS Xen                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM" + "'", str1.equals("                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM                                                  neX SO caM"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test494");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "   #  ", charSequence1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Oracle#-1#Corporation4441.4", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Or cle#-1#Corpor tion4441.4" + "'", str3.equals("Or cle#-1#Corpor tion4441.4"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test496");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "A1.0A10", (java.lang.CharSequence) "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/...", (int) (short) 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS IPA mroftalP avaJ" + "'", str1.equals("noitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test498");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("....r.........r.........r.........r.........r.........r.........r.........r.........r......r.........r.........r.........r.........r.........r.........r.........r.........r..", "Java HotSpot(TM) 64-Bit Server VM", "32#0#3#0#-##0##00#0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "............................................................................................................................................................" + "'", str3.equals("............................................................................................................................................................"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest10.test500");
        double[] doubleArray4 = new double[] { ' ', 3, (byte) -1, (short) 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', 100, 20);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "32.0a3.0a-1.0a100.0" + "'", str12.equals("32.0a3.0a-1.0a100.0"));
    }
}

