import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97ava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "100404-141004100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaa                                                                                          ", (java.lang.CharSequence) "01 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 ", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "10.0#100.0#-1.0#-1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1410040497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-145249");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7940400141" + "'", str1.equals("942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7940400141"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "51b-08_0.7.1                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Dk1.7.0_80.jdk/contents/home/jr", "10.0a100.0a-1.0a-1.0", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Dk1.7.0_80.jdk/contents/home/jr" + "'", str3.equals("Dk1.7.0_80.jdk/contents/home/jr"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_-56127983", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        double[] doubleArray1 = new double[] { (short) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100.0" + "'", str5.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0" + "'", str7.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0" + "'", str9.equals("100.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        float[] floatArray2 = new float[] { 10, 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0 1.0" + "'", str4.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0a1.0" + "'", str6.equals("10.0a1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0 1.0" + "'", str8.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 10.0f + "'", float10 == 10.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("tiklooTCWL.xsocam.twawl.nus");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "10.0 1.0 5.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n", (java.lang.CharSequence) "dk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("x86_64////", (int) (byte) -1, "100.0100.0100.0100.0100.0100.01 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64////" + "'", str3.equals("x86_64////"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                   1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.04-1.0467.0", "1.01.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.10.0", 520);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre", (java.lang.CharSequence) "mac os x");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        int[] intArray3 = new int[] { (short) -1, '4', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 97, 5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        int int15 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a52a97" + "'", str5.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1452497" + "'", str14.equals("-1452497"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                    sun.awt.CGraphicsEnvironmen                                     ", (java.lang.CharSequence) "iklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-1a52a97-1", (java.lang.CharSequence) "1.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "00.0 10.0 67.0", charSequence1, 520);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444...", "dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/10.04100.04-1.04-1.0dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        java.lang.Class<?> wildcardClass13 = shortArray3.getClass();
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#10#10" + "'", str6.equals("0#10#10"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0 10 10" + "'", str10.equals("0 10 10"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0#10#10" + "'", str12.equals("0#10#10"));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                         sun.awt.cgraphicsenvironmen", "Java Virtual Machine Specification", "...444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("aaaaaaaaaa                                                                                          ", "tionatform API Specifica PlavaJ                                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionatform API Specifica PlavaJ                                                                  " + "'", str2.equals("tionatform API Specifica PlavaJ                                                                  "));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("-1#52#97");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#52#97" + "'", str1.equals("-1#52#97"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0", "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051..9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0" + "'", str2.equals("10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "44444444444444444444444444444444444444444444444444444444444444...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        double[] doubleArray2 = new double[] { (short) 10, (-1.0d) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0a-1.0" + "'", str5.equals("10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(".7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", "tionatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavaJ", 68);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', 97, (int) 'a');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1 32" + "'", str7.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("00#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("6_64////");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"6_64////\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "10.0a1.0", (java.lang.CharSequence) "                                             1a100a0a97                                             ", 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "0 10 100 1", 0);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("10.0#1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0#1.0" + "'", str1.equals("10.0#1.0"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!", "01 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_-56127983", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents" + "'", str2.equals("/Users/sophie/Documents"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/Users/...", (java.lang.CharSequence) "aa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Users/..." + "'", charSequence2.equals("/Users/..."));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "\n");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "aaaaaaaaaaaa10.0a1.0");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str3.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        short[] shortArray1 = new short[] { (short) 100 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 67, (int) ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                10.0", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "79 0 001 ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                  ", " 100 100                                        ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("10.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.0", " 35.0#10.      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.0" + "'", str2.equals("10.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.0"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4444444100404-141004100", "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983", 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "35.0#10.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        double[] doubleArray1 = new double[] { (short) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100.0" + "'", str5.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0" + "'", str7.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0" + "'", str9.equals("100.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.0a10.sun.awt....");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "tionatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        char[] charArray3 = new char[] { '#', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a', 100, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray3, '#', (int) (short) 10, 0);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1A100A0A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A9", charArray3);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "#aa" + "'", str5.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "# a" + "'", str16.equals("# a"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Class<?> wildcardClass4 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "iklooTCWL.xsocam.twawl.nus", (java.lang.CharSequence) "TIONATFORM api sPECIFICA pLAVAj0.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10.0A-1.0", (java.lang.CharSequence) "tionatform API Specifica PlavaJ", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("US", "1.744444444444444444444444444444");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("100-1 32                        ", 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10.0 1.0", strArray3, strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "          ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0 1.0" + "'", str7.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "US" + "'", str9.equals("US"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("10.0 1.0 5.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0 1.0 5.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) (byte) 1, (-1));
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte18 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte19 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#100#0#-1#100#100" + "'", str10.equals("100#100#0#-1#100#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1004100404-141004100" + "'", str12.equals("1004100404-141004100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) -1 + "'", byte17 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) 100 + "'", byte18 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) 100 + "'", byte19 == (byte) 100);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("##a", "100                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##a" + "'", str2.equals("##a"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                             ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        float[] floatArray2 = new float[] { 10, 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float15 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0 1.0" + "'", str4.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0a1.0" + "'", str6.equals("10.0a1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0 1.0" + "'", str8.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 10.0f + "'", float10 == 10.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0#1.0" + "'", str12.equals("10.0#1.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 10.0f + "'", float13 == 10.0f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 10.0f + "'", float14 == 10.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 10.0f + "'", float15 == 10.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aa", "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                   " + "'", str1.equals("                   "));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("AAAAAAAAAA", "24.80-b11", 100);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0, (double) 20L, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        double[] doubleArray2 = new double[] { 10, '4' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4', 1, 69);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.0d + "'", double6 == 52.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0 10 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 10 10" + "'", str1.equals("0 10 10"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("79 0 001 ", "1.74444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "79 0 001 " + "'", str2.equals("79 0 001 "));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) ".924.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "               1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "OracleCorporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("100-1 32                        ", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        long[] longArray2 = new long[] { 0L, 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', 20, (int) (byte) 10);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0#100" + "'", str5.equals("0#100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                               \n\n                                                ", 20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               \n\n                                                " + "'", str2.equals("                                               \n\n                                                "));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1452497", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "             -1A32                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("                                               \n\n                                                ", "444444444444444444444444444444444444444444444444444444444...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               \n\n                                                " + "'", str2.equals("                                               \n\n                                                "));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("tionatformaAPIaSpecificaaPlavaJ", (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        short[] shortArray1 = new short[] { (short) 100 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 67, (int) ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", "00#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("             0.                 ", "                                                                                                    ");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "", 2, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a32" + "'", str7.equals("-1a32"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1a32" + "'", str10.equals("-1a32"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("-1a52a9");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1a52a9\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "10.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.0", charSequence1, (int) (short) 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "-1#100#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        double[] doubleArray2 = new double[] { 10, '4' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0#52.0" + "'", str8.equals("10.0#52.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(20, 92, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(520.0f, (float) (short) -1, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 520.0f + "'", float3 == 520.0f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        int[] intArray4 = new int[] { (short) 1, 100, (short) 0, 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 32, 2);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) (byte) -1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a100a0a97" + "'", str6.equals("1a100a0a97"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1a100a0a97" + "'", str8.equals("1a100a0a97"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1#100#0#97" + "'", str10.equals("1#100#0#97"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1 100 0 97" + "'", str12.equals("1 100 0 97"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0.0100.0100.0100.0100.0100.01");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents", (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("aaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaa" + "'", str1.equals("aaaaaa"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                             ", "10.0#-1.0", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("35a4a5a4a2");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/10.04100.04-1.04-1.0dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/", (double) 20.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.0d + "'", double2 == 20.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str1.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("#aa#aa#aa#aa#aa#aa#aa#aa#aa##aa#aa#aa#aa#aa#aa#aa#aa#aa#", "100#100#0#-1#100#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#aa#aa#aa#aa#aa#aa#aa#aa#aa##aa#aa#aa#aa#aa#aa#aa#aa#aa#" + "'", str2.equals("#aa#aa#aa#aa#aa#aa#aa#aa#aa##aa#aa#aa#aa#aa#aa#aa#aa#aa#"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 0);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97" + "'", str4.equals("1a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                   ", (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("4-1.0467                                                                                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4-1.0467                                                                                         " + "'", str1.equals("4-1.0467                                                                                         "));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "tionatform API Specifica PlavaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.0a10.0", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "00", (java.lang.CharSequence) "100-1 32                        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("IKLOOTCWL.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "IKLOOTCWL.XSOCAM.TWAWL.NUS" + "'", str1.equals("IKLOOTCWL.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("-1#100#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("6_64////", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 6_64////" + "'", str2.equals(" 6_64////"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents", "IKLOOtcwl.XSOCAM.TWAWL.NUS", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.8", "444444444444444444444444444444444444444444444444444444444444444444444100.0100.0100.0100.0100.0100.01");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!IH" + "'", str1.equals("!IH"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "dk1.7.0_80.jdk/contents/home/jr1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        char[] charArray3 = new char[] { '#', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray3, '4');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                               UTF-8", charArray3);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray3, '#', (-1), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "#aa" + "'", str5.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#4a" + "'", str7.equals("#4a"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "79 0 001 ", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("IKLOOTCWL.XSOCAM.TWAWL.NUS444444444444444444444444444444", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "IKLOOTCWL.XSOCAM.TWAWL.NUS444444444444444444444444444444" + "'", str2.equals("IKLOOTCWL.XSOCAM.TWAWL.NUS444444444444444444444444444444"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                        100 100 0 -1 100 100                                        ", "1004100404-141004100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "10.0a-1.0");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 9, 7);
        java.lang.Class<?> wildcardClass8 = strArray3.getClass();
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100L, (float) (short) -1, (float) 68);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("     ", "http://java.oracle.com/                       ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     " + "'", str3.equals("     "));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.awt....sun.awt....sun.awt....sunJava Platform API Specification", (java.lang.CharSequence) "00.0 10.0 67.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("MacOSX");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MacOSX\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java(TM) SE ROracleCorporatioments/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                   1.7.0_80-b15", "                                                                                               UTF-8", (int) (short) 100);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "4444444sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("100 100 0 -1 100 100", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 100 0 -1 100 100" + "'", str2.equals("100 100 0 -1 100 100"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.awt....sun.awt....sun.awt....sunJava Platform API Specification", (java.lang.CharSequence[]) strArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ".", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str6.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) -1, (int) (byte) 100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                         sun.awt.cgraphicsenvironmen", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n" + "'", str2.equals("n"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(10, 31, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        double[] doubleArray3 = new double[] { 10.0d, (-1), 67 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.04-1.0467.0" + "'", str5.equals("10.04-1.0467.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 67.0d + "'", double6 == 67.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 67.0d + "'", double7 == 67.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "7", (java.lang.CharSequence) "44#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_-56127983", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", ".9", "10.04-1.0467.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560210.04-1.0467.835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560210.04-1.0467.835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                              1#52#97", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                              1#52#97" + "'", str2.equals("                                                              1#52#97"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                              1.");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "ES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', 52, 13);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', 17, 67);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 17");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 10 + "'", short9 == (short) 10);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 68, (long) 20);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("!IH", "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_-56127983", "http://jv.orcle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!IH" + "'", str3.equals("!IH"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                                    ", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                 " + "'", str2.equals("                 "));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "1.744444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', (-1), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1 32" + "'", str7.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("4-1.0467                                                                                         ", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4-1.0467                        ..." + "'", str2.equals("4-1.0467                        ..."));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nUTF-8\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", 34);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"    \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "100.0100.0100.0100.0100.0100.01", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560210.04-1.0467.835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("32       ", 52, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                     32                             " + "'", str3.equals("                     32                             "));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(35.0f, 2.0f, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("TIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"TIONA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("####################", "a100#100#0#-1#100#100100#100#0#-1#1", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("SUN.LWAWT.MACOSX.LWCTOOLKI", "/Users/...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKI" + "'", str2.equals("SUN.LWAWT.MACOSX.LWCTOOLKI"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        char[] charArray3 = new char[] { '#', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a', 100, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray3, '#', (int) (short) 10, 0);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0.9", charArray3);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "#aa" + "'", str5.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "#aa" + "'", str16.equals("#aa"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 11, 20.0f, 96.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 96.0f + "'", float3 == 96.0f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n", 5L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (double) 520.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 520.0d + "'", double2 == 520.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("-1A32                  ", 2, 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1A32   ..." + "'", str3.equals("-1A32   ..."));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("10.0#1.0", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0#1.0  " + "'", str2.equals("10.0#1.0  "));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        int[] intArray3 = new int[] { (short) -1, '4', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', (int) '4', (int) (short) -1);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', (int) (short) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a52a97" + "'", str5.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "32#-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("ass [J", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [J" + "'", str2.equals("ass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [J"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        char[] charArray4 = new char[] { '4', '#' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                              1.7", charArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 1, (int) (short) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray4, '4');
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKI", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4a#" + "'", str11.equals("4a#"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4 #" + "'", str13.equals("4 #"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4a#" + "'", str15.equals("4a#"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "44#" + "'", str17.equals("44#"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("- 32", "7                                  ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "           10.0#-1.0", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("JAVA(TM) SE RUNTIME ENVIRONMENT", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("32       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32       " + "'", str1.equals("32       "));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("51b-08_0.7.1                   ", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', (int) (short) 0, 1);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1" + "'", str8.equals("-1"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(96.0f, (float) 56, 97.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                       100#100#0#-1#100#100                        ", "-1a52a97");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        float[] floatArray2 = new float[] { 10, 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', (int) ' ', (int) (byte) 0);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (-1), (int) (byte) -1);
        float float16 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0 1.0" + "'", str4.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0a1.0" + "'", str11.equals("10.0a1.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10.0#1.0" + "'", str18.equals("10.0#1.0"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle Corporation                                  ", "sophie", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#100" + "'", str1.equals("0#100"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100-132100-132100-1tionatformaAPIaSpecificaaPlavaJ100-132100-132100-1", "http://jv.orcle.com/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#4a", "SUN.LWAWT.MACOSX.lwctOOLKI");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1A32                  ", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Dk1.7.0_80.jdk/contents/home/j", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Dk1.7.0_80.jdk/contents/home/j" + "'", str2.equals("Dk1.7.0_80.jdk/contents/home/j"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Oracle Corporation", "######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(20, (-1), 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0_80.JDK/CONTENTS/HOME/JRE", '4');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.lwctoolki", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("10a1a0a100a-1", "", 17);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a1a0a100a-1" + "'", str3.equals("10a1a0a100a-1"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("TIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("x86_64////", "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre", 69);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7940400141", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "IKLOOtcwl.XSOCAM.TWAWL.NUS", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "                         sun.awt.cgraphicsenvironmen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        char[] charArray4 = new char[] { '#', 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444444sun.lwawt.macosx.CPrinterJob", charArray4);
        java.lang.Class<?> wildcardClass9 = charArray4.getClass();
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("/", "TIONATFORM api sPECIFICA pLAVAj");
        java.lang.Class<?> wildcardClass13 = strArray12.getClass();
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.split("/", "TIONATFORM api sPECIFICA pLAVAj");
        java.lang.Class<?> wildcardClass17 = strArray16.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray18 = new java.lang.reflect.GenericDeclaration[] { wildcardClass9, wildcardClass13, wildcardClass17 };
        java.lang.reflect.GenericDeclaration[][] genericDeclarationArray19 = new java.lang.reflect.GenericDeclaration[][] { genericDeclarationArray18 };
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray19);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "#aa" + "'", str6.equals("#aa"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(genericDeclarationArray18);
        org.junit.Assert.assertNotNull(genericDeclarationArray19);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                    ", "100#100#0#-1#100#100", 92);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Documents", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "                                                                       1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', 52, 13);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 10 + "'", short9 == (short) 10);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 10 + "'", short10 == (short) 10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0a10a10" + "'", str12.equals("0a10a10"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "aa", (java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051..9");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', (int) (byte) 100, (int) (short) 1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', 7, 2);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0 1.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion[] javaVersionArray3 = new org.apache.commons.lang3.JavaVersion[] { javaVersion0 };
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion[] javaVersionArray7 = new org.apache.commons.lang3.JavaVersion[] { javaVersion4 };
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean10 = javaVersion8.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion[] javaVersionArray11 = new org.apache.commons.lang3.JavaVersion[] { javaVersion8 };
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean14 = javaVersion12.atLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion[] javaVersionArray15 = new org.apache.commons.lang3.JavaVersion[] { javaVersion12 };
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean18 = javaVersion16.atLeast(javaVersion17);
        org.apache.commons.lang3.JavaVersion[] javaVersionArray19 = new org.apache.commons.lang3.JavaVersion[] { javaVersion16 };
        org.apache.commons.lang3.JavaVersion[][] javaVersionArray20 = new org.apache.commons.lang3.JavaVersion[][] { javaVersionArray3, javaVersionArray7, javaVersionArray11, javaVersionArray15, javaVersionArray19 };
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(javaVersionArray20);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(javaVersionArray3);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(javaVersionArray7);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(javaVersionArray11);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(javaVersionArray15);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(javaVersionArray19);
        org.junit.Assert.assertNotNull(javaVersionArray20);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VM444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "sun.lwawt.macosx.lwctoolki");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                1.                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                1.                 " + "'", str1.equals("                1.                 "));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        char[] charArray5 = new char[] { '4', '#' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                              1.7", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "32       ", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "B", (java.lang.CharSequence) ".1                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        char[] charArray4 = new char[] { '#', 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 100, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray4, '#', (int) (short) 10, 0);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ".7.0_80-B15", charArray4);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray4, '#', 1, (int) (short) 0);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "35.0#10.", charArray4);
        java.lang.Class<?> wildcardClass23 = charArray4.getClass();
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "#aa" + "'", str6.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "##a" + "'", str17.equals("##a"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "mac os x", (java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("-1a52a9", "10.0 1.0", 68);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a9" + "'", str3.equals("-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a9"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.awt....sun.awt....sun.awt....sunJava Platform API Specificatio", 34, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        java.lang.String str5 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.9" + "'", str5.equals("0.9"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10.0#-1.0#67.0", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0#-1.0#67.0" + "'", str2.equals("10.0#-1.0#67.0"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("520.0#100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"520.0#100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 23, 0.0d, 32.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1#52#97");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1#52#97\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("00", "1.7.0_80-b15", (int) (short) 1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(" 100 100                                        ", "1410040497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-145249", 56, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " 100 100  1410040497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-145249" + "'", str4.equals(" 100 100  1410040497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-145249"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("44444444444444444444444444444444444444444444444444444444444444...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("51.0                                                                                                ", "TIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0                                                                                                " + "'", str2.equals("51.0                                                                                                "));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "mac os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("# a", (-1), 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "# a" + "'", str3.equals("# a"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a910.0 1.0-1a52a9", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("444444444444444444444444444444444444444444444444444444444...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444444...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11#########", "444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 2.0d, (double) 9);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0#10#10" + "'", str9.equals("0#10#10"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("...rs/_...", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/", "TIONATFORM api sPECIFICA pLAVAj");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "00.0410.0467.0", (int) (short) 10, (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                       100#100#0#-1#100#100                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                       100#100#0#-1#100#100                        \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(73, 6, 56);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("TIONATFORM api sPECIFICA pLAVAj", 23L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 23L + "'", long2 == 23L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        char[] charArray5 = new char[] { '#', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100.0100.0100.0100.0100.0100.01", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 17, (int) (byte) 10);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#aa" + "'", str7.equals("#aa"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart(":", "4444444100404-141004100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("-1#52#97");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#52#9" + "'", str1.equals("-1#52#9"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "24.80-b11#########", 56);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.cgraphicsenvironment" + "'", str1.equals("sun.awt.cgraphicsenvironment"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKI", (java.lang.CharSequence) "0.0100.0100.0100.0100.0100.01");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" 100 100  1410040497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-145249", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 100 100  1410040497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-145249" + "'", str2.equals(" 100 100  1410040497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-145249"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835", (java.lang.CharSequence) "1 52 97");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835" + "'", charSequence2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "10.0A-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7942541-7940400141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "32       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                     32                             ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     32                                                  32                                                  32                                                  32                                                  32                                                  32                                                  32                                                  32                                                  32                                                  32                             " + "'", str2.equals("                     32                                                  32                                                  32                                                  32                                                  32                                                  32                                                  32                                                  32                                                  32                                                  32                             "));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("#aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#aa" + "'", str1.equals("#aa"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444100.0100.0100.0100.0100.0100.01", 56, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("01 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 0", "1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "01 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 0" + "'", str2.equals("01 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 0"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("##aOracle Cor", "", "10.0#-1.0#67.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983", (int) 'a', "Es/jdk1.7.0_80.jdk/Contents/Home/jrees/                  es/jdk1.7.0_80.jdk/Contents/Home/jrees/j");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Es/jdk1.7.0_80/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983Es/jdk1.7.0_80." + "'", str3.equals("Es/jdk1.7.0_80/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983Es/jdk1.7.0_80."));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("!IH", (double) 13.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.0d + "'", double2 == 13.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaS", (java.lang.CharSequence) "51.0                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 0, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                           35.0#10.", "0#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                           35.0#10." + "'", str2.equals("                           35.0#10."));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "7                                  ", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("...444444444444444444444444444444444444444444444444444444444444444444", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("...444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "10.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 10.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100#100#0#-1#100#100" + "'", str11.equals("100#100#0#-1#100#100"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(" 100 100  1410040497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-145249", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 100 100  1410040497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-145249" + "'", str2.equals(" 100 100  1410040497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-145249"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "51 -                                                                                                ", (java.lang.CharSequence) "01010");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("4444444sun.lwawt.macosx.CPrinterJob", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("4444444sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        char[] charArray6 = new char[] { '#', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444444sun.lwawt.macosx.CPrinterJob", charArray6);
        java.lang.Class<?> wildcardClass11 = charArray6.getClass();
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/USERS/SOPHIE", charArray6);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#aa" + "'", str8.equals("#aa"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0#10#10" + "'", str9.equals("0#10#10"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0#10#10" + "'", str11.equals("0#10#10"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', (int) (short) 7, 23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1 32" + "'", str7.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', 2, 0);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "es/jdk1.7.0_80.jdk/Contents/Home/jrees/                  es/jdk1.7.0_80.jdk/Contents/Home/jrees/j");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: es/jdk1.7.0_80.jdk/Contents/Home/jrees/                  es/jdk1.7.0_80.jdk/Contents/Home/jrees/j");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100#100#0#-1#100#100" + "'", str11.equals("100#100#0#-1#100#100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 100 + "'", byte16 == (byte) 100);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                       100#100#0#-1#100#100                        ", "-1#52#97");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       100#100#0#-1#100#100                        " + "'", str2.equals("                       100#100#0#-1#100#100                        "));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) (byte) 1, (-1));
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 2, 0);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', 520, 17);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#100#0#-1#100#100" + "'", str10.equals("100#100#0#-1#100#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1004100404-141004100" + "'", str12.equals("1004100404-141004100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 2, (float) 69, 2.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java(TM) SE ROracleCorporatioments/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA", 73);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73 + "'", int2 == 73);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "10.0a-1.0", (java.lang.CharSequence) "32                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("00#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("java HotSpot(TM) 64-Bit Server VM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "          ", (java.lang.CharSequence) ".", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents", (int) (byte) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents" + "'", str3.equals("/Users/sophie/Documents"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("ES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "-1a52a97-1a52a97-1a52a10.0a1.0-1a52a97-1a52a97-1a52a", "/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE" + "'", str3.equals("ES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a100#100#0#-1#100#100100#100#0#-1#1", "               1.7", 52);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1 32", "", (int) (byte) 100);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "a 00# 00#0#- # 00# 00 00# 00#0#- # " + "'", str6.equals("a 00# 00#0#- # 00# 00 00# 00#0#- # "));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("32#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32#-1" + "'", str1.equals("32#-1"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa" + "'", str1.equals("aa"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("0#100", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4444444100404-141004100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4444444100404-141004100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("24.80-b11#########", "- 32");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11#########" + "'", str2.equals("24.80-b11#########"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("US", "");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "-1A32   ...");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                 " + "'", str2.equals("                 "));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        double[] doubleArray2 = new double[] { (short) 10, (-1.0d) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0a-1.0" + "'", str5.equals("10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.04-1.0" + "'", str8.equals("10.04-1.0"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(".", "# a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        float[] floatArray5 = new float[] { 135432, 69, 520, 32L, 520.0f };
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 32.0f + "'", float6 == 32.0f);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("##aOracle Cor", "######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##aOracle Cor" + "'", str2.equals("##aOracle Cor"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        char[] charArray5 = new char[] { '4', '#' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                              1.7", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4a#", charArray5);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 0, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "class [Jclass org.apache.commons.lang3.JavaVersionclass [J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n", ".7.0_80-B15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("444444444", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444" + "'", str2.equals("444444444"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Cor", 50, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Coraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("Oracle Coraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sophiesophiesophiesophiesophieso/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesophiesophiesophiesophieso/Users/sophie/Documents/defectsj/tmp/run_rndoop.pl_5226_156027983" + "'", str2.equals("sophiesophiesophiesophiesophieso/Users/sophie/Documents/defectsj/tmp/run_rndoop.pl_5226_156027983"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                                                    1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        short[] shortArray1 = new short[] { (short) 100 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 67, (int) ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', (int) (short) -1, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 97, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "32       ", (java.lang.CharSequence) "TIONATFORM api sPECIFICA pLAVAj");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_-56127983", (java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "avaj/bil/" + "'", str2.equals("avaj/bil/"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "http://jv.orcle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10", "SUN.LWAWT.MACOSX.lwctOOLKI");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("S");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "dk1.7.0_80.jdk/contents/10.04100.04-1.04-1.0dk1.7.0_80.jdk/contents/", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("...rs/_...", "Oracle Cor", (int) '4');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "TIONATFORM api sPECIFICA pLAVAj0.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("n", "# a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", (int) '4', (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 520L, (float) 3, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 520.0f + "'", float3 == 520.0f);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("100#100#0#-1#100#100aaaaaaaaaaa", "                                                                                               UTF-8", 2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '4');
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " 100 100                                        ", (java.lang.CharSequence[]) strArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7.0_80", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.7.0_80" + "'", str11.equals("1.7.0_80"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("avaj/bil/rs", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/rs" + "'", str2.equals("/rs"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                           35.0#10.", (java.lang.CharSequence) "0410410");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("TIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"TIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJ\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        int[] intArray4 = new int[] { (short) 1, 100, (short) 0, 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a100a0a97" + "'", str6.equals("1a100a0a97"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1#100#0#97" + "'", str8.equals("1#100#0#97"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("4-1.0467                        ...", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0467                        ..." + "'", str2.equals("1.0467                        ..."));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "###################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                1.                 ", "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.0467                        ...", 520);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0467                        ..." + "'", str2.equals("1.0467                        ..."));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4", (java.lang.CharSequence) "                0.                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("ass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [Jass [J", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "100-132100-132100-1tionatformaAPIaSpecificaaPlavaJ100-132100-132100-1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 100-132100-132100-1tionatformaAPIaSpecificaaPlavaJ100-132100-132100-1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("avaj/bil/rs");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"av\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("00.0 10.0 67.0", "0.15", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "00.0 10.0 67.0" + "'", str3.equals("00.0 10.0 67.0"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("             ", "17.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             " + "'", str2.equals("             "));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "100#100#0#-1#100#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("avaj/bil/rs");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "0.0", (java.lang.CharSequence) "senwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("           10.0#-1.0", "44444444444444444444444444444444444444444444444444444444444444...");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                           35.0#10.", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                              JAVA3PLATFORM3API3SPECIFICATION                               ", (int) (short) 100, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                              JAVA3PLATFORM3API3SPECIFICATION                               " + "'", str3.equals("                              JAVA3PLATFORM3API3SPECIFICATION                               "));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("100#100#0#-1#100#1001100#100#0#-1#100#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100", 0, "a100#100#0#-1#100#100100#100#0#-1#1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#100#0#-1#100#1001100#100#0#-1#100#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100" + "'", str3.equals("100#100#0#-1#100#1001100#100#0#-1#100#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10.04-1.0467.10.010.04-1.0467.10.04", 50, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaa10.04-1.0467.10.010.04-1.0467.10.04aaaaaaaa" + "'", str3.equals("aaaaaaa10.04-1.0467.10.010.04-1.0467.10.04aaaaaaaa"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                 " + "'", str1.equals("                                                                                                 "));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "a", (java.lang.CharSequence) "44#", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("class [Jclass org.apache.commons.lang3.JavaVersionclass [J");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Jclass org.apache.commons.lang3.JavaVersionclass [J" + "'", str1.equals("class [Jclass org.apache.commons.lang3.JavaVersionclass [J"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "00#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.awt.CGraphicsEnvironmen", "Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironmen" + "'", str2.equals("sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10", (java.lang.CharSequence) "100#100#0#-1#100#100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.0A-1.0", (int) (short) 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "00", (java.lang.CharSequence) "Java(TM) SE ROracleCorporatioments/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1#32", "0#10#10", (int) (byte) 1);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun.awt....JAVA PLATFORM API SPECIFICATION", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA vIRTUAL mACHINE sPECIFICATION" + "'", str1.equals("jAVA vIRTUAL mACHINE sPECIFICATION"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Lib...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIB..." + "'", str1.equals("/LIB..."));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) ".");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("http://java.oracle.com/                       ", "AAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/                       " + "'", str2.equals("http://java.oracle.com/                       "));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("24.80-b11", "jEvE HotSpot(TM) 64EBit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("jav...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jav...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("24.80-b11#########", 135432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 135432 + "'", int2 == 135432);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        char[] charArray5 = new char[] { '4', '#' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                              1.7", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 1, (int) (short) 1);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 11, (int) (short) -1);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "TIONATFORM api sPECIFICA pLAVAj", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                                                           10.0A-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0A-1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a100#100#0#-1#100#100100#100#0#-1#1", "dk1.7.0_80.jdk/contents/home/jre", 34);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.0a-1.0a-1.0a-1.0a18.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("100.0", (int) (short) 7, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 100.0 " + "'", str3.equals(" 100.0 "));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        short[] shortArray4 = new short[] { (short) 100, (short) 10, (byte) 0, (short) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaa10.0a1.0", 520);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaa10.0a1.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    " + "'", str2.equals("aaaaaaaaaaaa10.0a1.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("IKLOOSOCAM.TWAWL.NUS", "###################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "IKLOOSOCAM.TWAWL.NUS" + "'", str2.equals("IKLOOSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("avaj/bil/rs");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("32#-1", (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        char[] charArray4 = new char[] { '#', 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 100, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray4, '#', (int) (short) 10, 0);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ".7.0_80-B15", charArray4);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "senwawt.macosx.CPrinterJob", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "#aa" + "'", str6.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10", "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10" + "'", str2.equals("0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        int[] intArray3 = new int[] { (short) -1, '4', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a52a97" + "'", str5.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a52a97" + "'", str8.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Oracle Corporation                                  ", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                    " + "'", str2.equals("                    "));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "#aa", "S");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:./USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str1.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52426_156027983", "\n\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52426_156027983" + "'", str2.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52426_156027983"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 96L, (double) 4.0f, (double) 13);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 96.0d + "'", double3 == 96.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "4-1.0467");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "100#100", (java.lang.CharSequence) "aaaaaaaaaaaa10.0a1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd(" 6_64////", "####################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 6_64////" + "'", str2.equals(" 6_64////"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.lwctoolki", (int) (short) 1, "OracleCorporati");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.lwctoolki" + "'", str3.equals("sun.lwawt.macosx.lwctoolki"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "100#100#0#-1#100#1001100#100#0#-1#100#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1...", (java.lang.CharSequence) " 100 0 97");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "                                                                                           10.0A-1.0", (java.lang.CharSequence) "TIONATFORM api sPECIFICA pLAVAj0.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                                           10.0A-1.0" + "'", charSequence2.equals("                                                                                           10.0A-1.0"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("dk1.7.0_80.jdk/contents/home/jre", "51.0", "###################################");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("-1a52a97");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a52a97" + "'", str1.equals("-1a52a97"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("51b-08_0.7.1                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51b-08_0.7.1                   " + "'", str1.equals("51b-08_0.7.1                   "));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                    sun.awt.CGraphicsEnvironmen                                     ", (java.lang.CharSequence) "-1a52a9", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "US", (java.lang.CharSequence) "1.2", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("sun.awt....JAVA PLATFORM API SPECIFICATION", "10.14.3", (int) (byte) 10);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.0", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.0" + "'", str7.equals("10.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.0"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java HotSpot(TM) 64-Bit Server VM", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0410410", "           10.0#-1.0");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        char[] charArray5 = new char[] { '#', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100.0100.0100.0100.0100.0100.01", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#aa" + "'", str7.equals("#aa"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                           35.0#10.", "SU", 92);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("0.91.70.91.20.90.9", "4444444100404-141004100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".91.70.91.20.90.9" + "'", str2.equals(".91.70.91.20.90.9"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52426_156027983");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52426_156027983" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52426_156027983"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                   1.7.0_80-B15", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "4444444100404-141004100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("TIONATFORM API SPECIFICA PLAVAJ", ".", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("0.15", "http://jv.orcle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.15" + "'", str2.equals("0.15"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("-1#52#97", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#52#97" + "'", str2.equals("-1#52#97"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        double[] doubleArray4 = new double[] { 10.0f, (short) 100, (-1), (-1.0f) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', (int) ' ', 1);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#', 10, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a100.0a-1.0a-1.0" + "'", str7.equals("10.0a100.0a-1.0a-1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "100-132100-132100-1tionatformaAPIaSpecificaaPlavaJ100-132100-132100-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("!IH", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        float[] floatArray2 = new float[] { 35L, (short) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "35.0#10.0" + "'", str4.equals("35.0#10.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 35.0f + "'", float5 == 35.0f);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "100-1 32                        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 93);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1410040497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-145249");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA", (java.lang.CharSequence) "                   1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/LIB...", (int) (short) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/LIB..." + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/LIB..."));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051..9", 97, ".1                                                                                              ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".1  51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051..9" + "'", str3.equals(".1  51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051..9"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("JavalP acificepS IPA mroftanoit", "6_64////");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavalP acificepS IPA mroftanoit" + "'", str2.equals("JavalP acificepS IPA mroftanoit"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), (long) 7, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("SUN.LWAWT.MACOSX.LWCTOOLKI", "dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/10.04100.04-1.04-1.0dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/", "100.0100.0100.0100.0100.0100.01 ", 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKI" + "'", str4.equals("SUN.LWAWT.MACOSX.LWCTOOLKI"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4##", "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051..9", 69);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.0a-1.0a-1.0a-1.0a18.0", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a-1.0a-1.0a-1.0a18.0" + "'", str2.equals("1.0a-1.0a-1.0a-1.0a18.0"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                   " + "'", str2.equals("                                                                   "));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51b-08_0.7.1                   ", (java.lang.CharSequence) "01 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1a100a0a97", (java.lang.CharSequence) "00.0410.0467.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("AAAAAAAAAA");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "aaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1 32" + "'", str7.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1a32" + "'", str9.equals("-1a32"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("tionatform API Specifica PlavaJ", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tionatform API Specifica PlavaJ" + "'", str3.equals("tionatform API Specifica PlavaJ"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaS", (java.lang.CharSequence) "                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.awt....sun.awt....sun.awt....sunJava Platform API Specificatio", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                           35.0#10.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "10.14.3", 10);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "mixed mode");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Platform API Specification" + "'", str4.equals("Java Platform API Specification"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Java Platform API Specification" + "'", str7.equals("Java Platform API Specification"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("tionatform API Specifica PlavaJ", (int) (short) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tionatform API Specifica PlavaJ" + "'", str3.equals("tionatform API Specifica PlavaJ"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/Users/...", "oraclecorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/..." + "'", str2.equals("/Users/..."));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.Class<?> wildcardClass13 = longArray2.getClass();
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a32" + "'", str7.equals("-1a32"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1#32" + "'", str11.equals("-1#32"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100.0100.0100.0100.0100.0100.01", "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        double[] doubleArray5 = new double[] { 1.0f, (-1.0f), (-1L), (byte) -1, 18 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 0, 5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 18.0d + "'", double6 == 18.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0a-1.0a-1.0a-1.0a18.0" + "'", str9.equals("1.0a-1.0a-1.0a-1.0a18.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.0a-1.0a-1.0a-1.0a18.0" + "'", str13.equals("1.0a-1.0a-1.0a-1.0a18.0"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "avaj/bil/rs", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0_80.JDK/CONTENTS/HOME/JRE" + "'", str1.equals("0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051..9", (java.lang.CharSequence) "sun.lwawt.macosx.lwctoolki");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "-1a52a97-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 2, (float) 5L, (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "-1a32", (java.lang.CharSequence) "dk1.7.0_80.jdk/contents/home/jr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 0, (long) (-1), (long) 3);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "0a10a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "avaj/bil/", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        java.lang.String str5 = javaVersion3.toString();
        boolean boolean6 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str7 = javaVersion0.toString();
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.2" + "'", str5.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        double[] doubleArray3 = new double[] { 10.0d, (-1), 67 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.04-1.0467.0" + "'", str5.equals("10.04-1.0467.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 67.0d + "'", double6 == 67.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 67.0d + "'", double7 == 67.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.04-1.0467.0" + "'", str9.equals("10.04-1.0467.0"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(strArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1#52#9", (java.lang.CharSequence) "TIONATFORM API SPECIFICA PLAVAJ", 68);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        float[] floatArray2 = new float[] { 10, 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0 1.0" + "'", str4.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0a1.0" + "'", str6.equals("10.0a1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0 1.0" + "'", str8.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 10.0f + "'", float10 == 10.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0 1.0" + "'", str12.equals("10.0 1.0"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1...", "24.80-b11#########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1..." + "'", str2.equals("1..."));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        java.lang.String str5 = javaVersion3.toString();
        boolean boolean6 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str7 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean10 = javaVersion8.atLeast(javaVersion9);
        java.lang.String str11 = javaVersion9.toString();
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean14 = javaVersion12.atLeast(javaVersion13);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean17 = javaVersion12.atLeast(javaVersion16);
        boolean boolean18 = javaVersion9.atLeast(javaVersion16);
        boolean boolean19 = javaVersion0.atLeast(javaVersion9);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.2" + "'", str5.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0.9" + "'", str11.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#4a", 'a');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "0 10 10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80", "jav...", 135432);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (-1), ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.0" + "'", str1.equals("10.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.0"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 0L, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".7.0_80-B15");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "sophiesophiesophiesophiesophieso/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".7.0_80-B15" + "'", str3.equals(".7.0_80-B15"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "es/jdk1.7.0_80.jdk/Contents/Home/jre", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "sophiesophiesophiesophiesophieso/Users/sophie/Documents/defectsj/tmp/run_rndoop.pl_5226_156027983");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaa                                                                                         ", (java.lang.CharSequence) "100#100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4, 0, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051..9", (double) 97L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aaaaaaaaaaaa10.0a1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("###################################", 93, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#############################################################################################" + "'", str3.equals("#############################################################################################"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (java.lang.CharSequence) "1#52#97");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "http://java.oracle.com/                       ", (java.lang.CharSequence) "es/jdk1.7.0_80.jdk/Contents/Home/jrees/                  es/jdk1.7.0_80.jdk/Contents/Home/jrees/j");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "http://java.oracle.com/                       " + "'", charSequence2.equals("http://java.oracle.com/                       "));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.0a10.0", "1.2", "-1#52#9");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Java(TM) SE Runtime Environment", "0.15", "                                                                                           10.0A-1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "tionatform API Specifica PlavaJ                                                                  ", (java.lang.CharSequence) "senwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                     32                                                  32                                                  32                                                  32                                                  32                                                  32                                                  32                                                  32                                                  32                                                  32                             ", "100#100#0#-1#100#100aaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a32" + "'", str7.equals("-1a32"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1#32" + "'", str9.equals("-1#32"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1 32" + "'", str11.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("100404-141004100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100404-141004100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }
}

