import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        char[] charArray4 = new char[] { '4', '#' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                              1.7", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "   ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("-1452497", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaSU");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1452497" + "'", str2.equals("-1452497"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        float[] floatArray2 = new float[] { 10, 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', (int) ' ', (int) (byte) 0);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', (-1), 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0 1.0" + "'", str4.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-1a52a97", 68);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("          ", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKI", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "10.0 1.0 5.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "100#100#0#-1#100#100aaaaaaaaaaaa", (java.lang.CharSequence) "sun.awt....");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("es/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0#-1.0", "                                                                                               UTF-8");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 11, (long) 35, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java Virtual Machine Specification", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "-1a32", (java.lang.CharSequence) "                                                                                               UTF-8", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        short[] shortArray5 = new short[] { (short) -1, (byte) 1, (byte) 100, (byte) 100, (byte) 1 };
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US", "4444444100404-141004100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                                                              1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".1                                                                                              " + "'", str1.equals(".1                                                                                              "));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("aa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa" + "'", str2.equals("aa"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("               1.7", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.LWCToolkit", "sun.awt....JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("dk1.7.0_80.jdk/contents/home/jr1", "-1 32                                                                                               ", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1#52#97");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre" + "'", str1.equals("/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("B", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.0", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0" + "'", str3.equals("0.0"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("http://java.oracle.com/", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "0#10#10", (java.lang.CharSequence) "1#52tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "mac os x", (java.lang.CharSequence) "iklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("-1432");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1432" + "'", str1.equals("-1432"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("tiklooTCWL.xsocam.twawl.nus", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 69);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str2.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1 100 0 97", "-1 32", "Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 100 0 97" + "'", str3.equals("1 100 0 97"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 97, (float) (short) 0, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "0a10a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1 100 0 97", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 100 0 97" + "'", str2.equals("1 100 0 97"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("100 100 0 -1 100 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 100 0 -1 100 100" + "'", str1.equals("100 100 0 -1 100 100"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1A100A0A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A9", 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1A100A0A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A9" + "'", str2.equals("1A100A0A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A9"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("          ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.awt....", (java.lang.CharSequence) ".9");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 31, 0.0f, (float) (short) 7);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 31.0f + "'", float3 == 31.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle Corporation");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_-56127983", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.744444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) (byte) 100, (-1));
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) (byte) -1, (-1));
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "100.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 100.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "TIONATFORM api sPECIFICA pLAVAj");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "TIONATFORM api sPECIFICA pLAVAj" + "'", charSequence2.equals("TIONATFORM api sPECIFICA pLAVAj"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                    sun.awt.CGraphicsEnvironmen                                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.awt....", (java.lang.CharSequence) "aaaaaaaaaa                                                                                          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "10.0a100.0a-1.0a-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.0", "1#52tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7.0_80", 31.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 31.0f + "'", float2 == 31.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10                              ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        char[] charArray4 = new char[] { '#', 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray4, '4');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                               UTF-8", charArray4);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "#aa" + "'", str6.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#4a" + "'", str8.equals("#4a"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.71");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71" + "'", str1.equals("1.71"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "x86_64////", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 1L, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10.0a1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("35.0#10.", (int) '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                           35.0#10." + "'", str3.equals("                           35.0#10."));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(20, 13, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1#52tiklooTCWL.xsocam.twawl.nus", "10.0A-1.0", "Oracle Cor");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1#52tiklooTCWL.xsocam.twawl.nus" + "'", str3.equals("1#52tiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 0, (long) '4', (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10.0#1.0", (java.lang.CharSequence) "0.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4a#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4a#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("dk1.7.0_80.jdk/contents/home/jre", (int) (short) 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nUTF-8\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", (int) (byte) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nUTF-8\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + "'", str3.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nUTF-8\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("100#100#0#-1#100#100");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("100-1 32                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 100-1 32                         is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1L, (long) (byte) 100, 35L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("-1A32", "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nUTF-8\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "7                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                                                              1.", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("10.0 1.0", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 1.0" + "'", str2.equals("10.0 1.0"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                        100 100 0 -1 100 100                                        ", (java.lang.CharSequence) "0 10 10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93 + "'", int2 == 93);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "OracleCorporatio", (java.lang.CharSequence) "24.80-b11", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 68, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "##aOracle Cor", (java.lang.CharSequence) "aaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835", (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("-1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.0a10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                       100#100#0#-1#100#100                        ", (java.lang.CharSequence) "100#100#0#-1#100#100", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaSU", 0);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10.0a1.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1#52#97");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#52#97" + "'", str1.equals("1#52#97"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("100                                                                                                 ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983", "24.80-b11#########", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10.0#-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0#-1.0" + "'", str1.equals("10.0#-1.0"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "-1", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "B");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str2.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("##aOracle Cor", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##aOracle Cor" + "'", str2.equals("##aOracle Cor"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre" + "'", str1.equals("/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) " ", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "1a100a0a97", (int) (byte) 10, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ".9", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10.0", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                10.0" + "'", str2.equals("                                                10.0"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "oraclecorporation", 93);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("-1 32                                                                                               ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 32                                                                                               " + "'", str2.equals("-1 32                                                                                               "));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("           10.0#-1.0", "10.0a100.0a-1.0a-1.0", "\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "           10.0#-1.0" + "'", str3.equals("           10.0#-1.0"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("01010");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 520L + "'", long1.equals(520L));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1A32", "                                    sun.awt.CGraphicsEnvironmen                                     ", 4);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Lib...");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("00.0410.0467.0", "                                ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "00.0410.0467.0" + "'", str3.equals("00.0410.0467.0"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "             0.                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("   ", "1004100404-141004100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) 'a', "\n\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + "'", str3.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B15" + "'", str1.equals("1.7.0_80-B15"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(56, (int) (byte) 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1A100A0A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A9", "1004100404-141004100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("-1432", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1." + "'", str3.equals("1."));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("             0.                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "             0.                 " + "'", str1.equals("             0.                 "));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.0a10.0", (java.lang.CharSequence) "oraclecorporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80-b15", "100.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "24.80-b11#########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "sun.awt....");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        double[] doubleArray2 = new double[] { (short) 10, (-1.0d) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', 0, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0a-1.0" + "'", str5.equals("10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0#-1.0" + "'", str7.equals("10.0#-1.0"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 1, (byte) 0, (byte) 100, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', (int) (byte) -1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("tiklooTCWL.xsocam.twawl.nus", (int) (byte) -1, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tiklooTCWL.xsocam.twawl.nus" + "'", str3.equals("tiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                              1.7", "00#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100", "10.0a-1.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "10.0a1.0", 1);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" ");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "en", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("B");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"B\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        char[] charArray4 = new char[] { '#', 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray4, '4');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                               UTF-8", charArray4);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray4, '4');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ', (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "#aa" + "'", str6.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#4a" + "'", str8.equals("#4a"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#4a" + "'", str12.equals("#4a"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "##a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str2.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("0.", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0." + "'", str2.equals("0."));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "100.0100.0100.0100.0100.0100.01", (int) (short) 100, (-1));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophie", "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("             0.                 ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("             0.                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0." + "'", str1.equals("0."));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "#aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1#52tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("UTF-8", (int) (short) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8" + "'", str3.equals("UTF-8"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.3", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        char[] charArray5 = new char[] { '#', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 100, 0);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray5);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.04-1.0467.0", charArray5);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "dk1.7.0_80.jdk/contents/home/jr1", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#aa" + "'", str7.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) (short) 10, 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', (int) (byte) 100, (int) 'a');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#10#10" + "'", str6.equals("0#10#10"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0410410" + "'", str13.equals("0410410"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "dk1.7.0_80.jdk/contents/home/jr", (java.lang.CharSequence) "7                                  ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "MacOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.3", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaSU", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "                                ", 18, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 41");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 10L, 0.0f, (float) 13);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1#52#97", (java.lang.CharSequence) "Java(TM) SE Runtime Environment", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Mac OS X", (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("dk1.7.0_80.jdk/contents/home/jr", (int) (short) 7, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dk1.7.0_80.jdk/contents/home/jr" + "'", str3.equals("dk1.7.0_80.jdk/contents/home/jr"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10.04100.04-1.04-1.0", (java.lang.CharSequence) "01010");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("java HotSpot(TM) 64-Bit Server VM", "100#100#0#-1#100#100aaaaaaaaaaa", "Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jEvE HotSpot(TM) 64EBit Server VM" + "'", str3.equals("jEvE HotSpot(TM) 64EBit Server VM"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("B");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.0", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.74444444444444444444444444444", "SU");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("MacOSX", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MacOSX" + "'", str3.equals("MacOSX"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("7                                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"7                                  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        float[] floatArray2 = new float[] { 10, 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', (int) ' ', (int) (byte) 0);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0 1.0" + "'", str4.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) ":", (java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "1.71", 2, 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.71" + "'", str4.equals("1.71"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 1, (byte) 0, (byte) 100, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1452497", 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 56, 11L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 11L + "'", long3 == 11L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        double[] doubleArray1 = new double[] { (short) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', 0, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444100.0100.0100.0100.0100.0100.01", (java.lang.CharSequence) "tionatform API Specifica PlavaJ", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "0.15", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.0 1.0", ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.9", "                                    sun.awt.CGraphicsEnvironmen                                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '4', 18, (int) ' ');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("US", "1.744444444444444444444444444444");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("x86_64////", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64////" + "'", str3.equals("x86_64////"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("0a10a10", "                           35.0#10.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a10a10" + "'", str2.equals("0a10a10"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "tionatform API Specifica PlavaJ                                                                  ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "1.", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '#', (int) (byte) 10, (int) (short) -1);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("0#10#10", strArray5, strArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence[]) strArray12);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0#10#10" + "'", str13.equals("0#10#10"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("10.0#-1.0#67.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_-56127983", "mixed mode", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_-56127983" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_-56127983"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10.0 1.0 5.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0 1.0 5.0" + "'", str1.equals("10.0 1.0 5.0"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("mixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "100-1 32                        ", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) 'a', 11, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) ' ', (float) 67L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 67.0f + "'", float3 == 67.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                    sun.awt.CGraphicsEnvironmen                                     ", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                    sun.awt.CGraphicsEnvironmen                                     " + "'", str2.equals("                                    sun.awt.CGraphicsEnvironmen                                     "));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        char[] charArray6 = new char[] { '#', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "TIONATFORM api sPECIFICA pLAVAj", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0a10.0", charArray6);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                               UTF-8", charArray6);
        java.lang.Class<?> wildcardClass14 = charArray6.getClass();
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#aa" + "'", str8.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#4a" + "'", str10.equals("#4a"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                    sun.awt.CGraphicsEnvironmen                                     ", "35a4a5a4a2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                    sun.awt.CGraphicsEnvironmen                                     " + "'", str2.equals("                                    sun.awt.CGraphicsEnvironmen                                     "));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10.0a-1.0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.7", 68);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "4 #", (java.lang.CharSequence) "Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 1, (byte) 0, (byte) 100, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1 100 0 97", "1#100#0#97");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 100 0 97" + "'", str2.equals("1 100 0 97"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "100a100a0a-1a100a100", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444100.0100.0100.0100.0100.0100.01");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "tionatformaAPIaSpecificaaPlavaJ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("oraclecorporation", 100, 56);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("35.0#10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "iklooTCWL.xsocam.twawl.nus", charSequence1, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "10.0#100.0#-1.0#-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                1.                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("10.04-1.0467.0", "0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.04-1.0467." + "'", str2.equals("10.04-1.0467."));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0." + "'", str3.equals("0."));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                              1.7", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "AAAAAAAAAA", (java.lang.CharSequence) "-1A32", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("100                                                                                                 ", "JAVA PLATFORM API SPECIFICATION", "Mac OS X", 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100                                                                                                 " + "'", str4.equals("100                                                                                                 "));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10.0a-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("0 10 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 10 10" + "'", str1.equals("0 10 10"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                           35.0#10.", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                       100#100#0#-1#100#100                        ", (java.lang.CharSequence) "jEvE HotSpot(TM) 64EBit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UTF-8", (int) ' ', 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nUTF-8\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", "                                                                                                    ", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(".7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".7.0_80-B15" + "'", str1.equals(".7.0_80-B15"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun.awt.CGraphicsEnvironmen", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         sun.awt.CGraphicsEnvironmen" + "'", str2.equals("                         sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(67L, 35L, (long) 23);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 67L + "'", long3 == 67L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java HotSpot(TM) 64-Bit Server VM", "1#100#0#97", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "00#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "01 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 0" + "'", str1.equals("01 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 0"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "0.", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean5 = javaVersion2.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean7 = javaVersion4.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean10 = javaVersion8.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean13 = javaVersion11.atLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean16 = javaVersion14.atLeast(javaVersion15);
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean18 = javaVersion15.atLeast(javaVersion17);
        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean21 = javaVersion19.atLeast(javaVersion20);
        boolean boolean22 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion19);
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean24 = javaVersion19.atLeast(javaVersion23);
        boolean boolean25 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion19);
        org.apache.commons.lang3.JavaVersion[] javaVersionArray26 = new org.apache.commons.lang3.JavaVersion[] { javaVersion0, javaVersion4, javaVersion8, javaVersion12, javaVersion15, javaVersion19 };
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join(javaVersionArray26);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(javaVersionArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0.91.70.91.20.90.9" + "'", str27.equals("0.91.70.91.20.90.9"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("01 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("sun.awt....JAVA PLATFORM API SPECIFICATION", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt....JAVA PLATFORM API SPECIFICATION" + "'", str2.equals("sun.awt....JAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                        100 100 0 -1 100 100                                        ", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 100 100                                        " + "'", str2.equals(" 100 100                                        "));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("10.0#-1.0", "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0.15", (java.lang.CharSequence) "0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100                                                                                                 ", "100a100a0a-1a100a100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Oracle Cor", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10.0#-1.0", (java.lang.CharSequence) "10.04-1.0467.", 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("-1A32", "/Lib...", " ", 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1A32" + "'", str4.equals("-1A32"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("-1A32", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1A32                  " + "'", str2.equals("-1A32                  "));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("-1A32", "1 100 0 97");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1A32" + "'", str2.equals("-1A32"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                       100#100#0#-1#100#100                        ", 69, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("100#100#0#-1#100#100aaaaaaaaaaaa", "java HotSpot(TM) 64-Bit Server VM", "http://jv.orcle.com/", 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100#100#0#-1#100#100aaaaaaaaaaaa" + "'", str4.equals("100#100#0#-1#100#100aaaaaaaaaaaa"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1 32", "1a100a0a97", (int) (short) 100);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983" + "'", str7.equals("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("java HotSpot(TM) 64-Bit Server VM", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("10.0a1.0", "sun.awt....JAVA PLATFORM API SPECIFICATION", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0" + "'", str3.equals("10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("100 100 0 -1 100 100", "S");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 100 0 -1 100 100" + "'", str2.equals("100 100 0 -1 100 100"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre" + "'", str1.equals("/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "             0.                 ", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0410410", "           10.0#-1.0");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4" + "'", str5.equals("4"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("0.15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.15" + "'", str1.equals("0.15"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Platform API Specification", 67, "sun.awt....");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt....sun.awt....sun.awt....sunJava Platform API Specification" + "'", str3.equals("sun.awt....sun.awt....sun.awt....sunJava Platform API Specification"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 32, (float) (byte) 100, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(".", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("hi!", "Oracle Corporation", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "OracleCorporation", (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.14.3", 4, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("JAVA3PLATFORM3API3SPECIFICATION", "0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10                              ", "sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA3PLATFORM3API3SPECIFICATION" + "'", str3.equals("JAVA3PLATFORM3API3SPECIFICATION"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        double[] doubleArray1 = new double[] { (short) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0" + "'", str7.equals("100.0"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80-b15", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                   1.7.0_80-b15" + "'", str2.equals("                   1.7.0_80-b15"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("10.04-1.0467.0", "10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4-1.0467" + "'", str2.equals("4-1.0467"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) ":", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                                10.0", (java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Lib...", (java.lang.CharSequence) "/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97", "-1a32", "/Users/sophie", 56);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97" + "'", str4.equals("1a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("#aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#aa" + "'", str1.equals("#aa"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0" + "'", str1.equals("10.0"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10" + "'", str2.equals("0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("100#100#0#-1#100#100", "aa0#100aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#100#100" + "'", str2.equals("-1#100#100"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("   ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(1L, (long) (short) -1, (long) 68);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 68L + "'", long3 == 68L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983" + "'", str1.equals("/users/sophie/documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun.awt.CGraphicsEnvironmen", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironmen" + "'", str2.equals("sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 10 100 1" + "'", str2.equals("0 10 100 1"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaa                                                                                          ", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "-1#32");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "100.0", (java.lang.CharSequence) "10.0#-1.0", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("10.0#1.0", "", 31, 68);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0#1.0" + "'", str4.equals("10.0#1.0"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("     ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Dk1.7.0_80.jdk/contents/home/jr", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100#100#0#-1#100#100", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("444444444444444444444444444444444444444444444444444444444444444444444100.0100.0100.0100.0100.0100.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444100.0100.0100.0100.0100.0100.01" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444100.0100.0100.0100.0100.0100.01"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10                              ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "10.04-1.0467.0", (java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10.04-1.0467.0" + "'", charSequence2.equals("10.04-1.0467.0"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.744444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.744444444444444444444444444444" + "'", str1.equals("1.744444444444444444444444444444"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(13, (int) (byte) 10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 7, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "-1A32                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.3", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.awt....sun.awt....sun.awt....sunJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt....sun.awt....sun.awt....sunJava Platform API Specificatio" + "'", str1.equals("sun.awt....sun.awt....sun.awt....sunJava Platform API Specificatio"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.0 1.0", "1.74444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "http://java.oracle.com/                       ", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10.0#100.0#-1.0#-1.0", (java.lang.CharSequence) "http://jv.orcle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 13, (double) ' ', (double) 23);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".1                                                                                              ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("100#100#0#-1#100#1001100#100#0#-1#100#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#100#0#-1#100#1001100#100#0#-1#100#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100" + "'", str2.equals("100#100#0#-1#100#1001100#100#0#-1#100#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0.15", "24.80-b11#########");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97", "10.0a1.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10                              ", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAA4....twa.nus4389720651_62425_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/4 4tnemnorivnE emitnuR ES )MT(avaJ" + "'", str1.equals("AAAAAAAAAA4....twa.nus4389720651_62425_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/4 4tnemnorivnE emitnuR ES )MT(avaJ"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                              1.7", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                    1.7" + "'", str2.equals("                                                                                    1.7"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "35.0#10.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 20);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                    sun.awt.CGraphicsEnvironmen                                     ", 2, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                    sun.awt.CGraphicsEnvironmen                                     " + "'", str3.equals("                                    sun.awt.CGraphicsEnvironmen                                     "));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaSU", (java.lang.CharSequence) "10.0#100.0#-1.0#-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("0 10 10", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("-1 32                                                                                               ", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32                                                                                               " + "'", str2.equals("32                                                                                               "));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("#aa", "sophie");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10.0#-1.0#67.0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("0.9");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.9f + "'", float1.equals(0.9f));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("35.0#10.", "100", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35.0#10.10035.0#10.10035.0#10.10035.0#10.10035.0#10.10035.0#10.10035.0#10.10035.0#10.10035.0#10.10035.0#10." + "'", str3.equals("35.0#10.10035.0#10.10035.0#10.10035.0#10.10035.0#10.10035.0#10.10035.0#10.10035.0#10.10035.0#10.10035.0#10."));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("44444444444444444444444444444444444444444444444444444444444444...", (int) '#', 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444" + "'", str3.equals("444444444"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "0 10 100 1", "10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(97.0f, (float) 23, (float) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80-b15", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(":", "http://java.oracle.com/                       ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        char[] charArray4 = new char[] { '#', 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                    ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "#aa" + "'", str6.equals("#aa"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1A100A0A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A9");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "-1432", (java.lang.CharSequence) "tionatform API Specifica PlavaJ", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aa", (java.lang.CharSequence) "/Lib...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Mac OS X", "                                                10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("-1#32");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 7, (int) (short) 10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("-1a52a97-1a52a97-1a52a10.0a1.0-1a52a97-1a52a97-1a52a", "", (int) '4', 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1a52a97-1" + "'", str4.equals("-1a52a97-1"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.0a1.0", 20, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaa10.0a1.0" + "'", str3.equals("aaaaaaaaaaaa10.0a1.0"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 18.0d, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(".9", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".9" + "'", str2.equals(".9"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nUTF-8\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        float[] floatArray3 = new float[] { 10L, 1.0f, 5 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0 1.0 5.0" + "'", str5.equals("10.0 1.0 5.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        int[] intArray3 = new int[] { (short) -1, '4', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', (int) '#', 93);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a52a97" + "'", str5.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a52a97" + "'", str8.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1#52#97" + "'", str11.equals("-1#52#97"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(2, 7, 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10.0A-1.0", "\n", "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_-56127983");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0A-1.0" + "'", str3.equals("10.0A-1.0"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                    sun.awt.CGraphicsEnvironmen                                     ", " 100 100                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                    sun.awt.CGraphicsEnvironmen                                     " + "'", str2.equals("                                    sun.awt.CGraphicsEnvironmen                                     "));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("SUN.LWAWT.MACOSX.LWCTOOLKI");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("444444444444444444444444444444444444444444444444444444444444444444444100.0100.0100.0100.0100.0100.01", "                       100#100#0#-1#100#100                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       100#100#0#-1#100#100                        " + "'", str2.equals("                       100#100#0#-1#100#100                        "));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("               1.7", "-1#32");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               1.7" + "'", str2.equals("               1.7"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                                                                    1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(100.0d, (double) 32L, (double) 31.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.0d + "'", double3 == 31.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "0.15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        float[] floatArray2 = new float[] { 10, 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0 1.0" + "'", str4.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0a1.0" + "'", str6.equals("10.0a1.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0 1.0" + "'", str9.equals("10.0 1.0"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "00");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                0.                 ", (int) '#', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "#aa", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(".9", (int) (byte) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9", "444444444444444444444444444444444444444444444444444444444444444444444100.0100.0100.0100.0100.0100.01", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("100.0100.0100.0100.0100.0100.01 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0100.0100.0100.0100.0100.01 " + "'", str1.equals("100.0100.0100.0100.0100.0100.01 "));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("0.91.70.91.20.90.9", (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("-1a52a97", 23, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("iklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("100#100#0#-1#100#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#100#0#-1#100#100" + "'", str1.equals("100#100#0#-1#100#100"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("0.15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java Virtual Machine Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("-1a32", (int) (short) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a32" + "'", str3.equals("-1a32"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10", (int) '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10" + "'", str3.equals("0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/                       ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 1, (double) (byte) 1, (double) 6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0d + "'", double3 == 6.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "mac os x", (java.lang.CharSequence) "0 10 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1 52 97", (java.lang.CharSequence) "      35.0#10.      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_-56127983", ".1                                                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_-56127983" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_-56127983"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Oracle Corporation                                  ", (java.lang.CharSequence) "....04...", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(4L, (long) (byte) 1, (long) 32);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd(".9", "                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".9" + "'", str2.equals(".9"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.awt....JAVA PLATFORM API SPECIFICATION", 7, "0.15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt....JAVA PLATFORM API SPECIFICATION" + "'", str3.equals("sun.awt....JAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                    ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("      35.0#10.      ", "                   1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                   1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                   1.7.0_80-b15\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("10.0 1.0 5.0", "100.0100.0100.0100.0100.0100.01");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0100.0100.0100.0100.0100.01" + "'", str2.equals("0.0100.0100.0100.0100.0100.01"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("10.04-1.0467.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.04-1.0467." + "'", str1.equals("10.04-1.0467."));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1#100#100", (java.lang.CharSequence) "0.9", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("100.0", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0" + "'", str2.equals("100.0"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "JAVA3PLATFORM3API3SPECIFICATION", (java.lang.CharSequence) "1#100#0#97");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java(TM) SE Runtime Environment", "JAVA3PLATFORM3API3SPECIFICATION", 100);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) (byte) 1, (-1));
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "TiklooTCWL.xsocam.twawl.nus");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: TiklooTCWL.xsocam.twawl.nus");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#100#0#-1#100#100" + "'", str10.equals("100#100#0#-1#100#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1004100404-141004100" + "'", str12.equals("1004100404-141004100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) -1 + "'", byte17 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1004100404-141004100" + "'", str19.equals("1004100404-141004100"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA", "1a100a0a97");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA" + "'", str2.equals("Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("#aa", (int) (short) -1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#aa" + "'", str3.equals("#aa"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                         sun.awt.CGraphicsEnvironmen", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.awt....sun.awt....sun.awt....sunJava Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("0.0", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0" + "'", str2.equals("0.0"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        java.lang.CharSequence[] charSequenceArray2 = new java.lang.CharSequence[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7", charSequenceArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "mixed mode", charSequenceArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray2, ' ', (int) (byte) 1, 0);
        org.junit.Assert.assertNotNull(charSequenceArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("tionatformaAPIaSpecificaaPlavaJ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("      35.0#10.      ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      35.0#10.      " + "'", str2.equals("      35.0#10.      "));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "1.0a10.0");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100 100 0 -1 100 100", (int) (short) 1, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "0.15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "100#100#0#-1#100#100aaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "mixed mode", "hi!");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "100#100#0#-1#100#100", 52);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("                1.                 ", strArray4, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "                1.                 " + "'", str9.equals("                1.                 "));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "-1#32");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "35a4a5a4a2", 23, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("44444444444444444444444444444444444444444444444444444444444444...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444..." + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444..."));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10.04-1.0467.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                              1.7", (java.lang.CharSequence) "35.0#10.0", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("SUN.LWAWT.MACOSX.LWCTOOLKI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 35, 10);
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#10#10" + "'", str6.equals("0#10#10"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0 10 10" + "'", str10.equals("0 10 10"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str1.equals("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.71");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "17.1" + "'", str1.equals("17.1"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("##aOracle Cor");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("100404-141004100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100404-141004100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "dk1.7.0_80.jdk/contents/home/jr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        java.lang.Class<?> wildcardClass10 = longArray2.getClass();
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1 32" + "'", str7.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1a32" + "'", str9.equals("-1a32"));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("US");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"US\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                    sun.awt.CGraphicsEnvironmen                                     ", (java.lang.CharSequence) "0.15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################" + "'", str2.equals("###################################"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                                                                              1.", "10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                              1." + "'", str2.equals("                                                                                              1."));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("....04...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "....04..." + "'", str1.equals("....04..."));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("...rs/_...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"...rs/_...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaaaaaaaaaaa10.0a1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("10.0a100.0a-1.0a-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0a100.0a-1.0a-1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        float[] floatArray0 = new float[] {};
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0 10 10", 68, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(20L, 0L, 4L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 20L + "'", long3 == 20L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "7                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) '#', (long) (byte) 10, 68L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 68L + "'", long3 == 68L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("-1a52a97-1", "##a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a52a97-1" + "'", str2.equals("-1a52a97-1"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "TiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_-56127983");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                    ", "100", 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    " + "'", str3.equals("                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    "));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("           10.0#-1.0", "0.0100.0100.0100.0100.0100.01");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "           10.0#-1.0" + "'", str2.equals("           10.0#-1.0"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.0f, (float) (byte) 1, (float) 18);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        float[] floatArray2 = new float[] { 10, 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', 5, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0 1.0" + "'", str4.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0a1.0" + "'", str6.equals("10.0a1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0 1.0" + "'", str8.equals("10.0 1.0"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("http://jv.orcle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://jv.orcle.com/" + "'", str1.equals("http://jv.orcle.com/"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaa" + "'", str2.equals("aaaaaa"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                         sun.awt.CGraphicsEnvironmen", "10.0a-1.0", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1 32");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1 32\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "mac os x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                        100 100 0 -1 100 100                                        ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1#52tiklooTCWL.xsocam.twawl.nus", "-1432");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#52tiklooTCWL.xsocam.twawl.nus" + "'", str2.equals("1#52tiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.awt....sun.awt....sun.awt....sunJava Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.awt....sun.awt....sun.awt....sunJava Platform API Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "100", (java.lang.CharSequence) "oraclecorporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("java HotSpot(TM) 64-Bit Server VM", 13, ".7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("10.0A-1.0", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0A-1.0" + "'", str2.equals("10.0A-1.0"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("sun.awt....sun.awt....sun.awt....sunJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt....sun.awt....sun.awt....sunJava Platform API Specification" + "'", str1.equals("sun.awt....sun.awt....sun.awt....sunJava Platform API Specification"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.04-1.0467.0", "                1.                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("-1#100#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#100#100" + "'", str1.equals("-1#100#100"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Oracle Cor", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Cor" + "'", str3.equals("Oracle Cor"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "....04...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "24.80-b11#########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("-1 32", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 32" + "'", str2.equals("-1 32"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaa                                                                                          ", 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.lwctOOLKI" + "'", str1.equals("SUN.LWAWT.MACOSX.lwctOOLKI"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "", (int) (short) 10);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) (byte) 100, (int) '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "0.");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "10.0#-1.0#67.0", (java.lang.CharSequence) "1#52#97", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("100#100#0#-1#100#1001100#100#0#-1#100#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("UTF-8", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre", "7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', (int) (short) 0, 1);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', 3, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1" + "'", str8.equals("-1"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("#aa", "sophie");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#aa" + "'", str3.equals("#aa"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", "100                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + "'", str2.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        short[] shortArray3 = new short[] { (byte) 1, (short) 7, (short) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 1 + "'", short4 == (short) 1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 7 + "'", short5 == (short) 7);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("-1A32                  ", "35.0#10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1A32                  " + "'", str2.equals("-1A32                  "));
    }
}

