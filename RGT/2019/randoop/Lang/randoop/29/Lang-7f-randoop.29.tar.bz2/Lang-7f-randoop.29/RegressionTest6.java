import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("4##", "100#100#0#-1#100#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4##" + "'", str2.equals("4##"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("-1452497");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        int[] intArray3 = new int[] { (short) -1, '4', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a52a97" + "'", str5.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a52a97" + "'", str7.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1#52#97" + "'", str9.equals("-1#52#97"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', 2, 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        byte byte18 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100#100#0#-1#100#100" + "'", str11.equals("100#100#0#-1#100#100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100#100#0#-1#100#100" + "'", str17.equals("100#100#0#-1#100#100"));
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) -1 + "'", byte18 == (byte) -1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1...", charSequence1, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("444444444444444444444444444444444444444444444444444444444444444444...", "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_-56127983", "                         sun.awt.cgraphicsenvironmen");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444..." + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444..."));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 135432, (long) 35, (long) 3);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 135432L + "'", long3 == 135432L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt....", "");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "hi!", 7, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "4444444sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("SU");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("SU", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983", (int) (short) 100, "sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophiesophiesophiesophiesophieso/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983" + "'", str3.equals("sophiesophiesophiesophiesophieso/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-1a52a9", (java.lang.CharSequence) "tionatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavationJatform API Specifica PlavaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(32, 520, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("# a", "iklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "oraclecorporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1.equals(1.0d));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4a#");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4a#" + "'", str3.equals("4a#"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("44#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1, (long) 0, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("mixed mode", "100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("\n\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n\n" + "'", str1.equals("\n\n"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("24.80-b11#########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11#########" + "'", str1.equals("24.80-b11#########"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.", "1#100#0#97", 11);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.0a-1.0", (float) 13);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13.0f + "'", float2 == 13.0f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "AAAAAAAAAA4....twa.nus4389720651_62425_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/4 4tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("#aa#aa#aa#aa#aa#aa#aa#aa#aa##aa#aa#aa#aa#aa#aa#aa#aa#aa#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#aa#aa#aa#aa#aa#aa#aa#aa#aa##aa#aa#aa#aa#aa#aa#aa#aa#aa#" + "'", str1.equals("#aa#aa#aa#aa#aa#aa#aa#aa#aa##aa#aa#aa#aa#aa#aa#aa#aa#aa#"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "ass [J", (java.lang.CharSequence) "1 100 0 97");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        char[] charArray5 = new char[] { '4', '#' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                              1.7", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 1, (int) (short) 1);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray5);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.4", (int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("             -1A32                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"             -1A32                  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0410410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("100404-141004100", (int) (byte) 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100404-141004100" + "'", str3.equals("100404-141004100"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        int[] intArray3 = new int[] { (short) -1, '4', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a52a97" + "'", str5.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a52a97" + "'", str8.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1#52#97" + "'", str12.equals("-1#52#97"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "520.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        char[] charArray4 = new char[] { '#', 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444444sun.lwawt.macosx.CPrinterJob", charArray4);
        java.lang.Class<?> wildcardClass9 = charArray4.getClass();
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983", '4');
        java.lang.Class<?> wildcardClass13 = strArray12.getClass();
        char[] charArray19 = new char[] { '#', 'a' };
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray19, 'a');
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(charArray19, 'a', 100, 0);
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join(charArray19, '#', (int) (short) 10, 0);
        boolean boolean30 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ".7.0_80-B15", charArray19);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.join(charArray19, '#');
        int int33 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray19);
        boolean boolean34 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray19);
        java.lang.Class<?> wildcardClass35 = charArray19.getClass();
        java.lang.String[] strArray38 = org.apache.commons.lang3.StringUtils.split("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "10.0a-1.0");
        java.lang.String str42 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray38, '#', 9, 7);
        java.lang.Class<?> wildcardClass43 = strArray38.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray44 = new java.lang.reflect.AnnotatedElement[] { wildcardClass9, wildcardClass13, wildcardClass35, wildcardClass43 };
        java.lang.String str45 = org.apache.commons.lang3.StringUtils.join(annotatedElementArray44);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "#aa" + "'", str6.equals("#aa"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "#aa" + "'", str21.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "##a" + "'", str32.equals("##a"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(annotatedElementArray44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "class [Cclass [Ljava.lang.String;class [Cclass [Ljava.lang.String;" + "'", str45.equals("class [Cclass [Ljava.lang.String;class [Cclass [Ljava.lang.String;"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1 32" + "'", str7.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1a32" + "'", str9.equals("-1a32"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1432" + "'", str11.equals("-1432"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        double[] doubleArray1 = new double[] { (short) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100.0" + "'", str5.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0" + "'", str7.equals("100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                           35.0#10.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "4444444100404-141004100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                    ", 0, "# a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                    " + "'", str3.equals("                                                    "));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("SUN.LWAWT.MACOSX.lwctOOLKI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.lwctoolki" + "'", str1.equals("sun.lwawt.macosx.lwctoolki"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        char[] charArray6 = new char[] { '#', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "TIONATFORM api sPECIFICA pLAVAj", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0a10.0", charArray6);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                               UTF-8", charArray6);
        java.lang.Class<?> wildcardClass14 = charArray6.getClass();
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#aa" + "'", str8.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#4a" + "'", str10.equals("#4a"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.0a10.sun.awt....");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0a10.sun.awt...." + "'", str1.equals("1.0a10.sun.awt...."));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("-1a52a97-1", (int) 'a', 135432);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a52a97-1" + "'", str3.equals("-1a52a97-1"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        int[] intArray4 = new int[] { (short) 1, 100, (short) 0, 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', (int) 'a', 35);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a100a0a97" + "'", str6.equals("1a100a0a97"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.awt.CGraphicsEnvironmen");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "10.0 1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        long[] longArray2 = new long[] { 0L, 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', (int) (byte) 10, 2);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaB", (int) 'a', 13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("4", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4" + "'", str2.equals("4"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(31.0d, (double) 68, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("TIONATFORM API SPECIFICA PLAVAJ", "Oracle Corporation", (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJ" + "'", str3.equals("TIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJOracle CorporationTIONATFORM API SPECIFICA PLAVAJ"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("B", "0 10 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "B" + "'", str2.equals("B"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "                   1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "...rs/_...", (java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("tionatform API Specifica PlavaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavalP acificepS IPA mroftanoit" + "'", str1.equals("JavalP acificepS IPA mroftanoit"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwawt.macosx.lwctoolki", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("100.0100.0100.0100.0100.0100.01", "44444444444444444444444444444444444444444444444444444444444444...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0100.0100.0100.0100.0100.01" + "'", str2.equals("100.0100.0100.0100.0100.0100.01"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("7", "1.01.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.10.0", (int) (byte) 10);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "oraclecorporation");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.0A-1.0", 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                           10.0A-1.0" + "'", str3.equals("                                                                                           10.0A-1.0"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "-1A32                  ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaa                                                                                          ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                          " + "'", str2.equals("                                                                                          "));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/", "", "7                                  ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("-1#32", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32#-1" + "'", str2.equals("32#-1"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("      35.0#10.      ", "1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      35.0#10.      " + "'", str2.equals("      35.0#10.      "));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("100#100#0#-1#100#100aaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#100#0#-1#100#100aaaaaaaaaaa" + "'", str1.equals("100#100#0#-1#100#100aaaaaaaaaaa"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "0#100", (java.lang.CharSequence) "TIONATFORM api sPECIFICA pLAVAj0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "4", (java.lang.CharSequence) "-1 32");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray5 = new char[] { '4', '#' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                              1.7", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 1, (int) (short) 1);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ass [J", charArray5);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                           35.0#10.", (java.lang.CharSequence) " 100 100                                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("0#10#10", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.", "", 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 100, 31);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a32" + "'", str7.equals("-1a32"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1#32" + "'", str9.equals("-1#32"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1 32" + "'", str11.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("ES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "10.0 100.0 -1.0 -1.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                  ", 97, "es/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "es/jdk1.7.0_80.jdk/Contents/Home/jrees/                  es/jdk1.7.0_80.jdk/Contents/Home/jrees/j" + "'", str3.equals("es/jdk1.7.0_80.jdk/Contents/Home/jrees/                  es/jdk1.7.0_80.jdk/Contents/Home/jrees/j"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/users/sophie/documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983", (float) 20);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 20.0f + "'", float2 == 20.0f);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                  ", "                                                                                           10.0A-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#aa", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] { '#', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 100, 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, '#', (int) (short) 10, 0);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ".7.0_80-B15", charArray6);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray6);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray6);
        java.lang.Class<?> wildcardClass22 = charArray6.getClass();
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#aa" + "'", str8.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "##a" + "'", str19.equals("##a"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    ", 10, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        char[] charArray6 = new char[] { '#', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                               UTF-8", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.0", charArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, '#', 9, 0);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.01.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.10.0", charArray6);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platform API Specification", charArray6);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 9, (-1));
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#aa" + "'", str8.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#4a" + "'", str10.equals("#4a"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("OracleCorporatio", (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        float[] floatArray2 = new float[] { 10, 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', (int) (short) 0, (int) (byte) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', 35, (int) ' ');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0 1.0" + "'", str4.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "# a", "1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9", 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Mac OS X", "Dk1.7.0_80.jdk/contents/home/jr", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("10.0A-1.0", 73, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1 52 97");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1 52 97\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 34 + "'", int1 == 34);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "100-132100-132100-1tionatformaAPIaSpecificaaPlavaJ100-132100-132100-1", (java.lang.CharSequence) "es/jdk1.7.0_80.jdk/Contents/Home/jre", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("0410410", "###################################", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("             -1A32                  ", "sun.awt....");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             -1A32                  " + "'", str2.equals("             -1A32                  "));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " ", (java.lang.CharSequence) "#aa#aa#aa#aa#aa#aa#aa#aa#aa##aa#aa#aa#aa#aa#aa#aa#aa#aa#", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        char[] charArray3 = new char[] { 'a', '#' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a', 11, (int) (short) 1);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "00#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100", charArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray3, '4', 20, 18);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                10.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1#100#0#97", (java.lang.CharSequence) "10.0#-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 1, (byte) 0, (byte) 100, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', 97, 35);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        char[] charArray4 = new char[] { '#', 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 100, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray4, '#', (int) (short) 10, 0);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ".7.0_80-B15", charArray4);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray4, '#', 1, (int) (short) 0);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporatio", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "#aa" + "'", str6.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "##a" + "'", str17.equals("##a"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("      35.0#10.      ", "-1a32");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                0.                 ", "", (int) (short) 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                0.                 " + "'", str3.equals("                0.                 "));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                1.                 ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        float[] floatArray2 = new float[] { 10, 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 69, 13);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0 1.0" + "'", str4.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0#1.0" + "'", str6.equals("10.0#1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 52);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "01 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 ", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        double[] doubleArray4 = new double[] { 10.0f, (short) 100, (-1), (-1.0f) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a100.0a-1.0a-1.0" + "'", str7.equals("10.0a100.0a-1.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Mac OS X", "JAVA(TM) SE RUNTIME ENVIRONMENT", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 96L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 96.0f + "'", float3 == 96.0f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(".9", 11, "24.80-b11#########");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".924.80-b11" + "'", str3.equals(".924.80-b11"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#100#0#-1#100#100" + "'", str10.equals("100#100#0#-1#100#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1004100404-141004100" + "'", str12.equals("1004100404-141004100"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1004100404-141004100" + "'", str16.equals("1004100404-141004100"));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) -1 + "'", byte17 == (byte) -1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "1.744444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#100#0#-1#100#100" + "'", str10.equals("100#100#0#-1#100#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1004100404-141004100" + "'", str12.equals("1004100404-141004100"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100#100#0#-1#100#100" + "'", str15.equals("100#100#0#-1#100#100"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("67 1 100", (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        char[] charArray5 = new char[] { '#', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, '4');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                               UTF-8", charArray5);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1 32                                                                                               ", charArray5);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolki", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#aa" + "'", str7.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "#4a" + "'", str9.equals("#4a"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "10.0", (java.lang.CharSequence) "                         sun.awt.CGraphicsEnvironmen", 520);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "hi!");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80" + "'", str5.equals("1.7.0_80"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("es/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "es/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("es/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        char[] charArray5 = new char[] { '#', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 100, 0);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray5);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.04-1.0467.0", charArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 100, 7);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444100404-141004100", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#aa" + "'", str7.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("ES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (int) (short) 10, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0_80.JDK/CONTENTS/HOME/JRE" + "'", str3.equals("0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("44#", "1410040497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-145249");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44#" + "'", str2.equals("44#"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.0a-1.0", 69);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("100 100 0 -1 100 100");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("0#10#10", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#10#10" + "'", str2.equals("0#10#10"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolki", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("aaaaaaaaaa                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaa                                                                                          " + "'", str1.equals("aaaaaaaaaa                                                                                          "));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 68, 31);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#100#0#-1#100#100" + "'", str10.equals("100#100#0#-1#100#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1004100404-141004100" + "'", str12.equals("1004100404-141004100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                   1.7.0_80-B15", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                   1.7.0_80-B15" + "'", str2.equals("                   1.7.0_80-B15"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("es/jdk1.7.0_80.jdk/Contents/Home/jre", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "es/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("es/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(32, 20, 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray2 = new char[] { '#' };
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA", 1);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "4444444sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 6, 11L, (long) 67);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 67L + "'", long3 == 67L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("       ", (int) '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       #############################################" + "'", str3.equals("       #############################################"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Mac OS X", "                                        100 100 0 -1 100 100                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4', 97, 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse(" 100 0 97");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "79 0 001 " + "'", str1.equals("79 0 001 "));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        double[] doubleArray2 = new double[] { (short) 10, (-1.0d) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0a-1.0" + "'", str5.equals("10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0#-1.0" + "'", str7.equals("10.0#-1.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0a-1.0" + "'", str9.equals("10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        int[] intArray3 = new int[] { (short) -1, '4', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', 93, 32);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a52a97" + "'", str5.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a52a97" + "'", str7.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        char[] charArray6 = new char[] { '#', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "TIONATFORM api sPECIFICA pLAVAj", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0a10.0", charArray6);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                               UTF-8", charArray6);
        java.lang.Class<?> wildcardClass14 = charArray6.getClass();
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "01 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 ", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#aa" + "'", str8.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#4a" + "'", str10.equals("#4a"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "#aa" + "'", str16.equals("#aa"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("       #############################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#############################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("-1#52#97", "0.15", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaSU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaS" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaS"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("444444444444444444444444444444444444444444444444444444444444444444444100.0100.0100.0100.0100.0100.01", 52);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 34, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("##aOracle Cor");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##aOracle Cor" + "'", str1.equals("##aOracle Cor"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                         sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", "                  ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        float[] floatArray2 = new float[] { 10, 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.Class<?> wildcardClass10 = floatArray2.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0 1.0" + "'", str4.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0a1.0" + "'", str6.equals("10.0a1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0 1.0" + "'", str8.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0a1.0" + "'", str12.equals("10.0a1.0"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        char[] charArray3 = new char[] { '4', '#' };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                              1.7", charArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a', 1, (int) (short) 1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray3, '4');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray3, '4');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4a#" + "'", str10.equals("4a#"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4 #" + "'", str12.equals("4 #"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4a#" + "'", str14.equals("4a#"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "44#" + "'", str16.equals("44#"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "44#" + "'", str18.equals("44#"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10a1a0a100a-1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1" + "'", str1.equals("-1"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre", "-1432", (int) (short) 7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "10.14.3", 10);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "mixed mode");
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("US", "1.744444444444444444444444444444");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach(" ", strArray13, strArray16);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "-1a52a97", (java.lang.CharSequence[]) strArray13);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("51.0", strArray4, strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Java Platform API Specification" + "'", str11.equals("Java Platform API Specification"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + " " + "'", str17.equals(" "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "51.0" + "'", str19.equals("51.0"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "# a##########################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "###############################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 32, 0.0f, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("sophie", "a100#100#0#-1#100#100100#100#0#-1#1", "SUN.LWAWT.MACOSX.LWCTOOLKI", 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sophie" + "'", str4.equals("sophie"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a32" + "'", str7.equals("-1a32"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1#32" + "'", str9.equals("-1#32"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) " 35.0#10.      ", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str4 = javaVersion0.toString();
        java.lang.String str5 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean8 = javaVersion6.atLeast(javaVersion7);
        boolean boolean9 = javaVersion0.atLeast(javaVersion6);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.9" + "'", str4.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.9" + "'", str5.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java HotSpot(TM) 64-Bit Server VM", ".7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("79 0 001 ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                                                             ", "Dk1.7.0_80.jdk/contents/home/j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "x86_64////", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "x86_64////" + "'", charSequence2.equals("x86_64////"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "100a100a0a-1a100a100", (java.lang.CharSequence) "             ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "100                                                                                                 ", (java.lang.CharSequence) "01010");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "100                                                                                                 " + "'", charSequence2.equals("100                                                                                                 "));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4', 1, 68);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "tionatform API Specifica PlavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("51.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("00#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100", "....04...", 100);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "00#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100" + "'", str5.equals("00#1000100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#100-100#100#0#-1#100#1001100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100#100#100#0#-1#100#1006100#100#0#-1#100#1007100#100#0#-1#100#100.100#100#0#-1#100#1000100#100#0#-1#100#100"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("10.0#-1.0", "aaaaaaaaaa                                                                                          ", 93);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0#-1.0" + "'", str3.equals("10.0#-1.0"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "avaj/bil/rs", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "0.91.70.91.20.90.9", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        int[] intArray3 = new int[] { (short) -1, '4', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', (int) '4', (int) (short) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', 69, 52);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a52a97" + "'", str5.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaSU", (java.lang.CharSequence) "10.0#1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporatio" + "'", str1.equals("Oracle Corporatio"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "10.0#1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("TIONATFORM api sPECIFICA pLAVAj", "1A100A0A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A9", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("10.0a100.0a-1.0a-1.0", 92);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.0" + "'", str2.equals("10.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.0"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "- 32", (java.lang.CharSequence) "1 52 97", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                  ", (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaB", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "tionatformaAPIaSpecificaaPlavaJ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 100, (long) 32, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("...444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("...444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.", "dk1.7.0_80.jdk/contents/home/jr", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1." + "'", str3.equals("1."));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sun.lwawt.macosx.lwctoolki");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.lwctoolki\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "-1a52a97-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("0a10a10", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.010.0a100.0a-1.0a-1.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0#100", (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("00", "                0.                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("51.0                                                                                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0      \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("oraclecorporation", ".", (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oraclecorporation" + "'", str3.equals("oraclecorporation"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "444444444", (java.lang.CharSequence) "1410040497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-145249");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("- 32");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10                              ", "Dk1.7.0_80.jdk/contents/home/j", "x86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10                              " + "'", str3.equals("0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10                              "));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("-1452497");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                1.                 ", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                1.                 " + "'", str3.equals("                1.                 "));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0.0100.0100.0100.0100.0100.01", (int) (short) 0, "10.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.010.0#-1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0100.0100.0100.0100.0100.01" + "'", str3.equals("0.0100.0100.0100.0100.0100.01"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.9f, 0.0f, (float) 'a');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("               1.7", 3, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               1.7" + "'", str3.equals("               1.7"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-1#52#97");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("es/jdk1.7.0_80.jdk/Contents/Home/jre", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "es/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("es/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                                                                               UTF-8", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                               UTF-8" + "'", str2.equals("                                                                                               UTF-8"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VM444444444444444444444444444444444444444444444444444444444444", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                                                          ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                  ", "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "iklooTCWL.xsocam.twawl.nus", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                0.                 ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                0.                 " + "'", str3.equals("                0.                 "));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("IKLOOTCWL.XSOCAM.TWAWL.NUS444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "IKLOOTCWL.XSOCAM.TWAWL.NUS444444444444444444444444444444" + "'", str2.equals("IKLOOTCWL.XSOCAM.TWAWL.NUS444444444444444444444444444444"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        char[] charArray5 = new char[] { '#', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100.0100.0100.0100.0100.0100.01", charArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 52, 0);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a100a0a-1a100a100", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#aa" + "'", str7.equals("#aa"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("OracleCorporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporati" + "'", str1.equals("OracleCorporati"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("4-1.0467", 97, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4-1.0467                                                                                         " + "'", str3.equals("4-1.0467                                                                                         "));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.0a10.0", 520);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("...rs/_...", "                                        100 100 0 -1 100 100                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...rs/_..." + "'", str2.equals("...rs/_..."));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("", "10.0a1.0", 1);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("", "10.0a1.0", 1);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray14, "                                                                                               UTF-8");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, 'a');
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray14);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983", strArray10, strArray19);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.stripAll(strArray19);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray3, strArray21);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str5.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983" + "'", str20.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983"));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str22.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("avaj/bil/rs");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"avaj/bil/rs\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#10#10" + "'", str6.equals("0#10#10"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0 10 10" + "'", str10.equals("0 10 10"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 10 + "'", short11 == (short) 10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1.0f), (double) 56, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(56, 0, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("100-1 32                        ", "Oracle", "4##");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100-1 32                        " + "'", str3.equals("100-1 32                        "));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("jav...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jav..." + "'", str1.equals("jav..."));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "- 32", (java.lang.CharSequence) "JavalP acificepS IPA mroftanoit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1a52a97-1", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre", "-1432", (int) (short) 7);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("US", "1.744444444444444444444444444444");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("B", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "B" + "'", str9.equals("B"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("10.0#100.0#-1.0#-1.0", 135432, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean9 = javaVersion4.atLeast(javaVersion8);
        boolean boolean10 = javaVersion1.atLeast(javaVersion8);
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean14 = javaVersion12.atLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean16 = javaVersion13.atLeast(javaVersion15);
        boolean boolean17 = javaVersion1.atLeast(javaVersion15);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9" + "'", str3.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("iklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "IKLOOtcwl.XSOCAM.TWAWL.NUS" + "'", str1.equals("IKLOOtcwl.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VM444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "4444444100404-141004100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("es/jdk1.7.0_80.jdk/Contents/Home/jrees/                  es/jdk1.7.0_80.jdk/Contents/Home/jrees/j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Es/jdk1.7.0_80.jdk/Contents/Home/jrees/                  es/jdk1.7.0_80.jdk/Contents/Home/jrees/j" + "'", str1.equals("Es/jdk1.7.0_80.jdk/Contents/Home/jrees/                  es/jdk1.7.0_80.jdk/Contents/Home/jrees/j"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(9, 23, 68);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 68);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("                                                    ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4-1.0467                                                                                         ", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4-1.0467                                                                                         " + "'", str3.equals("4-1.0467                                                                                         "));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("-1452497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1452497" + "'", str2.equals("-1452497"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "...444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100#100#0#-1#100#100" + "'", str11.equals("100#100#0#-1#100#100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100 100 0 -1 100 100" + "'", str13.equals("100 100 0 -1 100 100"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                              1#52#97", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US" + "'", str2.equals("US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                         sun.awt.CGraphicsEnvironmen", "", "0.0100.0100.0100.0100.0100.01", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                         sun.awt.CGraphicsEnvironmen" + "'", str4.equals("                         sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("x86_64////", 2, 69);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6_64////" + "'", str3.equals("6_64////"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0a10a10", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 18L, (float) (byte) 10, (float) 68L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '#', 52, 68);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaaaaaaaaaaa10.0a1.0", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaa10.0a1.0" + "'", str2.equals("aaaaaaaaaaaa10.0a1.0"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("24.80-b11#########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11#########" + "'", str1.equals("24.80-b11#########"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52426_156027983");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sun.awt....sun.awt....sun.awt....sunJava Platform API Specificatio", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt....sun.awt....sun.awt....sunJava Platform API Specificatio" + "'", str2.equals("sun.awt....sun.awt....sun.awt....sunJava Platform API Specificatio"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("100.0100.0100.0100.0100.0100.01 ", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0100.0100.0100.0100.0100.01 " + "'", str3.equals("100.0100.0100.0100.0100.0100.01 "));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "100404-141004100", (java.lang.CharSequence) ".7.0_80-B15", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("class [Cclass [Ljava.lang.String;class [Cclass [Ljava.lang.String;", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("0.15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("10.14.3", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "4");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97ava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("x86_64////", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "iklooTCWL.xsocam.twawl.nus", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1#32");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "iklooTCWL.xsocam.twawl.nus" + "'", charSequence2.equals("iklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1#32", "51.0                                                                                                ", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                              1.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        double[] doubleArray4 = new double[] { 10.0f, (short) 100, (-1), (-1.0f) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', (int) ' ', 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 10, 68);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a100.0a-1.0a-1.0" + "'", str7.equals("10.0a100.0a-1.0a-1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10.0#100.0#-1.0#-1.0" + "'", str13.equals("10.0#100.0#-1.0#-1.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "oraclecorporation", (java.lang.CharSequence) "Oracle Corporation                                  ", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaa10.0a1.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("0 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 100 10 10", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Oracle Cor", (int) (short) 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle " + "'", str2.equals("Oracle "));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString(" ", "4##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("IKLOOTCWL.XSOCAM.TWAWL.NUS", "1#52tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "IKLOOTCWL.XSOCAM.TWAWL.NUS" + "'", str2.equals("IKLOOTCWL.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("tionatform API Specifica PlavaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tionatform API Specifica PlavaJ" + "'", str1.equals("tionatform API Specifica PlavaJ"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "http://jv.orcle.com/", (java.lang.CharSequence) "0.0100.0100.0100.0100.0100.01");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "#aa", "JAVA PLATFORM API SPECIFICATION");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.", "", 100);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("7                                  ", strArray4, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "7                                  " + "'", str9.equals("7                                  "));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("senwawt.macosx.CPrinterJob", "0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "-1a52a97-1a52a97-1a52a10.0a1.0-1a52a97-1a52a97-1a52a");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "0 10 10", (int) (short) 1, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "x86_64////", 56);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("dk1.7.0_80.jdk/contents/10.04100.04-1.04-1.0dk1.7.0_80.jdk/contents/", "7", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/10.04100.04-1.04-1.0dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/" + "'", str3.equals("dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/10.04100.04-1.04-1.0dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("JAVA3PLATFORM3API3SPECIFICATION", 92);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              JAVA3PLATFORM3API3SPECIFICATION                               " + "'", str2.equals("                              JAVA3PLATFORM3API3SPECIFICATION                               "));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("0 10 100 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 10 100 1" + "'", str1.equals("0 10 100 1"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) (short) 10, 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 69, (int) (byte) 10);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) (byte) 10, 23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#10#10" + "'", str6.equals("0#10#10"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.", "JAVA PLATFORM API SPECIFICATION", (int) (byte) 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "17.1");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1." + "'", str5.equals("1."));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "-1a52a97");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.7.0_80-b15", "410040497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-1452497-145249", "-1a52a97-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                              JAVA3PLATFORM3API3SPECIFICATION                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                              JAVA3PLATFORM3API3SPECIFICATION                               " + "'", str1.equals("                              JAVA3PLATFORM3API3SPECIFICATION                               "));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaa                                                                                          ", "x86_64////", 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa                                                                                          " + "'", str3.equals("aaaaaaaaaa                                                                                          "));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("-1452497", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1452497" + "'", str2.equals("-1452497"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "dk1.7.0_80.jdk/contents/home/jre", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("4##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4##" + "'", str1.equals("4##"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("00.0 10.0 67.0", "-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1#100#0#97", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        int[] intArray3 = new int[] { (short) -1, '4', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a52a97" + "'", str5.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a52a97" + "'", str8.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1 52 97" + "'", str10.equals("-1 52 97"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        char[] charArray3 = new char[] { '#', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a');
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1#32", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "#aa" + "'", str5.equals("#aa"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 69);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(135432L, (long) 7, (long) 18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 135432L + "'", long3 == 135432L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "Java Platform API Specification", 69);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        char[] charArray5 = new char[] { '4', '#' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                              1.7", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 1, (int) (short) 1);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen", charArray5);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "tionatform API Specifica PlavaJ                                                                  ", charArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4##" + "'", str14.equals("4##"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("0#100", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0#100" + "'", str3.equals("0#100"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.744444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "10.0a1.0", 1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "                                                                                               UTF-8");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1a100a0a97", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                             1a100a0a97                                             " + "'", str2.equals("                                             1a100a0a97                                             "));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("# a##########################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# a##########################################################################################" + "'", str1.equals("# a##########################################################################################"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "sophiesophiesophiesophiesophieso/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                           10.0A-1.0", "Mac OS X", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        float[] floatArray1 = new float[] { 0L };
        float[] floatArray3 = new float[] { 0L };
        float[][] floatArray4 = new float[][] { floatArray1, floatArray3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray4);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1#52tiklooTCWL.xsocam.twawl.nus", "1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "               1.7", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        char[] charArray3 = new char[] { '4', '#' };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                              1.7", charArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a', 1, (int) (short) 1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray3, '#', 10, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4a#" + "'", str10.equals("4a#"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                   1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51b-08_0.7.1                   " + "'", str1.equals("51b-08_0.7.1                   "));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444100.0100.0100.0100.0100.0100.01", (java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1a52a9", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(".1                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("4");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("aaaaaaaaaa                                                                                         ", "0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa                                                                                         " + "'", str2.equals("aaaaaaaaaa                                                                                         "));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        java.lang.String str7 = javaVersion3.toString();
        java.lang.String str8 = javaVersion3.toString();
        boolean boolean9 = javaVersion1.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean12 = javaVersion10.atLeast(javaVersion11);
        boolean boolean13 = javaVersion3.atLeast(javaVersion10);
        java.lang.String str14 = javaVersion3.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.9" + "'", str8.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.9" + "'", str14.equals("0.9"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("0#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#100" + "'", str1.equals("0#100"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/10.04100.04-1.04-1.0dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                0.                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/10.04100.04-1.04-1.0dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/" + "'", str3.equals("dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/10.04100.04-1.04-1.0dk1.sun.lwawt.macosx.CPrinterJob.0_80.jdk/contents/"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("\n", "1a100a0a97", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/..." + "'", str2.equals("/Users/..."));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "OracleCorporati", (java.lang.CharSequence) "jEvE HotSpot(TM) 64EBit Server VM", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                              JAVA3PLATFORM3API3SPECIFICATION                               ", (java.lang.CharSequence) "/Lib...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a', 0, (int) '#');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1A100A0A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                    1.7", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.7f + "'", float2 == 1.7f);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "100#100                                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                " + "'", str1.equals("                                                                                                "));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("10.04-1.0467.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                0.                 ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                0.                 " + "'", str2.equals("                0.                 "));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "OracleCorporati");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52, (float) 31, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern(".7.0_80-b15", "100.0", "- 32");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".7.0_80-b15" + "'", str3.equals(".7.0_80-b15"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835", "MacOSX");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "1.744444444444444444444444444444");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByCharacterType("US");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("http://java.oracle.com/                       ", strArray7, strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("-1#52#97", strArray3, strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "http://java.oracle.com/                       " + "'", str10.equals("http://java.oracle.com/                       "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1#52#97" + "'", str11.equals("-1#52#97"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sophie", "0#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (short) 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaa" + "'", str2.equals("aaaaaaa"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(" ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        double[] doubleArray2 = new double[] { (short) 10, (-1.0d) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0a-1.0" + "'", str5.equals("10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0#-1.0" + "'", str9.equals("10.0#-1.0"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "Dk1.7.0_80.jdk/contents/home/j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                         sun.awt.cgraphicsenvironmen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0.91.70.91.20.90.9", "                                                                                             ", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("avaj/bil/rs", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "avaj/bil/rs" + "'", str3.equals("avaj/bil/rs"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("ass [J");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ass [J" + "'", str1.equals("ass [J"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        short[] shortArray1 = new short[] { (short) 100 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 67, (int) ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0" + "'", str1.equals("100.0"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("1004100404-141004100", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1004100404-141004100" + "'", str2.equals("1004100404-141004100"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                         sun.awt.cgraphicsenvironmen", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                         sun.awt.cgraphicsenvironmen" + "'", str3.equals("                         sun.awt.cgraphicsenvironmen"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.0a10.sun.awt....", "                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0.0100.0100.0100.0100.0100.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0100.0100.0100.0100.0100.01" + "'", str1.equals("0.0100.0100.0100.0100.0100.01"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = new byte[] {};
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = new byte[] {};
        byte[][] byteArray4 = new byte[][] { byteArray0, byteArray1, byteArray2, byteArray3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray4);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(".1                                                                                              ", "32                                                                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".1" + "'", str2.equals(".1"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("10.0 1.0 5.0", "                                        100 100 0 -1 100 100                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 1.0 5.0" + "'", str2.equals("10.0 1.0 5.0"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        int[] intArray3 = new int[] { (short) -1, '4', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ', (int) ' ', 31);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', (int) (short) 100, 3);
        int int18 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a52a97" + "'", str5.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1452497" + "'", str9.equals("-1452497"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 97 + "'", int18 == 97);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97ava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0sun.awt....JAVA PLATFORM API SPECIFICATION10.0a1.0", (java.lang.CharSequence) "Oracle Corporation", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        float[] floatArray3 = new float[] { 10L, 1.0f, 5 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0 1.0 5.0" + "'", str5.equals("10.0 1.0 5.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.3", 93);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("x86_64", 4.44444448E8f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.44444448E8f + "'", float2 == 4.44444448E8f);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("http://jv.orcle.com/", "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://jv.orcle.com/" + "'", str2.equals("http://jv.orcle.com/"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "avaj/bil/rs");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Oracle");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle" + "'", str1.equals("Oracle"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("\n\n", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               \n\n                                                " + "'", str2.equals("                                               \n\n                                                "));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444...", 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("HI!", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENT" + "'", str1.equals("JAVA(TM) SE RUNTIME ENVIRONMENT"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("...rs/_...", "-1", "             -1A32                  ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        long[] longArray2 = new long[] { 0L, 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a', (int) (short) 7, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0#100" + "'", str5.equals("0#100"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sun.lwawt.macosx.lwctoolki");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.lwctoolki" + "'", str1.equals("sun.lwawt.macosx.lwctoolki"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 1, (byte) 0, (byte) 100, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "1.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/", "TIONATFORM api sPECIFICA pLAVAj");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "0_80.JDK/CONTENTS/HOME/JRE", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/" + "'", str4.equals("/"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "a100#100#0#-1#100#100100#100#0#-1#1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: a100#100#0#-1#100#100100#100#0#-1#1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("IKLOOtcwl.XSOCAM.TWAWL.NUS", "", 5, 11);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "IKLOOSOCAM.TWAWL.NUS" + "'", str4.equals("IKLOOSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', 34, (int) (byte) 0);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1 32" + "'", str7.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1a32" + "'", str9.equals("-1a32"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1432" + "'", str11.equals("-1432"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        char[] charArray4 = new char[] { '#', 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 100, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray4, '#', (int) (short) 10, 0);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ".7.0_80-B15", charArray4);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray4);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "#aa" + "'", str6.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "##a" + "'", str17.equals("##a"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', (int) '4', 7);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#100#0#-1#100#100" + "'", str10.equals("100#100#0#-1#100#100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100a100a0a-1a100a100" + "'", str16.equals("100a100a0a-1a100a100"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1004100404-141004100" + "'", str18.equals("1004100404-141004100"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test421");
        int[] intArray3 = new int[] { (short) -1, '4', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', 7, 2);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 7, 135432);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a52a97" + "'", str5.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a52a97" + "'", str7.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1#52#97" + "'", str9.equals("-1#52#97"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Java(TM) SE ROracleCorporatioments/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA", "#4a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE ROracleCorporatioments/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA" + "'", str2.equals("Java(TM) SE ROracleCorporatioments/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.awt....sun.awt....sun.awt....sunJava Platform API Specificatio", "0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt....sun.awt....sun.awt....sunJava Platform API Specificatio" + "'", str2.equals("sun.awt....sun.awt....sun.awt....sunJava Platform API Specificatio"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                                           10.0A-1.0", (java.lang.CharSequence) "/Lib...", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray3 = new char[] { '#', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a', 100, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray3, '#', (int) (short) 10, 0);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "#aa" + "'", str5.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "es/jdk1.7.0_80.jdk/Contents/Home/jrees/                  es/jdk1.7.0_80.jdk/Contents/Home/jrees/j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Librlry/Jlvl/JlvlVirtullMlchines/jdksn7nu_8unjdk/Contents/Home/jre", (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.01.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.10.0", 97);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "10.0#-1.0");
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10.0 100.0 -1.0 -1.0", (java.lang.CharSequence[]) strArray7);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, ' ', 9, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("dk1.7.0_80.jdk/contents/10.04100.04-1.04-1.0dk1.7.0_80.jdk/contents/", "0#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "dk1.7.0_80.jdk/contents/10.04100.04-1.04-1.0dk1.7.0_80.jdk/contents/" + "'", str2.equals("dk1.7.0_80.jdk/contents/10.04100.04-1.04-1.0dk1.7.0_80.jdk/contents/"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA", 1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "100#100#0#-1#100#100", (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        int[] intArray4 = new int[] { 96, 68, (short) 0, (byte) 100 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', (int) (short) 100, 0);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    ", (int) '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    " + "'", str3.equals("                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    100                                                    "));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.lwawt.macosx.lwctoolki", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 7.0f, 0.0d, (double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("###################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################################" + "'", str1.equals("###################################"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("\n", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aa", "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa" + "'", str2.equals("aa"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.01.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.10.0", 97);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "10.0#-1.0");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "1a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97 1a100a0a9711a100a0a9701a100a0a97");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("     ", (int) (short) 1, 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    " + "'", str3.equals("    "));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "10.14.3", 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "mixed mode");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("US", "1.744444444444444444444444444444");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach(" ", strArray7, strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "Oracle Corporation");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Java Platform API Specification" + "'", str5.equals("Java Platform API Specification"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " " + "'", str11.equals(" "));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray14);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "10.0 1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("SU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SU" + "'", str1.equals("SU"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#10#10" + "'", str6.equals("0#10#10"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0 10 10" + "'", str10.equals("0 10 10"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 520, (long) 23, (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 23L + "'", long3 == 23L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("- 32", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "- 32" + "'", str2.equals("- 32"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("10.04-1.0467.");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaB", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaB" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaB"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100#100");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        java.lang.String str4 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.3" + "'", str4.equals("1.3"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("100-1 32                        ", "32                                                                                               ", "aaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100-1 32                        " + "'", str3.equals("100-1 32                        "));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre", 0, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.7.0_80-B15", "dk1.7.0_80.jdk/contents/10.04100.04-1.04-1.0dk1.7.0_80.jdk/contents/", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-B15" + "'", str3.equals("1.7.0_80-B15"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "0410410", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaSU");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(13, 67, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01" + "'", str1.equals("100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01100.0100.0100.0100.0100.0100.01"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0a10a10");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "\n\n", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "", (int) (short) 10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, '#', (int) (byte) 100, (int) '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray8);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(strArray15);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("B");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "B" + "'", str1.equals("B"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("7", 11, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaa7aaaaa" + "'", str3.equals("aaaaa7aaaaa"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        long[] longArray2 = new long[] { 0L, 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a', 3, (int) (byte) -1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 32, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 11, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ass [J", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 1, (byte) 0, (byte) 100, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        float[] floatArray3 = new float[] { 10L, 1.0f, 5 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', 0, (int) (short) 1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0 1.0 5.0" + "'", str5.equals("10.0 1.0 5.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0" + "'", str10.equals("10.0"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                           35.0#10.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("US", "oraclecorporation");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("7                                  ", "dk1.7.0_80.jdk/contents/10.04100.04-1.04-1.0dk1.7.0_80.jdk/contents/", 20);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("dk1.7.0_80.jdk/contents/home/jre", "aa0#100aaa", (int) ' ');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1a52a97-1", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 92, (double) 2, (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test477");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1#32", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "-1a52a97-1a52a97-1a52a10.0a1.0-1a52a97-1a52a97-1a52a");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "avaj/bil/rs-1#100#100aaaaaaaaaaa", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 35, "10.04-1.0467.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.04-1.0467.10.010.04-1.0467.10.04" + "'", str3.equals("10.04-1.0467.10.010.04-1.0467.10.04"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean8 = javaVersion5.atLeast(javaVersion7);
        boolean boolean9 = javaVersion0.atLeast(javaVersion5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                " + "'", str1.equals("                                "));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", 93);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93 + "'", int2 == 93);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "    ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 68);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                              1.7", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                       1.7" + "'", str2.equals("                                                                       1.7"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("7", "1.01.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.10.0", (int) (byte) 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "x86_64////");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "S", (java.lang.CharSequence) "aa0#100aaa", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("SUN.LWAWT.MACOSX.LWCTOOLKI");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SUN.LWAWT.MACOSX.LWCTOOLKI\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "10.04-1.0467.0", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10.04-1.0467.0", (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        double[] doubleArray2 = new double[] { (short) 10, (-1.0d) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4', 10, (int) (short) 7);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1432" + "'", str7.equals("-1432"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "1.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9", "", (int) (byte) -1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 20, 67);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9" + "'", str4.equals("1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("51.0                                                                                                ", "0.", "- 32");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51 -                                                                                                " + "'", str3.equals("51 -                                                                                                "));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("US", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "01 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 001 01 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0_80.JDK/CONTENTS/HOME/JRE", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0_80.JDK/CONTENTS/HOME/JRE" + "'", str2.equals("0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0410410", "           10.0#-1.0");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "a100#100#0#-1#100#100100#100#0#-1#1");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "a100#100#0#-1#100#100100#100#0#-1#1" + "'", str6.equals("a100#100#0#-1#100#100100#100#0#-1#1"));
    }
}

