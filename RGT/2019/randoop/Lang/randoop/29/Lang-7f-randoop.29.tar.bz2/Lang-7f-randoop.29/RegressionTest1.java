import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nUTF-8\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", "sun.lwawt.macosx.LWCToolki", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "US", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "24.80-b11" + "'", str0.equals("24.80-b11"));
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1004100404-141004100", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "10.14.3", 10);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "mixed mode");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Platform API Specification" + "'", str4.equals("Java Platform API Specification"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        long[] longArray2 = new long[] { 0L, 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', (long) 100, (long) 67);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1" + "'", str1.equals("-1"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10.04-1.0467.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.04-1.0467.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("B", 0, "1.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "B" + "'", str3.equals("B"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        int[] intArray3 = new int[] { (short) -1, '4', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ', (int) (short) 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a52a97" + "'", str5.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a52a97" + "'", str7.equals("-1a52a97"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java Virtual Machine Specification", "", "                                                                                               UTF-8");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "10.0a1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        float[] floatArray2 = new float[] { 10, 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', (int) ' ', (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0 1.0" + "'", str4.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0 1.0" + "'", str10.equals("10.0 1.0"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.7", "aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sun.awt....", "JAVA PLATFORM API SPECIFICATION", (int) (short) 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.awt....JAVA PLATFORM API SPECIFICATION" + "'", str4.equals("sun.awt....JAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!", "sun.awt....");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java Platform API Specification", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "10.14.3", 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str3.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("#aa", (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1a100a0a97", 100, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1a100a0a97" + "'", str3.equals("1a100a0a97"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("tionatform API Specifica PlavaJ                                                                  ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 1, (int) (byte) 100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "1.7.0_80" + "'", str0.equals("1.7.0_80"));
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71." + "'", str1.equals("1.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71."));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sun.awt....");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str2.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                1.                 ", (-1), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                1.                 " + "'", str3.equals("                1.                 "));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("http://java.oracle.com/", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("100", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100                                                                                                 " + "'", str2.equals("100                                                                                                 "));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolki", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.0a1.0", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("100", "sun.awt....JAVA PLATFORM API SPECIFICATION", "Java Virtual Machine Specification");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.744444444444444444444444444444", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("100#100#0#-1#100#100", "1.7.0_80", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100#100#0#-1#100#100", (int) ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#100#0#-1#100#100aaaaaaaaaaaa" + "'", str3.equals("100#100#0#-1#100#100aaaaaaaaaaaa"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "sun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: sun.lwawt.macosx.LWCToolkit");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "", "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle Corporation");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 67, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 67");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 10, (double) (byte) 10, (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Oracle Corporation", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("51.0", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaa", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa                                                                                          " + "'", str2.equals("aaaaaaaaaa                                                                                          "));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.awt....", "JAVA PLATFORM API SPECIFICATION", "hi!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                1.                 ", "-1a52a97", "100                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                0.                 " + "'", str3.equals("                0.                 "));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("US", "10.04-1.0467.0", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US" + "'", str3.equals("US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("\n\n", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(18, (int) (byte) -1, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.04-1.0467.0", "100#100#0#-1#100#100aaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sun.awt....JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("10.04-1.0467.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "dk1.7.0_80.jdk/contents/home/jre" + "'", str2.equals("dk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983", "mixed mode", "10.0 1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 52, (long) (byte) -1, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "-1a52a97", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "1.7.0_80");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("100#100#0#-1#100#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#100#0#-1#100#100" + "'", str1.equals("100#100#0#-1#100#100"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "#4a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9", (java.lang.CharSequence) "1.744444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9" + "'", charSequence2.equals("1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.7.0_80-b15", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "100                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "#4a", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.0a10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0a10.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 2, (float) 35L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Oracle Corporation                                  ", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("#4a", "1004100404-141004100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#4a" + "'", str2.equals("#4a"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("100.0", "1.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0" + "'", str2.equals("0.0"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9" + "'", str1.equals("1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 100, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("100#100#0#-1#100#100aaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) (byte) 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "10.0 1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 10.0f, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaa                                                                                          ", 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a" + "'", str3.equals("a"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "en", (java.lang.CharSequence) "10.0 1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Oracle Corporation", 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "TIONATFORM api sPECIFICA pLAVAj");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 4, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0" + "'", str1.equals("100.0"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("100#100#0#-1#100#100");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("100#100#0#-1#100#100aaaaaaaaaaaa", "1004100404-141004100", "                1.                 ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100#100#0#-1#100#100aaaaaaaaaaaa" + "'", str4.equals("100#100#0#-1#100#100aaaaaaaaaaaa"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("100.0100.0100.0100.0100.0100.01 ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.awt.CGraphicsEnvironmen", 0, "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironmen" + "'", str3.equals("sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("tionatform API Specifica PlavaJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"tionatform API Specifica PlavaJ\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "100.0100.0100.0100.0100.0100.01 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("x86_64", 10, "/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64////" + "'", str3.equals("x86_64////"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.01.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.01.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.10.0" + "'", str1.equals("1.01.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.10.0"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("x86_64////", (int) (byte) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64////" + "'", str3.equals("x86_64////"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "100", (java.lang.CharSequence) "dk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "100" + "'", charSequence2.equals("100"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nUTF-8\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", "", "\n", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nUTF-8\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + "'", str4.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nUTF-8\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "10.0a-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_LIBRARY_PATH;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str0.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("10.04-1.0467.0", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.04-1.0467.0" + "'", str2.equals("10.04-1.0467.0"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("JAVA PLATFORM API SPECIFICATION", "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983", "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA PLATFORM API SPECIFICATION" + "'", str3.equals("JAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("TIONATFORM api sPECIFICA pLAVAj", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TIONATFORM api sPECIFICA pLAVAj" + "'", str2.equals("TIONATFORM api sPECIFICA pLAVAj"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "10.0a-1.0", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10.0a-1.0" + "'", charSequence2.equals("10.0a-1.0"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "100.0100.0100.0100.0100.0100.01 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "US", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("-1a52a97", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7" + "'", str2.equals("7"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("UTF-8", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("100#100#0#-1#100#100", 67, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                       100#100#0#-1#100#100                        " + "'", str3.equals("                       100#100#0#-1#100#100                        "));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.01.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.10.0", "sun.awt....");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.01.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.10.0" + "'", str2.equals("1.01.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.10.0"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("          ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("#4a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#4a" + "'", str1.equals("#4a"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("SU", 52, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaSU" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaSU"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', (int) (short) -1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10.0 1.0", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                1.                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.0a10.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "10.0#-1.0#67.0", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("x86_64", "100#100#0#-1#100#100aaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1L, (float) (short) -1, (float) 11);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("\n\n", "", (int) (short) -1, 11);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#', 97, 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "10.04-1.0467.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "1.744444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(":", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100.0100.0100.0100.0100.0100.01 ", (java.lang.CharSequence) "/Users/sophie", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSX" + "'", str1.equals("MacOSX"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("tionatform API Specifica PlavaJ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionatform API Specifica PlavaJ" + "'", str2.equals("tionatform API Specifica PlavaJ"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100                                                                                                 ", "Java Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (-1), "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.CharSequence[] charSequenceArray6 = new java.lang.CharSequence[] { "Java(TM) SE Runtime Environment", " ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983", "sun.awt....", "AAAAAAAAAA" };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", charSequenceArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray6, '4');
        org.junit.Assert.assertNotNull(charSequenceArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA" + "'", str9.equals("Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("          ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7" + "'", str1.equals("7"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) -1, (double) (byte) 1, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "", (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8" + "'", str3.equals("UTF-8"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("dk1.7.0_80.jdk/contents/home/jre", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "dk1.7.0_80.jdk/contents/home/jre" + "'", str2.equals("dk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("x86_64////", "                                                                                              1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("100.0100.0100.0100.0100.0100.01 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0100.0100.0100.0100.0100.01" + "'", str1.equals("100.0100.0100.0100.0100.0100.01"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaSU", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0#10#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#10#10" + "'", str1.equals("0#10#10"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tiklooTCWL.xsocam.twawl.nus" + "'", str1.equals("tiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.0a10.0", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a10.0" + "'", str4.equals("1.0a10.0"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.awt....");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.awt....\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                1.                 ", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                1.                 " + "'", str2.equals("                1.                 "));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "MacOSX", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "10.0a1.0", 1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "-1 32", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("10.0a-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0A-1.0" + "'", str1.equals("10.0A-1.0"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("100#100#0#-1#100#100aaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#100#0#-1#100#100aaaaaaaaaaaa" + "'", str1.equals("100#100#0#-1#100#100aaaaaaaaaaaa"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.", "aaaaaaaaaa                                                                                          ", "1.7.0_80-b15", 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71." + "'", str4.equals("1.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71."));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("US", "1.744444444444444444444444444444");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1", charSequence1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("0 10 10", "0.15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 10 10" + "'", str2.equals("0 10 10"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(52.0f, (float) (byte) 1, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("dk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "dk1.7.0_80.jdk/contents/home/jre" + "'", str1.equals("dk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nUTF-8\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", (int) '4', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) " ", (java.lang.CharSequence) "tionatform API Specifica PlavaJ                                                                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aaaaaaaaaa                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "10.0a1.0", (java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sun.awt....", "0.15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt...." + "'", str2.equals("sun.awt...."));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Mac OS X", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        char[] charArray3 = new char[] { '4', '#' };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                              1.7", charArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a', 3, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("tionatform API Specifica PlavaJ", "100.0100.0100.0100.0100.0100.01");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "100                                                                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                                              1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("10.0a-1.0", "1.01.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a-1.0" + "'", str2.equals("10.0a-1.0"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0#10#10", (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "dk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0410410" + "'", str6.equals("0410410"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split(":");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("tionatform API Specifica PlavaJ", 0, 67);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tionatform API Specifica PlavaJ" + "'", str3.equals("tionatform API Specifica PlavaJ"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("US", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S" + "'", str2.equals("S"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        int[] intArray3 = new int[] { (short) -1, '4', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', 3, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a52a97" + "'", str5.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a52a97" + "'", str8.equals("-1a52a97"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 100, (int) (byte) 10, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "10.14.3", 10);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "mixed mode");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("US", "1.744444444444444444444444444444");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach(" ", strArray8, strArray11);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray11, "Oracle Corporation");
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0a10.0", (java.lang.CharSequence[]) strArray14);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, '#', (int) ' ', 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Java Platform API Specification" + "'", str6.equals("Java Platform API Specification"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " " + "'", str12.equals(" "));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "1004100404-141004100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("mixed mode");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                1.                 ", "1.744444444444444444444444444444", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("10.0A-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0A-1.0" + "'", str1.equals("10.0A-1.0"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("-1a32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1A32" + "'", str1.equals("-1A32"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "10.14.3", 10);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("", "10.0a1.0", 1);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "                                                                                               UTF-8");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, 'a');
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aa", strArray4, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Java Platform API Specification" + "'", str6.equals("Java Platform API Specification"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "aa" + "'", str16.equals("aa"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                0.                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                0.                 " + "'", str1.equals("                0.                 "));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Oracle Corporation                                  ", "                                                                                              1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation                                  " + "'", str2.equals("Oracle Corporation                                  "));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.0a-1.0", "0 10 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("          ", "Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) '#', (long) (-1), (long) 2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "AAAAAAAAAA");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) (byte) 0, 11L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 11L + "'", long3 == 11L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sun.lwawt.macosx.LWCToolki", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolki" + "'", str2.equals("sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 4, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7.0_80-b15", "1a100a0a97");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("http://java.oracle.com/", "100#100#0#-1#100#100aaaaaaaaaaaa", "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nUTF-8\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", 67);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "http://java.oracle.com/" + "'", str4.equals("http://java.oracle.com/"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java Virtual Machine Specification", "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983", 100);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#10#10" + "'", str6.equals("0#10#10"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Virtual Machine Specification", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("-1a32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a32" + "'", str1.equals("-1a32"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("100#100#0#-1#100#100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "SU", (java.lang.CharSequence) "10.04-1.0467.0", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("MacOSX", 18, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MacOSX" + "'", str3.equals("MacOSX"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "0.9", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "10.0#-1.0#67.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        short[] shortArray1 = new short[] { (short) 1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Oracle Corporation", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Cor" + "'", str2.equals("Oracle Cor"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "1.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.", (int) (short) 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71." + "'", str4.equals("1.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71."));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("-1 32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 32" + "'", str1.equals("-1 32"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) (byte) -1, (long) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "10.0A-1.0", (java.lang.CharSequence) "4a#", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "1a100a0a97", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#100#0#-1#100#100" + "'", str10.equals("100#100#0#-1#100#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1004100404-141004100" + "'", str12.equals("1004100404-141004100"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                0.                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0." + "'", str1.equals("0."));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1 32", (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.", (java.lang.CharSequence) "10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1A100A0A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A9" + "'", str1.equals("1A100A0A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A9"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("10.0 1.0", "sun.awt....");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 1.0" + "'", str2.equals("10.0 1.0"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("10.0#-1.0#67.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0#-1.0#67.0" + "'", str1.equals("10.0#-1.0#67.0"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.01.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.10.0", "#aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#aa" + "'", str2.equals("#aa"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " " + "'", str1.equals(" "));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                              1.", charSequence1, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "0 10 10", (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "\n\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("-1 32", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 32                                                                                               " + "'", str2.equals("-1 32                                                                                               "));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("tionatform API Specifica PlavaJ                                                                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"tionatform API Specifica PlavaJ                                                                  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.lang.String str0 = org.apache.commons.lang3.StringUtils.SPACE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + " " + "'", str0.equals(" "));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Oracle Cor");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Cor" + "'", str1.equals("Oracle Cor"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java HotSpot(TM) 64-Bit Server VM", (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("a");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("B", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0 10 10", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 10 10" + "'", str2.equals("0 10 10"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("100.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10.0a-1.0", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0410410", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nUTF-8\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_52426_156027983");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("100                                                                                                 ", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("   ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen", (java.lang.CharSequence) ":", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "                0.                 ", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "0.", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1A100A0A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A97-1A52A9", (int) '#', (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "100.0100.0100.0100.0100.0100.01 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1.7.0_80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "S");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAA" + "'", str1.equals("AAAAAAAAAA"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "#4a", charSequence1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                               UTF-8");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("dk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "dk1.7.0_80.jdk/contents/home/jr" + "'", str1.equals("dk1.7.0_80.jdk/contents/home/jr"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("dk1.7.0_80.jdk/contents/home/jr", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "x86_64", "0#100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100                                                                                                 ", (int) '#', "100.0100.0100.0100.0100.0100.01 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100                                                                                                 " + "'", str3.equals("100                                                                                                 "));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "10.0#-1.0#67.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaa                                                                                          ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.7", 1, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("0410410");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "tionatform API Specifica PlavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "hi!");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.04-1.0467.0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("100#100#0#-1#100#100", "-1 32");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#100#0#-1#100#100" + "'", str2.equals("100#100#0#-1#100#100"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1a100a0a97", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a100a0a97" + "'", str2.equals("1a100a0a97"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("dk1.7.0_80.jdk/contents/home/jr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-1a32");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("0.", "S", "10.0#-1.0#67.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0." + "'", str3.equals("0."));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus", (java.lang.CharSequence) "                                ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 69 + "'", int1 == 69);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                1.                 ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("10.0 1.0", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 1.0" + "'", str2.equals("10.0 1.0"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", (java.lang.CharSequence) "0410410");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "iklooTCWL.xsocam.twawl.nus" + "'", str1.equals("iklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.0a10.0", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("dk1.7.0_80.jdk/contents/home/jre", "0 10 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "dk1.7.0_80.jdk/contents/home/jre" + "'", str2.equals("dk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "10.04-1.0467.0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0 10 10", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "01010" + "'", str2.equals("01010"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("-1", "                                                                                              1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10.0a1.0", 2, "Java(TM) SE Runtime Environment4 4/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279834sun.awt....4AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0a1.0" + "'", str3.equals("10.0a1.0"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "##a", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("US", (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "100#100#0#-1#100#100aaaaaaaaaaaa", (java.lang.CharSequence) "                1.                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1 32", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.744444444444444444444444444444", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("10.0A-1.0", "Java(TM) SE Runtime Environment", "-1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        long[] longArray2 = new long[] { (-1), ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1 32" + "'", str4.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a32" + "'", str7.equals("-1a32"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1432" + "'", str9.equals("-1432"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1432" + "'", str11.equals("-1432"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        int[] intArray3 = new int[] { (short) -1, '4', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', (int) (short) -1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a52a97" + "'", str5.equals("-1a52a97"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a52a97" + "'", str8.equals("-1a52a97"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/", (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("##a", "0#10#10", "\n\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##a" + "'", str3.equals("##a"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("100.0100.0100.0100.0100.0100.01 ", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1004100404-141004100", 4, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100404-141004100" + "'", str3.equals("100404-141004100"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "                0.                 ", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0410410", (java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(11, (int) (byte) 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_1560279835/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 0, (byte) -1, (byte) 100, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) (byte) 1, (-1));
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "sun.awt....");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: sun.awt....");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#100#0#-1#100#100" + "'", str10.equals("100#100#0#-1#100#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1004100404-141004100" + "'", str12.equals("1004100404-141004100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) -1 + "'", byte17 == (byte) -1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "-1", (java.lang.CharSequence) "0#100");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "-1" + "'", charSequence2.equals("-1"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.0a-1.0", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "iklooTCWL.xsocam.twawl.nus", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Oracle Corporation                                  ", (java.lang.CharSequence) "1a100a0a97");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                                               UTF-8", "                                                                                               UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (int) (byte) 0, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 67, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0#100", 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa0#100aaa" + "'", str3.equals("aa0#100aaa"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("B");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "4a#", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "java HotSpot(TM) 64-Bit Server VM" + "'", charSequence2.equals("java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "10.04-1.0467.0", (java.lang.CharSequence) "                                                                                               UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', 0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#10#10" + "'", str6.equals("0#10#10"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 10 10" + "'", str8.equals("0 10 10"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 52, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.7.0_80", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "-1A32", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                                                                              1.7");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                1.                 ", (java.lang.CharSequence) "-1a52a97");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.744444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.74444444444444444444444444444" + "'", str1.equals("1.74444444444444444444444444444"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.7.0_80-B15", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("tiklooTCWL.xsocam.twawl.nus", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tiklooTCWL.xsocam.twawl.nus" + "'", str2.equals("tiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        long[] longArray2 = new long[] { 0L, 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a', 10, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "                                                                                              1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a100a0a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a97-1a52a9\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US10.04-1.0467.0US", (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str1.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("100                                                                                                 ", 69);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100                                                                                                 " + "'", str2.equals("100                                                                                                 "));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                ", "                                ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("-1 32                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 32" + "'", str1.equals("-1 32"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        float[] floatArray2 = new float[] { 10, 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0 1.0" + "'", str4.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0a1.0" + "'", str6.equals("10.0a1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0 1.0" + "'", str8.equals("10.0 1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0a1.0" + "'", str12.equals("10.0a1.0"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun.awt.CGraphicsEnvironmen", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                    sun.awt.CGraphicsEnvironmen                                     " + "'", str2.equals("                                    sun.awt.CGraphicsEnvironmen                                     "));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("0.", "iklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "iklooTCWL.xsocam.twawl.nus" + "'", str2.equals("iklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        short[] shortArray3 = new short[] { (short) 0, (byte) 10, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', (int) (short) -1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#10#10" + "'", str6.equals("0#10#10"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("MacOSX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSX" + "'", str1.equals("MacOSX"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("UTF-8", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        float[] floatArray5 = new float[] { 0, 69, (byte) 1, 1.0f, 35 };
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', (int) (byte) 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "#4a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        long[] longArray2 = new long[] { 0L, 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#100" + "'", str6.equals("0#100"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#', (int) (short) 1, (int) 'a');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Oracle Corporation                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.01.71.71.71.71.71.Oracle Corporation1.71.71.71.71.71.10.0", (java.lang.CharSequence) "0.0", 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 56 + "'", int3 == 56);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8" + "'", str3.equals("UTF-8"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", "-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("iklooTCWL.xsocam.twawl.nus", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10.0a100.0a-1.0a-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0a100.0a-1.0a-1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("0.0", "10.0A-1.0", "1.74444444444444444444444444444", 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0" + "'", str4.equals("0.0"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1004100404-141004100", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#100#0#-1#100#100" + "'", str3.equals("100#100#0#-1#100#100"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "SU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("-1a52a97");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("\n\n");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10.0a-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0a-1.0" + "'", str1.equals("10.0a-1.0"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 4L, (float) 10, (float) 0L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac os x" + "'", str1.equals("mac os x"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("dk1.7.0_80.jdk/contents/home/jr", "1.7.0_80-B15", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dk1.7.0_80.jdk/contents/home/jr" + "'", str3.equals("dk1.7.0_80.jdk/contents/home/jr"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java(TM) SE Runtime Environment", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) ".7.0_80-B15", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("          ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporation" + "'", str1.equals("OracleCorporation"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("10.0", (int) '#', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("-1 32", (int) (short) 100, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 0L, (float) (byte) 1, (float) 97);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '#', (long) 'a', 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        char[] charArray4 = new char[] { '4', '#' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                              1.7", charArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 1, (int) (short) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4a#" + "'", str11.equals("4a#"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mixed mode", "-1A32", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10.0a100.0a-1.0a-1.0", 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", 67);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test466");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_ENDORSED_DIRS;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str0.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("100.0100.0100.0100.0100.0100.01", "", "                                                                                              1.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0100.0100.0100.0100.0100.01" + "'", str3.equals("100.0100.0100.0100.0100.0100.01"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "01010");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TiklooTCWL.xsocam.twawl.nus" + "'", str1.equals("TiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray4 = new char[] { '#', 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray4, '4');
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "TIONATFORM api sPECIFICA pLAVAj", charArray4);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "#aa" + "'", str6.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#4a" + "'", str8.equals("#4a"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("B", "", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        char[] charArray4 = new char[] { '#', 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "#aa" + "'", str6.equals("#aa"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("24.80-b11", 18, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11#########" + "'", str3.equals("24.80-b11#########"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1004100404-141004100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                              1.7", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               1.7" + "'", str2.equals("               1.7"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("   ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("-1", "http://java.oracle.com/", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1" + "'", str3.equals("-1"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1#100#0#97", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#100#0#97" + "'", str2.equals("1#100#0#97"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("100#100#0#-1#100#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#100#0#-1#100#100" + "'", str1.equals("100#100#0#-1#100#100"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "TIONATFORM api sPECIFICA pLAVAj", (java.lang.CharSequence) "TIONATFORM api sPECIFICA pLAVAj");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 10, (long) 67, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("0#100", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 10L, (double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ', 97, (int) (byte) 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52426_156027983");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        char[][] charArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(charArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 100, 0L, 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "SU", (java.lang.CharSequence) "MacOSX");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 100, 0L, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "                0.                 ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                0.                 " + "'", charSequence2.equals("                0.                 "));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                1.                 ", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                1.                 " + "'", str2.equals("                1.                 "));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str2.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }
}

