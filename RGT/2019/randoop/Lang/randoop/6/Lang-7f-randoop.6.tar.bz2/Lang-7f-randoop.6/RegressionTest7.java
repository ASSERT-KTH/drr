import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) '#', 31);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1a10a100a1a100a-1" + "'", str17.equals("1a10a100a1a100a-1"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Oracle Corporation", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Ho...", (java.lang.CharSequence) "1.0a0.0a0.0", 392);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("ificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", "-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0", "Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre", 89);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification" + "'", str4.equals("ificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "X0.0a10.0X", (int) (byte) 100, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(52L, 52L, 2L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (double) 52L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("-1 100 10", "13a1-a0...", "####################");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java Ho..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "1.6", 77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "46_68X", (java.lang.CharSequence) "#a4a4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "java hotspot(tm) 64-bit server vm", "### hO..AVAj####");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" hO..AVAj hO..AVAj hO..AVAj hO..              hO..AVAj hO..AVAj hO..AVAj hO..", "0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0", 29);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Jntents/Home/jre/lib/endorsed", "");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "http://java.oracle.com/");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "35a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("\n", '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach(" ######################################################################sun.lwawt.macosx.LWCToolkit  ", strArray5, strArray10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Library/Jntents/Home/jre/lib/endorsed" + "'", str7.equals("Library/Jntents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "\n" + "'", str11.equals("\n"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " ######################################################################sun.lwawt.macosx.LWCToolkit  " + "'", str12.equals(" ######################################################################sun.lwawt.macosx.LWCToolkit  "));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("          ", " jAVA hOTsPOT(tm) 64-bIT sERVER vm  ", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1a10a100a1a100a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a10a100a1a100a-" + "'", str1.equals("1a10a100a1a100a-"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;", (java.lang.CharSequence) "PlatformAPISpeci");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        long[] longArray6 = new long[] { 1, (byte) 1, 52L, 2, (byte) 0, 4 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 31, 19);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', (int) (short) 0, (int) (byte) 1);
        long long17 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "141452424044" + "'", str12.equals("141452424044"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("             1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "/r/ar/aar/r/aar-/");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/80" + "'", str3.equals("             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/80"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate(":", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("8utf-8utf-8utf-8utf-8utf-8utf-8utf-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        long[] longArray1 = new long[] { 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, '#', (int) (byte) 100, 2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10" + "'", str8.equals("10"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Aaaaaaaaaaa10a32a1a32aaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 89);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (java.lang.CharSequence) "r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 217 + "'", int2 == 217);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("CLASS [LJAVA.LANG.STRING;");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sun.awt.CGraphicsEnvironmen", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironmen" + "'", str2.equals("sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Ljava.lang.String;" + "'", str1.equals("class [Ljava.lang.String;"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/uSERS/SOPHIE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /uSERS/SOPHIE is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "                     Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        long[] longArray4 = new long[] { 31L, 10L, 28, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.Class<?> wildcardClass6 = longArray4.getClass();
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 94, 56);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 31L + "'", long8 == 31L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 31L + "'", long10 == 31L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        double[] doubleArray2 = new double[] { (byte) 0, (byte) 10 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.0a10.0" + "'", str6.equals("0.0a10.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                               4a4a#", 32, "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                               4a4a#" + "'", str3.equals("                                               4a4a#"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("NTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSE");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 73, 19L, (long) 16);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 73L + "'", long3 == 73L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION" + "'", str2.equals("jAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1-A001A1A001A01A1", 0, "1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1-A001A1A001A01A1" + "'", str3.equals("1-A001A1A001A01A1"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        char[] charArray9 = new char[] { 'a', '4', 'a', '4', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Platform API Specif", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                         ...", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("PlatformAPISpecif");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlatformAPISpecif" + "'", str1.equals("PlatformAPISpecif"));
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest7.test053");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
//        boolean boolean11 = javaVersion8.atLeast(javaVersion9);
//        boolean boolean12 = javaVersion6.atLeast(javaVersion8);
//        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean15 = javaVersion6.atLeast(javaVersion14);
//        boolean boolean16 = javaVersion4.atLeast(javaVersion14);
//        boolean boolean17 = javaVersion2.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean19 = javaVersion2.atLeast(javaVersion18);
//        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean21 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion20);
//        java.lang.String str22 = javaVersion20.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean24 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
//        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion26 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean27 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion26);
//        boolean boolean28 = javaVersion25.atLeast(javaVersion26);
//        boolean boolean29 = javaVersion23.atLeast(javaVersion25);
//        boolean boolean30 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
//        org.apache.commons.lang3.JavaVersion javaVersion31 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean32 = javaVersion23.atLeast(javaVersion31);
//        boolean boolean33 = javaVersion20.atLeast(javaVersion23);
//        boolean boolean34 = javaVersion2.atLeast(javaVersion20);
//        java.lang.Class<?> wildcardClass35 = javaVersion20.getClass();
//        org.apache.commons.lang3.JavaVersion javaVersion36 = null;
//        try {
//            boolean boolean37 = javaVersion20.atLeast(javaVersion36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1.8" + "'", str22.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion26 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion26.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion31 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion31.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("             1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ocuments/defects4j/framework/lib", 3, "3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ocuments/defects4j/framework/lib" + "'", str3.equals("ocuments/defects4j/framework/lib"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.", "phie", 31);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "31410428410", 2, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1", 76);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1" + "'", str2.equals("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1586 + "'", int1 == 1586);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("141041004141004-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "141041004141004-1" + "'", str1.equals("141041004141004-1"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4', (int) (byte) 10, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a0" + "'", str8.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-140" + "'", str11.equals("-140"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1#0" + "'", str13.equals("-1#0"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest7.test063");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
//        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
//        boolean boolean8 = javaVersion2.atLeast(javaVersion4);
//        boolean boolean9 = javaVersion0.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str11 = javaVersion10.toString();
//        boolean boolean12 = javaVersion4.atLeast(javaVersion10);
//        java.lang.Class<?> wildcardClass13 = javaVersion4.getClass();
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
//        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion17);
//        boolean boolean19 = javaVersion16.atLeast(javaVersion17);
//        boolean boolean20 = javaVersion14.atLeast(javaVersion16);
//        boolean boolean21 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion16);
//        boolean boolean22 = javaVersion4.atLeast(javaVersion16);
//        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean24 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
//        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion26 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean27 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion26);
//        boolean boolean28 = javaVersion25.atLeast(javaVersion26);
//        boolean boolean29 = javaVersion23.atLeast(javaVersion25);
//        boolean boolean30 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
//        org.apache.commons.lang3.JavaVersion javaVersion31 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean32 = javaVersion23.atLeast(javaVersion31);
//        java.lang.String str33 = javaVersion31.toString();
//        boolean boolean34 = javaVersion4.atLeast(javaVersion31);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.2" + "'", str11.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion26 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion26.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion31 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion31.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.5" + "'", str33.equals("1.5"));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "1a10a100a1a100a-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("       Sophie", "a", "java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       Sophie" + "'", str3.equals("       Sophie"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                         ...", (java.lang.CharSequence) "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.0 97.0", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 9" + "'", str2.equals("1.0 9"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        long[] longArray5 = new long[] { '#', 100L, 100, (byte) -1, 31 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "35a100a100a-1a31" + "'", str7.equals("35a100a100a-1a31"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("46_68X", "///////////////////");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaa" + "'", str2.equals("aaaa"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("a4a4                                             ", "aaaa", "sun.lwawt.macosx.LWCToolkitx86_64                                                                                              ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Java Platform API Specification", (int) (byte) 100);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Java Platform API Specification");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 28, 14);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str5.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str10.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray4 = new char[] { ' ', '#' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray4, '4', 0, (int) (short) -1);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0a97.", charArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ', 19, (int) (byte) -1);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("              eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("eihpos/sresU/", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpos/sresU/" + "'", str2.equals("eihpos/sresU/"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("4aaa4a4", (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(" hO..AVAj hO..AVAj hO..AVAj hO..              hO..AVAj hO..AVAj hO..AVAj hO..", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " hO..AVAj hO..AVAj hO..AVAj hO..              hO..AVAj hO..AVAj hO..AVAj hO.." + "'", str3.equals(" hO..AVAj hO..AVAj hO..AVAj hO..              hO..AVAj hO..AVAj hO..AVAj hO.."));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Hi!", (java.lang.CharSequence) "X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        float[] floatArray5 = new float[] { 13, 32.0f, 32.0f, '4', 8 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 8.0f + "'", float6 == 8.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 94, 0.0d, (double) 28.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 94.0d + "'", double3 == 94.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8", (java.lang.CharSequence) "eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                           ", (java.lang.CharSequence) "                     Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70 + "'", int2 == 70);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1-A001A1A001A01A1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("           X86_6", (int) (short) 0, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "           X86_6" + "'", str3.equals("           X86_6"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("...0a-1a31");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("PLATFORMAPISPECIF", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.0 97.0", "10#32#1#32", 10);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "x86_64");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("\n", strArray5, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "\n" + "'", str9.equals("\n"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "hO..AVAj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "35 100 100 -1 31", (java.lang.CharSequence) "          0.79a0.1          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Library/Jntents/Home/jre/lib/endorsed", "0.0#10.0", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("0.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0410.0" + "'", str1.equals("0.0410.0"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        long[] longArray2 = new long[] { (short) 1, (byte) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', (int) '4', (int) (short) 1);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a', 5, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(" 4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus" + "'", str1.equals("4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        int[] intArray1 = new int[] { 28 };
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 52, 2748);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/uSERS/SOPHIE", "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE" + "'", str2.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-x#0", "1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("A 4 a 4 4", "-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64                   ...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "JAVApLATFORMapisPECI/Users/sophi", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 29.0f, (double) 4, 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.0 97.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 97" + "'", str1.equals("1.0 97"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1.0", "NEMNORIVNeSCIHPARgc.TWA.NUS");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10#32#1#32", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#32#1#32" + "'", str5.equals("10#32#1#32"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.79a0.1", 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Eihpos/sresU/NEihpos/sresU/TEihpos/sresU/EEihpos/sresU/NEihpos/sresU/TEihpos/sresU/SEihpos/sresU//Eihpos/sresU/HEihpos/sresU/OEihpos/sresU/MEihpos/sresU/EEihpos/sresU//Eihpos/sresU/JEihpos/sresU/REihpos/sresU/EEihpos/sresU//Eihpos/sresU/LEihpos/sresU/IEihpos/sresU/BEihpos/sresU//Eihpos/sresU/EEihpos/sresU/NEihpos/sresU/DEihpos/sresU/OEihpos/sresU/REihpos/sresU/SEihpos/sresU/EEihpos/sresU/", "46_68X", 36);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("UTF-8", 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ":", (int) 'a', (int) (short) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray4, strArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "java Platform API Specification");
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", 'a');
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String[] strArray28 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray24, strArray28);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEach("Java HotSpot(TM) 64-Bit Server VM", strArray19, strArray28);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray4, strArray28);
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "1.5");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str13.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTF-8" + "'", str15.equals("UTF-8"));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str30.equals("Java HotSpot(TM) 64-Bit Server VM"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str31.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "UTF-8" + "'", str33.equals("UTF-8"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "10.14.310.14.310.14PlatformAPISpecif");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1410040410");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1410040410L + "'", long1 == 1410040410L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("jAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION" + "'", str2.equals("jAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.7", 0, 94);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.8", 1586, "                                                                             46_68xtiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                     1.8                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                      " + "'", str3.equals("                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                     1.8                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                      "));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "a444 4 4 44");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("#a4a4                                              ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a4a4                                              " + "'", str2.equals("#a4a4                                              "));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Java Ho..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        double[] doubleArray4 = new double[] { (-1.0f), 10.0d, 1.0f, (-1L) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 38, (int) (byte) 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0410.041.04-1.0" + "'", str7.equals("-1.0410.041.04-1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.0410.041.04-1.0" + "'", str13.equals("-1.0410.041.04-1.0"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Platform API Specification", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J4v4 Pl4tform API Specific4tion" + "'", str3.equals("J4v4 Pl4tform API Specific4tion"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 1.2f, (float) '#');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!" + "'", str2.equals("Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80", "");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "x86_64");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("en", strArray4, strArray7);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", "Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) 0);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("   1.0 97.", strArray4, strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 38");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "en" + "'", str8.equals("en"));
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("PlatformAPISpecif", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlatformAPISpecif" + "'", str2.equals("PlatformAPISpecif"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A", " hO..AVAj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A" + "'", str2.equals("4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.0410.0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1#10#100#1#100#-1" + "'", str13.equals("1#10#100#1#100#-1"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 100 + "'", byte16 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1#10#100#1#100#-1" + "'", str18.equals("1#10#100#1#100#-1"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 39, (long) 2432);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10.14.310.14.310.14PlatformAPISpecif", (java.lang.CharSequence) "1.0 97.0", 89);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "##########################                              ", (java.lang.CharSequence) "1.0 0.0 0.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm", "       SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A", 27);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("mixed mode", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM  ", (java.lang.CharSequence) "PlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformA.0#10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("141452424044", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "141452424044" + "'", str2.equals("141452424044"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "0140400141/Jntents/Home/jre/lib/endorse", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("10.14.3", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str2.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Ho..ava", "X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Ho..ava" + "'", str2.equals("Ho..ava"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("JAVApLATFORMapisPECI/Users/sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVApLATFORMapisPECI/Users/soph" + "'", str1.equals("JAVApLATFORMapisPECI/Users/soph"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "-1 100 10", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("0.0410.0-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0410.0-1" + "'", str1.equals("0.0410.0-1"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tnemnorivnE emitnuR ES )MT(avaJ" + "'", str1.equals("tnemnorivnE emitnuR ES )MT(avaJ"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("LATFORMAPISPECIF", 91);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                          -x#0                                           ", "51.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aaaaaaaaaaaaaa", "hO..AVAj", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "73", "                   ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.CharSequence charSequence4 = null;
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.0a97.0", (int) (byte) 10);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence4, (java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("###############################", strArray2, strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "###############################" + "'", str10.equals("###############################"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "-1 100 10", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "java hotspot(tm) 64-bit server vm", (java.lang.CharSequence) "#A4A4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("...0a-1a31", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...0-131" + "'", str2.equals("...0-131"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        long[] longArray5 = new long[] { '#', 100L, 100, (byte) -1, 31 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, '4', 2432, (int) (byte) 1);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "35a100a100a-1a31" + "'", str7.equals("35a100a100a-1a31"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10#32#1#32", 97, "                                                                             46_68xtiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                           10#32#1#32                                            " + "'", str3.equals("                                           10#32#1#32                                            "));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("JAVA HO...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HO..." + "'", str1.equals("JAVA HO..."));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", (java.lang.CharSequence) "1.0a97.0", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.0 0.0 0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        char[] charArray7 = new char[] { 'a', '4', ' ', ' ', ' ', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!", charArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a#4# # # #4" + "'", str10.equals("a#4# # # #4"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "a 4       4" + "'", str12.equals("a 4       4"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("-1.0410.041.04-1.0", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaEihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaeihpos/sresu/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaeihpos/sresu/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;", "mixed mod", 1410040410);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 29, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("#################################ts4j/tMp/run_ranOXXp.pl_50283_1560277096", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "24.80-b11", 56);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "4444444444444", 77);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("X86_");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"X86_\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "PLATFORMAPISPECIF");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) 'a', 1410040410);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hO..AVAj", (java.lang.CharSequence) "X0.0a10.0X", 77);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        double[] doubleArray2 = new double[] { (byte) 0, (byte) 10 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.0410.0" + "'", str6.equals("0.0410.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0 9", "mixedmod");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "             Hi!             ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("0.0a10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0a10.0" + "'", str1.equals("0.0a10.0"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "          ", charSequence1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("       Sophie", "platformapispecif");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("             Hi!             ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("          0.79a0.1          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.79a0.1" + "'", str1.equals("0.79a0.1"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Ho..avaJ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("0a11a10a100a1a100a-110a11a10a100a1a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a1a001a01a11a011-a001a1a001a01a11a0" + "'", str1.equals("a1a001a01a11a011-a001a1a001a01a11a0"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "10", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("73", 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "73" + "'", str3.equals("73"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("a#4# # # #4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a#4# # # #4" + "'", str1.equals("a#4# # # #4"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Aaaaaaaaaaa10a32a1a32aaaaaaaaaaa", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Aaaaaaaaaaa10a32a1a32aaaaaaaaaaa" + "'", str2.equals("Aaaaaaaaaaa10a32a1a32aaaaaaaaaaa"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 392, 0.0d, 61.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 392.0d + "'", double3 == 392.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4", "0.0#14.0#38.0#10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4" + "'", str2.equals("a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("  #################################", 77, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                            #################################" + "'", str3.equals("                                            #################################"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaeihpos/sresu/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaeihpos/sresu/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaeihpos/sresu/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8" + "'", str1.equals("8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "CLASS [LJAVA.LANG.STRING;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.0", "!iH", "           X86_6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) " hO..AVAj hO..AVAj hO..AVAj hO..              hO..AVAj hO..AVAj hO..AVAj hO..", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                           10a1                                            ", 2748);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                           10a1                                            " + "'", str2.equals("                                           10a1                                            "));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4444444444444444444444440.79a0.1", (java.lang.CharSequence) "ary/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("####################################################");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      " + "'", str2.equals("      "));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 52, 0.0f, (float) 28L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "a#4# # # #4", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 89);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0#0.0#0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#0.0#0.0" + "'", str1.equals("0#0.0#0.0"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "UTF-8", (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("sun.lwawt.macosx.LWCToolkitx86_64                                                                                              ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaEihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkitx86_64                                                                                              " + "'", str2.equals("sun.lwawt.macosx.LWCToolkitx86_64                                                                                              "));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 100, (float) 38L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("13");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 13.0f + "'", float1 == 13.0f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                         ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "", 70);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest7.test212");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
//        boolean boolean11 = javaVersion8.atLeast(javaVersion9);
//        boolean boolean12 = javaVersion6.atLeast(javaVersion8);
//        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean15 = javaVersion6.atLeast(javaVersion14);
//        boolean boolean16 = javaVersion4.atLeast(javaVersion14);
//        boolean boolean17 = javaVersion2.atLeast(javaVersion4);
//        java.lang.String str18 = javaVersion4.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean20 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion19);
//        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean22 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion21);
//        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion24 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean25 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion24);
//        boolean boolean26 = javaVersion23.atLeast(javaVersion24);
//        boolean boolean27 = javaVersion21.atLeast(javaVersion23);
//        boolean boolean28 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion21);
//        org.apache.commons.lang3.JavaVersion javaVersion29 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean30 = javaVersion21.atLeast(javaVersion29);
//        boolean boolean31 = javaVersion19.atLeast(javaVersion29);
//        org.apache.commons.lang3.JavaVersion javaVersion32 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str33 = javaVersion32.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion34 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean35 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion34);
//        org.apache.commons.lang3.JavaVersion javaVersion36 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean37 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion36);
//        org.apache.commons.lang3.JavaVersion javaVersion38 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion39 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean40 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion39);
//        boolean boolean41 = javaVersion38.atLeast(javaVersion39);
//        boolean boolean42 = javaVersion36.atLeast(javaVersion38);
//        boolean boolean43 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion36);
//        org.apache.commons.lang3.JavaVersion javaVersion44 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean45 = javaVersion36.atLeast(javaVersion44);
//        boolean boolean46 = javaVersion34.atLeast(javaVersion44);
//        boolean boolean47 = javaVersion32.atLeast(javaVersion34);
//        boolean boolean48 = javaVersion19.atLeast(javaVersion32);
//        org.apache.commons.lang3.JavaVersion javaVersion49 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean50 = javaVersion32.atLeast(javaVersion49);
//        boolean boolean51 = javaVersion4.atLeast(javaVersion49);
//        boolean boolean52 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion49);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.2" + "'", str18.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion24 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion24.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion29 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion29.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion32 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion32.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.8" + "'", str33.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion34 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion34.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion36 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion36.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion38 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion38.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion39 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion39.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion44 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion44.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion49 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion49.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("#a4a4                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#a4a4                                               " + "'", str1.equals("#a4a4                                               "));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        double[] doubleArray2 = new double[] { (byte) 0, (byte) 10 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ', (int) ' ', 17);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.0a10.0" + "'", str6.equals("0.0a10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1S10S100S1S100S-1", "class [Lja");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("aaaaaaaaaa", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1a10a100a1a100a-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "platformapispecif", 97, 91);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("0.0#10.0", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0#10.0" + "'", str2.equals("0.0#10.0"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-140" + "'", str5.equals("-140"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hO..AVAj", "         I");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hO..AVAj" + "'", str2.equals("hO..AVAj"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", "", "46_6");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "x86_64                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;", (java.lang.CharSequence) "10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("51.0", "a 4 a 4 4", "       Sophie");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "0.0 0.0 0.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("10a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10a1" + "'", str1.equals("10a1"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/80", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r-/80ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/_/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/0/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/7/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/1/r/ar/r/ar/a             /r/" + "'", str2.equals("r-/80ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/_/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/0/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/7/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/1/r/ar/r/ar/a             /r/"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEh/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEi/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEe/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", "0.0a14.0a38.0a10.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0a1410034.4034.4.014.4003300031" + "'", str3.equals("0.0a1410034.4034.4.014.4003300031"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.6", 56);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("46_68X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "46_68X" + "'", str1.equals("46_68X"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 13, 2432);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 13");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10a1" + "'", str4.equals("10a1"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10 1" + "'", str6.equals("10 1"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(73L, (long) (short) -1, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1aaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1aaaaaaaaaaaaaa" + "'", str2.equals("10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1aaaaaaaaaaaaaa"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0", 28, "4444444444444444444444440.79a0.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0" + "'", str3.equals("PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 38, (double) 397, (double) 9);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.0d + "'", double3 == 9.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.6", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444 ##444444", "8utf-8utf-8utf-8utf-8utf-8utf-8utf-8", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("JAVA HO...", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O..." + "'", str2.equals("O..."));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "###############################", (java.lang.CharSequence) "2 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.lwawt.macosx.CPrinterJob", "US", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "I", (java.lang.CharSequence) " 4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus", 2748);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("141452424044");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "141452424044" + "'", str1.equals("141452424044"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.0 97");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10a32a1a32", (java.lang.CharSequence) "1.0#97.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", "1.0 97");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096" + "'", str2.equals("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Mac OS ", (java.lang.CharSequence) "Ho..ava", 72);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) " 4 a 4 4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("#A4A4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#A4A4" + "'", str1.equals("#A4A4"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        long[] longArray2 = new long[] { 77L, 29 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 29L + "'", long3 == 29L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 77L + "'", long4 == 77L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Jntents/Home/jre/lib/endorsed", "");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray8, strArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-140", strArray3, strArray12);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-140" + "'", str16.equals("-140"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "A100A-", (java.lang.CharSequence) "####################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "a444 4 4 44", 34);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("mixed mod", "                                                                                                 ", 52, 72);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mixed mod                                                                                                 " + "'", str4.equals("mixed mod                                                                                                 "));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "x86_64                                                                                              ", (java.lang.CharSequence) "-1.0410.041.04-1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10a1", 100, "x86_64                   ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64                   ...x86_64              10a1x86_64                   ...x86_64              " + "'", str3.equals("x86_64                   ...x86_64              10a1x86_64                   ...x86_64              "));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("10#32#1#32", "-1 100 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 100 10" + "'", str2.equals("-1 100 10"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("10.14.310.14.310.14PlatformAPISpecif");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.310.14.310.14PlatformAPISpecif" + "'", str1.equals("10.14.310.14.310.14PlatformAPISpecif"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("#a4a4                                              ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("NTENTS/HOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NTENTS/HOME/JRE/LIB/ENDORS" + "'", str1.equals("NTENTS/HOME/JRE/LIB/ENDORS"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("x86_64                   ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...                   46_68x" + "'", str1.equals("...                   46_68x"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", 217, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("0.1-#0.1#0.01#0.1-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.1-#0.1#0.01#0.1-" + "'", str1.equals("0.1-#0.1#0.01#0.1-"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.ja" + "'", str1.equals("JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.ja"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444" + "'", str3.equals("4444"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("0a11a10a100a1a100a-110a11a10a100a1a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a11a10a100a1a100a-110a11a10a100a1a" + "'", str1.equals("0a11a10a100a1a100a-110a11a10a100a1a"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1043241432", 13, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "a 4 a 4 4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.0a97.0");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "jAVApLATFORMapisPECI/Users/sophi");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1aaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.0a97.0", "                                                                                                    ");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Platform35#100#100#-1#31API35#100#100#-1#31Specification", ":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:", "                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Platform35#   #   #  #3 API35#   #   #  #3 Specification" + "'", str3.equals("Platform35#   #   #  #3 API35#   #   #  #3 Specification"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 97, 5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', (int) (byte) 1, 0);
        int int16 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 32 + "'", int16 == 32);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Platform API Specification", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("#a4a4                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#a4a4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "141452424044");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0", "#a4a4                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-140                                                                                                ", (java.lang.CharSequence) "NTENTS/HOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaats4j/tmp/run_randoop.pl_50283_1560277096aaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("141452424044");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", (java.lang.CharSequence) "                            ", 91);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("0.0410.00.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("####################################################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("x86_64", "##############################444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("0.0 0.0 0.1", "46_6", 32, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "46_6" + "'", str4.equals("46_6"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 73, 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("46_6", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "I");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("          ", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "0#0.0#0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("#A4A4");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 42148 + "'", number1.equals(42148));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(19, 2, 61);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "2 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("ts4j/tmp/run_randoop.pl_50283_1560277096                                    ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ts4j/tmp/run_randoop.pl_50283_1560277096                                    " + "'", str2.equals("ts4j/tmp/run_randoop.pl_50283_1560277096                                    "));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAA" + "'", str2.equals("AAAAAAAAAA"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11", "1.0a97.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("10#32#1#32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#32#1#32" + "'", str1.equals("10#32#1#32"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "                         ...");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "class [Ljava.l...", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + ":" + "'", str6.equals(":"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                   ", "2 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1#10#100#1#100#-1" + "'", str13.equals("1#10#100#1#100#-1"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) -1 + "'", byte16 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 100 + "'", byte17 == (byte) 100);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("#", "ts4j/tMp/run_ranOXXp.pl_50283_1560277096", "PlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformA.0#10.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#" + "'", str3.equals("#"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 100, (byte) 10 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("#################################ts4j/tMp/run_ranOXXp.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.Class<?> wildcardClass8 = byteArray6.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 2748, (int) (byte) -1);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 10 100 1 100 -1" + "'", str10.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Ho...", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.0 0.0 0.", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 0.0 0." + "'", str2.equals("1.0 0.0 0."));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("13a1-a0...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Library/Jntents/Home/jre/lib/endorsed", "a4a4                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                                                 ", (java.lang.CharSequence) "10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0", (java.lang.CharSequence) "10a-1a-1a10a100", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "X86_6X86_6", (java.lang.CharSequence) "1a10a100a1a100a-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, 'a', 0, 36);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(1410040410, 76, 89);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 76 + "'", int3 == 76);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Oracle Corporation", 77L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 77L + "'", long2 == 77L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("X0.0a10.0X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"X0.0a10.0X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("   1.0 97.", 76);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97." + "'", str2.equals("   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97."));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "LATFORMAPISPECIF", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray9, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Jntents/Home/jre/lib/endorsed", strArray4, strArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophi", (java.lang.CharSequence[]) strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "/Library/Jntents/Home/jre/lib/endorsed" + "'", str15.equals("/Library/Jntents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                               4a4a#", (java.lang.CharSequence) "1.0#0.0#0.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8" + "'", str1.equals("8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        double[] doubleArray3 = new double[] { 1, (short) 0, 0L };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', 77, 8);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(34, (int) (byte) 0, 70);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_64                   ...x86_64              10a1x86_64                   ...x86_64              ", 0, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "10#32#1#32");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "X86_", 397);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("mixedmod", "x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmod" + "'", str2.equals("mixedmod"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 50, (double) 2, 1.41004041E9d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "-140");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("24.80-b11");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(4444.0f, 0.0f, (float) 52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "X0.0a10.0X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("-1#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#" + "'", str1.equals("-1#"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1", (java.lang.CharSequence) "1a0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 8, (int) (byte) -1);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', 73, 17);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: sun.awt.CGraphicsEnvironment");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) -1 + "'", byte16 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Library/Jntents/Home/jre/lib/endorsed", "PlatformAPISpecif", "141452424044                                                                                     ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1", "0.0410.0", 32);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#a##a###a#a###a-##a##a###a#a###a-##a##a###a#a##0a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1" + "'", str7.equals("#a##a###a#a###a-##a##a###a#a###a-##a##a###a#a##0a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 19, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 19.0f + "'", float3 == 19.0f);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.0#97.0", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#97.0" + "'", str2.equals("1.0#97.0"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1a10a100a1a100a-1", "java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a10a100a1a100a-1" + "'", str2.equals("1a10a100a1a100a-1"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("x86_64                                                                                              ");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 35, 73);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "      ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("a4a4                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a4a4                                              \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 42148);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        double[] doubleArray4 = new double[] { (-1.0f), 10.0d, 1.0f, (-1L) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', 9, 42148);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0#10.0#1.0#-1.0" + "'", str7.equals("-1.0#10.0#1.0#-1.0"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "X86_6X86_6", (java.lang.CharSequence) "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("#", "J4v4 Pl4tform API Specific4tion", "35 100 100 -1 31");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#" + "'", str3.equals("#"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) '4', 17);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                           10a1                                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                            1a01                                           " + "'", str1.equals("                                            1a01                                           "));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "X86_6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) '#', 19.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("-140", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-10" + "'", str2.equals("-10"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "0.0 0.0 0.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        char[] charArray8 = new char[] { ' ', '#' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', 0, (int) (short) -1);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "class [Ljava.lang.String;", charArray8);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray8);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + " ##" + "'", str19.equals(" ##"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Use\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" hO..AVAj", 52, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                            hO..AVAj" + "'", str3.equals("                                            hO..AVAj"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("CLASS [LJAVA.LANG.STRING;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CLASS [LJAVA.LANG.STRING;" + "'", str1.equals("CLASS [LJAVA.LANG.STRING;"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("          0.79a0.1          ", 0, 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  " + "'", str3.equals("  "));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "X86_", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1410040410L, (long) (short) -1, 35L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          " + "'", str1.equals("          "));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 19.0f, (double) 1410040410L, (double) 68);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.41004041E9d + "'", double3 == 1.41004041E9d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "1A10A100A1A100A-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.0#97.", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest7.test392");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
//        boolean boolean9 = javaVersion6.atLeast(javaVersion7);
//        boolean boolean10 = javaVersion4.atLeast(javaVersion6);
//        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean13 = javaVersion4.atLeast(javaVersion12);
//        boolean boolean14 = javaVersion2.atLeast(javaVersion12);
//        boolean boolean15 = javaVersion0.atLeast(javaVersion2);
//        boolean boolean16 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0a11a10a100a1a100a-110a11a10a100a1a", 31, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a11a10a100a1a100a-110a11a10a100a1a" + "'", str3.equals("0a11a10a100a1a100a-110a11a10a100a1a"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("hi!", "#########################################################a4a4");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("UTF-8", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".nus" + "'", str2.equals(".nus"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("           X86_6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "           X86_6" + "'", str1.equals("           X86_6"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 6.0f, (float) 35L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "a 4       4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#a4a4                                               ", ".0#10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.0#0.0#0.0", 56);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#0.0#0.0" + "'", str2.equals("1.0#0.0#0.0"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                     Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 27, 1586);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("          0.79a0.1          ", "X86_64", "x86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          0.79a0.1          " + "'", str3.equals("          0.79a0.1          "));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "10.0#-1.0#10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Ho..ava");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10 2 17 28 0", (java.lang.CharSequence) "1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (short) 100, 100);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 31, 17);
        int int15 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 32 + "'", int15 == 32);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "NTENTS/HOME/JRE/LIB/ENDORS", (java.lang.CharSequence) "1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#0", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("-1.0#10.0#1.0#-1.0", "/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0#10.0#1.0#-1.0" + "'", str2.equals("-1.0#10.0#1.0#-1.0"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("-1a", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a-1a-1a-1a" + "'", str2.equals("-1a-1a-1a-1a"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "eihpos/sresU/", (java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaJava(TM) SE Runtime EnvironmentaJava Virtual Machine Specification", (int) 'a', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("UTF-8", "1a10a100a1a100a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Eihpos/sresU/NEihpos/sresU/TEihpos/sresU/EEihpos/sresU/NEihpos/sresU/TEihpos/sresU/SEihpos/sresU//Eihpos/sresU/HEihpos/sresU/OEihpos/sresU/MEihpos/sresU/EEihpos/sresU//Eihpos/sresU/JEihpos/sresU/REihpos/sresU/EEihpos/sresU//Eihpos/sresU/LEihpos/sresU/IEihpos/sresU/BEihpos/sresU//Eihpos/sresU/EEihpos/sresU/NEihpos/sresU/DEihpos/sresU/OEihpos/sresU/REihpos/sresU/SEihpos/sresU/EEihpos/sresU/", (java.lang.CharSequence) "10a32a1a32", 42148);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 391 + "'", int3 == 391);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "phie", 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("vaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0", "LATFORMAPISPECIF");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0" + "'", str2.equals("0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(" Ho..avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " Ho..avaJ" + "'", str1.equals(" Ho..avaJ"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Platform API Specification", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "a4a4                                             ");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strArray15);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10a1", "4444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("10#-1#-1#10#100", "x86_64", "aa4aaa4a4");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Platform API Specif", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Platform API Specif" + "'", str2.equals("Platform API Specif"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS ", "JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jar");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "a1a001a01a11a011-a001a1a001a01a11a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "JavaPlatformAPISpecification", (java.lang.CharSequence) "35#100#100#-1#31                      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', (int) (short) 10, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', 97, 52);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 94, 29);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1#0" + "'", str10.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-140" + "'", str20.equals("-140"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("aaaaaaaaaa", "-1 100 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.5", "51.051.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("NTENTS/HOME/JRE/LIB/ENDORS", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "hO..AVAj");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0.79a0.1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0.79a0.1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("platformapispecif", '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "x86_64");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8" + "'", str7.equals("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Platform35#100#100#-1#31API35#100#100#-1#31Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "platform35#100#100#-1#31api35#100#100#-1#31specification" + "'", str1.equals("platform35#100#100#-1#31api35#100#100#-1#31specification"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "eihpos/sresU/", "   1.0 97.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("\n", "1#10#100#1#100#-1");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.2", strArray4, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "\n" + "'", str5.equals("\n"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.2" + "'", str10.equals("1.2"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("6");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.0f + "'", float1.equals(6.0f));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("10#-1#-1#10#100", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#-1#-1#10#100" + "'", str2.equals("10#-1#-1#10#100"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("US", 28, 76);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1.0", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("...0-131");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!", "...0a-1a31", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("UTF-8", 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ":", (int) 'a', (int) (short) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray4, strArray6);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "31a10a28a10", (java.lang.CharSequence[]) strArray4);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str13.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Platform35#100#100#-1#31API35#100#100#-1#31Specification", "X86_6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0" + "'", str1.equals("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31", (java.lang.CharSequence) " Java HotSpot(TM) 64-Bit Server VM  ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jar");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1790 + "'", int1 == 1790);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("eihpos/sresU/", 61);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpos/sresU/" + "'", str2.equals("eihpos/sresU/"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("1043241432", "          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1043241432" + "'", str2.equals("1043241432"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "PlatformAPISpecif");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "  1.", (java.lang.CharSequence) "0.01#0.AmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalP");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 1790, (float) 77L, (float) 52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1790.0f + "'", float3 == 1790.0f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " 4#", (java.lang.CharSequence) "6", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/uSERS/SOPHIE", "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0" + "'", str2.equals("0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) " ######################################################################sun.lwawt.macosx.LWCToolkit  ", (java.lang.CharSequence) "0.0410.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98 + "'", int2 == 98);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(10.0d, 1.0d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Platform API Specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("a444 4 4 44", "en");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "NTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 0, (long) 29, 28L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                                             46_68xtiklooTCWL.xsocam.twawl.nus", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410." + "'", str1.equals("0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410."));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "#a4a4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                                                             ", (java.lang.CharSequence) "0.0410.0-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("44444 ##444444", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444 ##444444" + "'", str3.equals("44444 ##444444"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1 100 10", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("0.0a10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0a10." + "'", str1.equals("0.0a10."));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("#a4a4                                              ", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a..." + "'", str2.equals("#a..."));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4L, 0.0d, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "             Hi!             ", 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("UTF-8");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest7.test484");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
//        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
//        boolean boolean8 = javaVersion2.atLeast(javaVersion4);
//        boolean boolean9 = javaVersion0.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str11 = javaVersion10.toString();
//        boolean boolean12 = javaVersion4.atLeast(javaVersion10);
//        java.lang.Class<?> wildcardClass13 = javaVersion4.getClass();
//        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "Oracle Corporation", (int) (short) 0);
//        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.split("Java Ho..", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
//        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray18, strArray21);
//        java.lang.Class<?> wildcardClass23 = strArray21.getClass();
//        int[] intArray28 = new int[] { (short) 10, ' ', 1, ' ' };
//        int int29 = org.apache.commons.lang3.math.NumberUtils.min(intArray28);
//        java.lang.Class<?> wildcardClass30 = intArray28.getClass();
//        java.lang.Class[] classArray32 = new java.lang.Class[3];
//        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray33 = (java.lang.Class<?>[]) classArray32;
//        wildcardClassArray33[0] = wildcardClass13;
//        wildcardClassArray33[1] = wildcardClass23;
//        wildcardClassArray33[2] = wildcardClass30;
//        org.apache.commons.lang3.JavaVersion javaVersion40 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str41 = javaVersion40.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion42 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean43 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion42);
//        org.apache.commons.lang3.JavaVersion javaVersion44 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion45 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean46 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion45);
//        boolean boolean47 = javaVersion44.atLeast(javaVersion45);
//        boolean boolean48 = javaVersion42.atLeast(javaVersion44);
//        boolean boolean49 = javaVersion40.atLeast(javaVersion44);
//        org.apache.commons.lang3.JavaVersion javaVersion50 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str51 = javaVersion50.toString();
//        boolean boolean52 = javaVersion44.atLeast(javaVersion50);
//        java.lang.Class<?> wildcardClass53 = javaVersion44.getClass();
//        java.lang.String[] strArray58 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "Oracle Corporation", (int) (short) 0);
//        java.lang.String[] strArray61 = org.apache.commons.lang3.StringUtils.split("Java Ho..", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
//        java.lang.String str62 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray58, strArray61);
//        java.lang.Class<?> wildcardClass63 = strArray61.getClass();
//        int[] intArray68 = new int[] { (short) 10, ' ', 1, ' ' };
//        int int69 = org.apache.commons.lang3.math.NumberUtils.min(intArray68);
//        java.lang.Class<?> wildcardClass70 = intArray68.getClass();
//        java.lang.Class[] classArray72 = new java.lang.Class[3];
//        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray73 = (java.lang.Class<?>[]) classArray72;
//        wildcardClassArray73[0] = wildcardClass53;
//        wildcardClassArray73[1] = wildcardClass63;
//        wildcardClassArray73[2] = wildcardClass70;
//        java.lang.Class[][] classArray81 = new java.lang.Class[2][];
//        @SuppressWarnings("unchecked") java.lang.Class<?>[][] wildcardClassArray82 = (java.lang.Class<?>[][]) classArray81;
//        wildcardClassArray82[0] = wildcardClassArray33;
//        wildcardClassArray82[1] = wildcardClassArray73;
//        java.lang.String str87 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray82);
//        java.lang.String str91 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) wildcardClassArray82, "1 1 52 2 0 4", 27, (int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.2" + "'", str11.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(strArray18);
//        org.junit.Assert.assertNotNull(strArray21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(classArray32);
//        org.junit.Assert.assertNotNull(wildcardClassArray33);
//        org.junit.Assert.assertTrue("'" + javaVersion40 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion40.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1.2" + "'", str41.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + javaVersion42 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion42.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion44 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion44.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion45 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion45.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion50 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion50.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1.2" + "'", str51.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(strArray58);
//        org.junit.Assert.assertNotNull(strArray61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "" + "'", str62.equals(""));
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass70);
//        org.junit.Assert.assertNotNull(classArray72);
//        org.junit.Assert.assertNotNull(wildcardClassArray73);
//        org.junit.Assert.assertNotNull(classArray81);
//        org.junit.Assert.assertNotNull(wildcardClassArray82);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "" + "'", str91.equals(""));
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "10a11a10a10...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("### hO..AVAj####", "a#4# # # #4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "### hO..AVAj####" + "'", str2.equals("### hO..AVAj####"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "              1 / u SERS / SOPHIE ./ u SERS / SOPHIE 7 / u SERS / SOPHIE ./ u SERS / SOPHIE 0 / u SERS / SOPHIE _ / u SERS / SOPHIE 80");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 134 + "'", int1 == 134);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("aaaa", "4aaa4a4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "a444 4 4 44", (java.lang.CharSequence) "A 4 a 4 4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1043241432" + "'", str8.equals("1043241432"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10 32 1 32" + "'", str10.equals("10 32 1 32"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("-1#", "######################################################################sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#" + "'", str2.equals("-1#"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Platform API Specificatio" + "'", str1.equals("Platform API Specificatio"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("13a1-a0...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13a1-a0..." + "'", str1.equals("13a1-a0..."));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                         ...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.0a0.0a0.0", (java.lang.CharSequence) "                                                             ", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) '#', 31);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        byte byte18 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.toString(byteArray6, " jAVA hOTsPOT(tm) 64-bIT sERVER vm  ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:  jAVA hOTsPOT(tm) 64-bIT sERVER vm  ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1a10a100a1a100a-1" + "'", str17.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) -1 + "'", byte18 == (byte) -1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Platform35#100#100#-1#31API35#100#100#-1#31Specification", "-1 0", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification" + "'", str3.equals("Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("O...", "utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8", 56);
        org.junit.Assert.assertNotNull(strArray3);
    }
}

