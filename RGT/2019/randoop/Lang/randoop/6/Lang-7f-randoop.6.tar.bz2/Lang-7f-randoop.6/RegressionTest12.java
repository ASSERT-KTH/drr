import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test001");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (short) 100, 100);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10a32a1a32" + "'", str12.equals("10a32a1a32"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10#32#1#32" + "'", str14.equals("10#32#1#32"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1043241432" + "'", str16.equals("1043241432"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test002");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test003");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test004");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1043241432" + "'", str8.equals("1043241432"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test005");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.maco", "", 89);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test006");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "       Sophie", (java.lang.CharSequence) "x86_", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test007");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.2", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("...                   46_68x", 397, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                   46_68xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("...                   46_68xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test009");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "vaPlatformAPISpecification", (java.lang.CharSequence) "ificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp(" hO..AVAj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " hO..AVAj" + "'", str1.equals(" hO..AVAj"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test011");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 37, 5);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test012");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils1 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils2 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils3 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils4 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils5 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray6 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0, numberUtils1, numberUtils2, numberUtils3, numberUtils4, numberUtils5 };
        org.apache.commons.lang3.math.NumberUtils numberUtils7 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils8 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils9 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils10 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils11 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils12 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray13 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils7, numberUtils8, numberUtils9, numberUtils10, numberUtils11, numberUtils12 };
        org.apache.commons.lang3.math.NumberUtils numberUtils14 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils15 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils16 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils17 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils18 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils19 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray20 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils14, numberUtils15, numberUtils16, numberUtils17, numberUtils18, numberUtils19 };
        org.apache.commons.lang3.math.NumberUtils numberUtils21 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils22 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils23 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils24 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils25 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils26 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray27 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils21, numberUtils22, numberUtils23, numberUtils24, numberUtils25, numberUtils26 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray28 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray6, numberUtilsArray13, numberUtilsArray20, numberUtilsArray27 };
        org.apache.commons.lang3.math.NumberUtils numberUtils29 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils30 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils31 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils32 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils33 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils34 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray35 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils29, numberUtils30, numberUtils31, numberUtils32, numberUtils33, numberUtils34 };
        org.apache.commons.lang3.math.NumberUtils numberUtils36 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils37 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils38 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils39 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils40 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils41 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray42 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils36, numberUtils37, numberUtils38, numberUtils39, numberUtils40, numberUtils41 };
        org.apache.commons.lang3.math.NumberUtils numberUtils43 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils44 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils45 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils46 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils47 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils48 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray49 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils43, numberUtils44, numberUtils45, numberUtils46, numberUtils47, numberUtils48 };
        org.apache.commons.lang3.math.NumberUtils numberUtils50 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils51 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils52 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils53 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils54 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils55 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray56 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils50, numberUtils51, numberUtils52, numberUtils53, numberUtils54, numberUtils55 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray57 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray35, numberUtilsArray42, numberUtilsArray49, numberUtilsArray56 };
        org.apache.commons.lang3.math.NumberUtils[][][] numberUtilsArray58 = new org.apache.commons.lang3.math.NumberUtils[][][] { numberUtilsArray28, numberUtilsArray57 };
        org.apache.commons.lang3.math.NumberUtils[][][][] numberUtilsArray59 = new org.apache.commons.lang3.math.NumberUtils[][][][] { numberUtilsArray58 };
        java.lang.String str60 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray59);
        org.junit.Assert.assertNotNull(numberUtilsArray6);
        org.junit.Assert.assertNotNull(numberUtilsArray13);
        org.junit.Assert.assertNotNull(numberUtilsArray20);
        org.junit.Assert.assertNotNull(numberUtilsArray27);
        org.junit.Assert.assertNotNull(numberUtilsArray28);
        org.junit.Assert.assertNotNull(numberUtilsArray35);
        org.junit.Assert.assertNotNull(numberUtilsArray42);
        org.junit.Assert.assertNotNull(numberUtilsArray49);
        org.junit.Assert.assertNotNull(numberUtilsArray56);
        org.junit.Assert.assertNotNull(numberUtilsArray57);
        org.junit.Assert.assertNotNull(numberUtilsArray58);
        org.junit.Assert.assertNotNull(numberUtilsArray59);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test013");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("4# 46_68x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/4# 46_68xt");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4# 46_68x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/4# 46_68xt" + "'", str1.equals("4# 46_68x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/4# 46_68xt"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test014");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("51.0", "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0", 17);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 35, 19);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test015");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 32, 760.0f, (float) 52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 760.0f + "'", float3 == 760.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test016");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("platform35#100#100#-1#31api35#100#100#-1#31specification", "                  ts4j/tmp/run_randoop.pl_50283_1560277096                   ", "10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test017");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("j#v# Pl#tform API Specific#tion");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test018");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test019");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test020");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 1586, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausers/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausers/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test021");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.2");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test022");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (short) 100, 100);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 5, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10a32a1a32" + "'", str12.equals("10a32a1a32"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "   1.6    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("PLATFORMAPISPECIF", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIF" + "'", str2.equals("PLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIF"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test025");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "platform35#100#100#-1#31api35#100#100#-1#31specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test026");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 217, 32);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10#32#1#32" + "'", str7.equals("10#32#1#32"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a32a1a32" + "'", str9.equals("10a32a1a32"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test027");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 143, (float) 1410040410L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.41004045E9f + "'", float3 == 1.41004045E9f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test028");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test029");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', (int) (short) 10, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', 97, 1);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short19 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        try {
            java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', 25, 56);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 25");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1#0" + "'", str10.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1#0" + "'", str12.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-1 0" + "'", str18.equals("-1 0"));
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) -1 + "'", short19 == (short) -1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test030");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("###############################4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test031");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("x86_64                   ...x86_64              10a1x86_64                   ...x86_64              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test032");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 217);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test033");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("ocuments/defects4j/framework/lib                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test035");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(72.0f, (float) 217, (float) 42148L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 42148.0f + "'", float3 == 42148.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test036");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0 0.0 0.0", ":");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test037");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("4aaa4a4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4aaa4a4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test038");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1), (double) 29L, (double) 42);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 42.0d + "'", double3 == 42.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test039");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31" + "'", str3.equals("3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test040");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 1, (double) 52, 12.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test041");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "444", 55, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "0.1-NTENTS/HOME/JRE/LIB/ENDORS0.1-#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test043");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "a 4       4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test044");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 38 + "'", int1 == 38);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("####################################################", 94);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################                                          " + "'", str2.equals("####################################################                                          "));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test046");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.Class[] classArray6 = new java.lang.Class[1];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray7 = (java.lang.Class<?>[]) classArray6;
        wildcardClassArray7[0] = wildcardClass4;
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.reflect.GenericDeclaration[]) wildcardClassArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(classArray6);
        org.junit.Assert.assertNotNull(wildcardClassArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "class [Ljava.lang.String;" + "'", str10.equals("class [Ljava.lang.String;"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "class [Ljava.lang.String;" + "'", str11.equals("class [Ljava.lang.String;"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " " + "'", str1.equals(" "));
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest12.test048");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
//        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
//        boolean boolean8 = javaVersion2.atLeast(javaVersion4);
//        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean11 = javaVersion2.atLeast(javaVersion10);
//        boolean boolean12 = javaVersion0.atLeast(javaVersion10);
//        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        java.lang.String str14 = javaVersion0.toString();
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.2" + "'", str14.equals("1.2"));
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("A100A-", (int) '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                             A100A-" + "'", str3.equals("                             A100A-"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test050");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80", "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "x86_64");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("en", strArray3, strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "en" + "'", str7.equals("en"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "mixed mode" + "'", str8.equals("mixed mode"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "mixed mode" + "'", str9.equals("mixed mode"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test051");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "      ");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "###############################4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "  ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("...                   46_68xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "-1.0#10.0#1.0#-1.0", 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...  -1.0#10.0#1.0#-1.0aaaa" + "'", str3.equals("...  -1.0#10.0#1.0#-1.0aaaa"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        "));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test054");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 1410040410, 17);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) (short) 100, 38);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1043241432" + "'", str8.equals("1043241432"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test055");
        long[] longArray2 = new long[] { (short) 1, (byte) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', (int) '4', (int) (short) 1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', 19, 8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 52, 4);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 89, (int) '4');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test056");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1a0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test057");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(8.0f, (float) 98L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test058");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test059");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "X0.0a10.0X", (java.lang.CharSequence) "-1 0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en..." + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en..."));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test061");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java Ho..", 74);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("0.0a10.0", "### hO..AVAj####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0a10.0" + "'", str2.equals("0.0a10.0"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test063");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("86_", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test064");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("   1.6    ", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test065");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie", "MIXED MOD", "/Library/Jntents/Home/jre/lib/endorsed###########################################################");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test066");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1 0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test067");
        float[] floatArray2 = new float[] { (short) 1, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a97.0" + "'", str4.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a97.0" + "'", str7.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test068");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("35100100-131");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "35100100-131" + "'", str1.equals("35100100-131"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "NEMNORIVNeSCIHPARgc.TWA.NUS 40                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test070");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "0140400141");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "a#4# # # #4", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest12.test071");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
//        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
//        boolean boolean8 = javaVersion2.atLeast(javaVersion4);
//        boolean boolean9 = javaVersion0.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str11 = javaVersion10.toString();
//        boolean boolean12 = javaVersion4.atLeast(javaVersion10);
//        java.lang.Class<?> wildcardClass13 = javaVersion4.getClass();
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
//        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion17);
//        boolean boolean19 = javaVersion16.atLeast(javaVersion17);
//        boolean boolean20 = javaVersion14.atLeast(javaVersion16);
//        boolean boolean21 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion16);
//        boolean boolean22 = javaVersion4.atLeast(javaVersion16);
//        boolean boolean23 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.2" + "'", str11.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test072");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("a4444444a444444///////////////////a4444444a444444", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaeihpos/sresu/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "###############################4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test074");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray2 = new char[] {};
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.4", charArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test075");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                              ", (java.lang.CharSequence) "          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test076");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test077");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("0.01#0.AmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalP");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".01#0.AmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalP\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test078");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                           10a1                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test079");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10#32#1#32" + "'", str7.equals("10#32#1#32"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a32a1a32" + "'", str9.equals("10a32a1a32"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10#32#1#32" + "'", str11.equals("10#32#1#32"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test080");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        java.lang.String str4 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test081");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Jntents/Home/jre/lib/endorsed", "");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "http://java.oracle.com/");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "JAVA HO...", (-1), 2434);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Library/Jntents/Home/jre/lib/endorsed" + "'", str6.equals("/Library/Jntents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Library/Jntents/Home/jre/lib/endorsed" + "'", str8.equals("/Library/Jntents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test082");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ", "0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0", "r-/8ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/_/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/0/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/7/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/1/r/ar/r/ar/a/r/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   "));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test083");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1420 + "'", int1 == 1420);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test084");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test085");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("####################################################", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test087");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("nEMNORIVNeSCIHPARgc.TWA.NUS                                                              ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test088");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("UTF-8", 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ":", (int) 'a', (int) (short) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray4, strArray6);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "31a10a28a10", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "-1.0");
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', 36, 34);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str13.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test089");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "###################################################1 10 100 1 100 -1", 0, 55);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test090");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '#', (double) 42148.0f, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test091");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 52, 13.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("10.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.04-1.0410.0" + "'", str1.equals("10.04-1.0410.0"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test093");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4444444444444444444444440.79a0.14444444444444444441.0#0.0#0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".79a0.144\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test094");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-140", 68);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test095");
        float[] floatArray3 = new float[] { 10.0f, (-1), 10.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) (short) 1, 0);
        java.lang.Class<?> wildcardClass9 = floatArray3.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.04-1.0410.0" + "'", str11.equals("10.04-1.0410.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10.0 -1.0 10.0" + "'", str13.equals("10.0 -1.0 10.0"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("             /r/ar...", "...0a-1a31...0a-1a31...0a-1a31...0a-1a31...0a-1a4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             /r/ar..." + "'", str2.equals("             /r/ar..."));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test098");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 77.0f, 77.0d, 51.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.0d + "'", double3 == 51.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("a1a001a01a11a011-a001a1a001a01a11a0", 38);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " a1a001a01a11a011-a001a1a001a01a11a0  " + "'", str2.equals(" a1a001a01a11a011-a001a1a001a01a11a0  "));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("51.0", "class [Ljava.l...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                               " + "'", str1.equals("                               "));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test102");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test103");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.0a97.0", (int) (byte) 10);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification", "10#32#1#32");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a", strArray4, strArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Java Platform API Specification" + "'", str9.equals("Java Platform API Specification"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a" + "'", str10.equals("       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Java Platform API Specification" + "'", str11.equals("Java Platform API Specification"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "1.0", "JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.ja");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.04", "13a1-a0...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.04" + "'", str2.equals("0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.04"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test106");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "             ", (java.lang.CharSequence) "14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   ", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa0.79A0.1aaaaaaaaaaaaaaaaaaavaPlatformAPISpecificationaaaaaaaaaa0.79A0.1aaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaa0.79A0.1aaaaaaaaaaaaaaaaaaavaPlatformAPISpecificationaaaaaaaaaa0.79A0.1aaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Iaa4aaa4a4", 29);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("              1 / u SERS / SOPHIE ./ u SERS / SOPHIE 7 / u SERS / SOPHIE ./ u SERS / SOPHIE 0 / u SERS / SOPHIE _ / u SERS / SOPHIE 80", 392, 1398);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test110");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Jntents/Home/jre/lib/endorsed", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test111");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "  1.", (java.lang.CharSequence) "java virtual machine specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test112");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MIXED MOD", "", 72);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test113");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.0 0.0 0.0", (java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test114");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "             ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test115");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("SUN.AWT.cgRAPHICSeNVIRONMEN", "", 134);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test116");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str4 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2" + "'", str4.equals("1.2"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test117");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(" ", "86_", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test118");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("SUN.AWT.cgRAPHICSeNVIRONMENT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test119");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("-1a0", 4444);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a0" + "'", str2.equals("-1a0"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("444444444444444440.1-#0.1#0.01#0.1-", "73");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444440.1-#0.1#0.01#0.1-" + "'", str2.equals("444444444444444440.1-#0.1#0.01#0.1-"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "platform35#100#100#-1#31api35#100#100#-1#31specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test123");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("en", "sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("class [Lja", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaEihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test124");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test125");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("NEMNORIVNeSCIHPARgc.TWA.NUS ", "/USERS/SOPHI", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test126");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "US", (java.lang.CharSequence) "##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test127");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.0#0.0#0.0", (int) (byte) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0#0.0#0.0" + "'", str3.equals("1.0#0.0#0.0"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "10a-1a-1a10a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test129");
        double[] doubleArray4 = new double[] { (-1.0f), 10.0d, 1.0f, (-1L) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0410.041.04-1.0" + "'", str7.equals("-1.0410.041.04-1.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0a10.0a1.0a-1.0" + "'", str11.equals("-1.0a10.0a1.0a-1.0"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test130");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "en                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test131");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Eihpos/sresU/", "1.0a0.0a0.0");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Eihpos/sresU/" + "'", str6.equals("Eihpos/sresU/"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test132");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                          -x#0                                           ", "1.6", 37);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test133");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.platformapispecif", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "e/lib/endorse");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test134");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "x86_64 ...x86_64 10a1x86_64 ...x86_64", (java.lang.CharSequence) "             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test135");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) '4', (-1));
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 1, 5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 100 + "'", byte16 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) -1 + "'", byte17 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10a100a1a100" + "'", str21.equals("10a100a1a100"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Platform API Specif", "#a4a4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Platform API Specif" + "'", str2.equals("Platform API Specif"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04", "a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4", "0.0 0.0 0.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8:-1.0.10.0.1.0.-1.0:-1.0.10.0.1.0.-1.0:-1.0.10.0.1.0." + "'", str3.equals("1.8:-1.0.10.0.1.0.-1.0:-1.0.10.0.1.0.-1.0:-1.0.10.0.1.0."));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("http://java.oracle.com/", "O...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test139");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a", (java.lang.CharSequence) "             Hi!             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45 + "'", int2 == 45);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test140");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(10.0d, (double) 2, 392.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                 JAVA HO...                                 ", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                 JAVA HO...                                 " + "'", str2.equals("                                 JAVA HO...                                 "));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", (int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 77, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                             " + "'", str3.equals("                                                                             "));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("44444444444444", (int) (short) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444" + "'", str3.equals("44444444444444"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test145");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hO..AVAj", (int) (short) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahO..AVAjaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahO..AVAjaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test147");
        long[] longArray6 = new long[] { 1, (byte) 1, 52L, 2, (byte) 0, 4 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 31, 19);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test148");
        char[] charArray7 = new char[] { ' ', '#' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', 0, (int) (short) -1);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS X", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.0a97.", charArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1a10a100a1a100a-1", charArray7);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "r", charArray7);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Sophie", charArray7);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + " ##" + "'", str18.equals(" ##"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test149");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "O...", (java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1", 1398);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test150");
        long[] longArray5 = new long[] { '#', 100L, 100, (byte) -1, 31 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "35a100a100a-1a31" + "'", str7.equals("35a100a100a-1a31"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35 100 100 -1 31" + "'", str9.equals("35 100 100 -1 31"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test151");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test152");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.01#0.AmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalP", "phie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test153");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("CLASS [LJAVA.LANG.STRING;");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test154");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.platformapispecif");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test155");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test156");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                     1.8                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                      ", (long) 25);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25L + "'", long2 == 25L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test157");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/Library/Jntents/Home/jre/lib/endorsed", (java.lang.CharSequence) "PlatformAPISpeci");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Library/Jntents/Home/jre/lib/endorsed" + "'", charSequence2.equals("/Library/Jntents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test158");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification" + "'", str2.equals("#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test160");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 20L, (double) 42, (double) 72);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 72.0d + "'", double3 == 72.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("///////////////////");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "///////////////////" + "'", str1.equals("///////////////////"));
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest12.test162");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
//        boolean boolean11 = javaVersion8.atLeast(javaVersion9);
//        boolean boolean12 = javaVersion6.atLeast(javaVersion8);
//        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean15 = javaVersion6.atLeast(javaVersion14);
//        boolean boolean16 = javaVersion4.atLeast(javaVersion14);
//        boolean boolean17 = javaVersion2.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean19 = javaVersion2.atLeast(javaVersion18);
//        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean21 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion20);
//        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean24 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
//        boolean boolean25 = javaVersion22.atLeast(javaVersion23);
//        boolean boolean26 = javaVersion20.atLeast(javaVersion22);
//        boolean boolean27 = javaVersion2.atLeast(javaVersion22);
//        boolean boolean28 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion22);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test163");
        long[] longArray4 = new long[] { 6, (short) 10, (-1L), 94 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "6#10#-1#94" + "'", str7.equals("6#10#-1#94"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test164");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test165");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("platformapispecif", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "platformapispecif" + "'", str3.equals("platformapispecif"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test167");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion1.atLeast(javaVersion2);
        boolean boolean5 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean9 = javaVersion6.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean13 = javaVersion10.atLeast(javaVersion11);
        java.lang.String str14 = javaVersion10.toString();
        boolean boolean15 = javaVersion7.atLeast(javaVersion10);
        boolean boolean16 = javaVersion0.atLeast(javaVersion10);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.4" + "'", str14.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "X86_", (java.lang.CharSequence) "///////////////////");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test169");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0", "", 45);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0", "a4444444", 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0" + "'", str3.equals("PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0a4444444PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0"));
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest12.test171");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
//        boolean boolean11 = javaVersion8.atLeast(javaVersion9);
//        boolean boolean12 = javaVersion6.atLeast(javaVersion8);
//        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean15 = javaVersion6.atLeast(javaVersion14);
//        boolean boolean16 = javaVersion4.atLeast(javaVersion14);
//        boolean boolean17 = javaVersion2.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
//        boolean boolean19 = javaVersion2.atLeast(javaVersion18);
//        boolean boolean20 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) " jAVA hOTsPOT(tm) 64-bIT sERVER vm  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test173");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(" 4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#" + "'", str1.equals("4#"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test174");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "0.1-#0.1#0.01#0.1-", 1586);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test175");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) 10, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#-1#-1#10#100" + "'", str8.equals("10#-1#-1#10#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test176");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 55, (long) 1586, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1586L + "'", long3 == 1586L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test177");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "51.051.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test178");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("10.14.3", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 36);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test180");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test181");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10.14.310.14.310.14PlatformAPISpecif", (java.lang.CharSequence) "       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test182");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test183");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "             Hi!             ", (java.lang.CharSequence) "##################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test184");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0.0410.00.0410.0", "0a1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar10a11a10a100a1a");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java4Platform4API4Specification", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java4Platform4API4Specification" + "'", str2.equals("Java4Platform4API4Specification"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                       AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str3.equals("                                                       AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test187");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Library/Jntents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Platform API Specification", 97, "                                                                                                                                                                                                                                                                                                                                                                                  ####################                                                                                                                                                                                                                                                                                                                                                                                  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                   Platform API Specification                                    " + "'", str3.equals("                                   Platform API Specification                                    "));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test189");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "e/lib/endorse");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test190");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.0a0.0a0.0", (java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test191");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "HI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test192");
        char[] charArray4 = new char[] { ' ', '#' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray4, '4', 0, (int) (short) -1);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10#-1#-1#10#100", charArray4);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80", "java virtual machine specification", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1/SERS/SOPHIE./SERS/SOPHIE7/SERS/SOPHIE./SERS/SOPHIE0/SERS/SOPHIE_/SERS/SOPHIE80" + "'", str3.equals("1/SERS/SOPHIE./SERS/SOPHIE7/SERS/SOPHIE./SERS/SOPHIE0/SERS/SOPHIE_/SERS/SOPHIE80"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test194");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.7.0_80-b15");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "44444 ##444444", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 14 + "'", int5 == 14);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/ Users / sophie / Library / Java / Extensions :/ Library / Java / Java Virtual Machines / jdk         jdk / Contents / Home / jre / li / ext :/ Library / Java / Extensions :/ Network / Library / Java / Extensions :/ System / Library / Java / Extensions :/ usr / li / java" + "'", str7.equals("/ Users / sophie / Library / Java / Extensions :/ Library / Java / Java Virtual Machines / jdk         jdk / Contents / Home / jre / li / ext :/ Library / Java / Extensions :/ Network / Library / Java / Extensions :/ System / Library / Java / Extensions :/ usr / li / java"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test195");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test196");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ocuments/defects4j/framework/lib                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test197");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "/ Users / sophie / Library / Java / Extensions :/ Library / Java / Java Virtual Machines / jdk         jdk / Contents / Home / jre / li / ext :/ Library / Java / Extensions :/ Network / Library / Java / Extensions :/ System / Library / Java / Extensions :/ usr / li / java", 42, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/ Users / sophie / Library / Java / Extensions :/ Library / Java / Java Virtual Machines / jdk         jdk / Contents / Home / jre / li / ext :/ Library / Java / Extensions :/ Network / Library / Java / Extensions :/ System / Library / Java / Extensions :/ usr / li / java" + "'", str4.equals("/ Users / sophie / Library / Java / Extensions :/ Library / Java / Java Virtual Machines / jdk         jdk / Contents / Home / jre / li / ext :/ Library / Java / Extensions :/ Network / Library / Java / Extensions :/ System / Library / Java / Extensions :/ usr / li / java"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test198");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.AWT.cgRAPHICSeNVIRONMEN", "1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("UTF-8", 'a');
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "          ", (java.lang.CharSequence[]) strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.0 97.", (java.lang.CharSequence[]) strArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                             aa4aaa4a4", (java.lang.CharSequence[]) strArray9);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                           ", strArray3, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 13 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test199");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("PlatformAPISpecif", 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("a1a001a01a11a011-a001a1a001a01a11a0", "1.0a0.0a0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a1a001a01a11a011-" + "'", str2.equals("a1a001a01a11a011-"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test201");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 4444, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test202");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) 10, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#-1#-1#10#100" + "'", str8.equals("10#-1#-1#10#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aa4aaa4a4", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa4aaa4a4" + "'", str2.equals("aa4aaa4a4"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test205");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" jAVA hOTsPOT(tm) 64-bIT sERVER vm  ", "-x#0");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 8, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test206");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "10a11a10a10...", (java.lang.CharSequence) "35a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test207");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test208");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("r-/8ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/_/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/0/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/7/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/1/r/ar/r/ar/a/r/", "/ Users / sophie / Library / Java / Extensions :/ Library / Java / Java Virtual Machines / jdk         jdk / Contents / Home / jre / li / ext :/ Library / Java / Extensions :/ Network / Library / Java / Extensions :/ System / Library / Java / Extensions :/ usr / li / java", 36);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test209");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorseP/library/ja...", "", "...                   46_68xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test210");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        int int15 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1043241432" + "'", str8.equals("1043241432"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1043241432" + "'", str14.equals("1043241432"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 32 + "'", int15 == 32);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test211");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("  #");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "0.79a0.1", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("-1.0a10.0a1.0a-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0a10.0a1.0a-1.0" + "'", str1.equals("-1.0a10.0a1.0a-1.0"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test213");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.5aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("4444444444444444444444441.44444444444444444444444444", "1.0 97.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test215");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                   Platform API Specification                                    ", 1420, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test216");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.04");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test217");
        char[] charArray4 = new char[] { '#', '4', '4' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "#a4a4" + "'", str6.equals("#a4a4"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test218");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test219");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test221");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"X8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test222");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Hi!");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test223");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("4444444444444444444444441.44444444444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test224");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                   java Platform API Specification                                                    ", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JA...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test225");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 690, 623.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 690.0f + "'", float3 == 690.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test226");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("##################");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test227");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Jntents/Home/jre/lib/endorsed###########################################################", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test228");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Platform35#100#100#-1#31API35#100#100#-1#31Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("### hO..AVAj####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "### hO..AVAj###" + "'", str1.equals("### hO..AVAj###"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("10A100A1A100A-11A10", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10A100A1A100A-11A10" + "'", str2.equals("10A100A1A100A-11A10"));
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest12.test231");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
//        boolean boolean5 = javaVersion2.atLeast(javaVersion3);
//        boolean boolean6 = javaVersion0.atLeast(javaVersion2);
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean9 = javaVersion0.atLeast(javaVersion8);
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
//        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
//        boolean boolean15 = javaVersion12.atLeast(javaVersion13);
//        boolean boolean16 = javaVersion10.atLeast(javaVersion12);
//        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
//        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean19 = javaVersion10.atLeast(javaVersion18);
//        boolean boolean20 = javaVersion8.atLeast(javaVersion10);
//        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str22 = javaVersion21.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean24 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
//        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean26 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion25);
//        org.apache.commons.lang3.JavaVersion javaVersion27 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion28 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean29 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion28);
//        boolean boolean30 = javaVersion27.atLeast(javaVersion28);
//        boolean boolean31 = javaVersion25.atLeast(javaVersion27);
//        boolean boolean32 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion25);
//        org.apache.commons.lang3.JavaVersion javaVersion33 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean34 = javaVersion25.atLeast(javaVersion33);
//        boolean boolean35 = javaVersion23.atLeast(javaVersion33);
//        boolean boolean36 = javaVersion21.atLeast(javaVersion23);
//        org.apache.commons.lang3.JavaVersion javaVersion37 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        java.lang.String str38 = javaVersion37.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion39 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        boolean boolean40 = javaVersion37.atLeast(javaVersion39);
//        boolean boolean41 = javaVersion21.atLeast(javaVersion39);
//        java.lang.String str42 = javaVersion39.toString();
//        boolean boolean43 = javaVersion10.atLeast(javaVersion39);
//        boolean boolean44 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion39);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1.8" + "'", str22.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion27 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion27.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion28 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion28.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion33 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion33.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion37 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion37.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1.4" + "'", str38.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + javaVersion39 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion39.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1.4" + "'", str42.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test232");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                           10a1                                            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                            10a1                                             is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test233");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10#32#1#32", "1.8");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0", strArray3, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 67");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test234");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("141452424044");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 141452424044L + "'", number1.equals(141452424044L));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre", "35#1   Hi!    35#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35#1   Hi!    35#10" + "'", str2.equals("35#1   Hi!    35#10"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test236");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "0.0#14.0#38.0#10.0", (java.lang.CharSequence) "                                                             aa4aaa4a4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("6#10#-1#94", 36, "                                                                                                                                                                                                    -140                                                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                          6#10#-1#94" + "'", str3.equals("                          6#10#-1#94"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test238");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aa4aaa4a4", (java.lang.CharSequence) "/r/ar/aar/r/aar-/ts4j/tMp/run_ranOXXp.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("4#", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       4#" + "'", str2.equals("                       4#"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("##################", "######################################################################sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##################" + "'", str2.equals("##################"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("##################class [Ljava.l...", "6#10#-1#94");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test243");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("0a11a10a100a1a100a-110a11a10a100a1a", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test244");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "///////////////////");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test245");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.4", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "   1.6    ", charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "A 4 a 4 4", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test246");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie", 391);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test247");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test248");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorseP/library/ja...", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test249");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(37, 1398, 2748);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 37 + "'", int3 == 37);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("\n", 50, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test251");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.4", "44444444444444444444444444444444444444444444444444", "1.0 97.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test252");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Oracle Corporation", 34, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test253");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                    ", "35a100a100a-1a31", (int) (short) -1);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "4444444444", (java.lang.CharSequence[]) strArray4);
        java.lang.Class<?> wildcardClass6 = strArray4.getClass();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test254");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(50, 134, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 50 + "'", int3 == 50);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test255");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) " a#", (java.lang.CharSequence) "                                            hO..AVAj");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaa", "a4a4                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("             /R/AR/AAR/R/AAR-/1/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/.//R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/7/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/.//R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/0/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/_/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/8", 1410040410, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test258");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1", "r-/8ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/_/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/0/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/7/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/1/r/ar/r/ar/a/r/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test259");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("...                   46_68xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java H", "0.0410.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                   46_68xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("...                   46_68xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test261");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.8", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "35#100#100#-1#31", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "NTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSE", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("0.1-#0.1#0.01#0.1-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.1-#0.1#0.01#0.1" + "'", str1.equals("0.1-#0.1#0.01#0.1"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test263");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 97L, (double) 39.0f, (double) 3L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test264");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test265");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test266");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ocuments/defects4j/framework/lib", 8, "          0.79a0.1          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ocuments/defects4j/framework/lib" + "'", str3.equals("ocuments/defects4j/framework/lib"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test267");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("4444444444444444444444440.79a0.1");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', 38, 74);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 38");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("class [Lj", " ######################################################################sun.lwawt.macosx.LWCToolkit  ", "mixed mod");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Lj" + "'", str3.equals("class [Lj"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test269");
        char[] charArray5 = new char[] { ' ', '#' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 0, (int) (short) -1);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', (int) '#', 8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1.0", charArray5);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "PlatformAPISpeci", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "jAVApLATFORMapisPECI/Users/sophijAVApLATFORMapisPECI/Users/sophijAVApLATFORMapisPECI/Users/1.81.2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test271");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                   4444444444444                    ", (java.lang.CharSequence) "             1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test272");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                 Java Ho...                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test273");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("86_", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test274");
        float[] floatArray2 = new float[] { (short) 1, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 217, 39);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a97.0" + "'", str4.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0 97.0" + "'", str6.equals("1.0 97.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0a97.0" + "'", str8.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0a97.0" + "'", str10.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 97.0f + "'", float11 == 97.0f);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("SUN.AWT.cgRAPHICSeNVIRONMENT", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".cgRAPHICSeNVIRONMENT" + "'", str2.equals(".cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test276");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) " a1a001a01a11a011-a001a1a001a01a11a0  ", 25);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test278");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest12.test279");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
//        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
//        boolean boolean8 = javaVersion2.atLeast(javaVersion4);
//        boolean boolean9 = javaVersion0.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str11 = javaVersion10.toString();
//        boolean boolean12 = javaVersion4.atLeast(javaVersion10);
//        java.lang.Class<?> wildcardClass13 = javaVersion4.getClass();
//        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "Oracle Corporation", (int) (short) 0);
//        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.split("Java Ho..", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
//        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray18, strArray21);
//        java.lang.Class<?> wildcardClass23 = strArray21.getClass();
//        int[] intArray28 = new int[] { (short) 10, ' ', 1, ' ' };
//        int int29 = org.apache.commons.lang3.math.NumberUtils.min(intArray28);
//        java.lang.Class<?> wildcardClass30 = intArray28.getClass();
//        java.lang.Class[] classArray32 = new java.lang.Class[3];
//        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray33 = (java.lang.Class<?>[]) classArray32;
//        wildcardClassArray33[0] = wildcardClass13;
//        wildcardClassArray33[1] = wildcardClass23;
//        wildcardClassArray33[2] = wildcardClass30;
//        org.apache.commons.lang3.JavaVersion javaVersion40 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str41 = javaVersion40.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion42 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean43 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion42);
//        org.apache.commons.lang3.JavaVersion javaVersion44 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion45 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean46 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion45);
//        boolean boolean47 = javaVersion44.atLeast(javaVersion45);
//        boolean boolean48 = javaVersion42.atLeast(javaVersion44);
//        boolean boolean49 = javaVersion40.atLeast(javaVersion44);
//        org.apache.commons.lang3.JavaVersion javaVersion50 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str51 = javaVersion50.toString();
//        boolean boolean52 = javaVersion44.atLeast(javaVersion50);
//        java.lang.Class<?> wildcardClass53 = javaVersion44.getClass();
//        java.lang.String[] strArray58 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "Oracle Corporation", (int) (short) 0);
//        java.lang.String[] strArray61 = org.apache.commons.lang3.StringUtils.split("Java Ho..", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
//        java.lang.String str62 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray58, strArray61);
//        java.lang.Class<?> wildcardClass63 = strArray61.getClass();
//        int[] intArray68 = new int[] { (short) 10, ' ', 1, ' ' };
//        int int69 = org.apache.commons.lang3.math.NumberUtils.min(intArray68);
//        java.lang.Class<?> wildcardClass70 = intArray68.getClass();
//        java.lang.Class[] classArray72 = new java.lang.Class[3];
//        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray73 = (java.lang.Class<?>[]) classArray72;
//        wildcardClassArray73[0] = wildcardClass53;
//        wildcardClassArray73[1] = wildcardClass63;
//        wildcardClassArray73[2] = wildcardClass70;
//        java.lang.Class[][] classArray81 = new java.lang.Class[2][];
//        @SuppressWarnings("unchecked") java.lang.Class<?>[][] wildcardClassArray82 = (java.lang.Class<?>[][]) classArray81;
//        wildcardClassArray82[0] = wildcardClassArray33;
//        wildcardClassArray82[1] = wildcardClassArray73;
//        java.lang.String str87 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray82);
//        java.lang.String str88 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray82);
//        java.lang.String str89 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[][]) wildcardClassArray82);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.2" + "'", str11.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(strArray18);
//        org.junit.Assert.assertNotNull(strArray21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(classArray32);
//        org.junit.Assert.assertNotNull(wildcardClassArray33);
//        org.junit.Assert.assertTrue("'" + javaVersion40 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion40.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1.2" + "'", str41.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + javaVersion42 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion42.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion44 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion44.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion45 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion45.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion50 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion50.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1.2" + "'", str51.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(strArray58);
//        org.junit.Assert.assertNotNull(strArray61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "" + "'", str62.equals(""));
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass70);
//        org.junit.Assert.assertNotNull(classArray72);
//        org.junit.Assert.assertNotNull(wildcardClassArray73);
//        org.junit.Assert.assertNotNull(classArray81);
//        org.junit.Assert.assertNotNull(wildcardClassArray82);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("a4a4", "JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a4a4" + "'", str2.equals("a4a4"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test281");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("6#10#-1#94", "### hO..AVAj####");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test282");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test283");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1410040410", (java.lang.CharSequence) "13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test284");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("phie", "10 -1 -1 10 100", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sun.lwawt.macosx.LWCToolkit", "/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test287");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8" + "'", str1.equals("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test289");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("NTENTS/HOME/JRE/LIB/ENDORS", "...0-131", "2 10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NTENTS/HOME/JRE/LIB/ENDORS" + "'", str3.equals("NTENTS/HOME/JRE/LIB/ENDORS"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test290");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/ Users / sophie / Library / Java / Extensions :/ Library / Java / Java Virtual Machines / jdk         jdk / Contents / Home / jre / li / ext :/ Library / Java / Extensions :/ Network / Library / Java / Extensions :/ System / Library / Java / Extensions :/ usr / li / java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("10A100A1A100A-11A10", 50);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test292");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("#UN.#WT.#gR##H#C##NV#RONMENT", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test293");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.81.2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("####################################################", "-140", 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################" + "'", str3.equals("####################################################"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test295");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4444, (int) (short) 4444, 42148);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4444 + "'", int3 == 4444);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test296");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test297");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (int) (short) 100, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test298");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1410040410");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.41004041E9d + "'", double1 == 1.41004041E9d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 61, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                             " + "'", str3.equals("                                                             "));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test300");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test301");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                               4a4a#");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split(":", "1.5");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1a10a100a1a100a-1", ":", 100);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray6, strArray10);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1.0#10.0#1.0#-1.0", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 6 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test302");
        long[] longArray4 = new long[] { 31L, 10L, 28, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.Class<?> wildcardClass6 = longArray4.getClass();
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 77, 31);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 9, 623);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31410428410" + "'", str9.equals("31410428410"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test303");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Eihpos/sresU/" + "'", str1.equals("Eihpos/sresU/"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test304");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 1.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test305");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.a0.0", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test306");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/...", 217, 37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("#a...", "             /R/AR/AAR/R/AAR-/1/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/.//R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/7/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/.//R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/0/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/_/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a..." + "'", str2.equals("#a..."));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("class [Lja", "31#10#28#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Lja" + "'", str2.equals("class [Lja"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test309");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-x#0", (java.lang.CharSequence) "10.14.", 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase(" ######################################################################sun.lwawt.macosx.LWCToolkit  ", "/ Users / sophie / Library / Java / Extensions :/ Library / Java / Java Virtual Machines / jdk         jdk / Contents / Home / jre / li / ext :/ Library / Java / Extensions :/ Network / Library / Java / Extensions :/ System / Library / Java / Extensions :/ usr / li / java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " ######################################################################sun.lwawt.macosx.LWCToolkit  " + "'", str2.equals(" ######################################################################sun.lwawt.macosx.LWCToolkit  "));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "r-/80ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/_/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/0/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/7/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/1/r/ar/r/ar/a             /r/", "  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test312");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1a10a100a1a100a-", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test313");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.platformapispecif");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test314");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("...  -1.0#10.0#1.0#-1.0aaaa", (double) 1398);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1398.0d + "'", double2 == 1398.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test315");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" ##", "31410428410");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("35#1   Hi!    35#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "35#1   hI!    35#10" + "'", str1.equals("35#1   hI!    35#10"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test317");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("NEMNORIVNeSCIHPARgc.TWA.NUS ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NEMNORIVNeSCIHPARgc.TWA.NUS " + "'", str2.equals("NEMNORIVNeSCIHPARgc.TWA.NUS "));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaa", "1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test320");
        float[] floatArray2 = new float[] { (short) 1, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a97.0" + "'", str4.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0a97.0" + "'", str6.equals("1.0a97.0"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("  ###########################", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  ###########################" + "'", str2.equals("  ###########################"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("8utf-8utf-8utf-8utf-8utf-8utf-8utf-8", "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!", 42);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8" + "'", str3.equals("8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0", "                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0" + "'", str2.equals("14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test324");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1.0 0.0 0.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test325");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("              eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test326");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("SUN.AWT.cgRAPHICSeNVIRONMENT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"S\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test327");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "mixedmod", (java.lang.CharSequence) "1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86 + "'", int2 == 86);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test328");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 98L, (float) (short) 4444, (float) 89);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 89.0f + "'", float3 == 89.0f);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test329");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.7.0_80-b15");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "44444 ##444444", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 14 + "'", int5 == 14);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test330");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "                                                          hi!", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test331");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test332");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(16, 45, 74);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test333");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("0.1-#0.1#0.01#0.1", "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.", "10a32a1a32");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test334");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("a#4#a#4#4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test335");
        double[] doubleArray2 = new double[] { (byte) 0, (byte) 10 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test336");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10a1" + "'", str4.equals("10a1"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                   4444444444444                    ", "##################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                   4444444444444                    " + "'", str2.equals("                   4444444444444                    "));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("-140", 39, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test339");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8", "                   ", 1398);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test340");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10.14.310.14.310.14PlatformAPISpecif", (java.lang.CharSequence) "S", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 30 + "'", int3 == 30);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test341");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "su 32");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("0.1-NTENTS/HOME/JRE/LIB/ENDORS0.1-#", "                ", 623);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.1-NTENTS/HOME/JRE/LIB/ENDORS0.1-#" + "'", str3.equals("0.1-NTENTS/HOME/JRE/LIB/ENDORS0.1-#"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test343");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Java Ho...", 0);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test344");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("a#4#a#4#4", "##################class [Ljava.l...", "1a0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test345");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("          0.79A0.1          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0.79A0.1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test346");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "a#4#a#4#4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test348");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "-1a0", 1410040410);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test349");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                            1a01                                           ", (java.lang.CharSequence) "Platform API Specif");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "PLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIF");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test351");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(" 4 a 4 4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" 4 a 4 4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("46_68X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "46_68X" + "'", str1.equals("46_68X"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("a4a4                                             ", "4# 46_68x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/4# 46_68xt");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a4a4                                             " + "'", str2.equals("a4a4                                             "));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test354");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                                                                                                                                                                                                                                                                                                  ####################                                                                                                                                                                                                                                                                                                                                                                                  ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("-1.0410.041.04-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0410.041.04-1.0" + "'", str1.equals("-1.0410.041.04-1.0"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("HI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!", "10#32#1#32", 34);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test357");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a1010a32a1a321a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test358");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("         I");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test359");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "NTENTS/HOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test360");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.4", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_80-b15", charArray3);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "0.0a10.0", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test363");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0", " 4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus", 72);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.0#0.0#0.0", (int) ' ', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test365");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-x#0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("         I");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "         I" + "'", str1.equals("         I"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test367");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(52, 9, 89);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 89 + "'", int3 == 89);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test368");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test369");
        char[] charArray5 = new char[] {};
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/uSERS/SOPHIE", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "A100A-1", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10 32 1 32", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test370");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 1410040410, 17);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1043241432" + "'", str8.equals("1043241432"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test371");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                        1410040410");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                        1410040410\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test372");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Sophie", 56);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("4#                                                                             46_68xtiklootcwl.xsocam.twawl.nus", 0, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4..." + "'", str3.equals("4..."));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Mac OS", 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS" + "'", str3.equals("Mac OS"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test375");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short16 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a0" + "'", str8.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-140" + "'", str11.equals("-140"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1 0" + "'", str14.equals("-1 0"));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) -1 + "'", short15 == (short) -1);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) -1 + "'", short16 == (short) -1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("JAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION" + "'", str2.equals("JAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test377");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("JAVA HO...", (int) (byte) 1, "1.0 9");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA HO..." + "'", str3.equals("JAVA HO..."));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("6_64", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6_64" + "'", str2.equals("6_64"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test379");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10 1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test380");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "444444444444", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test381");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a4a4                                              ", "1.8:-1.0.10.0.1.0.-1.0:-1.0.10.0.1.0.-1.0:-1.0.10.0.1.0.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test383");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (short) 100, 100);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 13, 134);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 13");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10#32#1#32" + "'", str13.equals("10#32#1#32"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test384");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str5.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test385");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...", 40);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test386");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) 10, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 72, 19);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test387");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.awt.CGraphicsEnvironmen", (float) 134);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 134.0f + "'", float2 == 134.0f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("4# 46_68x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/4# 46_68xt");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4# 46_68x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/4# 46_68xt" + "'", str1.equals("4# 46_68x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/4# 46_68xt"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("-1#0", 4444, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1#0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        " + "'", str3.equals("-1#0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        "));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test390");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Mixedmod", "10.0#-1.0#10.0", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test391");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (short) 100, 100);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        int int19 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10a32a1a32" + "'", str12.equals("10a32a1a32"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10a32a1a32" + "'", str14.equals("10a32a1a32"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10#32#1#32" + "'", str16.equals("10#32#1#32"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1043241432" + "'", str18.equals("1043241432"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test392");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "aaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en...", "13a1-a0...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test394");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                               X86_6X86_6                                ", (java.lang.CharSequence) "Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification", 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("   ", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test396");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/...", (java.lang.CharSequence) "aaaa", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test397");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray10, strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Jntents/Home/jre/lib/endorsed", strArray5, strArray14);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.split("PlatformAPISpecif", "1043241432", (int) (short) 0);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.stripAll(strArray20);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray20, "0140400141", (int) (byte) 100, (int) (short) 100);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEach("NEMNORIVNeSCIHPARgc.TWA.NUS ", strArray14, strArray20);
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1.0", "NEMNORIVNeSCIHPARgc.TWA.NUS");
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray20, strArray29);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "/Library/Jntents/Home/jre/lib/endorsed" + "'", str16.equals("/Library/Jntents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "NEMNORIVNeSCIHPARgc.TWA.NUS " + "'", str26.equals("NEMNORIVNeSCIHPARgc.TWA.NUS "));
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", " jAVA hOTsPOT(tm) 64-bIT sERVER vm  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test399");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Java Ho...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test400");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test401");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                                                                    ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test402");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', (int) (short) 10, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 35, (int) (short) 1);
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', (int) (short) 4444, 0);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1#0" + "'", str10.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) -1 + "'", short15 == (short) -1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test403");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.0a97.0", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a97.0" + "'", str2.equals("1.0a97.0"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test405");
        char[] charArray7 = new char[] { ' ', '#' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', 0, (int) (short) -1);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS X", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ocuments/defects4j/framework/lib", charArray7);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) '4', (int) (short) 1);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "\n", charArray7);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "46_68X", charArray7);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " ##", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test406");
        char[] charArray4 = new char[] { ' ', '#' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray4, '4', 0, (int) (short) -1);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10#-1#-1#10#100", charArray4);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                             A100A-", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("jAVA hOTsPOT(tm) 64-bIT sERVER vm", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str2.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test408");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 39L, 760.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test409");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("X86_64", '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1.0", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10.14.3", strArray3, strArray6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.14.3" + "'", str7.equals("10.14.3"));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test410");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 9.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.0d + "'", double2 == 9.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8", "####################################################                                          ", "10.14.");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test412");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short17 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a0" + "'", str8.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-140" + "'", str11.equals("-140"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1#0" + "'", str13.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1 0" + "'", str16.equals("-1 0"));
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) -1 + "'", short17 == (short) -1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-1 0" + "'", str19.equals("-1 0"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("PLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIF", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIF" + "'", str2.equals("PLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIF"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test414");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444440.79a0.1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test415");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test416");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("141041004141004-1", "31#10#28#10", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test417");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 97, 5);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1043241432" + "'", str15.equals("1043241432"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test418");
        float[] floatArray3 = new float[] { 10.0f, (-1), 10.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) (short) 1, 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', 17, (int) (short) 0);
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 10.0f + "'", float13 == 10.0f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 10.0f + "'", float14 == 10.0f);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test419");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 2432, (long) 36, (long) (short) 4444);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 36L + "'", long3 == 36L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test420");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test421");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-class [Lj");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.", " a#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97." + "'", str2.equals("   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97."));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test423");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test424");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java4Platform4API4Specification", (java.lang.CharSequence) "platform35#100#100#-1#31api35#100#100#-1#31specification", 681);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest12.test425");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
//        boolean boolean11 = javaVersion8.atLeast(javaVersion9);
//        boolean boolean12 = javaVersion6.atLeast(javaVersion8);
//        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean15 = javaVersion6.atLeast(javaVersion14);
//        boolean boolean16 = javaVersion4.atLeast(javaVersion14);
//        boolean boolean17 = javaVersion2.atLeast(javaVersion4);
//        java.lang.String str18 = javaVersion4.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean20 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion19);
//        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean22 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion21);
//        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion24 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean25 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion24);
//        boolean boolean26 = javaVersion23.atLeast(javaVersion24);
//        boolean boolean27 = javaVersion21.atLeast(javaVersion23);
//        boolean boolean28 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion21);
//        org.apache.commons.lang3.JavaVersion javaVersion29 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean30 = javaVersion21.atLeast(javaVersion29);
//        boolean boolean31 = javaVersion19.atLeast(javaVersion29);
//        org.apache.commons.lang3.JavaVersion javaVersion32 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str33 = javaVersion32.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion34 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean35 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion34);
//        org.apache.commons.lang3.JavaVersion javaVersion36 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean37 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion36);
//        org.apache.commons.lang3.JavaVersion javaVersion38 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion39 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean40 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion39);
//        boolean boolean41 = javaVersion38.atLeast(javaVersion39);
//        boolean boolean42 = javaVersion36.atLeast(javaVersion38);
//        boolean boolean43 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion36);
//        org.apache.commons.lang3.JavaVersion javaVersion44 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean45 = javaVersion36.atLeast(javaVersion44);
//        boolean boolean46 = javaVersion34.atLeast(javaVersion44);
//        boolean boolean47 = javaVersion32.atLeast(javaVersion34);
//        boolean boolean48 = javaVersion19.atLeast(javaVersion32);
//        org.apache.commons.lang3.JavaVersion javaVersion49 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean50 = javaVersion32.atLeast(javaVersion49);
//        boolean boolean51 = javaVersion4.atLeast(javaVersion49);
//        org.apache.commons.lang3.JavaVersion javaVersion52 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean53 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion52);
//        java.lang.String str54 = javaVersion52.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion55 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean56 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion55);
//        org.apache.commons.lang3.JavaVersion javaVersion57 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion58 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean59 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion58);
//        boolean boolean60 = javaVersion57.atLeast(javaVersion58);
//        boolean boolean61 = javaVersion55.atLeast(javaVersion57);
//        boolean boolean62 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion55);
//        org.apache.commons.lang3.JavaVersion javaVersion63 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean64 = javaVersion55.atLeast(javaVersion63);
//        boolean boolean65 = javaVersion52.atLeast(javaVersion55);
//        java.lang.String str66 = javaVersion55.toString();
//        boolean boolean67 = javaVersion49.atLeast(javaVersion55);
//        org.apache.commons.lang3.JavaVersion javaVersion68 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        java.lang.String str69 = javaVersion68.toString();
//        java.lang.String str70 = javaVersion68.toString();
//        java.lang.String str71 = javaVersion68.toString();
//        boolean boolean72 = javaVersion55.atLeast(javaVersion68);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.2" + "'", str18.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion24 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion24.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion29 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion29.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion32 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion32.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.8" + "'", str33.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion34 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion34.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion36 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion36.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion38 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion38.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion39 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion39.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion44 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion44.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion49 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion49.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion52 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion52.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "1.8" + "'", str54.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion55 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion55.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion57 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion57.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion58 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion58.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion63 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion63.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "1.8" + "'", str66.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion68 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion68.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "1.4" + "'", str69.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "1.4" + "'", str70.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "1.4" + "'", str71.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test426");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.8", 35, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test427");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa", "PLATFORMAPISPECIF", 391);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("46_68X", 45);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X" + "'", str2.equals("46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test429");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "X86_6", "PLATFORMAPISPECIF", 681);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test430");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("             1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80", "JAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("#################################ts4j/tMp/run_ranOXXp.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#################################ts4j/tMp/run_ranOXXp.pl_50283_1560277096" + "'", str1.equals("#################################ts4j/tMp/run_ranOXXp.pl_50283_1560277096"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test432");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', (int) (short) 10, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 35, (int) (short) 1);
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short16 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1#0" + "'", str10.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) -1 + "'", short15 == (short) -1);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) -1 + "'", short16 == (short) -1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-1a0" + "'", str18.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-140" + "'", str20.equals("-140"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test433");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.0a97.0", "                                                                                                    ");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', 4, 397);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test434");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "73");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.2", (-1), 1410040410);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test436");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("\n", '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ', 31, 0);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray14);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/USERS/SOPHI", (java.lang.CharSequence[]) strArray14);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0.79a0.1", strArray4, strArray14);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                                                 ", (java.lang.CharSequence[]) strArray14);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0.79a0.1" + "'", str17.equals("0.79a0.1"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test437");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "#UN.#WT.#gR##H#C##NV#RONMENT", (java.lang.CharSequence) "#a...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test438");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray10, strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Jntents/Home/jre/lib/endorsed", strArray5, strArray14);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray14, "-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0");
        boolean boolean19 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "######################################################################sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray14);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray14);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "/Library/Jntents/Home/jre/lib/endorsed" + "'", str16.equals("/Library/Jntents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test439");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10a1" + "'", str4.equals("10a1"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test441");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", (java.lang.CharSequence) "Eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test442");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("a4a4                                              ", "                                 JAVA HO...                                 ", 10, 38);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "a4a4                                       JAVA HO...                                             " + "'", str4.equals("a4a4                                       JAVA HO...                                             "));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test444");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test445");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("51.051.0                                                                                   ", (int) (byte) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.051.0                                                                                   " + "'", str3.equals("51.051.0                                                                                   "));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie", "13");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test447");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "                                                                                           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test448");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test449");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("-1#", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test450");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 0, 45, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test451");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0#a4a4                                              ", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0#a4a44444444444444444444444444444444444444444444444" + "'", str3.equals("0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0#a4a44444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test452");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 690L, (double) 134.0f, (double) 5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 690.0d + "'", double3 == 690.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test453");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.0 97", 17, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "sun.lwawt.macosx.LWCToolkitx86_64                                                                                              ", "jAVApLATFORMapisPECI/Users/sophijAVApLATFORMapisPECI/Users/sophijAVApLATFORMapisPECI/Users/1.81.2");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("-1 0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 1-" + "'", str1.equals("0 1-"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("Hi!", "              Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!" + "'", str2.equals("Hi!"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;", "             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;" + "'", str2.equals("4.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test458");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '#', 38, 17);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1043241432" + "'", str12.equals("1043241432"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test459");
        java.lang.Number[][] numberArray0 = new java.lang.Number[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(numberArray0);
        org.junit.Assert.assertNotNull(numberArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test460");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("PlatformAPISpecif");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: PlatformAPISpecif is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0" + "'", str2.equals("a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test462");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test463");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(391, 1, (int) (short) 4444);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test464");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("e/lib/endorse", "46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X46_68X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e/lib/endorse" + "'", str2.equals("e/lib/endorse"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test466");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "", 134);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test467");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test468");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) " ######################################################################sun.lwawt.macosx.LWCToolkit  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test469");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.0 97.", (long) 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test470");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "X86_6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test471");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Platform35#100#100#-1#31API35#100#100#-1#31Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test472");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.0 9");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test473");
        char[] charArray6 = new char[] { ' ', '#' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', 0, (int) (short) -1);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0a97.", charArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ', 19, (int) (byte) -1);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray6);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                              ", charArray6);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.0#97.1.0#97.1.0#97.1.0#97.1.0#97.1.0#97.1.0#97.1.0#97.1.0#97.1.0#97.1.0#97.1.0#97.1.0#97.1.0#97.1.0#97.1.0#97.1.0#97.1.0#97.1.0#97.1", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test474");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "ts4j/tmp/run_randoop.pl_50283_1560277096                                    ", (java.lang.CharSequence) "#a4a4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test475");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 98L, (float) 35, (float) 86);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 98.0f + "'", float3 == 98.0f);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test476");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "      vaPlatformAPISpecification", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test477");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.0#97.", 94, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0#97.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("1.0#97.444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test478");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", (java.lang.CharSequence) "############################################################################", 42);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test479");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "mixedmod", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                                                                                                                    -140                                                                                                                                                                                                     ", (int) (short) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                    -140                                                                                                                                                                                                     " + "'", str3.equals("                                                                                                                                                                                                    -140                                                                                                                                                                                                     "));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                             aa4aaa4a4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa4aaa4a4" + "'", str1.equals("aa4aaa4a4"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test482");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test483");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) " hO..AVAj hO..AVAj hO..AVAj hO..              hO..AVAj hO..AVAj hO..AVAj hO..", (java.lang.CharSequence) "10A100A1A100A-11A10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test484");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Platform API Specification", (java.lang.CharSequence) "MIXED MOD");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test485");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test486");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 46, 1.2f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test487");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test488");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("35#100#100#-1#31                      ", "  1.");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.0#97.0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test489");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("eihpos/sresU/");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "1.7");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test491");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "", (java.lang.CharSequence) "class [Lja", 42);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("46_68X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "46_68" + "'", str1.equals("46_68"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test493");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Ho..ava", (java.lang.CharSequence) "...                   46_68x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test494");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 0, (int) (byte) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 37, 25);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10#32#1#32" + "'", str7.equals("10#32#1#32"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10#32#1#32" + "'", str13.equals("10#32#1#32"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 32 + "'", int14 == 32);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10a32a1a32" + "'", str16.equals("10a32a1a32"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test495");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Oracle Corporation");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "8utf-8utf-8utf-8utf-8utf-8utf-8utf-8");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                               4a4a#", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test496");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "4...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "Iaa4aaa4a4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  " + "'", str2.equals("  "));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest12.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("en                             ", "                                                          hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en                             " + "'", str2.equals("en                             "));
    }
}

