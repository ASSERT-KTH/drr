import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1.0#0.0#0.0", (java.lang.CharSequence) "0.0410.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-x#0", charSequence1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("  1.", (long) 19);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 19L + "'", long2 == 19L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!", 19, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!" + "'", str3.equals("Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass7 = intArray4.getClass();
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, '#', 1, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("x86_64", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.0a97.0", (int) (byte) 10);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "-1a");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str7.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1a10a100a1a100a-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java Ho..", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("class [Ljava.lang.String;", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.l..." + "'", str2.equals("class [Ljava.l..."));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1" + "'", charSequence2.equals("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;", "PlatformAPISpecif", 1410040410, 19);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.14.310.14.310.14PlatformAPISpecif" + "'", str4.equals("10.14.310.14.310.14PlatformAPISpecif"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.0", "-1 100 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.4", "0140400141");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEh/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEi/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEe/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", (java.lang.CharSequence) "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.0 97.0", (java.lang.CharSequence) "1a0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("#a4a4", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a4a4" + "'", str2.equals("#a4a4"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1" + "'", str1.equals("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", 13, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", "-x#0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(31L, (long) 10, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 31L + "'", long3 == 31L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("eihpos/sresU/", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.0#0.0#0.0", 38);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("10a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10a1" + "'", str1.equals("10a1"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.CharSequence charSequence4 = null;
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.0a97.0", (int) (byte) 10);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence4, (java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("###############################", strArray2, strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "###############################" + "'", str10.equals("###############################"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1410040410", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("http://java.oracle.com/", (float) 89);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 89.0f + "'", float2 == 89.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(" ", ":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "Oracle Corporation", (int) (short) 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("Java Ho..", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "a 4 a 4 4", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Java Ho...", (java.lang.CharSequence) "       Sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 14, "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.maco" + "'", str3.equals("sun.lwawt.maco"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 35L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", (java.lang.CharSequence) "X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("SUN.AWT.cgRAPHICSeNVIRONMEN");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironmen" + "'", str1.equals("sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("46_68X", 61);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61 + "'", int2 == 61);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#a4a4", 1410040410);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("  #", 1410040410);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1410040410, 72L, (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("#", "1.0 0.0 0.0", "1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1", "Java Ho...", "", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1" + "'", str4.equals("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-" + "'", str2.equals("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) ":", (java.lang.CharSequence) "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.0 0.0 0.0", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("10a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.8", 56, ":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04" + "'", str3.equals("1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("ocuments/defects4j/framework/lib");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ocuments/defects4j/framework/lib" + "'", str1.equals("ocuments/defects4j/framework/lib"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "1.0#97.", "-1a0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/r/ar/aar/r/aar-/", (java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/r/ar/aar/r/aar-/" + "'", charSequence2.equals("/r/ar/aar/r/aar-/"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("51.0", "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0", 17);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0", "http://java.oracle.com/", (int) (short) 0);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("UTF-8", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus", "ificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus" + "'", str2.equals("                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun.awt.CGraphicsEnvironmen", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironmen" + "'", str2.equals("sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "PLATFORMAPISPECIF");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 17, 77);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 17");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32, (double) (byte) 0, 35.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.0 0.0 0.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1" + "'", str2.equals("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("mixed mode", "-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("phie", (float) 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1a0", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1.7");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 1.7f + "'", number1.equals(1.7f));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("0.79a0.1", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          0.79a0.1          " + "'", str2.equals("          0.79a0.1          "));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "46_68X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "", "1043241432");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("mixed mode", (int) (short) -1, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("0.0#10.0", "", (int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ".0#10.0" + "'", str4.equals(".0#10.0"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1A10A100A1A100A-1", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "a 4 a 4 4", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "a 4 a 4 4" + "'", charSequence2.equals("a 4 a 4 4"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "-x#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("x86_64                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "Oracle Corporation", (int) (short) 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("Java Ho..", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1a10a100a1a100a-1", "35a100a100a-1a31");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("###############################", "1.0#97.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############################" + "'", str2.equals("###############################"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", "eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Mac OS X", (double) 1410040410);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.41004041E9d + "'", double2 == 1.41004041E9d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.0 0.0 0.0", "1410040410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 0.0 0.0" + "'", str2.equals("1.0 0.0 0.0"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("141452424044", (int) (short) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "141452424044" + "'", str3.equals("141452424044"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java Ho..", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Ho..avaJ" + "'", str2.equals(" Ho..avaJ"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "1.0 0.0 0.");
        org.junit.Assert.assertNotNull(strArray2);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test098");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
//        boolean boolean5 = javaVersion2.atLeast(javaVersion3);
//        boolean boolean6 = javaVersion0.atLeast(javaVersion2);
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean9 = javaVersion0.atLeast(javaVersion8);
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
//        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
//        boolean boolean15 = javaVersion12.atLeast(javaVersion13);
//        boolean boolean16 = javaVersion10.atLeast(javaVersion12);
//        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
//        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean19 = javaVersion10.atLeast(javaVersion18);
//        boolean boolean20 = javaVersion8.atLeast(javaVersion10);
//        java.lang.String str21 = javaVersion10.toString();
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1.8" + "'", str21.equals("1.8"));
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Library/Jntents/Home/jre/lib/endorsed", ":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Jntents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Jntents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("phie", "8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "phie" + "'", str3.equals("phie"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("   ", "ificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", "0.79a0.1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("141041004141004-1", "/", "ificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "141041004141004-1" + "'", str3.equals("141041004141004-1"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("\n", '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 31, 0);
        java.lang.String[] strArray8 = null;
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("class [Ljava.lang.String;", strArray3, strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "class [Ljava.lang.String;" + "'", str9.equals("class [Ljava.lang.String;"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        double[] doubleArray3 = new double[] { 1, (short) 0, 0L };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0 0.0 0.0" + "'", str8.equals("1.0 0.0 0.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.0 0.0 0.", (java.lang.CharSequence) "31a10a28a10", 1410040410);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaa" + "'", str1.equals("aaaaaaaaaa"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "/Users/sophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Sophie", (java.lang.CharSequence) "Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#" + "'", str3.equals("#"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sun.lwawt.maco");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.maco" + "'", str1.equals("sun.lwawt.maco"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 1, 0L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-x#0", (java.lang.CharSequence) "JavaPlatformAPISpecification", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "35a100a100a-1a31", (java.lang.CharSequence) "JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Java Ho..", "1.5", "SUN.AWT.cgRAPHICSeNVIRONMEN");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Ho.." + "'", str3.equals("Java Ho.."));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "US", (java.lang.CharSequence) "35#100#100#-1#31");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "java hotspot(tm) 64-bit server vm", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.8", (java.lang.CharSequence) "Eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test127");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
//        boolean boolean11 = javaVersion8.atLeast(javaVersion9);
//        boolean boolean12 = javaVersion6.atLeast(javaVersion8);
//        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean15 = javaVersion6.atLeast(javaVersion14);
//        boolean boolean16 = javaVersion4.atLeast(javaVersion14);
//        boolean boolean17 = javaVersion2.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean19 = javaVersion2.atLeast(javaVersion18);
//        java.lang.String str20 = javaVersion2.toString();
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.2" + "'", str20.equals("1.2"));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "ificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-" + "'", str2.equals("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("#a4a4", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", "1a10a100a1a100a-1", 97);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("A100A-1", "                                                          hi!", "sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "A100A-1" + "'", str3.equals("A100A-1"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("jAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) '#', 31);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 0, 38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.awt.CGraphicsEnvironment", 32.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(97.0f, (float) 3, (float) 94);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ts4j/tmp/run_randoop.pl_50283_1560277096" + "'", str2.equals("ts4j/tmp/run_randoop.pl_50283_1560277096"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("       sOPHIE", 52, "1a10a100a1a100a-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a" + "'", str3.equals("       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.04-1.0410.0", '4');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "24.80-b11");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "141452424044                                                                                     ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.0a97.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0a97." + "'", str1.equals("1.0a97."));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophi", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("UTF-8", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ":", (int) 'a', (int) (short) -1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray3, strArray5);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str12.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0", "0.0a10.0", 100);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("UTF-8", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ":", (int) 'a', (int) (short) -1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray3, strArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str12.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java HotSpot(TM) 64-Bit Server VM", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("10a32a1a32");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10a32a1a32\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', 2, 38);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("35a100a100a-1a31", "Oracle Corporation", "mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35a100a100a-1a31" + "'", str3.equals("35a100a100a-1a31"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "35#100#100#-1#31");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a", (double) 72L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 72.0d + "'", double2 == 72.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("phie", 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "-1 100 10", (java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-" + "'", str2.equals("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "  #");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaa", 8, 1410040410);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 10, (long) ' ', (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(" ", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.Class<?> wildcardClass8 = byteArray6.getClass();
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Java HotSpot(TM) 64-Bit Server VM");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "35a100a100a-1a31", "Java Ho...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/", (java.lang.CharSequence) "                                   ", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        int[] intArray2 = new int[] { 61, (short) 100 };
        int[] intArray5 = new int[] { 61, (short) 100 };
        int[] intArray8 = new int[] { 61, (short) 100 };
        int[][] intArray9 = new int[][] { intArray2, intArray5, intArray8 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray9);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(" ##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " ##" + "'", str1.equals(" ##"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("vaPlatformAPISpecification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"vaPlatformAPISpecification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "/Library/Jntents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad(":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:" + "'", str2.equals(":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(31L, (long) 97, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("#a4a4", 38);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a4a4" + "'", str2.equals("#a4a4"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1.0", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.", "0.0a10.0", "8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1." + "'", str3.equals("1."));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("jAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION", 38, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(2L, (long) 100, (long) 1410040410);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1410040410L + "'", long3 == 1410040410L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("   Hi!    ", "-1.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("141041004141004-1", "4444444444444", "Sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1S10S100S1S100S-1" + "'", str3.equals("1S10S100S1S100S-1"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("HI!", "Hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I" + "'", str2.equals("I"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1a10a100a1a100a-1", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMEN", 56);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHI" + "'", str1.equals("/USERS/SOPHI"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "JavaPlatformAPISpecification", (java.lang.CharSequence) "0140400141");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "JavaPlatformAPISpecification" + "'", charSequence2.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("A100A-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A100A-" + "'", str1.equals("A100A-"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("35a100a100a-1a31");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("PlatformAPISpecif", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.0a97.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "4444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a", "10.14.310.14.310.14PlatformAPISpecif");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a" + "'", str2.equals("       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 0, (double) 100.0f, (double) 61);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("jAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION", "Java HotSpot(TM) 64-Bit Server VM", "-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0a97.", "vaPlatformAPISpecification", (int) 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.0 0.0 0.", "ts4j/tmp/run_randoop.pl_50283_1560277096");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2432 + "'", int2 == 2432);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "I", (java.lang.CharSequence) "X86_6X86_6", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java(TM) SE Runtime Environment", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Hi!", "java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-x#0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "   1.6    ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                             46_68xtiklooTCWL.xsocam.twawl.nus" + "'", str2.equals("                                                                             46_68xtiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(28, 1410040410, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1410040410 + "'", int3 == 1410040410);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) (short) 100, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "SUN.AWT.cgRAPHICSeNVIRONMENT", 32);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10a32a1a32", (java.lang.CharSequence[]) strArray4);
        float[] floatArray9 = new float[] { 10.0f, (-1), 10.0f };
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray9, 'a', (int) (short) 1, 0);
        float float15 = org.apache.commons.lang3.math.NumberUtils.min(floatArray9);
        float float16 = org.apache.commons.lang3.math.NumberUtils.min(floatArray9);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.0 97.0", "10#32#1#32", 10);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "x86_64");
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("\n", strArray21, strArray24);
        java.lang.Object[] objArray27 = new java.lang.Object[] { "10a32a1a32", floatArray9, str25, "\n" };
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join(objArray27, "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + (-1.0f) + "'", float15 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + (-1.0f) + "'", float16 == (-1.0f));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "\n" + "'", str25.equals("\n"));
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.0 0.0 0.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".0 0.0 0.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "0.0410.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "1#10#100#1#100#-1");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.0#97.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0#97.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("-1a0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("ificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 10, 52.0f, (float) ' ');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(" Ho..avaJ", 1, "10.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " Ho..avaJ" + "'", str3.equals(" Ho..avaJ"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1#0", 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", (float) 13L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13.0f + "'", float2 == 13.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", "0.0410.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10a32a1a32", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("0140400141", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0140400141" + "'", str2.equals("0140400141"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("0.0410.0", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0410.0" + "'", str2.equals("0.0410.0"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("###############################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.0#0.0#0.0", (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Oracle Corporation", "6_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/r/ar/aar/r/aar-/", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("-1 100 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 28L, (float) (short) 100, (float) 89);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "AAAAAAAAAA", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1#10#100#1#100#-1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                   ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "X86_64", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ".0#10.0", (java.lang.CharSequence) "1.7", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0", "1.0#97.", 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0" + "'", str4.equals("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEh/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEi/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEe/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a" + "'", str1.equals("sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Java(TM) SE Runtime Environment", "1.2", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 77L, 77.0f, (float) 10L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.8", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "   1.6    ", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.0#97.", "X86_6", "class [Ljava.l...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0#97." + "'", str3.equals("1.0#97."));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) ":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", "/Library/Jntents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              " + "'", str2.equals("X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              "));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "A100A-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "0.0#10.0", (java.lang.CharSequence) "Platform API Specif");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EN" + "'", str1.equals("EN"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0140400141", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0140400141" + "'", str2.equals("0140400141"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java Platform API Specification", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("X86_6X86_6", "SUN.AWT.cgRAPHICSeNVIRONMEN");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_6X86_6" + "'", str2.equals("X86_6X86_6"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("6_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "46_6" + "'", str1.equals("46_6"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 38);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("class [Ljava.l...", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test272");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
//        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
//        boolean boolean8 = javaVersion2.atLeast(javaVersion4);
//        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean11 = javaVersion2.atLeast(javaVersion10);
//        boolean boolean12 = javaVersion0.atLeast(javaVersion10);
//        org.apache.commons.lang3.JavaVersion javaVersion13 = null;
//        try {
//            boolean boolean14 = javaVersion10.atLeast(javaVersion13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64                                                                                              ", "1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart(" ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1.2");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 1.2f + "'", number1.equals(1.2f));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("-1a0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("35#1   Hi!    35#10", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', 0, (int) (short) 1);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1#10#100#1#100#-1" + "'", str13.equals("1#10#100#1#100#-1"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "ts4j/tmp/run_randoop.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", (int) (short) 100);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "JavaPlatformAPISpecification", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "java Platform API Specification", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("X86_6", 38);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38 + "'", int2 == 38);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        int[] intArray4 = new int[] { (short) 10, 35, 0, 17 };
        int[] intArray9 = new int[] { (short) 10, 35, 0, 17 };
        int[] intArray14 = new int[] { (short) 10, 35, 0, 17 };
        int[] intArray19 = new int[] { (short) 10, 35, 0, 17 };
        int[] intArray24 = new int[] { (short) 10, 35, 0, 17 };
        int[] intArray29 = new int[] { (short) 10, 35, 0, 17 };
        int[][] intArray30 = new int[][] { intArray4, intArray9, intArray14, intArray19, intArray24, intArray29 };
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.join(intArray30);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', (int) '4', (int) ' ');
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 100, 2432);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0" + "'", str2.equals("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1a0", charSequence1, 94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("          0.79a0.1          ", "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          0.79a0.1          " + "'", str2.equals("          0.79a0.1          "));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 1.2f, (double) 13L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.0d + "'", double3 == 13.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                             " + "'", str1.equals("                                                             "));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 1, 32L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "#a4a4", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("a 4 a 4 4", " 4#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        short[] shortArray6 = new short[] { (byte) 0, (short) 0, (short) 1, (short) 10, (short) -1, (byte) -1 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-140                                                                                                ", "       sOPHIE");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ', 89, (-1));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (-1), (int) '4');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("-1.0#10.0#1.0#-1.0", "46_6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "#a4a4                                               ", (java.lang.CharSequence) "a 4 a 4 4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 14, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaa"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(".0#10.0", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEh/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEi/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEe/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEh/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEi/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEe/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE" + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEh/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEi/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEe/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                          hi!", "-1.0#10.0#1.0#-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                          hi!" + "'", str2.equals("                                                          hi!"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "US", (java.lang.CharSequence) "-1.0#10.0#1.0#-1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("A100A-", "35#100#100#-1#31", "X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "A100A-" + "'", str4.equals("A100A-"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/", "Java Ho..");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jar" + "'", str3.equals("JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jar"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                                             ", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(".0#10.0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "31a10a28a10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10a32a1a32");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("PlatformAPISpecif", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "1 0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "###############################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(97, 4, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "ificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen", (java.lang.CharSequence) "/Library/Jntents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Java(TM) SE Runtime Environment", "35a100a100a-1a31");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Eihpos/sresU/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-140                                                                                                ", 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/r/ar/aar/r/aar-/", (java.lang.CharSequence) "http://java.oracle.com/-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("US", "1.7.0_80-b15", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 14, 72L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 72L + "'", long3 == 72L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        double[] doubleArray3 = new double[] { 1, (short) 0, 0L };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', (int) '4', (int) ' ');
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("X86_64", "sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64" + "'", str2.equals("X86_64"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("46_68X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"46_68X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "1.5", 2432);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0" + "'", str2.equals("-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "0.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("I");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "I" + "'", str1.equals("I"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.0a97.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0a97." + "'", str1.equals("1.0a97."));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "0.0#10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(100.0d, (double) 'a', (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10#32#1#32");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10#32#1#32\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) " Ho..avaJ", (java.lang.CharSequence) "class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444" + "'", str1.equals("4444444444"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "eihpos/sresU/", (java.lang.CharSequence) "a#4# # # #4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1#10#100#1#100#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#10#100#1#100#-1" + "'", str1.equals("1#10#100#1#100#-1"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "6_64", 77, 56);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "6_64" + "'", str4.equals("6_64"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("SUN.AWT.cgRAPHICSeNVIRONMEN");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SUN.AWT.cgRAPHICSeNVIRONMEN\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1.7f, (double) (-1L), (double) 72L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 72, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Hi!", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!" + "'", str2.equals("Hi!"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("A100A-1");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "///////////////////", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("31410428410");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1a10a100a1a100a-1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/r/ar/aar/r/aar-/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/r/ar/aar/r/aar-/" + "'", str1.equals("/r/ar/aar/r/aar-/"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("#a4a4                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#a4a4                                              " + "'", str1.equals("#a4a4                                              "));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 17.0f, (double) 32.0f, (double) 17);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 17.0d + "'", double3 == 17.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Platform API Specif");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophi", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("ocuments/defects4j/framework/lib");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("10.04-1.0410.0", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.04-1.0410.0" + "'", str2.equals("10.04-1.0410.0"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("phie", "                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "phie" + "'", str2.equals("phie"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Platform API Specification", "1 10 100 1 100 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 10 100 1 100 -1" + "'", str2.equals("1 10 100 1 100 -1"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEh/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEi/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEe/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", (java.lang.CharSequence) "10.14.310.14.310.14PlatformAPISpecif");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwawt.macosx.LWCToolkit", (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "A100A-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 2432, "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("\n", "1#10#100#1#100#-1");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.2", strArray3, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\n" + "'", str4.equals("\n"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.2" + "'", str9.equals("1.2"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.8");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        double[] doubleArray1 = new double[] { (-1L) };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 10, 1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 31, 1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 0, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0" + "'", str12.equals("-1.0"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.0a97.", "1#10#100#1#100#-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "31a10a28a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ts4j/tmp/run_randoop.pl_50283_1560277096", "mixed mode", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ts4j/tMp/run_ranOXXp.pl_50283_1560277096" + "'", str3.equals("ts4j/tMp/run_ranOXXp.pl_50283_1560277096"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', 1, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "35a100a100a-1a31", (java.lang.CharSequence) "1 10 100 1 100 -1", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "1.7", "1#10#100#1#100#-1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "       sOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              " + "'", str2.equals("X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              "));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                            " + "'", str2.equals("                            "));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 32, 8.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.2");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "-1a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "x86_64                                                                                              ", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 10, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("141041004141004-1", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "141041004141004-1" + "'", str2.equals("141041004141004-1"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("X86_6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_6" + "'", str1.equals("X86_6"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Sophie", (java.lang.CharSequence) "10.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Sophie" + "'", charSequence2.equals("Sophie"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("A100A-1", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A100A-1" + "'", str2.equals("A100A-1"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("en");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sun.lwawt.maco", 2432);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.maco" + "'", str2.equals("sun.lwawt.maco"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.0#97.", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#97." + "'", str2.equals("1.0#97."));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", "4444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Library/Jntents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10a1", (java.lang.CharSequence) "///////////////////");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", (double) 6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096" + "'", str1.equals("users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "ts4j/tMp/run_ranOXXp.pl_50283_1560277096", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0140400141", (java.lang.CharSequence) "-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', 0, (int) (short) 1);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "A100A-1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: A100A-1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1#10#100#1#100#-1" + "'", str13.equals("1#10#100#1#100#-1"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(":", "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("PLATFORMAPISPECIF", "   1.6    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PLATFORMAPISPECIF" + "'", str2.equals("PLATFORMAPISPECIF"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("a444 4 4 44");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("UTF-8", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1S10S100S1S100S-1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1S10S100S1S100S-1" + "'", str2.equals("1S10S100S1S100S-1"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "          0.79a0.1          ", (java.lang.CharSequence) "35#100#100#-1#31                      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.0 0.0 0.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.14.310.14.310.14PlatformAPISpecif");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0a0.0a0.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              " + "'", str2.equals("x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              "));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("UTF-8", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString(" Ho..avaJ", "r");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Ho..avaJ" + "'", str2.equals(" Ho..avaJ"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.2", "PlatformAPISpecif");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Eihpos/sresU/", 72, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaEihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaEihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("ts4j/tmp/run_randoop.pl_50283_1560277096", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1", (java.lang.CharSequence) " 4#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("0.0410.0", "", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0410.00.0410.0" + "'", str3.equals("0.0410.00.0410.0"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("10.14.310.14.310.14PlatformAPISpecif", "1.0#97.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.310.14.310.14PlatformAPISpecif" + "'", str2.equals("10.14.310.14.310.14PlatformAPISpecif"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a" + "'", str3.equals("a"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "en", (java.lang.CharSequence) "10#-1#-1#10#100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "java Platform API Specification", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMEN", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 94, (float) 3, (float) 52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 94.0f + "'", float3 == 94.0f);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("-1.0", "r", "10a1", 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0" + "'", str4.equals("-1.0"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "ificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("35a100a100a-1a31", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31" + "'", str2.equals("35a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8utf-8utf-8utf-8utf-8utf-8utf-8utf-8" + "'", str1.equals("8utf-8utf-8utf-8utf-8utf-8utf-8utf-8"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "10.0#-1.0#10.0", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Platform API Specification", (java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ", (java.lang.CharSequence) "Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEh/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEi/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEe/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 392 + "'", int2 == 392);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("0.0#10.0", "1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04", "class [Ljava.lang.String;");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Java Ho..", "       sOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Ho.." + "'", str2.equals("Java Ho.."));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java Ho..", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.awt.CGraphicsEnvironment", "######################################################################sun.lwawt.macosx.LWCToolkit", "10#-1#-1#10#100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str3.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("-x#0", 89);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                          -x#0                                           " + "'", str2.equals("                                          -x#0                                           "));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.0#97.", "PlatformAPISpecif");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#97." + "'", str2.equals("1.0#97."));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase(" ##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " ##" + "'", str1.equals(" ##"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", "-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096" + "'", str2.equals("users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", (java.lang.CharSequence) "Sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.0a0.0a0.0", "mixed mode", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.awt.CGraphicsEnvironment", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#0" + "'", str1.equals("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#0"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaPlatformAPISpecification" + "'", str1.equals("javaPlatformAPISpecification"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java Platform API Specification" + "'", str1.equals("java Platform API Specification"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.4", "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-1a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "   1.6    ", (java.lang.CharSequence) "a#4# # # #4", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("I");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "35#100#100#-1#31", (java.lang.CharSequence) "sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("///////////////////", 61, "a444 4 4 44");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4" + "'", str3.equals("a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "-1#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "PlatformAPISpecif", (java.lang.CharSequence) "   Hi!    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                            ", 0, 19);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                   " + "'", str3.equals("                   "));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04", (float) 1410040410L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.41004045E9f + "'", float2 == 1.41004045E9f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.6", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4", "1 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4" + "'", str2.equals("a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 32, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 56, (double) 72, (double) 61);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 72.0d + "'", double3 == 72.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "sun.lwawt.maco", 61);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0" + "'", str1.equals("-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Platform API Specification", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaEihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Platform API Specification" + "'", str2.equals("Platform API Specification"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                 ", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(" Ho..avaJ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1A10A100A1A100A-1", "class [Ljava.lang.String;");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("-x#0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.0 97.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 97." + "'", str1.equals("1.0 97."));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "   1.6    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("#a4a4                                              ", "sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a4a4                                              " + "'", str2.equals("#a4a4                                              "));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "       sOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "###############################");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                          -x#0                                           ", "1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80", 13, (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "             1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80" + "'", str4.equals("             1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "PLATFORMAPISPECIF", (java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "PLATFORMAPISPECIF" + "'", charSequence2.equals("PLATFORMAPISPECIF"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("PLATFORMAPISPECIF");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "platformapispecif" + "'", str1.equals("platformapispecif"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("1.", "class [Ljava.l...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }
}

