import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test001");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "   1.0 97.", (java.lang.CharSequence) "0.0a10.", 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 392);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test003");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "13a1-a0...", 61, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test004");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("       Sophie", "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0", "...                   46_68x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       Sophie" + "'", str3.equals("       Sophie"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test005");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1", ":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test006");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) '4', 0);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "141041004141004-1" + "'", str11.equals("141041004141004-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1#10#100#1#100#-1" + "'", str13.equals("1#10#100#1#100#-1"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test007");
        char[] charArray5 = new char[] { ' ', '#' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 0, (int) (short) -1);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray5);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", charArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray5, '4');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ":", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " ##" + "'", str13.equals(" ##"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + " 4#" + "'", str15.equals(" 4#"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test008");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-x#0", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JA...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test009");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 10, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test010");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JavaPlatformAPISpecification", 3, 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                            1a01                                           ", "x86_64                   ...x86_64              10a1x86_64                   ...x86_64              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                            1a01                                           " + "'", str2.equals("                                            1a01                                           "));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test012");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "##############################444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test013");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "######################################################################sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0", 2748);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test014");
        java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("6");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1.equals(6));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test015");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "10 2 17 28 0", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test016");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                     1.8                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test017");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("EN", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 76);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test018");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test019");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "          0.79A0.1          ", charSequence1, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test020");
        char[] charArray10 = new char[] { 'a', '4', 'a', '4', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.2", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.79a0.1", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "141041004141004-1", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "en", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test021");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1 1 52 2 0 4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test022");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("class [ljava.lang.string;", "/r/ar/aar/r/aar-/", "          ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test023");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "pLATFORM api sPECIFICATION" + "'", str1.equals("pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                   4444444444444                    ", "1.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                   4444444444444                    " + "'", str2.equals("                   4444444444444                    "));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test025");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                            #################################");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test026");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test027");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "A4A4", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.LWCToolkit", "6");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test029");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("mixed mod                                                                                                 ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test030");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "NTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test031");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("0.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0410.0" + "'", str1.equals("0.0410.0"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test032");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.0a0.0a0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("0140400141/Jntents/Home/jre/lib/endorse", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e/lib/endorse" + "'", str2.equals("e/lib/endorse"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test034");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a", "                                            hO..AVAj", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-" + "'", str1.equals("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test036");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8" + "'", str1.equals("/r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test038");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus" + "'", str1.equals("4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test039");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Mac OS ", "platformapispecif");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test041");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test042");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/80", (java.lang.CharSequence) "0.01#0.AmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test043");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaats4j/tmp/run_randoop.pl_50283_1560277096aaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test044");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1a10a100a1a100a-", "Sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test045");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.0 9", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test046");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test047");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test048");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "0.0#14.0#38.0#10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test049");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1, 28L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test050");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Platform API Specificatio", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test051");
        char[] charArray8 = new char[] { 'a', '4', ' ', ' ', ' ', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.maco", charArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, '#', (int) '#', 17);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaa", " ", 70);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa" + "'", str3.equals("aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test053");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("a 4       4");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test054");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JA...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test055");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "a1a001a01a11a011-a001a1a001a01a11a0", (java.lang.CharSequence) "       sOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Platform API Specif", "                                                                                                    ", 4444);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Platform API Specif" + "'", str3.equals("Platform API Specif"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                                             ", "1################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                             " + "'", str2.equals("                                                             "));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test058");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0.01#0.AmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalP");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0.01#0.AmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalP\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test059");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                            1a01                                           ", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", "1.81.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test061");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "0.0410.0-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test062");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("EN", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("-1#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#" + "'", str1.equals("-1#"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test064");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "ts4j/tMp/run_ranOXXp.pl_50283_1560277096", (java.lang.CharSequence) "1.0 97.", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 37 + "'", int3 == 37);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("JAVA HO...", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA HO..." + "'", str2.equals("JAVA HO..."));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test066");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("PlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformA.0#10.0", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test067");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "10 2 17 28 0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test068");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("10#-1#-1#10#100", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test069");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(" 4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("35 100 100 -1 31", " hO..AVAj hO..AVAj hO..AVAj hO..              hO..AVAj hO..AVAj hO..AVAj hO..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35 100 100 -1 31" + "'", str2.equals("35 100 100 -1 31"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test071");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "                                               4a4a#", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test072");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "13.0#32.0#32.0#52.0#8.0", (java.lang.CharSequence) "                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test073");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test074");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.04", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a", "0.0#10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test076");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("0140400141/Jntents/Home/jre/lib/endorse", "jAVApLATFORMapisPECI/Users/sophi", 0, 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "jAVApLATFORMapisPECI/Users/sophi0141/Jntents/Home/jre/lib/endorse" + "'", str4.equals("jAVApLATFORMapisPECI/Users/sophi0141/Jntents/Home/jre/lib/endorse"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test077");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Library/Jntents/Home/jre/lib/endorsed###########################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test078");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "java Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test079");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Jntents/Home/jre/lib/endorsed", "");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "http://java.oracle.com/");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 100, 16);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Library/Jntents/Home/jre/lib/endorsed" + "'", str6.equals("/Library/Jntents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test080");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu", 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test081");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "AAAAAAAAAA", 392);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Mac OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS" + "'", str1.equals("Mac OS"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/USERS/SOPHI", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHI" + "'", str3.equals("/USERS/SOPHI"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test084");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-140                                                                                                ", (java.lang.CharSequence) "141452424044", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test085");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Platform35#   #   #  #3 API35#   #   #  #3 Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.8", 72);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                  1.8                                   " + "'", str2.equals("                                  1.8                                   "));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test087");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "10a-1a-1a10a100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("#################################ts4j/tMp/run_ranOXXp.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "6907720651_38205_lp.pXXOnar_nur/pMt/j4st#################################" + "'", str1.equals("6907720651_38205_lp.pXXOnar_nur/pMt/j4st#################################"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test089");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "44444 ##444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test090");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Platform35#   #   #  #3 API35#   #   #  #3 Specification", "             Hi!             ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test092");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("             Hi!             ", "Mac OS", 76);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test093");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80");
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitx86_64                                                                                              ", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("2 10", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2 10" + "'", str2.equals("2 10"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test097");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.0#97.", (java.lang.CharSequence) "       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test098");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "141452424044", (java.lang.CharSequence) "1 10 100 1 100 -1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test099");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4# 46_68xtiklooTCWL.xsocam.twawl.nus" + "'", str1.equals("4# 46_68xtiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;" + "'", str1.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa", 74, 1790);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa" + "'", str3.equals("aa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test102");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test103");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#########################################################a4a4", (java.lang.CharSequence) "/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test104");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaeihpos/sresu/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "10.14.3", "a444 4 4 44");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test105");
        char[] charArray8 = new char[] { ' ', '#' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', 0, (int) (short) -1);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "class [Ljava.lang.String;", charArray8);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray8);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "31410428410", charArray8);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + " 4#" + "'", str20.equals(" 4#"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test106");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1a100a0a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test107");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.platformapispecif");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test108");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "35a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31", (java.lang.CharSequence) "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test109");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test110");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "...0a-1a31");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37 + "'", int2 == 37);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test111");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("PlatformAPISpecif", "JavaPlatformAPISpecification", "r-/80ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/_/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/0/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/7/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/1/r/ar/r/ar/a             /r/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a-/r/ar/0r-/SOPr" + "'", str3.equals("0a-/r/ar/0r-/SOPr"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.81.2", 39, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test113");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("  1.", (long) 1586);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1586L + "'", long2 == 1586L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test114");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) ".41.01");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4aaa4a4", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaa" + "'", str2.equals("aaaa"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test116");
        long[] longArray5 = new long[] { '#', 100L, 100, (byte) -1, 31 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ', (int) (short) -1, (int) (byte) -1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray5, '4', 36, (int) (byte) 0);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "35a100a100a-1a31" + "'", str7.equals("35a100a100a-1a31"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("\n", "Sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("a444a4444", "10 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a444a4444" + "'", str2.equals("a444a4444"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test119");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("             1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80", "CLASS [LJAVA.LANG.STRING;", "  #################################");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test120");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("4# 46_68xtiklooTCWL.xsocam.twawl.nus", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test121");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "51.051.0                                                                                   ", (java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test122");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0", "Platform35#100#100#-1#31API35#100#100#-1#31Specification", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test123");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 8, (int) (byte) -1);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', 73, 17);
        byte byte21 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) -1 + "'", byte16 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + byte21 + "' != '" + (byte) -1 + "'", byte21 == (byte) -1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test124");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("-1.0410.041.04-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test125");
        double[] doubleArray1 = new double[] { (byte) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0" + "'", str6.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0" + "'", str8.equals("1.0"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test126");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("   1.6    ", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.platformapispecif");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.platformapispecif" + "'", str2.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.platformapispecif"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test128");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "10.14.", (java.lang.CharSequence) "444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test129");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "31410428410");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test130");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "##########################                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter(".0#10.0", "hO..AVAj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test132");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444", 35, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test133");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 50, 0.0f, (float) 397);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                           " + "'", str1.equals("                                                                                           "));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test135");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test136");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 32L, (float) 32);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test137");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4', 50, 56);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 50");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1#0" + "'", str8.equals("-1#0"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test138");
        java.lang.Object[] objArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(objArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test140");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test141");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) ":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("10", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test143");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test144");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "A100A-", (java.lang.CharSequence) "                                           10#32#1#32                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test145");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("46_68X");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) ".0#10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("       sOPHIE", 94, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       sOPHIE#################################################################################" + "'", str3.equals("       sOPHIE#################################################################################"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test148");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "#a4a4                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test149");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("JAVApLATFORMapisPECI/Users/sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVApLATFORMapisPECI/Users/sophi" + "'", str1.equals("JAVApLATFORMapisPECI/Users/sophi"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test150");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) " 4 a 4 4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test151");
        char[] charArray9 = new char[] { 'a', '4', 'a', '4', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophi", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ts4j/tmp/run_randoop.pl_50283_1560277096", charArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "aa4aaa4a4" + "'", str15.equals("aa4aaa4a4"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(" Ho..avaJ", 74);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                  Ho..avaJ" + "'", str2.equals("                                                                  Ho..avaJ"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test153");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "java Platform API Specification", (java.lang.CharSequence) "1.0#0.0#0.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test154");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                   4444444444444                    ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test155");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1a10a100a1a100a-1", ":", 100);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1a10a100a1a100a-1" + "'", str8.equals("1a10a100a1a100a-1"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("j#v# Pl#tform API Specific#tion", 0, 20);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "j#v# Pl#tform API Sp" + "'", str3.equals("j#v# Pl#tform API Sp"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test157");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test158");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 20, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 20L + "'", long3 == 20L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test159");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test160");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, charSequence1, 134);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest9.test161");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
//        boolean boolean5 = javaVersion2.atLeast(javaVersion3);
//        boolean boolean6 = javaVersion0.atLeast(javaVersion2);
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean9 = javaVersion0.atLeast(javaVersion8);
//        java.lang.String str10 = javaVersion8.toString();
//        java.lang.String str11 = javaVersion8.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
//        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion17);
//        boolean boolean19 = javaVersion16.atLeast(javaVersion17);
//        boolean boolean20 = javaVersion14.atLeast(javaVersion16);
//        boolean boolean21 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
//        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean23 = javaVersion14.atLeast(javaVersion22);
//        boolean boolean24 = javaVersion12.atLeast(javaVersion22);
//        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str26 = javaVersion25.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion27 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean28 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion27);
//        org.apache.commons.lang3.JavaVersion javaVersion29 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean30 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion29);
//        org.apache.commons.lang3.JavaVersion javaVersion31 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion32 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean33 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion32);
//        boolean boolean34 = javaVersion31.atLeast(javaVersion32);
//        boolean boolean35 = javaVersion29.atLeast(javaVersion31);
//        boolean boolean36 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion29);
//        org.apache.commons.lang3.JavaVersion javaVersion37 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean38 = javaVersion29.atLeast(javaVersion37);
//        boolean boolean39 = javaVersion27.atLeast(javaVersion37);
//        boolean boolean40 = javaVersion25.atLeast(javaVersion27);
//        boolean boolean41 = javaVersion12.atLeast(javaVersion25);
//        boolean boolean42 = javaVersion8.atLeast(javaVersion12);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.5" + "'", str10.equals("1.5"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.5" + "'", str11.equals("1.5"));
//        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1.8" + "'", str26.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion27 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion27.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion29 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion29.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion31 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion31.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion32 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion32.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion37 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion37.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test162");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("  #################################", strArray2, strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "  #################################" + "'", str4.equals("  #################################"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test163");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 77);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test164");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1 0", "Sophie");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "444444444444444440.1-#0.1#0.01#0.1-", 5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("444444444444444444444444444444444444444444444444444444444444444444444444", strArray3, strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str8.equals("444444444444444444444444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("...0a-1a31", 17, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       ...0a-1a31" + "'", str3.equals("       ...0a-1a31"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.0 0.0 0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 0.0 0.0" + "'", str1.equals("1.0 0.0 0.0"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test167");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 760, (float) 1790, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1790.0f + "'", float3 == 1790.0f);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test168");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.04", (java.lang.CharSequence) "cLASS [LJAVA.LANG.STRING;");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test169");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                           10#32#1#32                                            ", (java.lang.CharSequence) "   Hi!    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test170");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "mixed mod                                                                                                 ", (java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test171");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test173");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', 14, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 14");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("SUN.AWT.cgRAPHICSeNVIRONMEN");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMEN" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMEN"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test175");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger(".41.01");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".41.01\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test176");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 2, (float) 76, 1790.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1790.0f + "'", float3 == 1790.0f);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("10", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test178");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) 10, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10 -1 -1 10 100" + "'", str8.equals("10 -1 -1 10 100"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test179");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "10.0#-1.0#10.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test180");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test182");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "141041004141004-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test184");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4', 1410040410, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test186");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0.0a14.0a38.0a10.0", "          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0a14.0a38.0a10.0" + "'", str3.equals("0.0a14.0a38.0a10.0"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test187");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "class [Ljava.lang.String;", " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1#10#100#1#100#-1", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1101001100-1" + "'", str2.equals("1101001100-1"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test189");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("0.0a10.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("              eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", 98, "java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "              eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str3.equals("              eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "51.051.0                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 68, "4# 46_68xtiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4# 46_68x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/4# 46_68xt" + "'", str3.equals("4# 46_68x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/4# 46_68xt"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test193");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test195");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification", (java.lang.CharSequence) "1S10S100S1S100S-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                        1410040410", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                        1410040410" + "'", str2.equals("                                        1410040410"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1043241432", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1043241432" + "'", str2.equals("1043241432"));
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest9.test199");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
//        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
//        boolean boolean8 = javaVersion2.atLeast(javaVersion4);
//        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean11 = javaVersion2.atLeast(javaVersion10);
//        boolean boolean12 = javaVersion0.atLeast(javaVersion10);
//        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test200");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "0a11a10a100a1a100a-110a11a10a100a1a", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test201");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("NEMNORIVNeSCIHPARgc.TWA.NUS                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "nEMNORIVNeSCIHPARgc.TWA.NUS                                                              " + "'", str1.equals("nEMNORIVNeSCIHPARgc.TWA.NUS                                                              "));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test202");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 0, (double) 72, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test203");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java H", (java.lang.CharSequence) "X86_6", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test204");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "US", charSequence1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test205");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification", "                                                             ", "pLATFORM api sPECIFICATION", 34);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification" + "'", str4.equals("Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test206");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 10, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test207");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                          hi!");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test208");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "0.0a10.", (java.lang.CharSequence) "4444444444", 397);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test209");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test210");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...0a-1a31", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.7.0_80-b15", "   10#-1#-1#10#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".7.0_80-b15" + "'", str2.equals(".7.0_80-b15"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.097.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-10" + "'", str2.equals("1.097.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-10"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("   1.6    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test214");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test215");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.", charSequence1, 1410040410);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test216");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#a4a4", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) " ##", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test217");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 19L, (float) 29, (float) 623);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 623.0f + "'", float3 == 623.0f);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("444444444444444440.1-#0.1#0.01#0.1-", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444440.1-#0.1#0.01#0.1-" + "'", str2.equals("444444444444444440.1-#0.1#0.01#0.1-"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test219");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 29.0f, 1790.0d, 97.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 29.0d + "'", double3 == 29.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.ja", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test221");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 16.0f, (double) 61, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 61.0d + "'", double3 == 61.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test222");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("...                   46_68x");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test223");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("A100A-1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test224");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', (int) (short) 10, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.Class<?> wildcardClass11 = shortArray2.getClass();
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1#0" + "'", str10.equals("-1#0"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-140" + "'", str14.equals("-140"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test225");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "NEMNORIVNeSCIHPARgc.TWA.NUS ", 10, 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("###############################aaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############################aaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("###############################aaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test227");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2434 + "'", int1 == 2434);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus", "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus" + "'", str2.equals("                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", 42148, '4');
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test230");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                               ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test232");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.5aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test233");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Ho...", " hO..AVAj hO..AVAj hO..AVAj hO..              hO..AVAj hO..AVAj hO..AVAj hO..", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test234");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaJava(TM) SE Runtime EnvironmentaJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test235");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("class [Ljava.l...", (int) '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##################class [Ljava.l..." + "'", str3.equals("##################class [Ljava.l..."));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test236");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, 36, 38);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 38 + "'", int3 == 38);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test237");
        char[] charArray9 = new char[] { 'a', '4', 'a', '4', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.2", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.79a0.1", charArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "a", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "a 4 a 4 4" + "'", str14.equals("a 4 a 4 4"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test238");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                            1a01                                           ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                            1a01                                           \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test239");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.8");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test240");
        char[] charArray6 = new char[] { ' ', '#' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', 0, (int) (short) -1);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", charArray6);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API Specification", charArray6);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.0410.0", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("-140                                                                                                ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-140                                                                                                " + "'", str2.equals("-140                                                                                                "));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test242");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0.1-NTENTS/HOME/JRE/LIB/ENDORS0.1-#", (java.lang.CharSequence) "x86_64                                                                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("10#-1#-1#10#100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#-1#-1#10#100" + "'", str2.equals("10#-1#-1#10#100"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                            #################################", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################" + "'", str2.equals("#################################"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test245");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                            #################################", (java.lang.CharSequence) "Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096" + "'", str2.equals("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test247");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(".0#10.0", "Java4Platform4API4Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test248");
        long[] longArray5 = new long[] { '#', 100L, 100, (byte) -1, 31 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ', 1790, 8);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "35a100a100a-1a31" + "'", str7.equals("35a100a100a-1a31"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35#100#100#-1#31" + "'", str9.equals("35#100#100#-1#31"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test249");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a', 77, 91);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test252");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("0140400141/Jntents/Home/jre/lib/endorse");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"140400141/Jntents/Home/jre/lib/endorse\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test253");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, " Ho..avaJ", 0, 1790);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test254");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ts4j/tmp/run_randoop.pl_50283_1560277096                                    ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test255");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "### hO..AVAj####", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("       sOPHIE", "                                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       sOPHIE" + "'", str2.equals("       sOPHIE"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test257");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0a0.0a0.0", "x86_", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test258");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("HI!", "##########################                              ", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test259");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                        1410040410", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                        1410040410" + "'", str2.equals("                                        1410040410"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test261");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("\n", "1#10#100#1#100#-1");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.2", strArray5, strArray10);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1#10#100#1#100#-1", strArray10, strArray14);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray14);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "-1.0", (java.lang.CharSequence[]) strArray14);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "\n" + "'", str6.equals("\n"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.2" + "'", str11.equals("1.2"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1#10#100#1#100#-1" + "'", str16.equals("1#10#100#1#100#-1"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test262");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("4444", "a 4       4", 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444" + "'", str3.equals("4444"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test263");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("13", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-10", 72, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test265");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "  #################################", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test266");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", (java.lang.CharSequence) "ts4j/tmp/run_randoop.pl_50283_1560277096", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test267");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test268");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus", (java.lang.CharSequence) "###############################", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test269");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test270");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1aaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test271");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1 10 100 1 100 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test272");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test273");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              ", (long) 73);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 73L + "'", long2 == 73L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test274");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("##################", "Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test275");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.Class<?> wildcardClass8 = byteArray6.getClass();
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "141041004141004-1" + "'", str11.equals("141041004141004-1"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test276");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test277");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 97, 0.0f, (float) 19L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test278");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', (int) '4', (int) ' ');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test279");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', (int) (short) 10, 0);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 34, 39);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 34");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a0" + "'", str8.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-140" + "'", str11.equals("-140"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test280");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test281");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("0.0a10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0a10.0" + "'", str1.equals("0.0a10.0"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test282");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test283");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("JAVApLATFORMapisPECI/Users/soph");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVAPLATFORMAPISPECI/USERS/SOPH" + "'", str1.equals("JAVAPLATFORMAPISPECI/USERS/SOPH"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test285");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "X86_64", "141452424044", 73);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test286");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(98L, 0L, (long) 134);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test287");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.maco", "Java Ho..", 1586);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test288");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test289");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "", "13a1-a0...", 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test290");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "   1.6    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test291");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate(".7.0_80-b15", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "aa4aaa4a4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1410040410", "javaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1410040410" + "'", str2.equals("1410040410"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test294");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "a 4 a 4 4", (java.lang.CharSequence) "                                  1.8                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("              Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/Users/sophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("              Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sun.awt.CGraphicsEnvironment", "             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test297");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                   4444444444444                    ", "1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04", "/Library/Jntents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                   4444444444444                    " + "'", str3.equals("                   4444444444444                    "));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Eihpos/sresU/NEihpos/sresU/TEihpos/sresU/EEihpos/sresU/NEihpos/sresU/TEihpos/sresU/SEihpos/sresU//Eihpos/sresU/HEihpos/sresU/OEihpos/sresU/MEihpos/sresU/EEihpos/sresU//Eihpos/sresU/JEihpos/sresU/REihpos/sresU/EEihpos/sresU//Eihpos/sresU/LEihpos/sresU/IEihpos/sresU/BEihpos/sresU//Eihpos/sresU/EEihpos/sresU/NEihpos/sresU/DEihpos/sresU/OEihpos/sresU/REihpos/sresU/SEihpos/sresU/EEihpos/sresU/", "", "                                  1.8                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Eihpos/sresU/NEihpos/sresU/TEihpos/sresU/EEihpos/sresU/NEihpos/sresU/TEihpos/sresU/SEihpos/sresU//Eihpos/sresU/HEihpos/sresU/OEihpos/sresU/MEihpos/sresU/EEihpos/sresU//Eihpos/sresU/JEihpos/sresU/REihpos/sresU/EEihpos/sresU//Eihpos/sresU/LEihpos/sresU/IEihpos/sresU/BEihpos/sresU//Eihpos/sresU/EEihpos/sresU/NEihpos/sresU/DEihpos/sresU/OEihpos/sresU/REihpos/sresU/SEihpos/sresU/EEihpos/sresU/" + "'", str3.equals("Eihpos/sresU/NEihpos/sresU/TEihpos/sresU/EEihpos/sresU/NEihpos/sresU/TEihpos/sresU/SEihpos/sresU//Eihpos/sresU/HEihpos/sresU/OEihpos/sresU/MEihpos/sresU/EEihpos/sresU//Eihpos/sresU/JEihpos/sresU/REihpos/sresU/EEihpos/sresU//Eihpos/sresU/LEihpos/sresU/IEihpos/sresU/BEihpos/sresU//Eihpos/sresU/EEihpos/sresU/NEihpos/sresU/DEihpos/sresU/OEihpos/sresU/REihpos/sresU/SEihpos/sresU/EEihpos/sresU/"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test299");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Platform API Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test300");
        float[] floatArray2 = new float[] { (short) 1, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a97.0" + "'", str4.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0 97.0" + "'", str6.equals("1.0 97.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0a97.0" + "'", str8.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0a97.0" + "'", str10.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1 0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1 0" + "'", str1.equals("1 0"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                                             aa4aaa4a4", (java.lang.CharSequence) "O...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test303");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04" + "'", str1.equals("1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "J4v4 Pl4tform API Specific4tion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("#a4a4", "R");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a4a4" + "'", str2.equals("#a4a4"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test306");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test307");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.awt.CGraphicsEnvironmen", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("java virtual machine specification", "platformapispecif");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java virtual machine specification" + "'", str2.equals("java virtual machine specification"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test309");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Platform API Specif", (java.lang.CharSequence) "Mac OS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1101001100-1", "a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4", 39);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1101001100-1" + "'", str3.equals("1101001100-1"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("   Hi!    ", 2748, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   Hi!    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   Hi!    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("S", 42148);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java(TM) SE Runtime Environment", "Mac OS ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("PLATFORMAPISPECIF", 3, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PLATFORMAPISPECIF" + "'", str3.equals("PLATFORMAPISPECIF"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test316");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(".7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test317");
        long[] longArray1 = new long[] { 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.Class<?> wildcardClass3 = longArray1.getClass();
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 2434, 5);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test318");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                           10#32#1#32                                            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test319");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test320");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEh/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEi/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEe/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 4, "a4a4                                              ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a4a4" + "'", str3.equals("a4a4"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test322");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaeihpos/sresu/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test323");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test324");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("en                             ", "j#v# Pl#tform API Specific#tion");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test325");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "#A4A4", (java.lang.CharSequence) "/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test326");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                   ", (java.lang.CharSequence) "platformapispecif");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("e/lib/endorse", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e/lib/endorse" + "'", str2.equals("e/lib/endorse"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test328");
        char[] charArray9 = new char[] { 'a', '4', 'a', '4', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.2", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "eihpos/sresU/", charArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophi", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "a444a4444" + "'", str14.equals("a444a4444"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("0#0.0#0.0", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#0.0#0.0" + "'", str2.equals("0#0.0#0.0"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   ", "#a4a4                                               ", "                              ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   " + "'", str3.equals("          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   "));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test331");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444440.79a0.1", "4444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test332");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                                                                                                                                                                                                                                                                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (short) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("A100A-", 1586, 89);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "A100A-" + "'", str3.equals("A100A-"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test334");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', (int) (short) 10, 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a0" + "'", str8.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-140" + "'", str11.equals("-140"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-1 0" + "'", str18.equals("-1 0"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("51.051.0                                                                                   ", 36);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.051.0                                                                                   " + "'", str2.equals("51.051.0                                                                                   "));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test336");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "x86_64                                                                                              ", (java.lang.CharSequence) "Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre", 2434);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test337");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test338");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10a32a1a32", (java.lang.CharSequence) "ts4j/tmp/run_randoop.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test339");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "X86_6X86_6", (java.lang.CharSequence) "java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("       Sophie", "...0-131");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       Sophie" + "'", str2.equals("       Sophie"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test341");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1a10a100a1a100a-1", ":", 100);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "0#0.0#0.0");
        java.lang.String[] strArray10 = null;
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Aaaaaaaaaaa10a32a1a32aaaaaaaaaaa", strArray5, strArray10);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Aaaaaaaaaaa10a32a1a32aaaaaaaaaaa" + "'", str11.equals("Aaaaaaaaaaa10a32a1a32aaaaaaaaaaa"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", 36);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE" + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test343");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("##########################                              ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test344");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   ", (java.lang.CharSequence) "Eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("4aaa4a4", "       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4aaa4a4" + "'", str2.equals("4aaa4a4"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test346");
        char[] charArray8 = new char[] { 'a', '4', ' ', ' ', ' ', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!", charArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                    ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a#4# # # #4" + "'", str11.equals("a#4# # # #4"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "a444 4 4 44" + "'", str13.equals("a444 4 4 44"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "a444 4 4 44" + "'", str15.equals("a444 4 4 44"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("class [Lja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Lj" + "'", str1.equals("class [Lj"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test348");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray9 = new char[] { 'a', '4', ' ', ' ', ' ', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!", charArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray9);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/USERS/SOPHI", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "a#4# # # #4" + "'", str12.equals("a#4# # # #4"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "a444 4 4 44" + "'", str14.equals("a444 4 4 44"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a444 4 4 44" + "'", str16.equals("a444 4 4 44"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "S");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test350");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test351");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("51.051.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test352");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1", 16, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1" + "'", str1.equals("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test355");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test356");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre", 391, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test357");
        long[] longArray2 = new long[] { (short) 1, (byte) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', (int) '4', (int) (short) 1);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a', 392, 52);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test358");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0.0410.0-1", (java.lang.CharSequence) "1.0#97.0", 623);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8", "1.0#97.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("javaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaPlatformAPISpecification" + "'", str1.equals("javaPlatformAPISpecification"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test361");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", "x86_64                                                                                              ", "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!", 760);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Sophie", "35#1   Hi!    35#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sophie" + "'", str2.equals("Sophie"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("aa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa" + "'", str1.equals("aa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Library/Jntents/Home/jre/lib/endorsed###########################################################", "#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Jntents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Jntents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test365");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("              1 / u SERS / SOPHIE ./ u SERS / SOPHIE 7 / u SERS / SOPHIE ./ u SERS / SOPHIE 0 / u SERS / SOPHIE _ / u SERS / SOPHIE 80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1 / u SERS / SOPHIE ./ u SERS / SOPHIE 7 / u SERS / SOPHIE ./ u SERS / SOPHIE 0 / u SERS / SOPHIE _ / u SERS / SOPHIE 80" + "'", str1.equals("1 / u SERS / SOPHIE ./ u SERS / SOPHIE 7 / u SERS / SOPHIE ./ u SERS / SOPHIE 0 / u SERS / SOPHIE _ / u SERS / SOPHIE 80"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test367");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "PlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformA.0#10.0", (java.lang.CharSequence) " 4 a 4 4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("       Sophie", "1 / u SERS / SOPHIE ./ u SERS / SOPHIE 7 / u SERS / SOPHIE ./ u SERS / SOPHIE 0 / u SERS / SOPHIE _ / u SERS / SOPHIE 80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test369");
        char[] charArray9 = new char[] { 'a', '4', 'a', '4', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.2", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.79a0.1", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "           X86_6", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/..." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/..."));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jar", 4);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test372");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("8utf-8utf-8utf-8utf-8utf-8utf-8utf-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8utf-8utf-8utf-8utf-8utf-8utf-8utf-8" + "'", str1.equals("8utf-8utf-8utf-8utf-8utf-8utf-8utf-8"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Ho..ava");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ho..ava" + "'", str1.equals("Ho..ava"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test375");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) '#', 31);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) -1 + "'", byte16 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 100 + "'", byte17 == (byte) 100);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test376");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "I", (java.lang.CharSequence) "                                                   java Platform API Specification                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test377");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 89, 2432);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 89");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10#32#1#32" + "'", str7.equals("10#32#1#32"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10#32#1#32" + "'", str9.equals("10#32#1#32"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test378");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "CLASS [LJAVA.LANG.STRING;", (java.lang.CharSequence) "a444a4444", 39);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test379");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) ":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.0#0.0#0.0", "10#32#1#32");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#0.0#0.0" + "'", str2.equals("1.0#0.0#0.0"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test382");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                                                 ", (java.lang.CharSequence) "       ...0a-1a31", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test383");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', 32, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(" hO..AVAj hO..AVAj hO..AVAj hO..              hO..AVAj hO..AVAj hO..AVAj hO..", "0.0a10.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " hO..AVAj hO..AVAj hO..AVAj hO..              hO..AVAj hO..AVAj hO..AVAj hO.." + "'", str2.equals(" hO..AVAj hO..AVAj hO..AVAj hO..              hO..AVAj hO..AVAj hO..AVAj hO.."));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test385");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "  ", (java.lang.CharSequence) "X0.0a10.0X", 397);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test386");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:" + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("10.0#-1.0#10.0", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#-1.0#10.0" + "'", str2.equals("#-1.0#10.0"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test388");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.097.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-10", (java.lang.CharSequence) "Hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test389");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "  1.", "phie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test390");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("\n", '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                          -x#0                                           ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\n" + "'", str4.equals("\n"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test393");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("         I");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test394");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "4# 46_68xtiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(" ##", "             1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " ##" + "'", str2.equals(" ##"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test396");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "0.0a14.0a38.0a10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("  ", 2434);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  "));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test398");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 4, (long) 10, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test399");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/r/ar/aar/r/aar-/", charSequence1, 77);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test400");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "         I", (java.lang.CharSequence) "1.81.2", 1586);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test401");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 61, 76);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 76 + "'", int3 == 76);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test402");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1a100a0a10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test403");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split(" 4#");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("#", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 25 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.0a0.0a0.0", "/-raa/r/raa/ra/r/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test406");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 4, (long) 4444, (long) 91);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4444L + "'", long3 == 4444L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 91);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test408");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS", "###############################aaaaaaaaaaaaaaaaaaaaa", 16);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                               4a4a#", "/Library/Jntents/Home/jre/lib/endorsed###########################################################", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                               4a4a#" + "'", str3.equals("                                               4a4a#"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.ja", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jaJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.ja" + "'", str2.equals("JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jaJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.ja"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test411");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("...                   46_68x", 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "a#4#a#4#4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.81.81.81.81.8", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.81.81.81.81.8" + "'", str3.equals("1.81.81.81.81.8"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "31a10a28a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test415");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1a10a100a1a100a-", "10a1", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test416");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEh/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEi/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEe/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test417");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "4# 46_68x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/4# 46_68xt");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("#########################################################a4a4", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########################################################a4a4" + "'", str3.equals("#########################################################a4a4"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test419");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                            #################################", "  #################################", 760);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("0.0a1410034.4034.4.014.4003300031", "###############################4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0a1410034.4034.4.014.4003300031" + "'", str2.equals("0.0a1410034.4034.4.014.4003300031"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test421");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("NTENTS/HOME/JRE/LIB/ENDORS", "###############################4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4", (java.lang.CharSequence) "!iH");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test423");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "aa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa" + "'", str2.equals("aa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test425");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("10a32a1a32", 3, 4444);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a32a1a32" + "'", str3.equals("10a32a1a32"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410." + "'", str2.equals("0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410."));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test427");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ts4j/tMp/run_ranOXXp.pl_50283_1560277096", ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "              eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test428");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.097.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-10", 2432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test430");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 76, 0L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test431");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.097.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-10", (java.lang.CharSequence) "A100A-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test432");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4444444444444444444444440.79a0.14444444444444444441.0#0.0#0.0", (java.lang.CharSequence) "1", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test433");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ', 32, (int) '4');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test434");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1586, 5.0f, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test435");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test436");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "#a4a4     ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test437");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', (int) (short) 10, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 35, (int) (short) 1);
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short16 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1#0" + "'", str10.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) -1 + "'", short15 == (short) -1);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test438");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMEN", (java.lang.CharSequence) "ts4j/tmp/run_randoop.pl_50283_1560277096", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test439");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Mac OS ", (java.lang.CharSequence) "/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("a 4       4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a 4       4" + "'", str1.equals("a 4       4"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test441");
        float[] floatArray3 = new float[] { 28, 6, 10.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', 100, 70);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 28.0f + "'", float4 == 28.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.LWCToolkitx86_64                                                                                              ", 76, "0a-/r/ar/0r-/SOPr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkitx86_64                                                                                              " + "'", str3.equals("sun.lwawt.macosx.LWCToolkitx86_64                                                                                              "));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test443");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                             46_68xtiklooTCWL.xsocam.twawl.nus", "10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1aaaaaaaaaaaaaa", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test444");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0", (java.lang.CharSequence) "                                            #################################", 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test445");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                  Ho..avaJ", (java.lang.CharSequence) "                     Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test447");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Jntents/Home/jre/lib/endorsed", "");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "http://java.oracle.com/");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        java.lang.String[] strArray10 = null;
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Library/Jntents/Home/jre/lib/endorsed" + "'", str7.equals("/Library/Jntents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Library/Jntents/Home/jre/lib/endorsed" + "'", str9.equals("/Library/Jntents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("-1a", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31", "###############################4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test450");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a', 4444, 68);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test451");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ":", 4, 56);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test452");
        char[] charArray10 = new char[] { 'a', '4', 'a', '4', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.2", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.79a0.1", charArray10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "6", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10#-1#-1#10#100", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "a 4 a 4 4" + "'", str15.equals("a 4 a 4 4"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test453");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java Ho..");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Ho..\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test454");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("NEMNORIVNeSCIHPARgc.TWA.NUS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NEMNORIVNeSCIHPARgc.TWA.NUS" + "'", str1.equals("NEMNORIVNeSCIHPARgc.TWA.NUS"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test456");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("X86_64", "4444444444");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1S10S100S1S100S-1");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', 391, 98);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "                                               4a4a#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test458");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8", 1586);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 690 + "'", int3 == 690);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 34, 397);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test460");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1A10A100A1A100A-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("SUN.AWT.cgRAPHICSeNVIRONMEN", 623);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test462");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.0a97.0", "###################################################1 10 100 1 100 -1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test463");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils1 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils2 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils3 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils4 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray5 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0, numberUtils1, numberUtils2, numberUtils3, numberUtils4 };
        org.apache.commons.lang3.math.NumberUtils numberUtils6 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils7 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils8 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils9 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils10 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray11 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils6, numberUtils7, numberUtils8, numberUtils9, numberUtils10 };
        org.apache.commons.lang3.math.NumberUtils numberUtils12 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils13 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils14 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils15 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils16 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray17 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils12, numberUtils13, numberUtils14, numberUtils15, numberUtils16 };
        org.apache.commons.lang3.math.NumberUtils numberUtils18 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils19 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils20 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils21 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils22 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray23 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils18, numberUtils19, numberUtils20, numberUtils21, numberUtils22 };
        org.apache.commons.lang3.math.NumberUtils numberUtils24 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils25 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils26 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils27 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils28 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray29 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils24, numberUtils25, numberUtils26, numberUtils27, numberUtils28 };
        org.apache.commons.lang3.math.NumberUtils numberUtils30 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils31 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils32 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils33 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils34 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray35 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils30, numberUtils31, numberUtils32, numberUtils33, numberUtils34 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray36 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray5, numberUtilsArray11, numberUtilsArray17, numberUtilsArray23, numberUtilsArray29, numberUtilsArray35 };
        java.lang.String str37 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray36);
        org.junit.Assert.assertNotNull(numberUtilsArray5);
        org.junit.Assert.assertNotNull(numberUtilsArray11);
        org.junit.Assert.assertNotNull(numberUtilsArray17);
        org.junit.Assert.assertNotNull(numberUtilsArray23);
        org.junit.Assert.assertNotNull(numberUtilsArray29);
        org.junit.Assert.assertNotNull(numberUtilsArray35);
        org.junit.Assert.assertNotNull(numberUtilsArray36);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test465");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(31L, 19L, (long) 2434);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2434L + "'", long3 == 2434L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test466");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test467");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase(" ", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test469");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "a 4       4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("0.0#10.0", "mixedmod");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0#10.0" + "'", str2.equals("0.0#10.0"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test471");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("x86_64                   ...", (int) (byte) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64                   ..." + "'", str3.equals("x86_64                   ..."));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("          0.79a0.1          ", "       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          0.79a0.1          " + "'", str2.equals("          0.79a0.1          "));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1101001100-1", "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1101001100-1" + "'", str2.equals("1101001100-1"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test474");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "a", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test475");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "1.81.81.81.81.8");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 1586);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test477");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A", 100, "...0a-1a31");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...0a-1a31...0a-1a31...0a-1a31...0a-1a31...0a-1a4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A" + "'", str3.equals("...0a-1a31...0a-1a31...0a-1a31...0a-1a31...0a-1a4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("######################################################################sun.lwawt.macosx.LWCToolkit", "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######################################################################sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("######################################################################sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test479");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mac OS X", 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test480");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                   4444444444444                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                   4444444444444                    " + "'", str1.equals("                   4444444444444                    "));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test481");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10", (java.lang.CharSequence) "   10#-1#-1#10#100", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test482");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 56, 0.0f, 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("class [Lj", 73, "UTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-class [Lj" + "'", str3.equals("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-class [Lj"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test484");
        char[] charArray9 = new char[] { ' ', '#' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', 0, (int) (short) -1);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API Specification", charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "class [Ljava.lang.String;", charArray9);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray9);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "///////////////////", charArray9);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMEN", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("       sOPHIE#################################################################################", "...0a-1a31...0a-1a31...0a-1a31...0a-1a31...0a-1a4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       sOPHIE#################################################################################" + "'", str2.equals("       sOPHIE#################################################################################"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test486");
        long[] longArray4 = new long[] { 6, (short) 10, (-1L), 94 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', (int) ' ', 17);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 94L + "'", long10 == 94L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test487");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                            1a01                                           ", (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test488");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a0" + "'", str5.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a0" + "'", str7.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("r");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "r" + "'", str1.equals("r"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test490");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) " hO..AVAj hO..AVAj hO..AVAj hO..              hO..AVAj hO..AVAj hO..AVAj hO..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test491");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("       sOPHIE");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "#A4A4", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test492");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaa", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test493");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("a#4#a#4#4");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test494");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "                         ...");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-class [Lj", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test495");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaJava(TM) SE Runtime EnvironmentaJava Virtual Machine Specification", (java.lang.CharSequence) "                                           10#32#1#32                                            ", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(" 4 a 4 4", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 4 a 4 4" + "'", str2.equals(" 4 a 4 4"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test497");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', (int) '4', (int) ' ');
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        short short16 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1a0" + "'", str13.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1#0" + "'", str15.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test498");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.097.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-10", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test499");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "j#v# Pl#tform API Sp", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test500");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("35#1   Hi!    35#10", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35#1   Hi!    35#10" + "'", str3.equals("35#1   Hi!    35#10"));
    }
}

