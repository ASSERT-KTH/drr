import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0.79a0.1", 32, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444440.79a0.1" + "'", str3.equals("4444444444444444444444440.79a0.1"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("JAVA HO...", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA HO..." + "'", str3.equals("JAVA HO..."));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "##################", (java.lang.CharSequence) "         I", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("A100A-1", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A100A-1" + "'", str2.equals("A100A-1"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("class [Ljava.l...", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Lja" + "'", str2.equals("class [Lja"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("46_6", "         I", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1.7.0_80-b15");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "44444 ##444444", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 14 + "'", int6 == 14);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.", "Library/Jntents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("141041004141004-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "141041004141004-1" + "'", str1.equals("141041004141004-1"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.310.14.310.14PlatformAPISpecif", "1.", 17);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("2 10", 1410040410, 77);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        float[] floatArray1 = new float[] { (-1L) };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a', 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '4', 19, 1410040410);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a" + "'", str1.equals("sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", 76);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "1 0", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7.0_80", "a 4 a 4 4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 19, 2432);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 2, (float) 1L, (float) 6);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                           10a1                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 56, (double) 72L, (double) 0L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "46_68X", 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (long) 13);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13L + "'", long2 == 13L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        org.apache.commons.lang3.JavaVersion[] javaVersionArray0 = new org.apache.commons.lang3.JavaVersion[] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join((java.lang.Enum<org.apache.commons.lang3.JavaVersion>[]) javaVersionArray0);
        org.junit.Assert.assertNotNull(javaVersionArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.4", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("A100A-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("javaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("  1.", "-1a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  1." + "'", str2.equals("  1."));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("X86_6X86_6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"X86_6X86_6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace(" ######################################################################sun.lwawt.macosx.LWCToolkit  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "######################################################################sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("######################################################################sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "I", (java.lang.CharSequence) "35#100#100#-1#31");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.0#0.0#0.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", (java.lang.CharSequence) "  #", 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "  #", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("  1.", "35#1   Hi!    35#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35#1   Hi!    35#10" + "'", str2.equals("35#1   Hi!    35#10"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.0#97.0", (java.lang.CharSequence) "                                                                                           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a0" + "'", str5.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("vaPlatformAPISpecification", "35#100#100#-1#31");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vaPlatformAPISpecification" + "'", str2.equals("vaPlatformAPISpecification"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("a 4 a 4 4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A 4 a 4 4" + "'", str1.equals("A 4 a 4 4"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "CLASS [LJAVA.LANG.STRING;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("PlatformAPISpecif", 56);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56 + "'", int2 == 56);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                   ", 35, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                   " + "'", str3.equals("                                   "));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "   Hi!    ", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4, 19, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", " Ho..avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Ho..avaJ" + "'", str2.equals(" Ho..avaJ"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification", "10#32#1#32");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a", 19, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-140", 1.41004041E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-140.0d) + "'", double2 == (-140.0d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "10.14.", (java.lang.CharSequence) "                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (-1), "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("       SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Library/Jntents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Jntents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Jntents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("hO..AVAj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hO..AVAj" + "'", str1.equals("hO..AVAj"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-", "1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "       SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A", charSequence1, 392);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "#########################################################a4a4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0.01#0.AmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalP", "10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1aaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("US");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "-x#0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("              Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.4", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java Platform API Specification", "  #");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("       sOPHIE");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0" + "'", str1.equals("-1.0"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", 392);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "JAVA HO...", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10a1", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a1" + "'", str2.equals("10a1"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1a10a100a1a100a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1", 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-1 100 10", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" hO..AVAj", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " hO..AVAj" + "'", str2.equals(" hO..AVAj"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/r/ar/aar/r/aar-/", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hi!", "sun.lwawt.macosx.LWCToolkit", "#");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("a#4# # # #4", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a#4# # # #4" + "'", str2.equals("a#4# # # #4"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", 77);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en..." + "'", str2.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en..."));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.5", (int) (byte) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) " Ho..avaJ", charSequence1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate(" Ho..avaJ", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 0, (int) (byte) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 10, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10#32#1#32" + "'", str7.equals("10#32#1#32"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10#32#1#32" + "'", str13.equals("10#32#1#32"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "2 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1S10S100S1S100S-1", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("aaaaaaaaaaa10a32a1a32aaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaa10a32a1a32aaaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaaa10a32a1a32aaaaaaaaaaa"));
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test097");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
//        boolean boolean5 = javaVersion2.atLeast(javaVersion3);
//        boolean boolean6 = javaVersion0.atLeast(javaVersion2);
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "class [ljava.lang.string;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("aaaaaaaaaaaaaa", "/r/ar/aar/r/aar-/ts4j/tMp/run_ranOXXp.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaa"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 28.0f, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 28.0f + "'", float3 == 28.0f);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("4444444444444", 1410040410);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444" + "'", str2.equals("4444444444444"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("0.0410.0", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0410.0" + "'", str2.equals("0.0410.0"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "1#10#100#1#100#-1", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        long[] longArray5 = new long[] { '#', 100L, 100, (byte) -1, 31 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ', 97, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "35a100a100a-1a31" + "'", str7.equals("35a100a100a-1a31"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35#100#100#-1#31" + "'", str9.equals("35#100#100#-1#31"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "/Library/Jntents/Home/jre/lib/endorsed", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.14.", "java hotspot(tm) 64-bit server vm", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1", (java.lang.CharSequence) "0.0410.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en...", (java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("   ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "              Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "35#1   Hi!    35#10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_80-b15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1" + "'", str2.equals("1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "1-A001A1A001A01A1", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(" ", "Java Ho..", "class [Ljava.l...");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "   ", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "2 10", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) " hO..AVAj", (java.lang.CharSequence) "          0.79a0.1          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 77L, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "6_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("6", "Library/Jntents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("X86_6X86_6", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 4, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444" + "'", str3.equals("4444"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm" + "'", str1.equals("java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("          0.79a0.1          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          0.79A0.1          " + "'", str1.equals("          0.79A0.1          "));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "141452424044", (java.lang.CharSequence) "1 10 100 1 100 -1");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "141452424044" + "'", charSequence2.equals("141452424044"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaJava(TM) SE Runtime EnvironmentaJava Virtual Machine Specification", "###############################", "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "  #");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en..." + "'", str3.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en..."));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                  ts4j/tmp/run_randoop.pl_50283_1560277096                   ", (java.lang.CharSequence) "1.0 97.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73 + "'", int2 == 73);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("class [Ljava.l...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x86_64 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, 52, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("class [Lja", "1#10#100#1#100#-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Lja" + "'", str2.equals("class [Lja"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', (int) (short) 10, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', 97, 1);
        short short17 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1#0" + "'", str10.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1#0" + "'", str12.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) -1 + "'", short17 == (short) -1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        long[] longArray5 = new long[] { '#', 100L, 100, (byte) -1, 31 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "35a100a100a-1a31" + "'", str7.equals("35a100a100a-1a31"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35#100#100#-1#31" + "'", str9.equals("35#100#100#-1#31"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "35a100a100a-1a31" + "'", str12.equals("35a100a100a-1a31"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("x86_64", "a#4# # # #4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/moc.elcaro.avaj//:ptth", (java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.0 0.0 0.0", (java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        char[] charArray7 = new char[] { ' ', '#' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', 0, (int) (short) -1);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS X", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ocuments/defects4j/framework/lib", charArray7);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) '4', (int) (short) 1);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "\n", charArray7);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus", charArray7);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 94 + "'", int19 == 94);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("SUN.AWT.cgRAPHICSeNVIRONMEN");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMEN" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMEN"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "a 4 a 4 4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("ts4j/tmp/run_randoop.pl_50283_1560277096");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ts4j/tmp/run_randoop.pl_50283_1560277096\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1A10A100A1A100A-1", "0.0#10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1A10A100A1A100A-1" + "'", str2.equals("1A10A100A1A100A-1"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((-1.0f), (float) ' ', (float) 77);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 77.0f + "'", float3 == 77.0f);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "10#-1#-1#10#100", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEh/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEi/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEe/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10#-1#-1#10#100" + "'", charSequence2.equals("10#-1#-1#10#100"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("CLASS [LJAVA.LANG.STRING;", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CLASS [LJAVA.LANG.STRING;" + "'", str2.equals("CLASS [LJAVA.LANG.STRING;"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "10 2 17 28 0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("-x#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-x#0" + "'", str1.equals("-x#0"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("-140                                                                                                ", "JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", "44444 ##444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-140                                                                                                " + "'", str3.equals("-140                                                                                                "));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 89, (float) (byte) -1, 17.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java Platform API Specification", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "///////////////////", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0.0#10.0", (java.lang.CharSequence) "sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(97, 0, 61);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", 'a');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray9, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("Java HotSpot(TM) 64-Bit Server VM", strArray4, strArray13);
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "#", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str15.equals("Java HotSpot(TM) 64-Bit Server VM"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 2432, (float) 16, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1 0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1 0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie", "vaPlatformAPISpecification");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "A 4 a 4 4", (java.lang.CharSequence) "I");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1aaaaaaaaaaaaaa", (int) (short) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a11a10a100a1a100a-110a11a10a100a1a" + "'", str3.equals("0a11a10a100a1a100a-110a11a10a100a1a"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "vaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0a97.", "vaPlatformAPISpecification", (int) 'a');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 35, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { 'a', '4', 'a', '4', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophi", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "a 4 a 4 4" + "'", str15.equals("a 4 a 4 4"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "a#4#a#4#4" + "'", str17.equals("a#4#a#4#4"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1 0", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "-1#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Library/Jntents/Home/jre/lib/endorsed", "1 10 100 1 100 -1", "4444");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(8, 72, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "31410428410", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("35#100#100#-1#31                      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"35#100#100#-1#31\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "r", (java.lang.CharSequence) "x86_64                   ...", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "class [Ljava.lang.String;", 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.0410.0-1", 3, 392);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                 Java Ho...                                 ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                   ", "1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Mac OS X", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.0a97.", (java.lang.CharSequence) "24.80-b11", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1S10S100S1S100S-1", "platformapispecif");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1S10S100S1S100S-1" + "'", str2.equals("1S10S100S1S100S-1"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "-140                                                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("35a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31" + "'", str2.equals("3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "sun.lwawt.macosx.LWCToolkitx86_64                                                                                              ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaJava(TM) SE Runtime EnvironmentaJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java Ho...", 94);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Ho..." + "'", str2.equals("Java Ho..."));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1a10a100a1a100a-1", 29, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 35, 35);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        float[] floatArray2 = new float[] { (short) 1, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4', 0, 0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a97.0" + "'", str4.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0 97.0" + "'", str6.equals("1.0 97.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0a97.0" + "'", str8.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaPlatformAPISpecification" + "'", str1.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 19, (double) 1.2f, (-140.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-140.0d) + "'", double3 == (-140.0d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.0410.041.04-1.0", "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "         I", (java.lang.CharSequence) "10a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(".0#10.0", 5, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".0#10.0" + "'", str3.equals(".0#10.0"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1 0", (java.lang.CharSequence) "http://java.oracle.com/-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "              Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.0 97.", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "31410428410");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("java hotspot(tm) 64-bit server vm", "10a32a1a32");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray2 = new char[] { 'a' };
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray2, 'a', (int) (short) 0, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 36 + "'", int1 == 36);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "X86_6X86_6", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", "                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus", 36);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEh/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEi/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEe/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0.0#10.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        char[] charArray4 = new char[] { ' ', '#' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray4, '4', 0, (int) (short) -1);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS X", charArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "  #" + "'", str11.equals("  #"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("X86_6", "#a4a4                                              ", "             1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_6" + "'", str3.equals("X86_6"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaEihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaEihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("141041004141004-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "141041004141004-1" + "'", str1.equals("141041004141004-1"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", "1a100a0a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "#a4a4", (java.lang.CharSequence) "0#0.0#0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("x86_64                                                                                              ", "1043241432");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64                                                                                              " + "'", str2.equals("x86_64                                                                                              "));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "1.0a0.0a0.0", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "35#100#100#-1#31                      ", (java.lang.CharSequence) "2 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophi", 32, "jAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVApLATFORMapisPECI/Users/sophi" + "'", str3.equals("jAVApLATFORMapisPECI/Users/sophi"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("aaaaaaaaaaaaaa", "0.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaa"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.0#97.", 72, 36);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("X86_6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_" + "'", str1.equals("X86_"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en...", "PlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformAPISpeciPlatformA.0#10.0", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en..." + "'", str3.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en..."));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 29, (long) (byte) 100, (long) 28);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28L + "'", long3 == 28L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sophie", "4444", "6_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "31410428410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 29, 2L, (long) 14);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("141452424044", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "141452424044" + "'", str2.equals("141452424044"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("       SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A" + "'", str3.equals("       SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("51.0", 72, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.0 97.0", "10#32#1#32", 10);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "x86_64");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("\n", strArray5, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "\n" + "'", str9.equals("\n"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", (java.lang.CharSequence) "1-A001A1A001A01A1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("X86_", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "444");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "4444444444444444444444440.79a0.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31", "CLASS [LJAVA.LANG.STRING;", (int) (short) -1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31" + "'", str4.equals("3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " hO..AVAj", 14, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie", "0.0410.00.0410.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        double[] doubleArray2 = new double[] { 97.0d, 0L };
        double[] doubleArray5 = new double[] { 97.0d, 0L };
        double[] doubleArray8 = new double[] { 97.0d, 0L };
        double[][] doubleArray9 = new double[][] { doubleArray2, doubleArray5, doubleArray8 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: hi! is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1#10#100#1#100#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#10#100#1#100#-1" + "'", str1.equals("1#10#100#1#100#-1"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-", 5, "x86_64                                                                                              ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-" + "'", str3.equals("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.7", "extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Mac OS X", "                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("NEMNORIVNeSCIHPARgc.TWA.NUS");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.7.0_80", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096" + "'", str2.equals("users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0.01#0.AmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalP", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.01#0.AmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalP" + "'", str2.equals("0.01#0.AmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalP"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0", "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0" + "'", str2.equals("14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("r", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r" + "'", str2.equals("r"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus", "10", 73);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "4444444444", 31);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                   ", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "                   " + "'", str9.equals("                   "));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1A10A100A1A100A-1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "          0.79A0.1          ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("2 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"2 10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                                 ", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 " + "'", str3.equals("                                                                                                 "));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "   Hi!    ", (java.lang.CharSequence) "javaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "I", "4444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        char[] charArray9 = new char[] { 'a', '4', 'a', '4', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Platform API Specif", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", charArray9);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', 13, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 13");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test282");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
//        boolean boolean11 = javaVersion8.atLeast(javaVersion9);
//        boolean boolean12 = javaVersion6.atLeast(javaVersion8);
//        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean15 = javaVersion6.atLeast(javaVersion14);
//        boolean boolean16 = javaVersion4.atLeast(javaVersion14);
//        boolean boolean17 = javaVersion2.atLeast(javaVersion4);
//        java.lang.String str18 = javaVersion2.toString();
//        java.lang.String str19 = javaVersion2.toString();
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.2" + "'", str18.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.2" + "'", str19.equals("1.2"));
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0", (java.lang.CharSequence) "JAVA HO...", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) 10, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 61, (int) (byte) 0);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "51.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 51.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("A 4 a 4 4", "", (int) (short) 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " 4 a 4 4" + "'", str4.equals(" 4 a 4 4"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Java Ho..", (java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        short[] shortArray4 = new short[] { (short) 1, (byte) 100, (byte) 0, (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ', (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1410040410" + "'", str6.equals("1410040410"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.LWCToolkitx86_64                                                                                              ", "          0.79A0.1          ", "1a10a100a1a100a-1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "             1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "ificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2748 + "'", int2 == 2748);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "en", charSequence1, 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("Java HotSpot(TM) 64-Bit Server VM", strArray2, strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str4.equals("Java HotSpot(TM) 64-Bit Server VM"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "-1#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitx86_64                                                                                              ", (java.lang.CharSequence) "1.0#97.", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!" + "'", str2.equals("Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(19L, 1410040410L, 13L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 13L + "'", long3 == 13L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                  ts4j/tmp/run_randoop.pl_50283_1560277096                   ", (java.lang.CharSequence) "31a10a28a10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("46_6", "X86_6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "46_6" + "'", str2.equals("46_6"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1, 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.04-1.0410.0", '4');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "24.80-b11");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0", '4');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4444444444444", strArray3, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        long[] longArray5 = new long[] { '#', 100L, 100, (byte) -1, 31 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', 31, 3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "35a100a100a-1a31" + "'", str7.equals("35a100a100a-1a31"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35#100#100#-1#31" + "'", str9.equals("35#100#100#-1#31"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1#10#100#1#100#-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!iH" + "'", str1.equals("!iH"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("              Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "              eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("              eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "4444444444444444444444440.79a0.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "a#4# # # #4", (java.lang.CharSequence) "141452424044");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1 0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("jAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        long[] longArray4 = new long[] { 31L, 10L, 28, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.Class<?> wildcardClass6 = longArray4.getClass();
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 29, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 29");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31410428410" + "'", str9.equals("31410428410"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                            ", "X86_6X86_6", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                            " + "'", str3.equals("                            "));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1", "10a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1" + "'", str2.equals("-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("10.14.310.14.310.14PlatformAPISpecif", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.0 0.0 0.0", 76);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 0.0 0.0" + "'", str2.equals("1.0 0.0 0.0"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "A100A-", "/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 38);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38 + "'", int2 == 38);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.0a97.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "35#100#100#-1#31                      ", (java.lang.CharSequence) "Platform API Specif");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "35#100#100#-1#31                      ", (java.lang.CharSequence) "1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification" + "'", str1.equals("JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironmen" + "'", str1.equals("sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie", 97, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("mixedmod");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mixedmod\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1#0" + "'", str8.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java HotSpot(TM) 64-Bit Server VM", 36);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Java HotSpot(TM) 64-Bit Server VM  " + "'", str2.equals(" Java HotSpot(TM) 64-Bit Server VM  "));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation", "X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "-140");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("jAVApLATFORMapisPECI/Users/sophi");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("UTF-8", 'a');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, ":", (int) 'a', (int) (short) -1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray5, strArray7);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "java Platform API Specification");
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", 'a');
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray25, strArray29);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.replaceEach("Java HotSpot(TM) 64-Bit Server VM", strArray20, strArray29);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray5, strArray29);
        java.lang.String[] strArray36 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Java Ho...", 0);
        try {
            java.lang.String str37 = org.apache.commons.lang3.StringUtils.replaceEach("24.80-b11", strArray5, strArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 19");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str14.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTF-8" + "'", str16.equals("UTF-8"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str31.equals("Java HotSpot(TM) 64-Bit Server VM"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str32.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
        org.junit.Assert.assertNotNull(strArray36);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("###############################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "\n", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("10.14.310.14.310.14PlatformAPISpecif");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.310.14.310.14PlatformAPISpecif" + "'", str1.equals("10.14.310.14.310.14PlatformAPISpecif"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("-1.0", "4444444444", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en...", 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0" + "'", str4.equals("-1.0"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en..." + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en..."));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("\n", "1#10#100#1#100#-1");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.2", strArray3, strArray8);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\n" + "'", str4.equals("\n"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.2" + "'", str9.equals("1.2"));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80" + "'", str4.equals("1.7.0_80"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        float[] floatArray2 = new float[] { (short) 1, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a97.0" + "'", str4.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0#97.0" + "'", str6.equals("1.0#97.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0#97.0" + "'", str8.equals("1.0#97.0"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              ", "NEMNORIVNeSCIHPARgc.TWA.NUS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', 56, 94);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 56");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "35#100#100#-1#31");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("35#100#100#-1#31", (float) 91);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 91.0f + "'", float2 == 91.0f);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a" + "'", str1.equals("a"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.CharSequence charSequence6 = null;
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.0a97.0", (int) (byte) 10);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence6, (java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("###############################", strArray4, strArray10);
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1043241432", (java.lang.CharSequence[]) strArray4);
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "###############################" + "'", str12.equals("###############################"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a#4#a#4#4", "sun.awt.CGraphicsEnvironmen", 36);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/r/ar/aar/r/aar-/ts4j/tMp/run_ranOXXp.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/r/ar/aar/r/aar-/ts4j/tMp/run_ranOXXp.pl_50283_1560277096" + "'", str1.equals("/r/ar/aar/r/aar-/ts4j/tMp/run_ranOXXp.pl_50283_1560277096"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        double[] doubleArray1 = new double[] { (byte) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0" + "'", str7.equals("1.0"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#A4A4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                          -x#0                                           ", 0, 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                             ", "mixed mode", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1", "1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) '4', (-1));
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 0, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) -1 + "'", byte16 == (byte) -1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\n\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                  ts4j/tmp/run_randoop.pl_50283_1560277096                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ts4j/tmp/run_randoop.pl_50283_1560277096" + "'", str1.equals("ts4j/tmp/run_randoop.pl_50283_1560277096"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("35a100a100a-1a31", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35a100a100a-1a31" + "'", str3.equals("35a100a100a-1a31"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkitx86_64                                                                                              ", "1.8");
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("Java Ho..", strArray4, strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification", "10#32#1#32");
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "/", 19, (int) (short) 10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("1-A001A1A001A01A1", strArray5, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Java Ho.." + "'", str6.equals("Java Ho.."));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1-A001A1A001A01A1" + "'", str16.equals("1-A001A1A001A01A1"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1410040410", "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        long[] longArray6 = new long[] { 1, (byte) 1, 52L, 2, (byte) 0, 4 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 31, 19);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1 1 52 2 0 4" + "'", str13.equals("1 1 52 2 0 4"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("-1.0#10.0#1.0#-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.1-#0.1#0.01#0.1-" + "'", str1.equals("0.1-#0.1#0.01#0.1-"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        float[] floatArray3 = new float[] { 10.0f, (-1), 10.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0#-1.0#10.0" + "'", str6.equals("10.0#-1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.04-1.0410.0" + "'", str8.equals("10.04-1.0410.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 10.0f + "'", float10 == 10.0f);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.0 97.", (java.lang.CharSequence) " ##", 2748);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("HI!", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("r");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("...0a-1a31");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"...0a-1a31\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("###############################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###############################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.2", (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2d + "'", double2 == 1.2d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("phie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "phie" + "'", str1.equals("phie"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("#a4a4", "ocuments/defects4j/framework/lib");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("-1a0", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_64                   ...", 8, 1410040410);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification", "10#32#1#32");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Mac OS X", (int) '4', (int) (short) 10);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray3, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str12.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Java Platform API Specification" + "'", str13.equals("Java Platform API Specification"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", (int) '4', 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NTENTS/HOME/JRE/LIB/ENDORSE" + "'", str3.equals("NTENTS/HOME/JRE/LIB/ENDORSE"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " ##", (java.lang.CharSequence) "mixedmod");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(52L, 0L, (long) 13);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10#32#1#32" + "'", str7.equals("10#32#1#32"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a32a1a32" + "'", str9.equals("10a32a1a32"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/USERS/SOPHI", 16, 89);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHI" + "'", str3.equals("/USERS/SOPHI"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.0 97.0", "10#32#1#32", 10);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-", 76, 91);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 76");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("I");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: I is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;" + "'", str1.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("sophie", "10 2 17 28 0", "NTENTS/HOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("PLATFORMAPISPECIF", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LATFORMAPISPECIF" + "'", str2.equals("LATFORMAPISPECIF"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1", (java.lang.CharSequence) "0.0410.0-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        float[] floatArray3 = new float[] { 10.0f, (-1), 10.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', 6, 2748);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0#-1.0#10.0" + "'", str6.equals("10.0#-1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.04-1.0410.0" + "'", str8.equals("10.04-1.0410.0"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4', 38, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 38");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a0" + "'", str8.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-140" + "'", str11.equals("-140"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.0a97.0", (int) (byte) 10);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification", "10#32#1#32");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a", strArray5, strArray8);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1", "1.0a97.0", (int) (short) 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray15);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "aaaaaaaaaaa10a32a1a32aaaaaaaaaaa");
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray18, "10.14.310.14.310.14PlatformAPISpecif", 56, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 56");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Java Platform API Specification" + "'", str10.equals("Java Platform API Specification"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a" + "'", str11.equals("       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(strArray18);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "SUN.AWT.cgRAPHICSeNVIRONMENT", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("35#1   Hi!    35#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"5#1   Hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("51.0", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.051.0" + "'", str2.equals("51.051.0"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" ##");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("2 10", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 5 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test421");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ":", (int) 'a', (int) (short) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(strArray2);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a3135a100a100a-1a31", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test422");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0", (java.lang.CharSequence) "                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test423");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0", 56, 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test424");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 17, (long) (byte) 1, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test425");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test426");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "phie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 94);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test428");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 39 + "'", int1 == 39);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test429");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "a444 4 4 44", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test430");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0", (float) 5);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.0a97.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0a97.0" + "'", str1.equals("1.0a97.0"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test432");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 1, (byte) -1, (byte) 100, (byte) -1, (byte) 10 };
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "x86_64");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: x86_64");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test433");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("  #################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test434");
        float[] floatArray3 = new float[] { 10.0f, (-1), 10.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) (short) 1, 0);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', 39, 73);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 39");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test435");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test436");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("444", "class [ljava.lang.string;", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test437");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "46_6", (java.lang.CharSequence) "0.79a0.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("10a1", "1.0a0.0a0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a1" + "'", str2.equals("10a1"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test439");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                              ", 56, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########################                              " + "'", str3.equals("##########################                              "));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.0 97.", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   1.0 97." + "'", str2.equals("   1.0 97."));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0.0410.0", "                            ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", "", "-x#0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification" + "'", str3.equals("JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test444");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) ' ', 16, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("-x#0", "10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-x#0" + "'", str2.equals("-x#0"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test446");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.0 97.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("ocuments/defects4j/framework/lib", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test448");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         ..." + "'", str2.equals("                         ..."));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a" + "'", str1.equals("       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("4444", 77);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444" + "'", str2.equals("4444"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test452");
        double[] doubleArray2 = new double[] { (byte) 0, (byte) 10 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', 0, (-1));
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test453");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test454");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "0.0410.0-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a11a10a10..." + "'", str2.equals("10a11a10a10..."));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en...", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en..." + "'", str2.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en..."));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test457");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1 1 52 2 0 4", "                                           10a1                                            ", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test458");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) " Ho..avaJ", (java.lang.CharSequence) "ts4j/tMp/run_ranOXXp.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test459");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("#");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test460");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.awt.CGraphicsEnvironmen", "  #", "PlatformAPISpeci");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironmen" + "'", str3.equals("sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test462");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" 4 a 4 4", (int) (short) 1, "1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 4 a 4 4" + "'", str3.equals(" 4 a 4 4"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test464");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52, (double) (byte) 1, (double) 19.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test465");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("java hotspot(tm) 64-bit server vm", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test466");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("EN");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"EN\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test468");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1", (java.lang.CharSequence) "0.79a0.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test469");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 17, (long) 2432, (long) 3);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test470");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.0 97.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("-x#0", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test472");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test473");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("          0.79A0.1          ", "java hotspot(tm) 64-bit server vm", "                                               4a4a#", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "          0.79A0.1          " + "'", str4.equals("          0.79A0.1          "));
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test474");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
//        boolean boolean5 = javaVersion2.atLeast(javaVersion3);
//        boolean boolean6 = javaVersion0.atLeast(javaVersion2);
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean9 = javaVersion0.atLeast(javaVersion8);
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
//        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
//        boolean boolean15 = javaVersion12.atLeast(javaVersion13);
//        boolean boolean16 = javaVersion10.atLeast(javaVersion12);
//        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
//        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean19 = javaVersion10.atLeast(javaVersion18);
//        boolean boolean20 = javaVersion8.atLeast(javaVersion10);
//        boolean boolean21 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test475");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "0.0410.00.0410.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0.0410.00.0410.0" + "'", charSequence2.equals("0.0410.00.0410.0"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("10.14.310.14.310.14PlatformAPISpecif");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.310.14.310.14PlatformAPISpecif" + "'", str1.equals("10.14.310.14.310.14PlatformAPISpecif"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test477");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("       SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A" + "'", str3.equals("4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test478");
        long[] longArray4 = new long[] { 31L, 10L, 28, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31410428410" + "'", str7.equals("31410428410"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test479");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Platform API Specificatio", (java.lang.CharSequence) "1.0#97.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test480");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("46_6", "35#100#100#-1#31");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("a", (-1), ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a" + "'", str3.equals("a"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("vaPlatformAPISpecification", (int) (byte) 100, "          0.79A0.1          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   " + "'", str3.equals("          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   "));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test484");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "a#4# # # #4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern(" ##", "AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " ##" + "'", str2.equals(" ##"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test486");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test487");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("HI!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test488");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test489");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test490");
        float[] floatArray3 = new float[] { 10.0f, (-1), 10.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0#-1.0#10.0" + "'", str6.equals("10.0#-1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.04-1.0410.0" + "'", str8.equals("10.04-1.0410.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test491");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0140400141/Jntents/Home/jre/lib/endorse", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test492");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("!iH");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"!iH\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Aaaaaaaaaaa10a32a1a32aaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaa10a32a1a32aaaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaaa10a32a1a32aaaaaaaaaaa"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test494");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0.0a10.0", 10, "X86_6X86_6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X0.0a10.0X" + "'", str3.equals("X0.0a10.0X"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test496");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test497");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0", (java.lang.CharSequence) "PlatformAPISpecif");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.0 97.", "##########################                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 97." + "'", str2.equals("1.0 97."));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test499");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Eihpos/sresU/", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test500");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("///////////////////", "", 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "platformapispecif", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }
}

