import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest16 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest16.test001");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
//        boolean boolean5 = javaVersion2.atLeast(javaVersion3);
//        boolean boolean6 = javaVersion0.atLeast(javaVersion2);
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        java.lang.String str8 = javaVersion2.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        boolean boolean10 = javaVersion2.atLeast(javaVersion9);
//        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        java.lang.String str12 = javaVersion11.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        boolean boolean14 = javaVersion11.atLeast(javaVersion13);
//        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
//        boolean boolean16 = javaVersion9.atLeast(javaVersion13);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.4" + "'", str12.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test003");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 28.0f, (double) 5.0f, 392.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 690);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             " + "'", str2.equals("             "));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test006");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("0.79a0.1", "                    aaaaaaaaaaaaaa                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.79a0.1" + "'", str2.equals("0.79a0.1"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test008");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", "-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096" + "'", str4.equals("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Library/Jntents/Home/jre/lib/endorse", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  /USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Jntents/Home/jre/lib/endorse" + "'", str2.equals("/Library/Jntents/Home/jre/lib/endorse"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Jntents/Home/jre/lib/endorsed", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Jntents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Jntents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("-140", "  ###########################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-140" + "'", str2.equals("-140"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test012");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                 JAVA HO...                                 ", (java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test013");
        long[] longArray4 = new long[] { 31L, 10L, 28, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(" ", 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4aaa4a4", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4aaa4a4" + "'", str2.equals("4aaa4a4"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("###########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################   1.6    ###########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "aa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa" + "'", str2.equals("aa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("RTUAL MACHINE SPECIFICATION", "ts4j/tmp/run_randoop.pl_50283_1560277096                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RTUAL MACHINE SPECIFICATION" + "'", str2.equals("RTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-140", 2, "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-140" + "'", str3.equals("-140"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test019");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.0 97.", 14, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test020");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "              Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "HI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test021");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "vaPlatformAPISpecification", 134);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test022");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JA...");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test023");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '4', 17, 5);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test024");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "  ###########################", (java.lang.CharSequence) " ######################################################################sun.lwawt.macosx.LWCToolkit  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test025");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("e", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test026");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#0", (java.lang.CharSequence) "sOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/80", "444444444444444440.1-#0.1#0.01#0.1-", "                               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/80" + "'", str3.equals("             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/80"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test028");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                  ts4j/tmp/run_randoop.pl_50283_1560277096                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("############################################################################", 74, 26);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test030");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(".41.01");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test031");
        java.lang.CharSequence[] charSequenceArray8 = new java.lang.CharSequence[] { "hi!", "hi!", "", "", "", "hi!" };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charSequenceArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray8, 'a', 19, (int) (byte) -1);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.051.0", charSequenceArray8);
        org.junit.Assert.assertNotNull(charSequenceArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0", "1.0 97", "###############################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0" + "'", str3.equals("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("####################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################" + "'", str1.equals("####################################################"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test034");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 760);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test035");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                               X86_6X86_6                                ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test036");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test037");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1.0", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "class [Lja", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test038");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1043241432");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test039");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.6", '4');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test040");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("JAVApLATFORMapisPECI/Users/sophi", "PLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIFPLATFORMAPISPECIF", "A100A-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVApLATFORMapisPECI/Users/sophi" + "'", str3.equals("JAVApLATFORMapisPECI/Users/sophi"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test041");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("   10#-1#-1#10#100");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test042");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                             A100A-", (float) 31);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 31.0f + "'", float2 == 31.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test043");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("jAVApLATFORMapisPECI/Users/sophi0141/Jntents/Home/jre/lib/endorse", (long) 70);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 70L + "'", long2 == 70L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test044");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Java Platform API Specification", (int) (byte) 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.0 0.0 0.0", 52, 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test045");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("O...", "");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "O..." + "'", str3.equals("O..."));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test046");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { 'a', '4', ' ', ' ', ' ', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!", charArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10A100A1A100A-11A10", charArray9);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray9);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "a#4# # # #4" + "'", str12.equals("a#4# # # #4"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "a444 4 4 44" + "'", str14.equals("a444 4 4 44"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a444 4 4 44" + "'", str16.equals("a444 4 4 44"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "a#4# # # #4" + "'", str20.equals("a#4# # # #4"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                           10#32#1#32                                            ", 7, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                           10#32#1#32                                            " + "'", str3.equals("                                           10#32#1#32                                            "));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("10.0 -1.0 10.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".01 0.1- 0.01" + "'", str1.equals(".01 0.1- 0.01"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("28.046.0410.0", "0.0#10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test050");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) ".nus", (int) (short) 4444);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test051");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 42, (double) 94L, (double) 143);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 143.0d + "'", double3 == 143.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test052");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "###############################4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "###############################4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", charSequence2.equals("###############################4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test053");
        long[] longArray5 = new long[] { '#', 100L, 100, (byte) -1, 31 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray5, '4', 61, 31);
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "35a100a100a-1a31" + "'", str7.equals("35a100a100a-1a31"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35#100#100#-1#31" + "'", str9.equals("35#100#100#-1#31"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "35a100a100a-1a31" + "'", str16.equals("35a100a100a-1a31"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "35a100a100a-1a31" + "'", str18.equals("35a100a100a-1a31"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test054");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test055");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "JavaPlatformAPISpecification", (java.lang.CharSequence) "0.0a10.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test056");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JAjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest16.test057");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
//        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
//        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
//        java.lang.String str8 = javaVersion4.toString();
//        boolean boolean9 = javaVersion1.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
//        boolean boolean13 = javaVersion10.atLeast(javaVersion11);
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str15 = javaVersion14.toString();
//        boolean boolean16 = javaVersion10.atLeast(javaVersion14);
//        java.lang.String str17 = javaVersion14.toString();
//        boolean boolean18 = javaVersion4.atLeast(javaVersion14);
//        boolean boolean19 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.8" + "'", str15.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.8" + "'", str17.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test058");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                                        1410040410", "           X86_6", "                                                             aa4aaa4a4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                        1410040410" + "'", str3.equals("                                        1410040410"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test060");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("jAVApLATFORMapisPECI/Users/sophi0141/Jntents/Home/jre/lib/endorse");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: jAVApLATFORMapisPECI/Users/sophi0141/Jntents/Home/jre/lib/endorse is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification-1 0Platform35#100#100#-1#31API35#100#100#-1#31Specification", 17, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test062");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', 0, (int) (short) 1);
        byte byte18 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte21 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1#10#100#1#100#-1" + "'", str13.equals("1#10#100#1#100#-1"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) -1 + "'", byte18 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1 10 100 1 100 -1" + "'", str20.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + byte21 + "' != '" + (byte) -1 + "'", byte21 == (byte) -1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test063");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_", (java.lang.CharSequence) "############################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "1.0 0.0 0.", 134);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test065");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.8", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4#", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test066");
        float[] floatArray3 = new float[] { 10.0f, (-1), 10.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) (short) 1, 0);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', 1410040410, 50);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 10.0f + "'", float11 == 10.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 10.0f + "'", float12 == 10.0f);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                            #################################", "/uSERS/SOPHIE");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("##################", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test069");
        double[] doubleArray2 = new double[] { (byte) 0, (byte) 10 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("      46_68x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "46_68x" + "'", str1.equals("46_68x"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test071");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/R/AR/AAR/R/AAR-/", (java.lang.CharSequence) "                                8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 77);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                             " + "'", str2.equals("                                                                             "));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test073");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10.0 -1.0 10.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0 -1.0 10." + "'", str1.equals("10.0 -1.0 10."));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test075");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("###################################################1 10 100 1 100 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################################################1101001100-1" + "'", str1.equals("###################################################1101001100-1"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test077");
        float[] floatArray3 = new float[] { 10.0f, (-1), 10.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) (short) 1, 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', 17, (int) (short) 0);
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + (-1.0f) + "'", float13 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 10.0f + "'", float14 == 10.0f);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10.0 -1.0 10.0" + "'", str16.equals("10.0 -1.0 10.0"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test078");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test079");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test080");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.097.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test081");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Eihpos/sresU/NEihpos/sresU/TEihpos/sresU/EEihpos/sresU/NEihpos/sresU/TEihpos/sresU/SEihpos/sresU//Eihpos/sresU/HEihpos/sresU/OEihpos/sresU/MEihpos/sresU/EEihpos/sresU//Eihpos/sresU/JEihpos/sresU/REihpos/sresU/EEihpos/sresU//Eihpos/sresU/LEihpos/sresU/IEihpos/sresU/BEihpos/sresU//Eihpos/sresU/EEihpos/sresU/NEihpos/sresU/DEihpos/sresU/OEihpos/sresU/REihpos/sresU/SEihpos/sresU/EEihpos/sresU/");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test082");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                           ", 70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70 + "'", int2 == 70);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test083");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("0a1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar10a11a10a100a1a", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test084");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "j/tmp/run_randoop.pl_50283_15602770964aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausers/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test085");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              ", "35a100a100a-1a3", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test086");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("en                       ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test088");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                 JAVA HO...                                 ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test089");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 12, (double) ' ', (double) 20L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test090");
        float[] floatArray3 = new float[] { 10.0f, (-1), 10.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) (short) 1, 0);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float14 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 10.0f + "'", float11 == 10.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 10.0f + "'", float12 == 10.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + (-1.0f) + "'", float13 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + (-1.0f) + "'", float14 == (-1.0f));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test091");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', (int) (short) 10, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', 97, 52);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4', 16, 0);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1#0" + "'", str10.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Hi!", "-1#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!" + "'", str2.equals("Hi!"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test093");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 1, (short) 4444);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 4444 + "'", short3 == (short) 4444);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test094");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("JAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"JAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test095");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("a444 4 4 44");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0a1a001a01a11a011-a001a1a001a01a11a0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#0", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1" + "'", str2.equals("0#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1#14.310.14.310.14.310.CLASS [LJAVA.LANG.STRING;-1"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test098");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 8, (int) (byte) -1);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte18 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) -1 + "'", byte16 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 100 + "'", byte17 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) 100 + "'", byte18 == (byte) 100);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8" + "'", str2.equals("8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!8utf-8utf-8utf-8utf-8utf-8utf-8utf-8"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test100");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/moc.elcaro.avaj//:ptthutf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test101");
        char[] charArray7 = new char[] { ' ', '#' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', 0, (int) (short) -1);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS X", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ocuments/defects4j/framework/lib", charArray7);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) '4', (int) (short) 1);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "\n", charArray7);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "PlatformAPISpeci", charArray7);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#################################", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test102");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sOrHE1101001100-11101001100-1110", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("##############################444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444##############################" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444##############################"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test104");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "java Platform API Specification", (java.lang.CharSequence) "a1a001a01a11a011-", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test105");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test106");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, charSequence1, 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test107");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("  aaaaaaaaaa   aaaaaaaaaa", "444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test108");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "O...", "/Library/Jntents/Home/jre/lib/endorsed", 1586);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test109");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("##################class [Ljava.l...", "31410428410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##################class [Ljava.l..." + "'", str2.equals("##################class [Ljava.l..."));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test111");
        double[] doubleArray3 = new double[] { 1, (short) 0, 0L };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', 77, 8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a');
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0#0.0#0.0" + "'", str10.equals("1.0#0.0#0.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0a0.0a0.0" + "'", str12.equals("1.0a0.0a0.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test112");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', (int) '4', (int) ' ');
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        short short16 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1a0" + "'", str13.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1#0" + "'", str15.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) -1 + "'", short16 == (short) -1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-1 0" + "'", str18.equals("-1 0"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test113");
        char[] charArray9 = new char[] { ' ', '#' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', 0, (int) (short) -1);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API Specification", charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "class [Ljava.lang.String;", charArray9);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray9);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "///////////////////", charArray9);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0", charArray9);
        try {
            java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', 9, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test114");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("         I");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Platform35#   #   #  #3 API35#   #   #  #3 Specification", 97, 3);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "13a1-a0...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test116");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "1.5aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test117");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("class [ljava.lang.string;", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1101001100-1", "44444 ##444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1101001100-1" + "'", str2.equals("1101001100-1"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test120");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 100, (short) 4444);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 4444 + "'", short3 == (short) 4444);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8", 45);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8" + "'", str2.equals("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "13a1-a0...", (java.lang.CharSequence) "NTENTS/HOME/JRE/LIB/ENDORS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test124");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, ":");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test125");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444", 1, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("I", 13, 20);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "I" + "'", str3.equals("I"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test127");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ', 76, 40);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10a1" + "'", str4.equals("10a1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("JAVAPLATFORMAPISPECI/USERS/SOPH", 1600);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                JAVAPLATFORMAPISPECI/USERS/SOPH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                JAVAPLATFORMAPISPECI/USERS/SOPH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 "));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test129");
        double[] doubleArray3 = new double[] { 1, (short) 0, 0L };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', 77, 8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a');
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#');
        double double18 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0#0.0#0.0" + "'", str10.equals("1.0#0.0#0.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0a0.0a0.0" + "'", str12.equals("1.0a0.0a0.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.0a0.0a0.0" + "'", str15.equals("1.0a0.0a0.0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.0#0.0#0.0" + "'", str17.equals("1.0#0.0#0.0"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("6907720651_38205_lp.pXXOnar_nur/pMt/j4st#################################", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "st#################################46907720651_38205_lp.pXXOnar_nur/pMt/j" + "'", str2.equals("st#################################46907720651_38205_lp.pXXOnar_nur/pMt/j"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Java HotSpot(TM) 64-Bit Server VM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "10", "AAAAAAAAAA");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test134");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 25, (double) (short) -1, (double) 143.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 143.0d + "'", double3 == 143.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test135");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.051.0", (java.lang.CharSequence) "28.0#6.0#10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("JAVA VIRTUAL MACHINE SPECIFICATION", "                                  1.8                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str2.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test137");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (java.lang.CharSequence) "                                                                  Ho..avaJ", 1398);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test138");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', 89, 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 50 + "'", int3 == 50);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test139");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4", (java.lang.CharSequence) "                                                                                              46_68xtiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test140");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                          hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test141");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "e/lib/endorse##########################################################################################################################################################################################################################################################################################################################################################################################", (java.lang.CharSequence) "1a100a0a10");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "e/lib/endorse##########################################################################################################################################################################################################################################################################################################################################################################################" + "'", charSequence2.equals("e/lib/endorse##########################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1aaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test143");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test144");
        double[] doubleArray1 = new double[] { (byte) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 70, (int) (byte) 10);
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0" + "'", str7.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0" + "'", str9.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test145");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                                    ", (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test146");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) 10, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', 72, 2);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#-1#-1#10#100" + "'", str8.equals("10#-1#-1#10#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test147");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test148");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 97, 5);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 32 + "'", int14 == 32);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1043241432" + "'", str16.equals("1043241432"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test150");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/r/ar/aar/r/aar-/", "                     Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test151");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 35, (long) 45, (long) 7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 45L + "'", long3 == 45L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test152");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 97, 5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', (int) (byte) 1, 0);
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) (short) 10, 89);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test153");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "### hO..AVAj####                                                                                                                               ", (java.lang.CharSequence) " hO..AVAj");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test154");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JAjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JA", (java.lang.CharSequence) "/Library/Jntents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test155");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 20, 2434.0f, 42.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2434.0f + "'", float3 == 2434.0f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test156");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("LATFORMAPISPECIF", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 17, 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LATFORMAPISPECIFaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("LATFORMAPISPECIFaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test157");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("51.051.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test158");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 2432, 16);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "141041004141004-1" + "'", str11.equals("141041004141004-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1#10#100#1#100#-1" + "'", str13.equals("1#10#100#1#100#-1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "141041004141004-1" + "'", str15.equals("141041004141004-1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test159");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte18 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1#10#100#1#100#-1" + "'", str13.equals("1#10#100#1#100#-1"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 100 + "'", byte16 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) -1 + "'", byte17 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) -1 + "'", byte18 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1#10#100#1#100#-1" + "'", str20.equals("1#10#100#1#100#-1"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                                                             46_68xtiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "46_68xtiklooTCWL.xsocam.twawl.nus" + "'", str1.equals("46_68xtiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test161");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "ts4j/tmp/run_randoop.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test162");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test163");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) 100, 21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...2n2x1n4fc0000gn/T/" + "'", str3.equals("...2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;", "Java Ho..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;" + "'", str2.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("51.0", "1410040410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51." + "'", str2.equals("51."));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("35#100#100#-1#31", 134);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35#100#100#-1#31" + "'", str2.equals("35#100#100#-1#31"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test167");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "46_68X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.7.0_80", 74, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test169");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(391, 50, 2432);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 50 + "'", int3 == 50);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test170");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 42, (float) (short) 4444);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4" + "'", str2.equals("#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4#A4A4"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("0.0 0.0 0.1", "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0 0.0 0.1" + "'", str2.equals("0.0 0.0 0.1"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                               ", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     "));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test174");
        char[] charArray5 = new char[] { ' ', '#' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 0, (int) (short) -1);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS X", charArray5);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.0a97.", charArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0a11a10a100a1a100a-110a11a10a100a1a", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "  #" + "'", str13.equals("  #"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.awt.CGraphicsEnvironmen", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironmen" + "'", str2.equals("sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Jv Pltform API Specifiction4444444444/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jreJv(TM) SE Runtime EnvironmentJv Virtul Mchine Specifiction");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jv pltform api specifiction4444444444/librry/jv/jvvirtulmchines/jdk1.7.0_80.jdk/contents/home/jrejv(tm) se runtime environmentjv virtul mchine specifiction" + "'", str1.equals("jv pltform api specifiction4444444444/librry/jv/jvvirtulmchines/jdk1.7.0_80.jdk/contents/home/jrejv(tm) se runtime environmentjv virtul mchine specifiction"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahO..AVAjaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test178");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray5 = new char[] { ' ', '#' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 0, (int) (short) -1);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', (int) '#', 8);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Eihpos/sresU/NEihpos/sresU/TEihpos/sresU/EEihpos/sresU/NEihpos/sresU/TEihpos/sresU/SEihpos/sresU//Eihpos/sresU/HEihpos/sresU/OEihpos/sresU/MEihpos/sresU/EEihpos/sresU//Eihpos/sresU/JEihpos/sresU/REihpos/sresU/EEihpos/sresU//Eihpos/sresU/LEihpos/sresU/IEihpos/sresU/BEihpos/sresU//Eihpos/sresU/EEihpos/sresU/NEihpos/sresU/DEihpos/sresU/OEihpos/sresU/REihpos/sresU/SEihpos/sresU/EEihpos/sresU/", charArray5);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "  #" + "'", str16.equals("  #"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test179");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test180");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444" + "'", str1.equals("444"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "             ", "              eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test183");
        long[] longArray2 = new long[] { (short) 1, (byte) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', (int) '4', (int) (short) 1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', 19, 8);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "140" + "'", str13.equals("140"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("             /R/AR/AAR/R/AAR-/1/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/.//R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/7/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/.//R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/0/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/_/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "             /R/AR/AAR/R/AAR-/1/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/.//R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/7/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/.//R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/0/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/_/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/8" + "'", str1.equals("             /R/AR/AAR/R/AAR-/1/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/.//R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/7/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/.//R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/0/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/_/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/8"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test185");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("10A100A1A100A-11A10", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test186");
        char[] charArray6 = new char[] { ' ', '#' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', 0, (int) (short) -1);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", charArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.14.", charArray6);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1420.0a19.0", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + " ##" + "'", str14.equals(" ##"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + " 4#" + "'", str16.equals(" 4#"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test187");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0a11a10a100a1a100a-110a11a10a100a1", (java.lang.CharSequence) "13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test188");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Platform API Specif", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test189");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0.0#14.0#38.0#10.0", (java.lang.CharSequence) "2 10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("x86_64                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;" + "'", str2.equals("4.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("a4a4                                              ", 97, "1043241432");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10432414321043241432104324143210432414321043241a4a4                                              " + "'", str3.equals("10432414321043241432104324143210432414321043241a4a4                                              "));
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest16.test193");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
//        boolean boolean11 = javaVersion8.atLeast(javaVersion9);
//        boolean boolean12 = javaVersion6.atLeast(javaVersion8);
//        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean15 = javaVersion6.atLeast(javaVersion14);
//        boolean boolean16 = javaVersion4.atLeast(javaVersion14);
//        boolean boolean17 = javaVersion2.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean19 = javaVersion2.atLeast(javaVersion18);
//        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean21 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion20);
//        java.lang.String str22 = javaVersion20.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean24 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
//        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion26 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean27 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion26);
//        boolean boolean28 = javaVersion25.atLeast(javaVersion26);
//        boolean boolean29 = javaVersion23.atLeast(javaVersion25);
//        boolean boolean30 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
//        org.apache.commons.lang3.JavaVersion javaVersion31 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean32 = javaVersion23.atLeast(javaVersion31);
//        boolean boolean33 = javaVersion20.atLeast(javaVersion23);
//        boolean boolean34 = javaVersion2.atLeast(javaVersion20);
//        java.lang.String str35 = javaVersion20.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion36 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str37 = javaVersion36.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion38 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean39 = javaVersion36.atLeast(javaVersion38);
//        boolean boolean40 = javaVersion20.atLeast(javaVersion36);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1.8" + "'", str22.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion26 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion26.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion31 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion31.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1.8" + "'", str35.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion36 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion36.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1.8" + "'", str37.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion38 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion38.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test194");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA51.0", (java.lang.CharSequence) "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test195");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1410040410");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test196");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Ho..", "0.1-#0.1#0.01#0.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test197");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                                                  Ho..avaJ", (java.lang.CharSequence) "                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("-1#0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        " + "'", str1.equals("-1#0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        "));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test200");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausers/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", (java.lang.CharSequence) "44");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test201");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1aaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaa0.79a0.1", 76);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test202");
        char[] charArray5 = new char[] { ' ', '#' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 0, (int) (short) -1);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS X", charArray5);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ocuments/defects4j/framework/lib", charArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', (int) '4', (int) (short) 1);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "\n", charArray5);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + " ##" + "'", str18.equals(" ##"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test203");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Aaaaaaaaaaa10a32a1a32aaaaaaaaaaa", (java.lang.CharSequence) ".0#10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;" + "'", str1.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test205");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10 32 1 32" + "'", str10.equals("10 32 1 32"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test206");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.0497.0", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test207");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                            ", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                            " + "'", str3.equals("                            "));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("44", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44" + "'", str2.equals("44"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test209");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "Mac OS ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ts4j/tmp/run_randoop.pl_50283_1560277096                                    ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ts4j/tmp/run_randoop.pl_50283_1560277096                                    " + "'", str2.equals("ts4j/tmp/run_randoop.pl_50283_1560277096                                    "));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test211");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1/Users/sophie./Users/sophie7/Users/sophie./Users/sophie0/Users/sophie_/Users/sophie80" + "'", str1.equals("1/Users/sophie./Users/sophie7/Users/sophie./Users/sophie0/Users/sophie_/Users/sophie80"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test212");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "JAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION", (java.lang.CharSequence) "x86_64                   ...x86_64              10a1x86_64                   ...x86_64              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test213");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "a 4 a 4 4", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444##############################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test214");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test215");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0", (int) '4', "aa4aaa4a4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0" + "'", str3.equals("0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test216");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "4444444444444444444444440.79a0.14444444444444444441.0#0.0#", (java.lang.CharSequence) "Hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test217");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 3, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("PlatformAPISpeca1a001a01a11a011-a001a1a001a01a11a0", 2434);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                PlatformAPISpeca1a001a01a11a011-a001a1a001a01a11a0" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                PlatformAPISpeca1a001a01a11a011-a001a1a001a01a11a0"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test219");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                           10#32#1#32                                            ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("6#10#-1#94");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "6#10#-1#94" + "'", str1.equals("6#10#-1#94"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test221");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "A100A-1", (java.lang.CharSequence) "MIXED MOD", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test222");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("a444a4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a444a4444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test223");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("class [Lja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Lja" + "'", str1.equals("class [Lja"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test224");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", 28.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 28.0f + "'", float2 == 28.0f);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test225");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1################", (java.lang.CharSequence) "JAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("4444444444444444444444440.79a0.14444444444444444441.0#0.0#", 2432, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444440.79a0.14444444444444444441.0#0.0#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("4444444444444444444444440.79a0.14444444444444444441.0#0.0#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test227");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1a-1a-1a-1a", (java.lang.CharSequence) "-1 0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test228");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("1.8", "Java HotSpot(TM) 64-Bit Server VM");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/uSERS/SOPHIE", "en");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("JAVA VIRTUAL MACHINE SPECIFICATION", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (byte) 1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java HotSpot(TM) 64-Bit Server VM", strArray9, strArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray13);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "ocuments/defects4j/framework/lib");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Ho...", strArray5, strArray13);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray21);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sophie");
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("-1a0", strArray21, strArray24);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray5, strArray24);
        boolean boolean27 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                          -x#0                                           ", (java.lang.CharSequence[]) strArray24);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str14.equals("Java HotSpot(TM) 64-Bit Server VM"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Java Ho..." + "'", str18.equals("Java Ho..."));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-1a0" + "'", str25.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str26.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("#UN.#WT.#gR##H#C##NV#RONMENT", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.platformapispecif", 55);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test230");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) '4', (-1));
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 32, (int) (short) -1);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1a10a100a1a100a-1" + "'", str21.equals("1a10a100a1a100a-1"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test231");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaeihpos/sresu/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test232");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Aaaaaaaaaaa10a32a1a32aaaaaaaaaaa", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.", "aaaaaaaaaaaaaaaaaaaaaclass [Ljaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97." + "'", str2.equals("   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97."));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test234");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(8.0f, (float) 690, 5.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 690.0f + "'", float3 == 690.0f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test235");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.097.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-10", "JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test236");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "MIXED MOD");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test237");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) 10, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a-1a-1a10a100" + "'", str9.equals("10a-1a-1a10a100"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test238");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(12, 37, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 37 + "'", int3 == 37);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 40);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test240");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 98L, (double) 1586.0f, (double) 31.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.0d + "'", double3 == 31.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test241");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1L, 94L, (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test242");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test243");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                    aaaaaaaaaaaaaa                     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace(" Java HotSpot(TM) 64-Bit Server VM  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test245");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.platformapispecif");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test246");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("JAVA VIRTUAL MACHINE SPECIFICATION", "", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test247");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                        1410040410", 37);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                        1410040410" + "'", str2.equals("                                        1410040410"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 1420);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test250");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', 0, (int) (short) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test251");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "1A10A100A1A100A-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test252");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausers/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test253");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test254");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "140", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test255");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test256");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "juSERSjSOPHIEjdOCUMENTSjDE...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test257");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "NEMNORIVNeSCIHPARgc.TWA.NU", (java.lang.CharSequence) "10.a0.0", 1600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test258");
        long[] longArray6 = new long[] { 1, (byte) 1, 52L, 2, (byte) 0, 4 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 31, 19);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "141452424044" + "'", str12.equals("141452424044"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test259");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("NEMNORIVNeSCIHPARgc.TWA.NU");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test260");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("### hO..AVAj####", "####################", 760);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test261");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.l0140400141");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test262");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "x86_64                                                                                              ", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ", 1410040410);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test263");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                      ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test264");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) " hO..AVAj", (java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test265");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "1.0a97.0", 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                     Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("                     Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("51.", 19, 45);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test268");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "Java Ho...", 1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("1.0 0.0 0.", strArray1, strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "24.80-b11");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0 0.0 0." + "'", str6.equals("1.0 0.0 0."));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str8.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("86_", "sPECIFICATION api pLATFORM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "86_" + "'", str2.equals("86_"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "############################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("JAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPH");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPH" + "'", str1.equals("JAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPHJAVAPLATFORMAPISPECI/USERS/SOPH"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test272");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("#a4a4", "jAVA hOTsPOT(tm) 64-bIT sERVER vm", 56);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "0.0410.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test273");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hO..AVAj");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.71.71.71.71.71.71.71.71.71....", "Eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.71.71.71.71.71.71.71...." + "'", str2.equals("1.71.71.71.71.71.71.71.71.71...."));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test275");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) " jAVA hOTsPOT(tm) 64-bIT sERVER vm  ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test276");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Hi!", " ");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test277");
        char[] charArray6 = new char[] { ' ', '#' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', 0, (int) (short) -1);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", charArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "a444 4 4 44", charArray6);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "35a100a100a-1a31", charArray6);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 56, 0);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + " ##" + "'", str14.equals(" ##"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test278");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8", "10a11a10a10...", 20);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8" + "'", str5.equals("8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.0 97");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 97" + "'", str1.equals("1.0 97"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test280");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Mac OS", (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.0410.0-1", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0410.0-1" + "'", str3.equals("0.0410.0-1"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test282");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(2, 28, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test283");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "### hO..AVAj####                                                                                                                               ", 61);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test284");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library/Jntents/Home/jre/lib/endorse", "");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "35#100#100#-1#31                      ");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("                                      ");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach(" Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..                   ", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + " Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..                   " + "'", str8.equals(" Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..avaJ Ho..                   "));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaEihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "44444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaEihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaEihpos/sresU/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test286");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("#################################", "10 -1 -1 10 100", "  ###########################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#################################" + "'", str3.equals("#################################"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("\n", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test288");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm", (java.lang.CharSequence) "-1#0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test289");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaclass [Ljaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1.7.0_80", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test290");
        char[] charArray6 = new char[] { ' ', '#' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', 0, (int) (short) -1);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', (int) '#', 8);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1.0", charArray6);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                    ", charArray6);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "X0.0a10.0X", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test291");
        float[] floatArray3 = new float[] { 28, 6, 10.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', 100, 70);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.Class<?> wildcardClass10 = floatArray3.getClass();
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 28.0f + "'", float4 == 28.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 28.0f + "'", float9 == 28.0f);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 28.0f + "'", float11 == 28.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test293");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 39, 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test294");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaausers/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 17, 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test295");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "              1 / u SERS / SOPHIE ./ u SERS / SOPHIE 7 / u SERS / SOPHIE ./ u SERS / SOPHIE 0 / u SERS / SOPHIE _ / u SERS / SOPHIE 80", 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("10 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 1" + "'", str1.equals("10 1"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "a 4       4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test298");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "PlatformAPISpeciPlatformAPISpeciPlatformAPIS1.0 97.ormAPISpeciPlatformAPISpeciPlatformA.0#10.0", (java.lang.CharSequence) "PlatformAPISpeca1a001a01a11a011-a001a1a001a01a11a0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          " + "'", str1.equals("          "));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test300");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwawt.macosx.CPrinterJob", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test301");
        char[] charArray5 = new char[] { ' ', '#' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 0, (int) (short) -1);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray5);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", charArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray5, '4');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.14.", charArray5);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray5, '4');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " ##" + "'", str13.equals(" ##"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + " 4#" + "'", str15.equals(" 4#"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + " 4#" + "'", str18.equals(" 4#"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test302");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a0" + "'", str8.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                     1.8                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                      ", 17, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                     1.8                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                      " + "'", str3.equals("                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                     1.8                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                                                                             46_68xtiklooTCWL.xsocam.twawl.nus                      "));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test304");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0" + "'", str1.equals("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04" + "'", str1.equals("1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test306");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10 1", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    " + "'", str2.equals("    "));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test308");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                               X86_6X86_6                                ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 73 + "'", int1 == 73);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test309");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(" a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test310");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test312");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Aaaaaaaaaaa10a32a1a32aaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test313");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "JavaPlatformAPISpecification");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test314");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray9);
        java.lang.CharSequence charSequence12 = null;
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.split(":", "1.5");
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1a10a100a1a100a-1", ":", 100);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray16, strArray20);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence12, (java.lang.CharSequence[]) strArray20);
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", (int) (short) 100);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray20, strArray26);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray26, "a 4 a 4 4", 27, 2);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.replaceEach("       ...0a-1a31", strArray5, strArray26);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str27.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "       ...0a-1a31" + "'", str32.equals("       ...0a-1a31"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("NEMNORIVNeSCIHPARgc.TWA.NUS                                                              ", "                                                       AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NEMNORIVNeSCIHPARgc.TWA.NUS                                                              " + "'", str2.equals("NEMNORIVNeSCIHPARgc.TWA.NUS                                                              "));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test316");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44444444444444444444444444", "en                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test317");
        char[] charArray2 = new char[] {};
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0 0.0 0.0", charArray2);
        java.lang.Class<?> wildcardClass5 = charArray2.getClass();
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray2, '#', 392, 5);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test318");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.0 97.", (java.lang.CharSequence) "             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test319");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test320");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1#0", '4');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 134, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("su 3", 2434, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               su 3                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               su 3                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               "));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test323");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "NEMNORIVNeSCIHPARgc.TWA.NUS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                           US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                           us" + "'", str1.equals("                                                           us"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Mac OS ", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEh/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEi/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEe/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS " + "'", str2.equals("Mac OS "));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test326");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("x86_64                                                                                              ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test327");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray2 = null;
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7.0_80", strArray1, strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 68);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test329");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library/Jntents/Home/jre/lib/endorse", "");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "35#100#100#-1#31                      ");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("/Library/Jntents/Home/jre/lib/endorse", "");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaa", "/", 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.04", strArray9, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.04" + "'", str14.equals("0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.04"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test330");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("a4444444a444444///////////////////a4444444a444444", "1.5                                                                          ", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test331");
        float[] floatArray1 = new float[] { (-1L) };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("NTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                    jAVA hOTsPOT(tm) 64-bIT sERVER vm", "                         ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test333");
        long[] longArray4 = new long[] { 31L, 10L, 28, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.Class<?> wildcardClass6 = longArray4.getClass();
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 0, 1790);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 31L + "'", long8 == 31L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 31L + "'", long10 == 31L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31L + "'", long11 == 31L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31L + "'", long12 == 31L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test334");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("x86_64 ...x86_64 10a1x86_64 ...x86_64");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test335");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test336");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Ho..avaJ", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Ho..avaJ" + "'", str2.equals("Ho..avaJ"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test338");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test339");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "46_68xtiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str6.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test340");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10#32#1#32", (java.lang.CharSequence) "NEMNORIVNeSCIHPARgc.TWA.NUS 40                                                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test342");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1a0", '#');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.0a97.0", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 391, (int) (short) -1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1a0" + "'", str6.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1a0" + "'", str11.equals("-1a0"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test343");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 2);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 68, 28);
        int int19 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1043241432" + "'", str8.equals("1043241432"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1043241432" + "'", str10.equals("1043241432"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10 32" + "'", str14.equals("10 32"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 32 + "'", int19 == 32);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test344");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "                                 Java Ho...                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test345");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test346");
        char[] charArray9 = new char[] { 'a', '4', 'a', '4', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophi", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444444444444444441.44444444444444444444444444", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test347");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.0 97.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 97." + "'", str1.equals("1.0 97."));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test349");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1#0", 16, 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test350");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("10.14.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14." + "'", str1.equals("10.14."));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test351");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Ho...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test352");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "JAVA HO...", 68);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                                            1a01                                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test354");
        long[] longArray2 = new long[] { (short) 1, (byte) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', (int) '4', (int) (short) 1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 97, 0);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test355");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', (int) (short) 10, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', 97, 52);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 94, 29);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 73, 6);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1#0" + "'", str10.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1a10a100a1a100a-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.lwawt.macosx.CPrinterJob", 89, 134);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("0.0 0.0 0.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0 0.0 0.1" + "'", str1.equals("0.0 0.0 0.1"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test359");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10 1", (java.lang.CharSequence) "aa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test360");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                   4444444444444                    ", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("00.0410.0#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#0.0410.0-1", 0, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "00.0410.0#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.041" + "'", str3.equals("00.0410.0#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.041"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test362");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0140400141", "JAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest16.test363");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
//        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
//        boolean boolean8 = javaVersion2.atLeast(javaVersion4);
//        boolean boolean9 = javaVersion0.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str11 = javaVersion10.toString();
//        boolean boolean12 = javaVersion4.atLeast(javaVersion10);
//        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean15 = javaVersion13.atLeast(javaVersion14);
//        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion16);
//        java.lang.String str18 = javaVersion16.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean20 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion19);
//        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean23 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion22);
//        boolean boolean24 = javaVersion21.atLeast(javaVersion22);
//        boolean boolean25 = javaVersion19.atLeast(javaVersion21);
//        boolean boolean26 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion19);
//        org.apache.commons.lang3.JavaVersion javaVersion27 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean28 = javaVersion19.atLeast(javaVersion27);
//        boolean boolean29 = javaVersion16.atLeast(javaVersion19);
//        boolean boolean30 = javaVersion13.atLeast(javaVersion19);
//        boolean boolean31 = javaVersion10.atLeast(javaVersion19);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.2" + "'", str11.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.8" + "'", str18.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion27 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion27.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test364");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "#########################################################a4a4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test365");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "1043241432");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strArray15);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test366");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1################", "##########################                              ", "13a1-a0...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "11111111111111111" + "'", str3.equals("11111111111111111"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test368");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 97, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("j#v# Pl#tform API Specific#tion                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ", "1.0 97.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j#v# Pl#tform API Specific#tion                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   " + "'", str2.equals("j#v# Pl#tform API Specific#tion                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   "));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test370");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "         I", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 142 + "'", int2 == 142);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test371");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "0.0a14.0a38.0a10.0", (java.lang.CharSequence) "  ##########################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test372");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".nus", "          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   ", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                     A");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test374");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest16.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }
}

