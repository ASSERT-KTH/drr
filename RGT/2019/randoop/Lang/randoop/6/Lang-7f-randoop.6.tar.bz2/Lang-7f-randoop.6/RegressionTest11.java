import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest11 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("              eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "              eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str3.equals("              eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        " + "'", str1.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        "));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test003");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest11.test004");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
//        boolean boolean9 = javaVersion6.atLeast(javaVersion7);
//        boolean boolean10 = javaVersion4.atLeast(javaVersion6);
//        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean13 = javaVersion4.atLeast(javaVersion12);
//        boolean boolean14 = javaVersion2.atLeast(javaVersion12);
//        boolean boolean15 = javaVersion0.atLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion16);
//        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean20 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion19);
//        boolean boolean21 = javaVersion18.atLeast(javaVersion19);
//        boolean boolean22 = javaVersion16.atLeast(javaVersion18);
//        boolean boolean23 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion16);
//        org.apache.commons.lang3.JavaVersion javaVersion24 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean25 = javaVersion16.atLeast(javaVersion24);
//        org.apache.commons.lang3.JavaVersion javaVersion26 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean27 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion26);
//        org.apache.commons.lang3.JavaVersion javaVersion28 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion29 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean30 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion29);
//        boolean boolean31 = javaVersion28.atLeast(javaVersion29);
//        boolean boolean32 = javaVersion26.atLeast(javaVersion28);
//        boolean boolean33 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion26);
//        org.apache.commons.lang3.JavaVersion javaVersion34 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean35 = javaVersion26.atLeast(javaVersion34);
//        boolean boolean36 = javaVersion24.atLeast(javaVersion26);
//        org.apache.commons.lang3.JavaVersion javaVersion37 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str38 = javaVersion37.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion39 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean40 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion39);
//        org.apache.commons.lang3.JavaVersion javaVersion41 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean42 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion41);
//        org.apache.commons.lang3.JavaVersion javaVersion43 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion44 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean45 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion44);
//        boolean boolean46 = javaVersion43.atLeast(javaVersion44);
//        boolean boolean47 = javaVersion41.atLeast(javaVersion43);
//        boolean boolean48 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion41);
//        org.apache.commons.lang3.JavaVersion javaVersion49 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean50 = javaVersion41.atLeast(javaVersion49);
//        boolean boolean51 = javaVersion39.atLeast(javaVersion49);
//        boolean boolean52 = javaVersion37.atLeast(javaVersion39);
//        org.apache.commons.lang3.JavaVersion javaVersion53 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        java.lang.String str54 = javaVersion53.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion55 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        boolean boolean56 = javaVersion53.atLeast(javaVersion55);
//        boolean boolean57 = javaVersion37.atLeast(javaVersion55);
//        java.lang.String str58 = javaVersion55.toString();
//        boolean boolean59 = javaVersion26.atLeast(javaVersion55);
//        boolean boolean60 = javaVersion0.atLeast(javaVersion55);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion24 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion24.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion26 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion26.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion28 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion28.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion29 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion29.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion34 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion34.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion37 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion37.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1.8" + "'", str38.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion39 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion39.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion41 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion41.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion43 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion43.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion44 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion44.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion49 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion49.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion53 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion53.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "1.4" + "'", str54.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + javaVersion55 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion55.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "1.4" + "'", str58.equals("1.4"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test005");
        float[] floatArray2 = new float[] { (short) 1, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', (int) ' ', (int) (byte) -1);
        float float15 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a97.0" + "'", str4.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0 97.0" + "'", str6.equals("1.0 97.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0a97.0" + "'", str8.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0 97.0" + "'", str10.equals("1.0 97.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 97.0f + "'", float15 == 97.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test007");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("PLATFORMAPISPECIF", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test008");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Jntents/Home/jre/lib/endorsed", "");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.0", "                                                             ", (int) ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("Platform API Specification", strArray4, strArray8);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.Class<?> wildcardClass14 = strArray13.getClass();
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("1a10a100a1a100a-", strArray8, strArray13);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "141452424044", 6, 89);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Platform API Specification" + "'", str9.equals("Platform API Specification"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1a10a100a1a100a-" + "'", str15.equals("1a10a100a1a100a-"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test009");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("##", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 42148, 40);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("##aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test011");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) '4', (-1));
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 56, 4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test012");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "Platform35#100#100#-1#31API35#100#100#-1#31Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test013");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("e/lib/endorse", 1790L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1790L + "'", long2 == 1790L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "###################################################1 10 100 1 100 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test015");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("O...");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test016");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1 / u SERS / SOPHIE ./ u SERS / SOPHIE 7 / u SERS / SOPHIE ./ u SERS / SOPHIE 0 / u SERS / SOPHIE _ / u SERS / SOPHIE 80", (java.lang.CharSequence) "/Users/sophi", 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test017");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("4444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444" + "'", str1.equals("4444444444"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test018");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, 'a', 61, (int) 'a');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test019");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test020");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray6, strArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "...0-131", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + ":" + "'", str13.equals(":"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test021");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#0", 397);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Mac OS X", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test023");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                 Java Ho...                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                 JAVA HO...                                 " + "'", str1.equals("                                 JAVA HO...                                 "));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test024");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("      vaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test025");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("aaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test026");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 19, (float) 61L, (float) 61);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 19.0f + "'", float3 == 19.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test027");
        double[] doubleArray3 = new double[] { 1, (short) 0, 0L };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a', 14, 10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#');
        double double15 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double16 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0 0.0 0.0" + "'", str8.equals("1.0 0.0 0.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.0#0.0#0.0" + "'", str14.equals("1.0#0.0#0.0"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test028");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1", (java.lang.CharSequence) "Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test029");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                              ", "", 1410040410, 72);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                              " + "'", str4.equals("                              "));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test030");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 8, (int) (byte) -1);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 392, 31);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test031");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "PlatformAPISpeci", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test032");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4444L, (double) 20L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4444.0d + "'", double3 == 4444.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test033");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', (int) '4', (int) ' ');
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1a0" + "'", str13.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1#0" + "'", str15.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1a0" + "'", str17.equals("-1a0"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test034");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1.0", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (short) -1, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test035");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("24.80-b11", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test036");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0.0a10.0", (java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test037");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "-1#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("         I", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         I" + "'", str3.equals("         I"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                 Java Ho...                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                 Java Ho...                                 " + "'", str1.equals("                                 Java Ho...                                 "));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test040");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) '4', 17);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test041");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.AWT.cgRAPHICSeNVIRONMENT", "Platform API Specif", (int) (byte) 0);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Jntents/Home/jre/lib/endorsed", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 38 + "'", int5 == 38);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#UN.#WT.#gR##H#C##NV#RONMENT" + "'", str7.equals("#UN.#WT.#gR##H#C##NV#RONMENT"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("platformapispecif", "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("73", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "73" + "'", str2.equals("73"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test044");
        int[] intArray1 = new int[] { 73 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "73" + "'", str3.equals("73"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 73 + "'", int4 == 73);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test045");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((-1L), 6L, (long) 70);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 70L + "'", long3 == 70L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test046");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("\n", '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 31, 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 98, 38);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "\n" + "'", str10.equals("\n"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test047");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("6907720651_38205_lp.pXXOnar_nur/pMt/j4st#################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test048");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp(" Java HotSpot(TM) 64-Bit Server VM  ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Java HotSpot(TM) 64-Bit Server VM  " + "'", str2.equals(" Java HotSpot(TM) 64-Bit Server VM  "));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test050");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 98, (double) 12, 97.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEh/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEi/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEe/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSE", "                            ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test052");
        float[] floatArray2 = new float[] { (short) 1, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a97.0" + "'", str4.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test053");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "a1a001a01a11a011-a001a1a001a01a11a0", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm", 89, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm" + "'", str3.equals("java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test055");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 0", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("nEMNORIVNeSCIHPARgc.TWA.NUS                                                              ", "sun.lwawt.macosx.CPrinterJob", "             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "nEMNORIVNeSCIHPARgc.TWA.NUS                                                              " + "'", str3.equals("nEMNORIVNeSCIHPARgc.TWA.NUS                                                              "));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test057");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 97, 5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 2748, (int) (byte) 10);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 217, 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test058");
        char[] charArray6 = new char[] { '#', '4', '4' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ', (int) (byte) 100, 2);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-", charArray6);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " 4#", charArray6);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#a4a4" + "'", str8.equals("#a4a4"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test059");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 100, (long) 690, (long) 94);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 690L + "'", long3 == 690L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "1.81.81.81.81.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.81.81.81.81.8" + "'", str2.equals("1.81.81.81.81.8"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("13.0#32.0#32.0#52.0#8.0", "wawl.nus", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0" + "'", str3.equals("13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0wawl.nus13.0#32.0#32.0#52.0#8.0"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test062");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("6_64");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test063");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "platformapispecif");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test064");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "A100A-", (java.lang.CharSequence) "####################################################", 134);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("141452424044                                                                                     ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "141452424044                                                                                     " + "'", str2.equals("141452424044                                                                                     "));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0.0a10.", "                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0a10." + "'", str2.equals("0.0a10."));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test067");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("O...", "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a1010a32a1a321a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10", 76);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu", 72);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu" + "'", str2.equals("                                8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test070");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "       SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("##########################                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########################" + "'", str1.equals("##########################"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 00 # 1 - 0 . 0140 . 0", "10.14.3", 38);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test073");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-", (int) (byte) 10, "############################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-" + "'", str3.equals("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test074");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                    ", 68);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test075");
        float[] floatArray2 = new float[] { (short) 1, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a97.0" + "'", str4.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0#97.0" + "'", str6.equals("1.0#97.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 97.0f + "'", float7 == 97.0f);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test077");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                                                             46_68xtiklooTCWL.xsocam.twawl.nus", (java.lang.CharSequence) "10 1", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test078");
        char[] charArray6 = new char[] { ' ', '#' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', 0, (int) (short) -1);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", charArray6);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API Specification", charArray6);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-140", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test079");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("a#4#a#4#4", strArray5, strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, 'a');
        java.lang.String[] strArray12 = null;
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("jAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION", strArray8, strArray12);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "a#4#a#4#4" + "'", str9.equals("a#4#a#4#4"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "jAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION" + "'", str13.equals("jAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test080");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 0, (int) (byte) 0);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10#32#1#32" + "'", str7.equals("10#32#1#32"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test081");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.0 97", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test082");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1 / u SERS / SOPHIE ./ u SERS / SOPHIE 7 / u SERS / SOPHIE ./ u SERS / SOPHIE 0 / u SERS / SOPHIE _ / u SERS / SOPHIE 80", (java.lang.CharSequence) "1.0 97.", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test083");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.4", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray3);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en...", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test084");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "class [Lja");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096" + "'", str1.equals("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test086");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 217);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test087");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10#32#1#32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#32#1#32" + "'", str1.equals("10#32#1#32"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test089");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "java hotspot(tm) 64-bit server vm", "1a10a100a1a100a-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test090");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", "Library/Jntents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test091");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "31#10#28#10", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test092");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("  ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test093");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "1.097.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-1010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class [Ljava.lang.String;-10", 46);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test094");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test095");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "10.a0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test096");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "       Sophie", (java.lang.CharSequence) "141452424044                                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test097");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en...", "                                                   java Platform API Specification                                                    ", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "j#v# Pl#tform API Sp");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test098");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.0 97.0", (java.lang.CharSequence) "###############################4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 392);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test099");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("A100A-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test100");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test101");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) (short) 10, (int) (short) 10);
        int int15 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 9, 36);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#32#1#32" + "'", str10.equals("10#32#1#32"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test102");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                                          hi!", (java.lang.CharSequence) "...0a-1a31...0a-1a31...0a-1a31...0a-1a31...0a-1a4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test103");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "#a4a4     ", (java.lang.CharSequence) "JAVApLATFORMapisPECI/Users/soph ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test104");
        float[][][] floatArray0 = new float[][][] {};
        float[][][][] floatArray1 = new float[][][][] { floatArray0 };
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray1);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("a#4#a#4#4", 77);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a#4#a#4#4" + "'", str2.equals("a#4#a#4#4"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test106");
        long[] longArray4 = new long[] { 31L, 10L, 28, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.Class<?> wildcardClass6 = longArray4.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', (int) '#', 0);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test107");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                 JAVA HO...                                 ", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test108");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("-140                                                                                                ", "NEMNORIVNeSCIHPARgc.TWA.NUS ", 0, 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "NEMNORIVNeSCIHPARgc.TWA.NUS 40                                                                                                " + "'", str4.equals("NEMNORIVNeSCIHPARgc.TWA.NUS 40                                                                                                "));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test109");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/...", (java.lang.CharSequence) "                                 JAVA HO...                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test110");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass6 = intArray4.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 1410040410, 17);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, '#', 2748, 50);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1043241432" + "'", str8.equals("1043241432"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test111");
        char[] charArray2 = new char[] {};
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.4", charArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray2, '#');
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test112");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Ho..ava");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("aaaaaaaaaaaaaaaaaats4j/tmp/run_randoop.pl_50283_1560277096aaaaaaaaaaaaaaaaaaa", "class [Lja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaats4j/tmp/run_randoop.pl_50283_1560277096aaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaats4j/tmp/run_randoop.pl_50283_1560277096aaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                                        1410040410", "j#v# Pl#tform API Specific#tion", ":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                        1410040410" + "'", str3.equals("                                        1410040410"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test115");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 9, 690);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test116");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test117");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10 -1 -1 10 100", "10 1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test118");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                   ", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment141452424044                                                                                     141452424044                                                                                     141452424044                                                                                     141452424044                                                                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test119");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.0a97.0", (int) (byte) 10);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification", "10#32#1#32");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a", strArray9, strArray12);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1", "1.0a97.0", (int) (short) 1);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray9, strArray19);
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "Oracle Corporation", (int) (short) 0);
        java.lang.String[] strArray28 = org.apache.commons.lang3.StringUtils.split("Java Ho..", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray25, strArray28);
        java.lang.Class<?> wildcardClass30 = strArray28.getClass();
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.replaceEach("##################", strArray9, strArray28);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.replaceEach("                                        1410040410", strArray2, strArray9);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Java Platform API Specification" + "'", str14.equals("Java Platform API Specification"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a" + "'", str15.equals("       sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a"));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "##################" + "'", str31.equals("##################"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "                                        1410040410" + "'", str32.equals("                                        1410040410"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0.0a10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0a10.0" + "'", str1.equals("0.0a10.0"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test121");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.0#97.", "sun.l0140400141", "              Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test122");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("UTF-8", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "          ", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "#a4a4                                              ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTF-8" + "'", str6.equals("UTF-8"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test123");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10#32#1#32" + "'", str7.equals("10#32#1#32"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test124");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "0a-/r/ar/0r-/SOPr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a-/r/ar/0r-/SOPr" + "'", str2.equals("0a-/r/ar/0r-/SOPr"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "                                  1.8                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test127");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test128");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1A10A100A1A100A-1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test129");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04", (java.lang.CharSequence) "-1.0#10.0#1.0#-1.0", 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test130");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Ho..", ":");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("  ###########################", "Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  ###########################" + "'", str2.equals("  ###########################"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test132");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "sOPHIE1a10a100a1a100a-11a10a100a1a100a-11a10a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test133");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80", "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "x86_64");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("en", strArray3, strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "en" + "'", str7.equals("en"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "mixed mode" + "'", str8.equals("mixed mode"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "mixed mode" + "'", str10.equals("mixed mode"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("-1a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a" + "'", str1.equals("-1a"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("...0a-1a31...0a-1a31...0a-1a31...0a-1a31...0a-1a4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A", (int) '4', 1586);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A" + "'", str3.equals("444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test136");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 56);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55 + "'", int2 == 55);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0.0410.0", "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0410.0" + "'", str2.equals("0.0410.0"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test138");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 42, (float) 1410040410, 5.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.41004045E9f + "'", float3 == 1.41004045E9f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0" + "'", str2.equals("0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test140");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', (int) (short) 10, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1#0" + "'", str10.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1#0" + "'", str12.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test141");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 4444, 690L, (long) 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4444L + "'", long3 == 4444L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test142");
        double[] doubleArray1 = new double[] { (byte) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', (int) (short) 1, 0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0" + "'", str6.equals("1.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test143");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("-1.0410.041.04-1.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test144");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", "/Library/Jntents/Home/jre/lib/endorsed###########################################################", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test145");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "1.5aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.5aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", charSequence2.equals("1.5aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test146");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 97);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test147");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 4444, (double) 17.0f, 4.444444444444E12d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 17.0d + "'", double3 == 17.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test148");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Eihpos/sresU/", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test149");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray9 = new char[] { 'a', '4', 'a', '4', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-140                                                                                                ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/USERS/SOPHI", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(" jAVA hOTsPOT(tm) 64-bIT sERVER vm  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " jAVA hOTsPOT(tm) 64-bIT sERVER vm  " + "'", str1.equals(" jAVA hOTsPOT(tm) 64-bIT sERVER vm  "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test152");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                  1.8                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test153");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("  ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test154");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 27, (double) (-1L), (double) 28L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test155");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test156");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "0.0410.0", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0.0410.0" + "'", charSequence2.equals("0.0410.0"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test157");
        char[] charArray4 = new char[] { ' ', '#' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray4, '4', 0, (int) (short) -1);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0a97.", charArray4);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1 0", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("a444 4 4 44a444 4 4 4///////////////////a444 4 4 44a444 4 4 4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a4444444a444444///////////////////a4444444a444444" + "'", str1.equals("a4444444a444444///////////////////a4444444a444444"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test159");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("java virtual machine specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str1.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test160");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "   1.0 97.", (java.lang.CharSequence) "ary/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa" + "'", str3.equals("aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa aaaaaaaaaa"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test162");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "0140400141", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test163");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" 4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus", "8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test164");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("java hotspot(tm) 64-bit server vm", (-140.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-140.0d) + "'", double2 == (-140.0d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test165");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ".nus", (java.lang.CharSequence) "0.0410.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test166");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                           US", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("ocuments/defects4j/framework/lib", 690);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ocuments/defects4j/framework/lib                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  " + "'", str2.equals("ocuments/defects4j/framework/lib                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  "));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test168");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0 0.0 0.0", "Oracle Corporation");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "######################################################################sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("##########################", "Java Platform API Specification", 392);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("4444444444444444444444440.79a0.14444444444444444441.0#0.0#0.0", "8utf-8utf-8utf-8utf-8utf-8utf-8utf-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444440.79a0.14444444444444444441.0#0.0#0.0" + "'", str2.equals("4444444444444444444444440.79a0.14444444444444444441.0#0.0#0.0"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test172");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "6907720651_38205_lp.pXXOnar_nur/pMt/j4st#################################", (java.lang.CharSequence) "-140                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test173");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "CLASS [LJAVA.LANG.STRING;", (java.lang.CharSequence) "##################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("#UN.#WT.#gR##H#C##NV#RONMENT", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#UN.#WT.#gR##H#C##NV#RONMENT" + "'", str2.equals("#UN.#WT.#gR##H#C##NV#RONMENT"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test175");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.l0140400141", (java.lang.CharSequence) "1043241432", 760);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test176");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils1 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils2 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils3 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils4 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray5 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0, numberUtils1, numberUtils2, numberUtils3, numberUtils4 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray6 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray5 };
        org.apache.commons.lang3.math.NumberUtils numberUtils7 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils8 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils9 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils10 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils11 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray12 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils7, numberUtils8, numberUtils9, numberUtils10, numberUtils11 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray13 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray12 };
        org.apache.commons.lang3.math.NumberUtils numberUtils14 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils15 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils16 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils17 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils18 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray19 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils14, numberUtils15, numberUtils16, numberUtils17, numberUtils18 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray20 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray19 };
        org.apache.commons.lang3.math.NumberUtils[][][] numberUtilsArray21 = new org.apache.commons.lang3.math.NumberUtils[][][] { numberUtilsArray6, numberUtilsArray13, numberUtilsArray20 };
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray21);
        org.junit.Assert.assertNotNull(numberUtilsArray5);
        org.junit.Assert.assertNotNull(numberUtilsArray6);
        org.junit.Assert.assertNotNull(numberUtilsArray12);
        org.junit.Assert.assertNotNull(numberUtilsArray13);
        org.junit.Assert.assertNotNull(numberUtilsArray19);
        org.junit.Assert.assertNotNull(numberUtilsArray20);
        org.junit.Assert.assertNotNull(numberUtilsArray21);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" Ho..avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ho..avaJ" + "'", str1.equals("Ho..avaJ"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test178");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", "10 1", "SUN.AWT.cgRAPHICSeNVIRONMEN", 68);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              " + "'", str4.equals("x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              "));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test179");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("#################################ts4j/tMp/run_ranOXXp.pl_50283_1560277096");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#################################ts4j/tMp/run_ranOXXp.pl_50283_1560277096" + "'", str1.equals("#################################ts4j/tMp/run_ranOXXp.pl_50283_1560277096"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              ", 1586, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test181");
        char[] charArray3 = new char[] { ' ', '#' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray3, '4', 0, (int) (short) -1);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10#-1#-1#10#100", charArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray3, '#', 1586, 40);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test182");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test183");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("###############################");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test184");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("I", "aa4aaa4a4", (int) (short) 100, 391);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Iaa4aaa4a4" + "'", str4.equals("Iaa4aaa4a4"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test185");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A", (java.lang.CharSequence) "R");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test186");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.", "6_64", 392);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test187");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test188");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) '4', (-1));
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) -1 + "'", byte16 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 100 + "'", byte17 == (byte) 100);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/-raa/r/raa/ra/r/", "##################class [Ljava.l...", "### hO..AVAj####");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/-raa/r/raa/ra/r/" + "'", str3.equals("/-raa/r/raa/ra/r/"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "141452424044                                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test191");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) " a#", (java.lang.CharSequence) "JAVApLATFORMapisPECI/Users/soph ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test192");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1 / u SERS / SOPHIE ./ u SERS / SOPHIE 7 / u SERS / SOPHIE ./ u SERS / SOPHIE 0 / u SERS / SOPHIE _ / u SERS / SOPHIE 80", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test193");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(690, 77, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 77 + "'", int3 == 77);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test194");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 391, 13.0f, (float) 56);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 13.0f + "'", float3 == 13.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test195");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1/uSERS/SOPHIE./uSERS/SOPHIE7/uSERS/SOPHIE./uSERS/SOPHIE0/uSERS/SOPHIE_/uSERS/SOPHIE80\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "su 32");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a1010a32a1a321a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("...0-131", " ##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...0-131" + "'", str2.equals("...0-131"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test199");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("####################################################", "                               ", 5, 17);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#####                               ###################################" + "'", str4.equals("#####                               ###################################"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test200");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("-10");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test201");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaJava(TM) SE Runtime EnvironmentaJava Virtual Machine Specification", "/uSERS/SOPHIE", 46);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "00.0410.0#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#0.0410.0-1");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("444", 72, 1586);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.awt.CGraphicsEnvironment141452424044                                                                                     141452424044                                                                                     141452424044                                                                                     141452424044                                                                  ", "10A100A1A100A-11A10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment141452424044                                                                                     141452424044                                                                                     141452424044                                                                                     141452424044                                                                  " + "'", str2.equals("sun.awt.CGraphicsEnvironment141452424044                                                                                     141452424044                                                                                     141452424044                                                                                     141452424044                                                                  "));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                                   java Platform API Specification                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test205");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 0, (double) 397, (double) 40);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test206");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", ":-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04-1.0:", 25);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test207");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1a0", '#');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) (byte) 10, 1398);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test208");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "73");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test209");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.lwawt.macosx.LWCToolkit", (float) 17);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 17.0f + "'", float2 == 17.0f);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test210");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "#####                               ###################################", (java.lang.CharSequence) "Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test211");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', (int) '4', (int) ' ');
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1a0" + "'", str13.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1a0" + "'", str15.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1a0" + "'", str17.equals("-1a0"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                           US", 1586);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                           US" + "'", str2.equals("                                                           US"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test213");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', 21, 89);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 21");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.0#0.0#0.0", 12, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test215");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1L, (-140.0f), (float) 623);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-140.0f) + "'", float3 == (-140.0f));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1#10#100#1#100#-1", 2748);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#10#100#1#100#-1" + "'", str2.equals("1#10#100#1#100#-1"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test217");
        java.lang.CharSequence charSequence3 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ":", (int) 'a', (int) (short) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/uSERS/SOPHIE", "en");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Jntents/Home/jre/lib/endorsed", strArray6, strArray15);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence3, (java.lang.CharSequence[]) strArray15);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.0 97.0", (java.lang.CharSequence[]) strArray15);
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/uSERS/SOPHIE", 0);
        int int24 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.0 97.", (java.lang.CharSequence[]) strArray23);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("jAVApLATFORMapisPECI/Users/sophi", strArray15, strArray23);
        int int26 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                 JAVA HO...                                 ", (java.lang.CharSequence[]) strArray15);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "/Library/Jntents/Home/jre/lib/endorsed" + "'", str16.equals("/Library/Jntents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "jAVApLATFORMapisPECI/Users/sophi" + "'", str25.equals("jAVApLATFORMapisPECI/Users/sophi"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test218");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 20, 100.0d, (double) 25);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 20.0d + "'", double3 == 20.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("X0.0a10.0X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X0.0a10.0X" + "'", str1.equals("X0.0a10.0X"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test220");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("e/lib/endorse", 391, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e/lib/endorse##########################################################################################################################################################################################################################################################################################################################################################################################" + "'", str3.equals("e/lib/endorse##########################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("HI!", "NTENTS/HOME/JRE/LIB/ENDORSE", 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!" + "'", str3.equals("HI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!NTENTS/HOME/JRE/LIB/ENDORSEHI!"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test222");
        char[] charArray8 = new char[] { 'a', '4', ' ', ' ', ' ', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!", charArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a#4# # # #4" + "'", str11.equals("a#4# # # #4"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "a444 4 4 44" + "'", str13.equals("a444 4 4 44"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "a444 4 4 44" + "'", str15.equals("a444 4 4 44"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test223");
        double[] doubleArray3 = new double[] { 1, (short) 0, 0L };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4', 32, 17);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0 0.0 0.0" + "'", str8.equals("1.0 0.0 0.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test224");
        int[] intArray4 = new int[] { (short) 10, ' ', 1, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a32a1a32" + "'", str9.equals("10a32a1a32"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test225");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("10.14.310.14.310.14PlatformAPISpecif", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test226");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test227");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "class [Lj");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test228");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "                                8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu8-ftu");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1a10a100a1a100a-1", "141452424044", "10.14.310.14.310.14PlatformAPISpecif");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1a10a100a1a100a-1" + "'", str3.equals("1a10a100a1a100a-1"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test230");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "http://java.oracle.com/-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test231");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.0 0.0 0.0", (java.lang.CharSequence) "44444 ##444444", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                           10a1                                            ", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                           10a1                                            " + "'", str2.equals("                                           10a1                                            "));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A" + "'", str2.equals("4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test234");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.0a0.0a0.0", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0a0.0a0.0" + "'", str3.equals("1.0a0.0a0.0"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test235");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test236");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("jAVApLATFORMapisPECI/Users/sophi0141/Jntents/Home/jre/lib/endorse", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test237");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                   4444444444444                    ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.444444444444E12d + "'", double1.equals(4.444444444444E12d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test238");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "NTENTS/HOME/JRE/LIB/ENDORS", (java.lang.CharSequence) "                                           10#32#1#32                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test239");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("SUN.AWT.cgRAPHICSeNVIRONMEN");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", strArray1, strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "a444 4 4 44");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
        org.junit.Assert.assertNull(strArray6);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test240");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 74);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 74 + "'", int2 == 74);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test241");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/80");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("       sOPHIE#################################################################################", "Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test243");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.l0140400141", "JAVAPLATFORMAPISPECI/USERS/SOPH");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Oracle Corporation", "0a-/r/ar/0r-/SOPr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test245");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("http://java.oracle.com/-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-1a0-", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test246");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("444444444444444440.1-#0.1#0.01#0.1-");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test247");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Library/Jntents/Home/jre/lib/endorsed###########################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test248");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("X86_6", "aaaaaaaaaaa10a32a1a32aaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test249");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1.0 97.", (java.lang.CharSequence) "      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                  1.8                                   ", "44444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-140", "31a10a28a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("EN", "###############################aaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "EN" + "'", str2.equals("EN"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test254");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 39, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 39.0f + "'", float3 == 39.0f);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test255");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test256");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "46_6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test257");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1r1 10 100 1 100 -1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test258");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10 32 1 32", "JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.ja");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Platform API Specificatio", (int) (short) -1, "                                                                             46_68xtiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Platform API Specificatio" + "'", str3.equals("Platform API Specificatio"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("4444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444" + "'", str1.equals("444444444444"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test261");
        float[] floatArray2 = new float[] { (short) 1, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 1, 37);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a97.0" + "'", str4.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a97.0" + "'", str7.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 97.0f + "'", float8 == 97.0f);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test262");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...                   46_68x", "1.8:-1.0410.041.04-1.0:-1.0410.041.04-1.0:-1.0410.041.04");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("10.14.", "6907720651_38205_lp.pXXOnar_nur/pMt/j4st#################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14." + "'", str2.equals("10.14."));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("10#-1#-1#10#100", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          10#-1#-1#10#100          " + "'", str2.equals("          10#-1#-1#10#100          "));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test265");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test266");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("MIXED MOD");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test267");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 6.0f, (double) 28, 1790.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0d + "'", double3 == 6.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test268");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                        1410040410", (java.lang.CharSequence) "0.79a0.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test269");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/USERS/SOPHI", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   " + "'", str1.equals("          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   "));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test271");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test272");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "#A4A4", charSequence1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("jAVA hOTsPOT(tm) 64-bIT sERVER vm", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str2.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test274");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test275");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Mac OS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS" + "'", str1.equals("Mac OS"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test276");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ary/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!" + "'", str1.equals("Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!1Hi!"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test278");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Sophie", 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test279");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "X0.0a10.0X");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test280");
        double[] doubleArray4 = new double[] { (-1.0f), 10.0d, 1.0f, (-1L) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 38, (int) (byte) 1);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#', 31, 134);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0410.041.04-1.0" + "'", str7.equals("-1.0410.041.04-1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8", (java.lang.CharSequence) "#################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test282");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                              " + "'", str1.equals("                              "));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test283");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "-1 100 10", 392);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test284");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMEN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test285");
        double[] doubleArray4 = new double[] { (-1.0f), 10.0d, 1.0f, (-1L) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0410.041.04-1.0" + "'", str7.equals("-1.0410.041.04-1.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0#10.0#1.0#-1.0" + "'", str10.equals("-1.0#10.0#1.0#-1.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test286");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("a1a001a01a11a011-a001a1a001a01a11a0", "1.0497.0", 217);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("             /r/ar...", "1a10a100a1a100a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a10a100a1a100a-1" + "'", str2.equals("1a10a100a1a100a-1"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test288");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test289");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test290");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jaJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JAjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JA" + "'", str1.equals("juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JAjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JARjuSERSjSOPHIEjdOCUMENTSjDEFECTS4JjTMPjRUN_RANDOOP.PL_50283_1560277096jTARGETjCLASSES:juSERSjSOPHIEjdOCUMENTSjDEFECTS4JjFRAMEWORKjLIBjTEST_GENERATIONjGENERATIONjRANDOOP-CURRENT.JA"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("  ###########################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  ##########################" + "'", str1.equals("  ##########################"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test292");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.14.3", "/uSERS/SOPHIE", 4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("  #");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("             Hi!             ", strArray4, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-1#", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "NEMNORIVNeSCIHPARgc.TWA.NUS");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1#" + "'", str3.equals("-1#"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test294");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "JAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVApLATFORMapisPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test295");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) 10, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#-1#-1#10#100" + "'", str8.equals("10#-1#-1#10#100"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("class [Lj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Class [Lj" + "'", str1.equals("Class [Lj"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test297");
        long[] longArray4 = new long[] { 31L, 10L, 28, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31a10a28a10" + "'", str7.equals("31a10a28a10"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 31L + "'", long8 == 31L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test298");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("X86_64", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm" + "'", str1.equals("java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test300");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                             ", (int) (short) 0, "####################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                             " + "'", str3.equals("                                                             "));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("-140", 397);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                    -140                                                                                                                                                                                                     " + "'", str2.equals("                                                                                                                                                                                                    -140                                                                                                                                                                                                     "));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test302");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "             /r/ar...", (java.lang.CharSequence) "x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x86_x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test303");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a0" + "'", str8.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-140" + "'", str11.equals("-140"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test304");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) '4', (-1));
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 32, (int) (short) -1);
        java.lang.Class<?> wildcardClass20 = byteArray6.getClass();
        byte byte21 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        try {
            java.lang.String str25 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "  1.");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:   1.");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 10 100 1 100 -1" + "'", str11.equals("1 10 100 1 100 -1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + byte21 + "' != '" + (byte) 100 + "'", byte21 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1a10a100a1a100a-1" + "'", str23.equals("1a10a100a1a100a-1"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test305");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 37, (double) 31L, (double) 14);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 37.0d + "'", double3 == 37.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("0.1-#0.1#0.01#0.1-", 56);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-" + "'", str2.equals("0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-0.1-#0.1#0.01#0.1-"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test307");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java hotspot(tm) 64-bit server vm", "http://java.oracle.com/");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 20, (-1));
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "8utf-8utf-8utf-8utf-8utf-8utf-8utf-8");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test308");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("SUN.AWT.cgRAPHICSeNVIRONMEN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              ", "", "...                   46_68x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              " + "'", str3.equals("X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              "));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("             /r/ar...", 39);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               /r/ar..." + "'", str2.equals("                               /r/ar..."));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test311");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray4 = new char[] { 'a' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "141452424044", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                             ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("10 -1 -1 10 100", "-140");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 -1 -1 10 100" + "'", str2.equals("10 -1 -1 10 100"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1a0", "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "   1.6    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1a0" + "'", str3.equals("1a0"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test314");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.0 0.0 0.");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "10a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 623);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test317");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "a 4 a 4 4", (java.lang.CharSequence) "1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Sophie", "X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", "A4A4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Sophie" + "'", str3.equals("Sophie"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "0.0410.0-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test320");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "10a1", (java.lang.CharSequence) "             /r/ar...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test321");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "86_", (-1), 56);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1a0", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a0" + "'", str2.equals("1a0"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test323");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 56, 217);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test324");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "r-/8ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/_/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/0/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/7/r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-/.//r/ar/r/ar/ar-/SOPHIE/r/ar/r/ar/ar-///r/ar/r/ar/ar-/SERS/r/ar/r/ar/ar-/u/r/ar/r/ar/ar-///r/ar/r/ar/ar-/1/r/ar/r/ar/a/r/");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", 'a');
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray13, strArray17);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("Java HotSpot(TM) 64-Bit Server VM", strArray8, strArray17);
        java.lang.String[] strArray20 = null;
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("#", strArray17, strArray20);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray3, strArray17);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str19.equals("Java HotSpot(TM) 64-Bit Server VM"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "#" + "'", str21.equals("#"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str22.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test325");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreaJava(TM) SE Runtime EnvironmentaJava Virtual Machine Specification", (java.lang.CharSequence) "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test326");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/uSERS/SOPHIE", "sun.lwawt.macosx.LWCToolkitx86_64                                                                                              ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test327");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("#a##a###a#a###a-##a##a###a#a###a-##a##a###a#a##0a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test328");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Iaa4aaa4a4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Iaa4aaa4a4" + "'", str1.equals("Iaa4aaa4a4"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test331");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 35L, (double) 1.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "                                        1410040410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "JAVApLATFORMapisPECI/Users/soph");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str2.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("!iH");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!iH" + "'", str1.equals("!iH"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test336");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 397, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test338");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("A 4 a 4 4");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test339");
        long[] longArray4 = new long[] { 31L, 10L, 28, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.Class<?> wildcardClass6 = longArray4.getClass();
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 31L + "'", long7 == 31L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test340");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("4aaa4a4", 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("x86_64                   ...x86_64              10a1x86_64                   ...x86_64              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64 ...x86_64 10a1x86_64 ...x86_64" + "'", str1.equals("x86_64 ...x86_64 10a1x86_64 ...x86_64"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test343");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("ocuments/defects4j/framework/lib");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test344");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Jntents/Home/jre/lib/endorsed", "a4444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                  ts4j/tmp/run_randoop.pl_50283_1560277096                   ", "10a-1a-1a10a100", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                  ts4j/tmp/run_randoop.pl_50283_1560277096                   " + "'", str3.equals("                  ts4j/tmp/run_randoop.pl_50283_1560277096                   "));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test346");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(19.0f, 35.0f, (float) 13);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 13.0f + "'", float3 == 13.0f);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test347");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 690L, (long) 61);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 690L + "'", long3 == 690L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test348");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test349");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("00.0410.0#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#0.0410.0-1", 73, "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/en...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "00.0410.0#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#0.0410.0-1" + "'", str3.equals("00.0410.0#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#0.0410.0-1"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test350");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("35#1   Hi!    35#10", "##########################", 27);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test351");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', (int) (short) 10, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', 97, 1);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1#0" + "'", str10.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1#0" + "'", str12.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-1 0" + "'", str18.equals("-1 0"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-1a0" + "'", str20.equals("-1a0"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test352");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "java hotspot(tm) 64-bit server vm", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test353");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.l0140400141", (java.lang.CharSequence) "0a-/r/ar/0r-/SOPr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test354");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(89, 100, 56);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 56 + "'", int3 == 56);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test355");
        float[] floatArray3 = new float[] { 10.0f, (-1), 10.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0#-1.0#10.0" + "'", str6.equals("10.0#-1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.04-1.0410.0" + "'", str8.equals("10.04-1.0410.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0a-1.0a10.0" + "'", str11.equals("10.0a-1.0a10.0"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test356");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("73", "444444444444444440.1-#0.1#0.01#0.1-");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("13a1-a0...", "Mac OS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test359");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(1.7f, 0.0f, (float) 8);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test360");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment1S10S100S1S100S-1sun.awt.CGraphicsEnvironment", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test361");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test362");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test363");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1#10#100#1#100#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#10#100#1#100#-1" + "'", str1.equals("1#10#100#1#100#-1"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("class [ljava.lang.string;", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [ljava.lang.string;" + "'", str2.equals("class [ljava.lang.string;"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test366");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "X0.0a10.0X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "13.0#32.0#32.0#52.0#8.0", 1410040410);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/-raa/r/raa/ra/r/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/-raa/r/raa/ra/r/" + "'", str1.equals("/-raa/r/raa/ra/r/"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test369");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie" + "'", str1.equals("Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie       Sophie"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test370");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("PlatformAPISpecif", "x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...x86_64                   ...", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlatformAPISpecif" + "'", str3.equals("PlatformAPISpecif"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test371");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(623, 56, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0.0#10.0", "#a4a4                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0#10.0" + "'", str2.equals("0.0#10.0"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 50, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#0" + "'", str2.equals("1.0#97.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#010.14.310.14.310.14.310.14.310.14.310.14.310.14.310.class[Ljava.lang.String;-1#0"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test375");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Mac OS");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test376");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0a1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar10a11a10a100a1a", (java.lang.CharSequence) "0140400141/Jntents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                                           ", "8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8-FTU8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                           " + "'", str2.equals("                                                                                           "));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test378");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "-1.0#10.0#1.0#-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test379");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Mac OS ", (java.lang.CharSequence) "#-1.0#10.0", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0, 91);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                                   java Platform API Specification                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("...0-131", 89);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...0-131" + "'", str2.equals("...0-131"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "ificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", (java.lang.CharSequence) "#########################################################a4a4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test384");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8", (java.lang.CharSequence) "Eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test385");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sophie");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test386");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10 -1 -1 10 100", (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test387");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0.0410.0", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test388");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Ho..ava");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Ho..ava\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test389");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test390");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("             ", "1a0", 16);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-class [Lj", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0#0.0#0.0", "NEMNORIVNeSCIHPARgc.TWA.NUS 40                                                                                                ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test393");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("4444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 4444 + "'", short1 == (short) 4444);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test394");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("0a-/r/ar/0r-/SOPr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a-/r/ar/0r-/SOPr" + "'", str1.equals("0a-/r/ar/0r-/SOPr"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(".0#10.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0#10.0" + "'", str2.equals(".0#10.0"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test396");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1 / u SERS / SOPHIE ./ u SERS / SOPHIE 7 / u SERS / SOPHIE ./ u SERS / SOPHIE 0 / u SERS / SOPHIE _ / u SERS / SOPHIE 80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1 / u SERS / SOPHIE ./ u SERS / SOPHIE 7 / u SERS / SOPHIE ./ u SERS / SOPHIE 0 / u SERS / SOPHIE _ / u SERS / SOPHIE 80" + "'", str1.equals("1 / u SERS / SOPHIE ./ u SERS / SOPHIE 7 / u SERS / SOPHIE ./ u SERS / SOPHIE 0 / u SERS / SOPHIE _ / u SERS / SOPHIE 80"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test397");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                 Java Ho...                                 ", "Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre", "444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                 4aa                                  " + "'", str3.equals("                                 4aa                                  "));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test398");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0140400141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jar", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jar" + "'", str2.equals("JUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jarJUsersJsophieJDocumentsJdefects4jJtmpJrun_randoop.pl_50283_1560277096JtargetJclasses:JUsersJsophieJDocumentsJdefects4jJframeworkJlibJtest_generationJgenerationJrandoop-current.jar"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test400");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0.0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.000.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0a0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0970.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0.0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test401");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', (int) (short) 10, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 35, (int) (short) 1);
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 3, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1#0" + "'", str10.equals("-1#0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) -1 + "'", short15 == (short) -1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test402");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "35#100#100#-1#31                      ", 39);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Jntents/Home/jre/lib/endorsed###########################################################", 46, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Jntents/Home/jre/lib/endorsed###########################################################" + "'", str3.equals("/Library/Jntents/Home/jre/lib/endorsed###########################################################"));
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest11.test404");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
//        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
//        boolean boolean8 = javaVersion2.atLeast(javaVersion4);
//        boolean boolean9 = javaVersion0.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str11 = javaVersion10.toString();
//        boolean boolean12 = javaVersion4.atLeast(javaVersion10);
//        java.lang.Class<?> wildcardClass13 = javaVersion4.getClass();
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
//        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion17);
//        boolean boolean19 = javaVersion16.atLeast(javaVersion17);
//        boolean boolean20 = javaVersion14.atLeast(javaVersion16);
//        boolean boolean21 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion16);
//        boolean boolean22 = javaVersion4.atLeast(javaVersion16);
//        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean24 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
//        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean26 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion25);
//        org.apache.commons.lang3.JavaVersion javaVersion27 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion28 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean29 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion28);
//        boolean boolean30 = javaVersion27.atLeast(javaVersion28);
//        boolean boolean31 = javaVersion25.atLeast(javaVersion27);
//        boolean boolean32 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion25);
//        org.apache.commons.lang3.JavaVersion javaVersion33 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean34 = javaVersion25.atLeast(javaVersion33);
//        boolean boolean35 = javaVersion23.atLeast(javaVersion33);
//        boolean boolean36 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
//        boolean boolean37 = javaVersion16.atLeast(javaVersion23);
//        org.apache.commons.lang3.JavaVersion javaVersion38 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str39 = javaVersion38.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion40 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean41 = javaVersion38.atLeast(javaVersion40);
//        org.apache.commons.lang3.JavaVersion javaVersion42 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str43 = javaVersion42.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion44 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean45 = javaVersion42.atLeast(javaVersion44);
//        org.apache.commons.lang3.JavaVersion javaVersion46 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean47 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion46);
//        org.apache.commons.lang3.JavaVersion javaVersion48 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean49 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion48);
//        org.apache.commons.lang3.JavaVersion javaVersion50 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        org.apache.commons.lang3.JavaVersion javaVersion51 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean52 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion51);
//        boolean boolean53 = javaVersion50.atLeast(javaVersion51);
//        boolean boolean54 = javaVersion48.atLeast(javaVersion50);
//        boolean boolean55 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion48);
//        org.apache.commons.lang3.JavaVersion javaVersion56 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean57 = javaVersion48.atLeast(javaVersion56);
//        boolean boolean58 = javaVersion46.atLeast(javaVersion56);
//        boolean boolean59 = javaVersion44.atLeast(javaVersion46);
//        boolean boolean60 = javaVersion38.atLeast(javaVersion44);
//        boolean boolean61 = javaVersion16.atLeast(javaVersion44);
//        java.lang.String str62 = javaVersion44.toString();
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.2" + "'", str11.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion27 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion27.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion28 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion28.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion33 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion33.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion38 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion38.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1.8" + "'", str39.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion40 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion40.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion42 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion42.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1.8" + "'", str43.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + javaVersion44 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion44.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion46 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion46.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion48 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion48.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion50 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion50.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + javaVersion51 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion51.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion56 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion56.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1.2" + "'", str62.equals("1.2"));
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test405");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test406");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "             /R/AR/AAR/R/AAR-/1/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/.//R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/7/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/.//R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/0/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/_/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/8" + "'", str1.equals("             /R/AR/AAR/R/AAR-/1/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/.//R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/7/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/.//R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/0/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/_/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/U/R/AR/AAR/R/AAR-/SERS/R/AR/AAR/R/AAR-///R/AR/AAR/R/AAR-/SOPHIE/R/AR/AAR/R/AAR-/8"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test407");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                  Ho..avaJ", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test409");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("\n", "1#10#100#1#100#-1");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split(":", "1.8", (int) (short) -1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.2", strArray4, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                  1.8                                   ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "\n" + "'", str5.equals("\n"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.2" + "'", str10.equals("1.2"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test410");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JA...", 3, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test412");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "en", (java.lang.CharSequence) "Library/Jntents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test413");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444444444444444441.44444444444444444444444444", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test414");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/USERS/SOPHI", "  ###########################", "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.04", 1410040410);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOPHI" + "'", str4.equals("/USERS/SOPHI"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test415");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0a11a10a100a1a100a-110a11a10a100a1a", (java.lang.CharSequence) "141452424044");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.81.2", 97, "jAVApLATFORMapisPECI/Users/sophi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVApLATFORMapisPECI/Users/sophijAVApLATFORMapisPECI/Users/sophijAVApLATFORMapisPECI/Users/1.81.2" + "'", str3.equals("jAVApLATFORMapisPECI/Users/sophijAVApLATFORMapisPECI/Users/sophijAVApLATFORMapisPECI/Users/1.81.2"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test417");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test418");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "35#1   Hi!    35#10", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test419");
        float[] floatArray2 = new float[] { (short) 1, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a97.0" + "'", str4.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0 97.0" + "'", str6.equals("1.0 97.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 97.0f + "'", float7 == 97.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0 97.0" + "'", str9.equals("1.0 97.0"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                                           US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                           US" + "'", str1.equals("                                                           US"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test421");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "          10#-1#-1#10#100          ", (java.lang.CharSequence) " hO..AVAj hO..AVAj hO..AVAj hO..              hO..AVAj hO..AVAj hO..AVAj hO..", 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test422");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/moc.elcaro.avaj//:ptth", 100, "utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/moc.elcaro.avaj//:ptthutf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf" + "'", str3.equals("/moc.elcaro.avaj//:ptthutf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test423");
        int[] intArray3 = new int[] { 91, (short) 1, (byte) -1 };
        int[] intArray7 = new int[] { 91, (short) 1, (byte) -1 };
        int[] intArray11 = new int[] { 91, (short) 1, (byte) -1 };
        int[][] intArray12 = new int[][] { intArray3, intArray7, intArray11 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray12);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("-1.0#10.0#1.0#-1.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0#10.0#1.0#-1.0" + "'", str2.equals("-1.0#10.0#1.0#-1.0"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test425");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "NTENTS/HOME/JRE/LIB/ENDORSE", (java.lang.CharSequence) "0.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0-1#00.0410.0", 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test426");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1043241432");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test427");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10aA100A-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test428");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "X86_6X86_6", 690);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test429");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "JAVAPLATFORMAPISPECI/USERS/SOPH");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test430");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("su 32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "su 3" + "'", str1.equals("su 3"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test431");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "###############################4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test432");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", 0);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String[] strArray6 = null;
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10a32a1a32", strArray4, strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10a32a1a32" + "'", str7.equals("10a32a1a32"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test433");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSEp/LIBRARY/JA...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus" + "'", charSequence2.equals("4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test434");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "A 4 a 4 4", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test435");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("35a100a100a-1a31", "-1#0", 42);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test436");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("a4444444a444444///////////////////a4444444a444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test437");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("   10#-1#-1#10#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   10#-1#-1#10#100" + "'", str1.equals("   10#-1#-1#10#100"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0.0a10.0", "...0a-1a31...0a-1a31...0a-1a31...0a-1a31...0a-1a4444444SOPHIE1A10A100A1A100A-11A10A100A1A100A-11A10A");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test439");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "mixed mod                                                                                                 ", 28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test440");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 91, (long) 42148, (long) 4444);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 42148L + "'", long3 == 42148L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test441");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test442");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("10A100A1A100A-11A10", "", "4444444444444", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10A100A1A100A-11A10" + "'", str4.equals("10A100A1A100A-11A10"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test443");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "2 10", (java.lang.CharSequence) "73");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("10a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1aaaaaaaaaaaaaa", 72);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1aaaaaaaaaaaaaa" + "'", str2.equals("100a1a100a-110a11a10a100a1a100a-110a11a10a100a1a100a-110a1aaaaaaaaaaaaaa"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test445");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("///////////////////");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test446");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 76, 98);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test447");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                             ", (java.lang.CharSequence) "             /r/ar/aar/r/aar-/1/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/7/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/.//r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/0/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/_/r/ar/aar/r/aar-///r/ar/aar/r/aar-/u/r/ar/aar/r/aar-/SERS/r/ar/aar/r/aar-///r/ar/aar/r/aar-/SOPHIE/r/ar/aar/r/aar-/80", 760);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 681 + "'", int3 == 681);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test448");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              JAVA HO...X86_64                                                                                              ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test449");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 100, (byte) 1, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a100a1a100a-1" + "'", str9.equals("1a10a100a1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "141041004141004-1" + "'", str11.equals("141041004141004-1"));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1a10a100a1a100a-1" + "'", str14.equals("1a10a100a1a100a-1"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test450");
        float[] floatArray2 = new float[] { (short) 1, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', (int) ' ', (int) (byte) -1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4');
        float float17 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a97.0" + "'", str4.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0 97.0" + "'", str6.equals("1.0 97.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0a97.0" + "'", str8.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0 97.0" + "'", str10.equals("1.0 97.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.0497.0" + "'", str16.equals("1.0497.0"));
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test451");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a1010a32a1a321a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10a100a1a100a-11a10");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test452");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "mixedmod", (int) (byte) -1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 134, 4444);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 134");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test453");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("PLATFORMAPISPECIF");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: PLATFORMAPISPECIF is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test454");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test455");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("10.04-1.0410.0", 50, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "....0410.0" + "'", str3.equals("....0410.0"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("#", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("nEMNORIVNeSCIHPARgc.TWA.NUS                                                              ", 38);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                      " + "'", str2.equals("                                      "));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test458");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("       sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "       sophie" + "'", str1.equals("       sophie"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test459");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.0 97", charSequence1, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test460");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sophie");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("-1a0", strArray3, strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1 10 100 1 100 -1", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.   1.0 97.");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a0" + "'", str7.equals("-1a0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "sophie" + "'", str12.equals("sophie"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Platform35#100#100#-1#31API35#100#100#-1#31Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test462");
        char[] charArray5 = new char[] { ' ', '#' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 0, (int) (short) -1);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray5);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "users/sophie/Documents/defects4j/tmp/run_randoop.pl_50283_1560277096", charArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray5, '4');
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10", charArray5);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 9, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " ##" + "'", str13.equals(" ##"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + " 4#" + "'", str15.equals(" 4#"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test463");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("javaPlatformAPISpecification");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "#################################", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test464");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4# 46_68x/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/4# 46_68xt", "ts4j/tmp/run_randoop.pl_50283_1560277096");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1.0#97.", "A 4 a 4 4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#97." + "'", str2.equals("1.0#97."));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test466");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0f), 0.0f, 1.41004045E9f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("java Platform API Specification", 143, 1398);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("class [Lj", (int) '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaclass [Ljaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaclass [Ljaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test469");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaeihpos/sresu/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.0 97.", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 97." + "'", str2.equals("1.0 97."));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test471");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#####                               ###################################", (java.lang.CharSequence) "0140400141");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("  1.", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  1." + "'", str3.equals("  1."));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("mixedmod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mixedmod" + "'", str1.equals("Mixedmod"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test474");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0 0.0 0.0", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "          0.79A0.1          ", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10#-1#-1#10#100", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("6", "sun.lwawt.maco");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6" + "'", str2.equals("6"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test476");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Jntents/Home/jre/lib/endorse", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test477");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("  ", "          0.79A0.1                   vaPlatformAPISpecification          0.79A0.1                   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test478");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "                                                   java Platform API Specification                                                    ", "10.14.310.14.310.14PlatformAPISpecif");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test479");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("13a1-a0...");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test480");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0.79a0.1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("4#                                                                             46_68xtiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#                                                                             46_68xtiklootcwl.xsocam.twawl.nus" + "'", str1.equals("4#                                                                             46_68xtiklootcwl.xsocam.twawl.nus"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test482");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                   java Platform API Specification                                                    ", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444" + "'", str1.equals("444"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test484");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("a 4       4", (double) 31L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.0d + "'", double2 == 31.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test485");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4aaa4a4", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorseP/library/ja...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test486");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.00#1-0.0140.0", 34, (-1));
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Mac OS", 0, 61);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS" + "'", str3.equals("Mac OS"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test488");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "10A100A1A100A-11A10", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test489");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#################################ts4j/tMp/run_ranOXXp.pl_50283_1560277096", (java.lang.CharSequence) "-1a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test490");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '#', 2748, (int) (short) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                        1410040410", "class [ljava.lang.string;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                        1410040410" + "'", str2.equals("                                        1410040410"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("jAVA hOTsPOT(tm) 64-bIT sERVER vm", 760, "NTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                    jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str3.equals("NTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                                          -x#0                                           B/ENDORSENTENTS/HOME/JRE/L                    jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test493");
        short[] shortArray3 = new short[] { (byte) 100, (byte) -1, (short) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a-1a1" + "'", str7.equals("100a-1a1"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test494");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0.01#0.AmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalPicepSIPAmroftalP", 1790L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1790L + "'", long2 == 1790L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test495");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("A100A-", "#a##a###a#a###a-##a##a###a#a###a-##a##a###a#a##0a-11a10a100a1a100a-11a10a100a1a100a-11a10aa100a-1", "", 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "A100A-" + "'", str4.equals("A100A-"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test496");
        char[] charArray8 = new char[] { ' ', '#' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', 0, (int) (short) -1);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS X", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.0a97.", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1a10a100a1a100a-1", charArray8);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "r", charArray8);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Sophie", charArray8);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("####################", 94);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################" + "'", str2.equals("####################"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test498");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray10 = new char[] { 'a', '4', 'a', '4', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Platform API Specif", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "X86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              Java Ho...x86_64                                                                                              ", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray10, '4');
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "a444a4444" + "'", str17.equals("a444a4444"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test499");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 1, (double) 29L, 77.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 77.0d + "'", double3 == 77.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }
}

