import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "mac os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java HotSpHTTP://JAVA.ORACLE.COM/", " ", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaOracle CorporationHotSpHTTP://JAVA.ORACLE.COM/" + "'", str3.equals("JavaOracle CorporationHotSpHTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("edom dexim", (int) (short) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 8, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "        " + "'", str3.equals("        "));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("             24.80-b11             ", "####7.1#######7.1#####   hi!    ", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             " + "'", str3.equals("             24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             "));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Mac OS X  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java virtual machine specification" + "'", str1.equals("java virtual machine specification"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("51.", "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("###1.7####", "                                                                          ORM api sPECIFICATION                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                          ORM api sPECIFICATION                                                                           ", "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 'a', (double) 337, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 337.0d + "'", double3 == 337.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 100, (double) (-1), (double) 24.8f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10.0f, (double) 0, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("java virtual machine specification");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7", (int) (short) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603", (java.lang.CharSequence) "                      edom dexim");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "sun.awt.CGraphicsEnvironment", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("Java Virtual Machine Specification", "####7.1###");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("US", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "X86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("mixed mode", 337);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "n", (java.lang.CharSequence) "             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 350 + "'", int2 == 350);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("HTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS X", "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                                          ORM api sPECIFICATION                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT" + "'", str2.equals("1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("utf-8", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8" + "'", str2.equals("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("JAVA VIRTUAL MACHINE SPECIFICATION", "              sophie               ", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("", "/var/folders/_v/6v597zmn4_v31hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(337.0d, (double) 97L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "             24.80-B11             ", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11             " + "'", str3.equals("             24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11             "));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n" + "'", str1.equals("n"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "####7.1#######7.1#####   hi!    ", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("x86_64", 170, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64####################################################################################################################################################################" + "'", str3.equals("x86_64####################################################################################################################################################################"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7", "UTF-8");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7" + "'", str4.equals("1.7"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("", "       hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("24.8", 8, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaa24.8" + "'", str3.equals("aaaa24.8"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                                                                                 ", 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                       oracle corporation                                        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "JavaOracle CorporationHotSpHTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                                                                       /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                        ", "M#c OS X", "Java(nn)ual(nachnno( Socnfnca)nMn");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("86_64", "", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aaaa24.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaa24.8" + "'", str1.equals("aaaa24.8"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("          ", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("1.7.0_80-B15", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(" ", "", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " " + "'", str4.equals(" "));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("utf-8");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("51.             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11" + "'", str1.equals("51.             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "              sophie               ", "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "!ih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("hi!", "\n", "44444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("OracleCrpratn", 338);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("51.             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11", 170.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 170.0d + "'", double2 == 170.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("             24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1.0f, (double) 0L, (double) 3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(96, 27, 338);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 27 + "'", int3 == 27);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("x86_64####################################################################################################################################################################", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64####################################################################################################################################################################" + "'", str2.equals("x86_64####################################################################################################################################################################"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("c OS XaM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("TNEMNORIVNE EMITNUR ES )MT(AVAJTNEMNORIVNE EMITNURTNEMNORIVNE EMITNUR ES )MT(AVAJTNEMNORIVNE EMITNUR", "mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TNEMNORIVNE EMITNUR ES )MT(AVAJTNEMNORIVNE EMITNURTNEMNORIVNE EMITNUR ES )MT(AVAJTNEMNORIVNE EMITNUR" + "'", str2.equals("TNEMNORIVNE EMITNUR ES )MT(AVAJTNEMNORIVNE EMITNURTNEMNORIVNE EMITNUR ES )MT(AVAJTNEMNORIVNE EMITNUR"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", (int) '#', "t");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.lwawt.macosx.LWCToolkit", "86_64", ":");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "M#c OS X", "                      edom dexim");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("       hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "             24.80-B11             ");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", 5, 352);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                      edom dexim");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8", "", "/Users/sophie", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8" + "'", str4.equals("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("UTF-8");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny("1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("             24.80-B11             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("51.             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11             ", 15, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sophie");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("HTTP://JAVA.ORACLE.COM/Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTP://JAVA.ORACLE.COM/MAC OS X" + "'", str1.equals("HTTP://JAVA.ORACLE.COM/MAC OS X"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "              sophie               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("HTTP://JAVA.ORACLE.COM/Mac OS X", "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(0.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("http://java.oracle.com/", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (-1), (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("HTTP://JAVA.ORACLE.COM/", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "       hi!");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("   hi!    ", "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc ", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    " + "'", str3.equals("   hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    "));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4j/tmp/run_randoop.pl_11091_1560229603", 31, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4j/tmp/run_randoop.pl_11091_1560229603" + "'", str3.equals("4j/tmp/run_randoop.pl_11091_1560229603"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("             24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11             ", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     24.80-B11                          24.80-B11                          24.80-B11             " + "'", str2.equals("     24.80-B11                          24.80-B11                          24.80-B11             "));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKITaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("      24.8", "   hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      24.8" + "'", str2.equals("      24.8"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java HotSpHTTP://JAVA.ORACLE.COM/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("      24.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.8" + "'", str1.equals("24.8"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc " + "'", str2.equals("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc "));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("             24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("      24.8", 27);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "     24.80-B11                          24.80-B11                          24.80-B11             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("###1.7####", "                                       oracle corporation                                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("44444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444", "Java Platform API Specification", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603", 15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "44444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444" + "'", str4.equals("44444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(" ", (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("###1.7####", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###1.7####" + "'", str2.equals("###1.7####"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("              sophie               ", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              sophie               " + "'", str2.equals("              sophie               "));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("TNEMNORIVNE EMITNUR ES )MT(AVAJTNEMNORIVNE EMITNURTNEMNORIVNE EMITNUR ES )MT(AVAJTNEMNORIVNE EMITNUR", "4j/tmp/run_randoop.pl_11091_1560229603");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 1, (double) (byte) 100, (double) 4L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("edom dexim", 10, 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("             24.80-B11             ", "aaaaaaa1.7aaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             24.80-B11             " + "'", str2.equals("             24.80-B11             "));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("JAVA(TM) SE RUNTIME ENVIRONMENT", "HTTP://JAVA.ORACLE.COM/MAC OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("          ", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", 4, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom      " + "'", str4.equals(" /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom      "));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) -1, (long) (short) 1, (long) 96);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        long[] longArray3 = new long[] { 0, 'a', (-1) };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "X86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "             24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("sun.lwawt.macosx.LWCToolkit", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "              sophie               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "              sophie               " + "'", str1.equals("              sophie               "));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 352);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Mac OS X  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.awt.CGraphicsEnvironment", "ORM api sPECIFICATION", 337);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("en", "1.7.0_80-B15", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny("", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java Platform API Specification", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 96);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "   hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!    ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Java Platform API Specification" + "'", charSequence2.equals("Java Platform API Specification"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("4444444444444444444444444444444444444444444444444\n44444444444444444444444444444444444444444444444444", "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603", "mixed mode", "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Usars/saphaa/DacuJants/ afacts4j/tJp/run_ran aap.pl_11091_1560229603" + "'", str3.equals("/Usars/saphaa/DacuJants/ afacts4j/tJp/run_ran aap.pl_11091_1560229603"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("             24.80-b11             ", "mac os x", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                      edom dexim", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      edom dexim" + "'", str2.equals("                      edom dexim"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("HTTP://JAVA.ORACLE.COM/MAC OS X", (int) '#', "   hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  HTTP://JAVA.ORACLE.COM/MAC OS X  " + "'", str3.equals("  HTTP://JAVA.ORACLE.COM/MAC OS X  "));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 8, 33.0f, (float) 97);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                       oracle corporation                                        ", ":", "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("\n", "", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("sun_lwawt_macosx_LWCToolkt44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun_lwawt_macosx_LWCToolkt44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("sun_lwawt_macosx_LWCToolkt44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("51.             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11             ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("51.", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/var/folders/_v/6v597zmn4_v31hi!", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31hi!" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31hi!"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "sun.lwawt.macosx.LWCToolkit", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11", "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7", 96, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/", "/var/folders/_v/6v597zmn4_v31hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Mc OS X", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mc OS X" + "'", str2.equals("Mc OS X"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("TNEMNORIVNE EMITNUR ES )MT(AVAJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n", "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("             24.80-b11             ", "sun_lwawt_macosx_LWCToolkt44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             24.80-b11             " + "'", str3.equals("             24.80-b11             "));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "              sophie               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("!ih", "", "mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!ih" + "'", str4.equals("!ih"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", " /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom      ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("JAVA(TM) SE RUNTIME ENVIRONMENT", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 33);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaa24.8");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "             24.80-b11             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                       oracle corporation                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                       oracle corporation                                        " + "'", str1.equals("                                       oracle corporation                                        "));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("24.80-b11", 170, "1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MAC24.80-b11" + "'", str3.equals("1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MAC24.80-b11"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("HTTP://JAVA.ORACLE.COM/MAC OS X", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HTTP://JAVA.ORACLE.COM/MAC OS X" + "'", str2.equals("HTTP://JAVA.ORACLE.COM/MAC OS X"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("1.7.0_80-b15", 337, 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("44444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("HTTP://JAVA.ORACLE.COM/Mac OS X", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "Mc OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("n", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("              sophie               ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny("TNEMNORIVNE EMITNUR ES )MT(AVAJ", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("mixed mode", "M#c OS X");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "c OS XaM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JavaVirtualMachineSpecification" + "'", str4.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("   hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"   hi!   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("mac os x", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("ORM api sPECIFICATION", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("t", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("             24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11             ", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "24.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Oracle Corporation", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("10.14.3", "Java Virtual Machine Specification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("mac os x", "US", 100, 15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mac os xUS" + "'", str4.equals("mac os xUS"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("http://java.oracle.com/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 352, (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 3, (double) 337, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 337.0d + "'", double3 == 337.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                          ORM api sPECIFICATION                                                                           ", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 97.0f, (double) 5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 33, (float) 5);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc ", "             24.80-b11             ", "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc " + "'", str3.equals("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc "));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "X86_64", "   hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("OracleCrpratn", "HTTP://JAVA.ORACLE.COM/", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "M#c OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("http://java.oracle.com/", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Mac OS X  ", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OS X  " + "'", str2.equals("OS X  "));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "86_64");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "51.", (java.lang.CharSequence) " /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105 + "'", int2 == 105);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", 338);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "       hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       hi!" + "'", str2.equals("       hi!"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray7 = new char[] { 'a', '4', 'a', 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sun.lwawt.macosx.LWCToolkit44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Java Virtual Machine Specification", 170);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("TNEMNORIVNE EMITNUR ES )MT(AVAJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TNEMNORIVNE EMITNUR ES )MT(AVAJ" + "'", str1.equals("TNEMNORIVNE EMITNUR ES )MT(AVAJ"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(1.7f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("24.8", 337);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("mac os x", 33, 96);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "OS X  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80sun.lwawt.macosx.LWCToolkit");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("              sophie               ", "1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MAC24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTP://JAVA.ORACLE.COM/" + "'", str1.equals("HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "####7.1#######7.1#####   hi!    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("51.");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("!ih", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("51.0", "1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("http://java.oracle.com/", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("JavaOracle CorporationHotSpHTTP://JAVA.ORACLE.COM/", "HTTP://JAVA.ORACLE.COM/Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaOracle CorporationHotSpHTTP://JAVA.ORACLE.COM/" + "'", str2.equals("JavaOracle CorporationHotSpHTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("c OS XaM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("c OS XaM", "####7.1###", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "aaaaaaa1.7aaaaaaaa", (java.lang.CharSequence) "   hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("java virtual machine specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificeps enihcam lautriv avaj" + "'", str1.equals("noitacificeps enihcam lautriv avaj"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] { ' ', 'a', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "###1.7####", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####7.1#######7.1#####   hi!    ", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "edom dexim");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("oracle corporation", (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("x86_64####################################################################################################################################################################", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603", "Java(nn)ual(nachnno( Socnfnca)nMn");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64####################################################################################################################################################################" + "'", str3.equals("x86_64####################################################################################################################################################################"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("                                                                                                                                       /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                        ", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java HotSpHTTP://JAVA.ORACLE.COM/", 0, 352);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sophie" + "'", str1.equals("Sophie"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("24.8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "   hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("HTTP://JAVA.ORACLE.COM/Mac OS X", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                     HTTP://JAVA.ORACLE.COM/Mac OS X" + "'", str2.equals("                                                                     HTTP://JAVA.ORACLE.COM/Mac OS X"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("86_64", "", "                                                                                                                                       /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "86_64" + "'", str3.equals("86_64"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("mac os xUS", "1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("1.7.0_80", "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("10.14.3");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100, (float) 10L, 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603", (int) (short) 1, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7.0_80sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("soph", "Java HotSpHTTP://JAVA.ORACLE.COM/", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("              sophie               ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("   hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!    " + "'", str1.equals("   hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!    "));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "              sophie               ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14 + "'", int2 == 14);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("              sophie               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Platform API Specification", 3, "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11             ", "1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Usars/saphaa/DacuJants/ afacts4j/tJp/run_ran aap.pl_11091_1560229603", 8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11             " + "'", str4.equals("             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11             "));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("soph", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) 1);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 96, (long) 3, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 96L + "'", long3 == 96L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("51.             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11", "Java HotSpHTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"        \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str1.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(charSequence0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("1.7.0_80sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "bojretnirpc.xsocam.twawl.nus" + "'", str1.equals("bojretnirpc.xsocam.twawl.nus"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10.14.3");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "                                                                                                                                       /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                                                                                       /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                        " + "'", charSequence2.equals("                                                                                                                                       /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                        "));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "24.8");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "M#c OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 8, (float) 338, (float) 337);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100L, 97.0f, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("JavaVirtualMachineSpecification", "1.7.0_80-B15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 0, (long) 5, (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("      24.8", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      24.8" + "'", str2.equals("      24.8"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "51.             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11             ", (int) (short) 1, 338);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("86_64");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"86_64\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                     HTTP://JAVA.ORACLE.COM/Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HTTP://JAVA.ORACLE.COM/Mac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "aaaa24.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 170, (float) (-1), (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Oracle Corporation", "1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("mac os x", 96);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", "aaaa24.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("JavaOracle CorporationHotSpHTTP://JAVA.ORACLE.COM/", "M#c OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("java virtual machine specification", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java virtual machine specification" + "'", str2.equals("java virtual machine specification"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "!ih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("JavaOracle CorporationHotSpHTTP://JAVA.ORACLE.COM/", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaOracle CorporationHotSpHTTP://JAVA.ORACLE.COM/" + "'", str2.equals("JavaOracle CorporationHotSpHTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8", "1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8" + "'", str2.equals("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("  HTTP://JAVA.ORACLE.COM/MAC OS X  ", "TNEMNORIVNE EMITNUR ES )MT(AVAJTNEMNORIVNE EMITNURTNEMNORIVNE EMITNUR ES )MT(AVAJTNEMNORIVNE EMITNUR", " ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  HTTP://JAVA.ORACLE.COM/MAC OS X  " + "'", str3.equals("  HTTP://JAVA.ORACLE.COM/MAC OS X  "));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                                                                                                       /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("      24.8", 352, " /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom       /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom       /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom       /Users/sophie/Librar      24.8" + "'", str3.equals(" /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom       /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom       /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom       /Users/sophie/Librar      24.8"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n" + "'", str1.equals("n"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        char[] charArray6 = new char[] { '#', 'a', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "utf-8", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "utf-8", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(35, 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "", "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("HTTP://JAVA.ORACLE.COM/MAC OS X", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HTTP://JAVA.ORACLE.COM/MAC OS X" + "'", str2.equals("HTTP://JAVA.ORACLE.COM/MAC OS X"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("JAVA(TM) SE RUNTIME ENVIRONMENT", 0, "!ih");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENT" + "'", str3.equals("JAVA(TM) SE RUNTIME ENVIRONMENT"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("10.14.3", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("44444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80-b15", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603", "java virtual machine specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKITaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "X86_64", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 10, (byte) 0, (byte) 10, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("c OS XaM", "HTTP://JAVA.ORACLE.COM/Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/Users/sophie", (int) (short) 10);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT" + "'", str2.equals("1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("UTF-8");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java(nn)ual(nachnno( Socnfnca)nMn", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(nn)ual(nachnno( Socnfnca)nMn" + "'", str2.equals("Java(nn)ual(nachnno( Socnfnca)nMn"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("####7.1#######7.1#####   hi!    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####7.1#######7.1#####   hi!    " + "'", str1.equals("####7.1#######7.1#####   hi!    "));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaa1.7aaaaaaaa", "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaa1.7aaaaaaaa" + "'", str2.equals("aaaaaaa1.7aaaaaaaa"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("             24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11             ", "  HTTP://JAVA.ORACLE.COM/MAC OS X  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HTTP://JAVA.ORACLE.COM/MAC OS X  " + "'", str2.equals("HTTP://JAVA.ORACLE.COM/MAC OS X  "));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("24.80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"24.80-b11\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java HotSpot(TM) 64-Bit Server VM", "51.             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7", "ORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8" + "'", str3.equals("utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "24.80-b11", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sun.lwawt.macosx.LWCToolkit44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("              sophie               ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              sophie               " + "'", str2.equals("              sophie               "));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.7.0_80sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("1.7.0_80sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("sun.lwawt.macosx.LWCToolkit44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("51.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Mac OS X  ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10.0f, 0.0d, (double) 8L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Java Virtual Machine Specification", "1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", 31, "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "t");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 4, 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 170 + "'", int3 == 170);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("x86_64####################################################################################################################################################################", "sun.awt.CGraphicsEnvironment", "      24.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64####################################################################################################################################################################" + "'", str3.equals("x86_64####################################################################################################################################################################"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("             24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11                          24.80-B11             ", "bojretnirpc.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/var/folders/_v/6v597zmn4_v31hi!", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31hi!" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31hi!"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("51.", "                                                                          ORM api sPECIFICATION                                                                           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51." + "'", str2.equals("51."));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKITaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) " /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("####7.1#######7.1#####   hi!    ", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####7.1#######7.1#####   hi!    " + "'", str2.equals("####7.1#######7.1#####   hi!    "));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 0.0d, (double) 8);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) " /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("51.             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11", "###1.7####", "                                                                                                 ", 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "51.             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11" + "'", str4.equals("51.             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "             24.80-B11             ", "                                                                                                                                       /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-B15", "OS X  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Sophie", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sophie" + "'", str2.equals("Sophie"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Usars/saphaa/DacuJants/ afacts4j/tJp/run_ran aap.pl_11091_1560229603", "4444444444444444444444444444444444444444444444444\n44444444444444444444444444444444444444444444444444", "bojretnirpc.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Usars/saphaa/DacuJants/ afacts4j/tJp/run_ran aap.pl_11091_1560229603" + "'", str3.equals("/Usars/saphaa/DacuJants/ afacts4j/tJp/run_ran aap.pl_11091_1560229603"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("mac os xUS", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac os xUS" + "'", str2.equals("mac os xUS"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("\n", (int) 'a', "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-\n" + "'", str3.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-\n"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sun.lwawt.macosx.cprinterjob", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "oracle corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(" ", "c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("HTTP://JAVA.ORACLE.COM/MAC OS X  ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("          ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(" ", "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("", " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc ", "M#c OS X", "utf-8");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80-b15", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MAC24.80-b11", (int) 'a', 337);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MAC24.80-b11" + "'", str3.equals("ctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MAC24.80-b11"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("HTTP://JAVA.ORACLE.COM/", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                             HTTP://JAVA.ORACLE.COM/" + "'", str2.equals("                                                                             HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/Users/sophie", (int) (short) 10);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "aaaaaaa1.7aaaaaaaa", (int) (short) 1, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Oracle Corporation", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("java virtual machine specification", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "\n");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("###1.7####", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "###1.7####" + "'", str4.equals("###1.7####"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "###1.7####" + "'", str6.equals("###1.7####"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                       oracle corporation                                        ", 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Sophie", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Sophie" + "'", str5.equals("Sophie"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("  HTTP://JAVA.ORACLE.COM/MAC OS X  ", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "Java(TM) SE Runtime Environment", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("OracleCrpratn", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "        " + "'", str1.equals("        "));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("   hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc c OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc OS XaMc    hi!    ", 'a');
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/var/folders/_v/6v597zmn4_v31hi!", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 373");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("24.8", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.8" + "'", str2.equals("24.8"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) " /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Hom      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        short[] shortArray2 = new short[] { (byte) -1, (short) 1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 1 + "'", short4 == (short) 1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("X86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        int[] intArray0 = new int[] {};
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                                                                                       /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                                                                                                                        /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                         is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(":", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((-1.0d), (double) 3, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "aaaaaaa1.7aaaaaaaa");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sunlwwtmcosxLWCToolkit" + "'", str3.equals("sunlwwtmcosxLWCToolkit"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 1, (long) 33, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("             24.80-B11             ", "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             24.80-B11             " + "'", str2.equals("             24.80-B11             "));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "              sophie               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("mac os xUS", "US", "Java Platform API Specification", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mac os xJava Platform API Specification" + "'", str4.equals("mac os xJava Platform API Specification"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "1.7");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny("US", strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny("####7.1###", strArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "HTTP://JAVA.ORACLE.COM/MAC OS X  ");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("24.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8.42" + "'", str1.equals("8.42"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("HTTP://JAVA.ORACLE.COM/Mac OS X", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HTTP://JAVA.ORACLE.COM/Mac OS X" + "'", str2.equals("HTTP://JAVA.ORACLE.COM/Mac OS X"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("             24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11" + "'", str1.equals("24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11             ####7.1#######7.1#####   hi!                 24.80-b11"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("noitacificeps enihcam lautriv avaj", 33, 33);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENT" + "'", str1.equals("JAVA(TM) SE RUNTIME ENVIRONMENT"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                     HTTP://JAVA.ORACLE.COM/Mac OS X", (long) 352);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 352L + "'", long2 == 352L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("noitacificeps enihcam lautriv avaj", "                                                                     HTTP://JAVA.ORACLE.COM/Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificeps enihcam lautriv avaj" + "'", str2.equals("noitacificeps enihcam lautriv avaj"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Mc OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 0L, 1.7f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.7f + "'", float3 == 1.7f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 338);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                  " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                  "));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("ctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MAC24.80-b11", 337);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "sun_lwawt_macosx_LWCToolkt44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("       hi!");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "86_64" + "'", str1.equals("86_64"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11             ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11             " + "'", str2.equals("             24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11                          24.80-b11             "));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("  HTTP://JAVA.ORACLE.COM/MAC OS X  ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_11091_1560229603/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("x86_64####################################################################################################################################################################", "JavaOracle CorporationHotSpHTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie", "                                       oracle corporation                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("HTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS XOracle CorporationHTTP://JAVA.ORACLE.COM/Mac OS X", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("n", 96, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "TNEMNORIVNE EMITNUR ES )MT(AVAJTNEMNORIVNE EMITNURTNEMNORIVNE EMITNUR ES )MT(AVAJTNEMNORIVNE EMITNUR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        double[] doubleArray6 = new double[] { 170.0d, 'a', 100.0f, 0L, 0L, 100 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8" + "'", str1.equals("Utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8utf-8"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 96, 0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("M#c OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "M#c OS X" + "'", str1.equals("M#c OS X"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("86_64", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 100, (float) 350, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 350.0f + "'", float3 == 350.0f);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("noitacificeps enihcam lautriv avaj", "1.7.0_80sun.lwawt.macosx.LWCToolkit", "HTTP://JAVA.ORACLE.COM/MAC OS X  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AMLAOfOepA eAhOA. OAVLrv AvAj" + "'", str3.equals("AMLAOfOepA eAhOA. OAVLrv AvAj"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.7", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("8.42", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               8.42" + "'", str2.equals("                               8.42"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "Java Virtual Machine Specification", "x86_64");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("soph", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("utf-8", "JavaOracle CorporationHotSpHTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "utf-8" + "'", str2.equals("utf-8"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                                                     HTTP://JAVA.ORACLE.COM/Mac OS X", "              sophie               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                     HTTP://JAVA.ORACLE.COM/Mac OS X" + "'", str2.equals("                                                                     HTTP://JAVA.ORACLE.COM/Mac OS X"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMENT", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MAC24.80-b11", 350, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                          ctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MAC24.80-b11                                                                                                                                           " + "'", str3.equals("                                                                                                                                          ctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MAC24.80-b11                                                                                                                                           "));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Java HotSpHTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpHTTP://JAVA.ORACLE.COM/" + "'", str1.equals("Java HotSpHTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (-1), 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "AMLAOfOepA eAhOA. OAVLrv AvAj");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("                                                                             HTTP://JAVA.ORACLE.COM/", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("###1.7####", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "HTTP://JAVA.ORACLE.COM/MAC OS X  ", (int) (byte) -1, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        long[] longArray0 = new long[] {};
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.min(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("51.", (int) 'a', "1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX" + "'", str3.equals("51.1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT1.7.0_80SUN.LWAWT.MACOSX"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("86_64", "8.42");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("sunlwwtmcosxLWCToolkit", 14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("sun.lwawt.macosx.LWCToolkit44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        float[] floatArray6 = new float[] { (-1), 'a', 96, 1, ' ', 96 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 97.0f + "'", float7 == 97.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 97.0f + "'", float11 == 97.0f);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT", "24.80-b11", 0);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "1.7.0_80");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT" + "'", str6.equals("1.7.0_80SUN.LWAWT.MACOSX.lwctOOLKIT"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("sun.lwawt.macosx.cprinterjob", "Java(nn)ual(nachnno( Socnfnca)nMn", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("JavaOracle CorporationHotSpHTTP://JAVA.ORACLE.COM/", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaOracle CorporationHotSpHTTP:" + "'", str2.equals("JavaOracle CorporationHotSpHTTP:"));
    }
}

