import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("95v6/v_/sredlof/rav/", 38);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/" + "'", str2.equals("95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" l utriV  v J");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "l utriV  v J" + "'", str1.equals("l utriV  v J"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "10.0 -1.0 10.0 0.0 0.0 10.0.0 -1.0 10.0 0.0 0.0 00.0", (java.lang.CharSequence) "                                                                                                                                                                                                               /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav                                                                                                                                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) " ###4");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "100.0a52.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0a52." + "'", str2.equals("100.0a52."));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("        E", "5.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "        E" + "'", str3.equals("        E"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL", "                                                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL" + "'", str2.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("             ...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             ..." + "'", str2.equals("             ..."));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) '4', 52L, 20L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "hi!..._519hi!..._519hi!..._519hi!..._519hi!..._ 4#44hi!..._519hi!..._519hi!..._519hi!..._519hi!..._5", (java.lang.CharSequence) "   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(638L, (long) 'a', 26L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 26L + "'", long3 == 26L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM                                                                   ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(5, 10, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XM1.7", (java.lang.CharSequence) "0.0 0.0 0.0 10.0 -1.0 10.0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/E" + "'", str2.equals("/Users/sophie/Library/Java/E"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0#1#100", 53, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1-1##########################################################################################", "################4.1################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1-1##########################################################################################" + "'", str2.equals("1-1##########################################################################################"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        double[] doubleArray4 = new double[] { (byte) -1, 100, 10, 100L };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0 100.0 10.0 100.0" + "'", str7.equals("-1.0 100.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.0 100.0 10.0 100.0" + "'", str9.equals("-1.0 100.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!", "phie/Library/Java/Extensio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(":                                            ...", 272);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                           4# #4Java HotSpot(TM) 64-Bit Server VM              ", (java.lang.CharSequence) "#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/extensions://extensio10.1.3", (java.lang.CharSequence) "/Users/sophie/Library/Java/E");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("a      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a" + "'", str1.equals("a"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Lib", 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("E        ", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "E        " + "'", str2.equals("E        "));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                           4# #4Java HotSpot(TM) 64-Bit Server VM              ", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0.0a0.0a0.0a10.0a-1.0a10.0                          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 0.0a0.0a0.0a10.0a-1.0a10.0                           is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 100, (byte) 0, (byte) 100, (byte) -1, (byte) -1 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', (int) (short) 100, 20);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "52a10a1a-1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 52a10a1a-1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1a100a0a100a-1a-1" + "'", str12.equals("-1a100a0a100a-1a-1"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "/Us.0s/s10./L0b010y/-1.1/Ex..0s00s:/L0b010y/-1.1/Ex..0s00s:/N..w0k/L0b010y/-1.1/Ex..0s00s:/ys..m/L0b010y/-1.1/Ex..0s00s:/0s0/10b/j1.1:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                                                                                                                                                                                                                                                             4# #4\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                                                                                                                                                                                                                             ", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) -1, 62, 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "0.0a0.0a0.0a10.0a-1.0a10.0                          ", (java.lang.CharSequence) "-1.0 100.0 10.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("52410414-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52410414-1" + "'", str1.equals("52410414-1"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("         0.00140.0140.00140.1         ", 35, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         0.00140.0140.00140.1         " + "'", str3.equals("         0.00140.0140.00140.1         "));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "UTF-8UTF-8UTF-8-1.04100.0410.04100.0UTF-8UTF-8UTF-8U");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (int) (short) 0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("0.9", "SOPHIE", "Desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.9" + "'", str4.equals("0.9"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/U/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/rs/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a   4 # a", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("################################", "/", 20);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100.0#52.0", " 4#44 4#44 4#44 4#44 4#44 4#44 4#44 4#44 4#44 4#44 4#44 4#-1.0A100.0A10.0A100.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        char[] charArray7 = new char[] { ' ', '#', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', (int) '4', 0);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15aaaaaaaaaaaaaaaaaaaa", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " a#a4", charArray7);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                       a   4 # a", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 13, (long) 10, (long) 16);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80S1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80o1.7.0_80r1.7.0_80g1.7.0_80.1.7.0_80a1.7.0_80p1.7.0_80a1.7.0_80c1.7.0_80h1.7.0_80e1.7.0_80.1.7.0_80c1.7.0_80o1.7.0_80m1.7.0_80m1.7.0_80o1.7.0_80n1.7.0_80s1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_8031.7.0_80.1.7.0_80J1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80V1.7.0_80e1.7.0_80r1.7.0_80s1.7.0_80i1.7.0_80o1.7.0_80n1.7.0_80", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80S1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80o1.7.0_80r1.7.0_80g1.7.0_80.1.7.0_80a1.7.0_80p1.7.0_80a1.7.0_80c1.7.0_80h1.7.0_80e1.7.0_80.1.7.0_80c1.7.0_80o1.7.0_80m1.7.0_80m1.7.0_80o1.7.0_80n1.7.0_80s1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_8031.7.0_80.1.7.0_80J1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80V1.7.0_80e1.7.0_80r1.7.0_80s1.7.0_80i1.7.0_80o1.7.0_80n1.7.0_80" + "'", str2.equals("1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80S1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80o1.7.0_80r1.7.0_80g1.7.0_80.1.7.0_80a1.7.0_80p1.7.0_80a1.7.0_80c1.7.0_80h1.7.0_80e1.7.0_80.1.7.0_80c1.7.0_80o1.7.0_80m1.7.0_80m1.7.0_80o1.7.0_80n1.7.0_80s1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_8031.7.0_80.1.7.0_80J1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80V1.7.0_80e1.7.0_80r1.7.0_80s1.7.0_80i1.7.0_80o1.7.0_80n1.7.0_80"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 9, "################1.4################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########" + "'", str3.equals("#########"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sophie", 32, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        int[] intArray3 = new int[] { 11, 7, 49 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 49 + "'", int4 == 49);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                mixed mJava Platform API Specification", "                           4# #4", (int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                           4# #4                                                mixed mJava Platform API Specification" + "'", str4.equals("                           4# #4                                                mixed mJava Platform API Specification"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", ' ');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', 0, 0);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "################################", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.7.0_80", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "################4.1################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("a   4 # a");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', (int) 'a', (int) (byte) -1);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', (int) (byte) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/L...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0.0a0.0a0.0a10.0a-1.0a10.0                          ", 0, "1.4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0a0.0a0.0a10.0a-1.0a10.0                          " + "'", str3.equals("0.0a0.0a0.0a10.0a-1.0a10.0                          "));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("24.80-b11");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                                                                                                                                                               /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav                                                                                                                                                                                                               ", (java.lang.CharSequence) "4# #4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("         /", (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                           4# #4", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                           4a a4" + "'", str3.equals("                           4a a4"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(630.0f, 69.0f, (float) 49);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 49.0f + "'", float3 == 49.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', 0, 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', 8, 40);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("-1 0 52 32 20");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 0 52 32 20" + "'", str1.equals("-1 0 52 32 20"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0.040.040.0410.04-1.0410.0", 62, 62);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("# 4", "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                " + "'", str2.equals(":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                "));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "####################################################", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", ' ');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', 0, 0);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "################################", (java.lang.CharSequence[]) strArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/Users/sophie");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str11.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertNotNull(strArray13);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Virtual Machine Specification", "                                                                                                                                                                                                                                                                             4# #4\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", ":                                                                                                ");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (short) 10, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                    ", (java.lang.CharSequence) "52 0 97 52IE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Library/Java/Extensions:/Library/Jav10", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Jav10" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Jav10"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sopsue/Lubrary/Java/Extensuons:/Lubrary/Java/Extensuons:/Network/Lubrary/Java/Extensuons:/System/Lubrary/Java/Extensuons:/usr/lub/java:.", '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "hi");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sopsue/Lubrary/Java/Extensuons:/Lubrary/Java/Extensuons:/Network/Lubrary/Java/Extensuons:/System/Lubrary/Java/Extensuons:/usr/lub/java:." + "'", str4.equals("/Users/sopsue/Lubrary/Java/Extensuons:/Lubrary/Java/Extensuons:/Network/Lubrary/Java/Extensuons:/System/Lubrary/Java/Extensuons:/usr/lub/java:."));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", ' ');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', 0, 0);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) " ", (java.lang.CharSequence[]) strArray4);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', (int) (short) -1, 324);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "10");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.", " Java HotSpot(TM) 64-Bit Server VM ", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("                                                mixed mJava Platform API Specification", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "                                                mixed mJava Platform API Specification" + "'", str9.equals("                                                mixed mJava Platform API Specification"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "l utriV  v J", "-1a100a0a100a-1a-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '4', 69, 272);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAV" + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAV"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", (java.lang.CharSequence) "ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten", 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1.0a100.0a10.0a100.0 ", "/extensions:/ne1.7avary/ja/extensions:/libravary/ja/users/sophie/libr1.7.0_80-b151.7.0_80-b151.7.0_8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("JAVA vIRTUAL mACHINE sPECIFICATION", 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA vIRTUAL mACHINE sPECIFICATION                                                                  " + "'", str3.equals("JAVA vIRTUAL mACHINE sPECIFICATION                                                                  "));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                               ", 0, "ironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmente");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                               " + "'", str3.equals(":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                               "));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java HotSpot(TM) 64-Bit Server VM", "a5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java HotSpot(TM) 64-Bit Server VM                                                                   ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM                                                                   " + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM                                                                   "));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                mixed mJava Platform API Specification", "sun.awt.CG", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd(":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                               ", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                               " + "'", str2.equals(":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                               "));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 1, 1L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                  Java Platform API Specification                                   ", (java.lang.CharSequence) "10.1.3", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("             ...", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "http://java.oracle.com", (java.lang.CharSequence) "1.7.0_80", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger(". . . . -. .. . . . -. .");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \". . . . -. .. . . . -. .\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '4', (int) (short) 5, 26);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaa", "##########################################################################################", "GC.twa.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("UTF-8UTF-8UTF-8-1.04100.0410.04100.0UTF-8UTF-8UTF-8U", (int) (short) -1, "# 4 4   a a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8UTF-8UTF-8-1.04100.0410.04100.0UTF-8UTF-8UTF-8U" + "'", str3.equals("UTF-8UTF-8UTF-8-1.04100.0410.04100.0UTF-8UTF-8UTF-8U"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                                mixed mJava Platform API Specification", (java.lang.CharSequence) "/var/folders/_v/6v59");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        double[] doubleArray4 = new double[] { (byte) -1, 100, 10, 100L };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#', 79, 22);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0 100.0 10.0 100.0" + "'", str7.equals("-1.0 100.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.0 100.0 10.0 100.0" + "'", str9.equals("-1.0 100.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1.0a100.0a10.0a100.0" + "'", str16.equals("-1.0a100.0a10.0a100.0"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                       a   4 # a", "1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0.9");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9d + "'", double1 == 0.9d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("-1.04100.0410.04100.0", (int) ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.04100.0410.04100.0           " + "'", str3.equals("-1.04100.0410.04100.0           "));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "4### ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 5, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", "USRSSOPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################" + "'", str2.equals("###################################"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        float[] floatArray2 = new float[] { (short) 100, 52 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (int) (short) 100, 0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/...", "################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/..." + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/..."));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java" + "'", str1.equals("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", 638);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                       a       a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                  Java Platform API Specification                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 5, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaxaCPaaaaaaJaa", (long) 38);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 38L + "'", long2 == 38L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                           4# #4Java HotSpot(TM) 64-Bit Server VM              ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.7", ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr" + "'", str2.equals("/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################" + "'", str2.equals("####################################################"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        double[] doubleArray3 = new double[] { 10.0f, 32.0d, 52 };
        double[] doubleArray7 = new double[] { 10.0f, 32.0d, 52 };
        double[] doubleArray11 = new double[] { 10.0f, 32.0d, 52 };
        double[] doubleArray15 = new double[] { 10.0f, 32.0d, 52 };
        double[] doubleArray19 = new double[] { 10.0f, 32.0d, 52 };
        double[] doubleArray23 = new double[] { 10.0f, 32.0d, 52 };
        double[][] doubleArray24 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19, doubleArray23 };
        double[] doubleArray28 = new double[] { 10.0f, 32.0d, 52 };
        double[] doubleArray32 = new double[] { 10.0f, 32.0d, 52 };
        double[] doubleArray36 = new double[] { 10.0f, 32.0d, 52 };
        double[] doubleArray40 = new double[] { 10.0f, 32.0d, 52 };
        double[] doubleArray44 = new double[] { 10.0f, 32.0d, 52 };
        double[] doubleArray48 = new double[] { 10.0f, 32.0d, 52 };
        double[][] doubleArray49 = new double[][] { doubleArray28, doubleArray32, doubleArray36, doubleArray40, doubleArray44, doubleArray48 };
        double[] doubleArray53 = new double[] { 10.0f, 32.0d, 52 };
        double[] doubleArray57 = new double[] { 10.0f, 32.0d, 52 };
        double[] doubleArray61 = new double[] { 10.0f, 32.0d, 52 };
        double[] doubleArray65 = new double[] { 10.0f, 32.0d, 52 };
        double[] doubleArray69 = new double[] { 10.0f, 32.0d, 52 };
        double[] doubleArray73 = new double[] { 10.0f, 32.0d, 52 };
        double[][] doubleArray74 = new double[][] { doubleArray53, doubleArray57, doubleArray61, doubleArray65, doubleArray69, doubleArray73 };
        double[][][] doubleArray75 = new double[][][] { doubleArray24, doubleArray49, doubleArray74 };
        java.lang.String str76 = org.apache.commons.lang3.StringUtils.join(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "#52");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("5", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5" + "'", str2.equals("5"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("################4.1################", 8, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################4.1################" + "'", str3.equals("################4.1################"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        char[] charArray9 = new char[] { '#', '4', '4', ' ', 'a', 'a' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                     Java(TM) SE Runtime Environment", charArray9);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                  Java Platform API Specification                                   ", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "#44444 4a4a" + "'", str13.equals("#44444 4a4a"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 34 + "'", int14 == 34);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "# 4 4   a a" + "'", str16.equals("# 4 4   a a"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0.0a0.0a0.0a10.0a-1.0a10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                          ", (java.lang.CharSequence) "52a10a...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "GC.twa.nu");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Jav10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("-1.0#100.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XM1.7", "                                  Java Platform API Specification                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XM1.7" + "'", str2.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XM1.7"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 630);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                  Java Platform API Specification                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                  Java Platform API Specification                                  " + "'", str1.equals("                                  Java Platform API Specification                                  "));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Lib", "0.040.040.0410.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java HotSpot(TM) 64-Bit Server VM                                                                   ", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(" Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0", "", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.7.0_80-b15aaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 1, (int) (byte) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 9, (int) (short) 0);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0#1#100" + "'", str10.equals("0#1#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0414100" + "'", str12.equals("0414100"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1N4FC0000GN/T/", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "FC0000GN/T/41N" + "'", str2.equals("FC0000GN/T/41N"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("FC0000GN/T/41N", "OracleCorporation", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                       a       a", 40);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               a       a" + "'", str2.equals("                               a       a"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "OracleCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444", (java.lang.CharSequence) "1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80S1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80o1.7.0_80r1.7.0_80g1.7.0_80.1.7.0_80a1.7.0_80p1.7.0_80a1.7.0_80c1.7.0_80h1.7.0_80e1.7.0_80.1.7.0_80c1.7.0_80o1.7.0_80m1.7.0_80m1.7.0_80o1.7.0_80n1.7.0_80s1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_8031.7.0_80.1.7.0_80J1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80V1.7.0_80e1.7.0_80r1.7.0_80s1.7.0_80i1.7.0_80o1.7.0_80n1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        char[] charArray10 = new char[] { '#', '4', '4', ' ', 'a', 'a' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                     Java(TM) SE Runtime Environment", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                        hi", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.4", charArray10);
        java.lang.Class<?> wildcardClass15 = charArray10.getClass();
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("S:USRIBAVA", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("0 1 100", "4###4", " ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 1 100" + "'", str3.equals("0 1 100"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("a   4 # as:/Ne1.7avary/Ja/Exte", 22, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a   4 # as:/Ne1.7avary/Ja/Exte" + "'", str3.equals("a   4 # as:/Ne1.7avary/Ja/Exte"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\n\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.4", "hi!..._519hi!..._519hi!..._519hi!..._519hi!..._ 4#44hi!..._519hi!..._519hi!..._519hi!..._519hi!..._5");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "#4 4#", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                               ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        char[] charArray5 = new char[] { ' ', '#', '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ', 5, (int) (short) 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "  # 4" + "'", str13.equals("  # 4"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0" + "'", str1.equals("0"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("phie/Library/Java/Extensio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"phie/Library/Java/Extensio\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("JAVA vIRTUAL mACHINE sPECIFICATION                                                                  ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss", "a   4 # as:/Ne1.7avary/Ja/Exte", 40);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "14104-145241", (java.lang.CharSequence) "1.2", 79);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 30, (double) 22.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 30.0d + "'", double3 == 30.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten" + "'", str2.equals("ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "10.1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("354041004974100", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.54040999E14f + "'", float2 == 3.54040999E14f);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("################4.1################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################4.1###############" + "'", str1.equals("################4.1###############"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaa", "sun.awt.CG");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!..._519");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("..._51964_1560279240/target/classes:/Users/sophie...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "..._51964_1560279240/target/classes:/Users/sophie..." + "'", str1.equals("..._51964_1560279240/target/classes:/Users/sophie..."));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1N4FC0000GN/T/", (int) 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1N4FC0000GN/T/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1N4FC0000GN/T/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "sun.awt.CG");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(" Java0.0a0.0a0.0a10.0a-1.0a10.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Java0.0a0.0a0.0a10.0a-1.0a10.0" + "'", str2.equals(" Java0.0a0.0a0.0a10.0a-1.0a10.0"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4', 9, 20);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_51964_1560279240/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r", "http://java.oracle.com/", "# 4 4   a a", 22);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_51964_1560279240/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_51964_1560279240/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("        E", 79, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################        E###################################" + "'", str3.equals("###################################        E###################################"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/...", 38, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("0.0410.040.040.040.0", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                        0.0410.040.040.040.0                                        " + "'", str2.equals("                                        0.0410.040.040.040.0                                        "));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("class [Dclass [Sclass [Bclass [Dclass [B");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CLASS [DCLASS [SCLASS [BCLASS [DCLASS [B" + "'", str1.equals("CLASS [DCLASS [SCLASS [BCLASS [DCLASS [B"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 28, (int) (byte) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', (int) (short) 0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                                                     Java(TM) SE Runtime Environment", "         24.80-b11          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                     Java(TM) SE Runtime Environment" + "'", str2.equals("                                                                     Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("S:USRIBAVA", (float) 20);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 20.0f + "'", float2 == 20.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Virtual Machine Specification", (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmente", "#a4a a a a#", "         24.80-b11          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmente" + "'", str3.equals("ironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmente"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten", "#########");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/", "/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr" + "'", str2.equals("/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        char[] charArray11 = new char[] { '#', '4', '4', ' ', 'a', 'a' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                     Java(TM) SE Runtime Environment", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                        hi", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.4", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15aaaaaaaaaaaaaaaaaaaa", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("_80.jdk/Contents/Home/jre/lib/endorsed##########", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "VVVVVVVVV/", (java.lang.CharSequence) "0 -1 52 10 0 100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie/Library/Java/E");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/E\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        char[] charArray6 = new char[] { ' ', '#', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J", charArray6);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ', 11, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " ###4" + "'", str10.equals(" ###4"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " a#a4" + "'", str12.equals(" a#a4"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_51964_1560279240/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_51964_1560279240/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_51964_1560279240/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("-1.0A100.0A10.0A100.0");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "0.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   " + "'", str1.equals("                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   "));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "Java Platform API Specific", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.Class<?> wildcardClass5 = javaVersion4.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str10 = javaVersion9.toString();
        boolean boolean11 = javaVersion8.atLeast(javaVersion9);
        boolean boolean12 = javaVersion7.atLeast(javaVersion8);
        boolean boolean13 = javaVersion6.atLeast(javaVersion8);
        boolean boolean14 = javaVersion4.atLeast(javaVersion6);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean16 = javaVersion1.atLeast(javaVersion4);
        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.2" + "'", str10.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!", "");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) ":                                                                                                ", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "-1.04100.0410.04100.0");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JAVA vIRTUAL mACHINE sPECIFICATION", (java.lang.CharSequence[]) strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!" + "'", str10.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80-b15aaaaaaaaaaaaaaaaaaaa", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15####################" + "'", str3.equals("1.7.0_80-b15####################"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java(TM) SE Runtime Environmentaaaaaaaaaaaaaaaaa", "1.4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                    ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("24.80-b11", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7" + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "http://java.oracle.com", (java.lang.CharSequence) "                                                           mixed mJava Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10.14.3", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", " a#a4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "43" + "'", str3.equals("43"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "#44444 4a4a", (java.lang.CharSequence) "1N4FC0000GN/T/", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Lib", 8, "..._51964_1560279240/target/classes:/Users/sophie...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Lib" + "'", str3.equals("users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Lib"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sun.awt.CGraphicsEnvironment", 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aasun.awt.CGraphicsEnvironmentaa" + "'", str3.equals("aasun.awt.CGraphicsEnvironmentaa"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "10");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 12, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 38, 7.0f, 7.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 7.0f + "'", float3 == 7.0f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "/var/folders/_v/6v59", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("#44444 4a4a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#44444 4a4" + "'", str1.equals("#44444 4a4"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("32#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32#-1" + "'", str1.equals("32#-1"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Java/100.0#52.0", ":                                            ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/100.0#52.0" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/100.0#52.0"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", (java.lang.CharSequence) "                                                                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "LyJvJvVM8CH", (java.lang.CharSequence) "4###4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/Us.0s/s10./L0b010y/-1.1/Ex..0s00s:/L0b010y/-1.1/Ex..0s00s:/N..w0k/L0b010y/-1.1/Ex..0s00s:/ys..m/L0b010y/-1.1/Ex..0s00s:/0s0/10b/j1.1:.", "1.7.0_80-b15aaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Us.0s/s10./L0b010y/-1.1/Ex..0s00s:/L0b010y/-1.1/Ex..0s00s:/N..w0k/L0b010y/-1.1/Ex..0s00s:/ys..m/L0b010y/-1.1/Ex..0s00s:/0s0/10b/j1.1:." + "'", str2.equals("/Us.0s/s10./L0b010y/-1.1/Ex..0s00s:/L0b010y/-1.1/Ex..0s00s:/N..w0k/L0b010y/-1.1/Ex..0s00s:/ys..m/L0b010y/-1.1/Ex..0s00s:/0s0/10b/j1.1:."));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', (int) 'a', (int) (byte) -1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 8, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 100 + "'", short14 == (short) 100);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.3", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                           1.3" + "'", str2.equals("                           1.3"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "52a10a...", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.maco#terJob#######", (java.lang.CharSequence) "JAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-B11");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                     Java(TM) SE Runtime Environmen", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                     Java(TM) SE Runtime Environmen" + "'", str2.equals("                                                                     Java(TM) SE Runtime Environmen"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        long[] longArray1 = new long[] { (byte) 1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaa", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "noit cificepS enihc M l utriV  v J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8", "1.1", "/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        double[] doubleArray4 = new double[] { (byte) -1, 100, 10, 100L };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0 100.0 10.0 100.0" + "'", str7.equals("-1.0 100.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.0 100.0 10.0 100.0" + "'", str9.equals("-1.0 100.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0 100.0 10.0 100.0" + "'", str12.equals("-1.0 100.0 10.0 100.0"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        short[][] shortArray0 = new short[][] {};
        short[][] shortArray1 = new short[][] {};
        short[][] shortArray2 = new short[][] {};
        short[][][] shortArray3 = new short[][][] { shortArray0, shortArray1, shortArray2 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray3);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("0.00.00.010.0-1.010.0", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "           0.00.00.010.0-1.010.0" + "'", str2.equals("           0.00.00.010.0-1.010.0"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "-140452432420");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/LIBRARY/JAVA/JAVAVIRT1ALMACHINE./JDK1.7.0_80.JDK/CONTENT./HOME/JRE/LIB/ENDOR.ED", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 34, "100#0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#0100#0100#0100#0100#0100#0100#" + "'", str3.equals("100#0100#0100#0100#0100#0100#0100#"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        float[] floatArray5 = new float[] { (short) 0, 10L, 0, 0L, 0.0f };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', (int) (short) 100, (int) '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0.0410.040.040.040.0" + "'", str11.equals("0.0410.040.040.040.0"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 10.0f + "'", float12 == 10.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("java Virtual Machine Specification", "1.7.0_80", (int) (short) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "##########");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java Virtual Machine Specification" + "'", str5.equals("java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java Virtual Machine Specification" + "'", str7.equals("java Virtual Machine Specification"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("52#0#97#52", 2, 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#0#97#52" + "'", str3.equals("#0#97#52"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7" + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("32 -1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32 -1" + "'", str2.equals("32 -1"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) " ", (java.lang.CharSequence[]) strArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "100", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("################################", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (short) -1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/extensions:/ne1.7avary/ja/extensions:/libravary/ja/users/sophie/libr1.7.0_80-b151.7.0_80-b151.7.0_8", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", " l utriV  v J");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("      51.0", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      51.0" + "'", str2.equals("      51.0"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", 69);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "################################", (java.lang.CharSequence[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Lib");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                      ", "..._51964_1560279240/target/classes:/Users/sophie...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      " + "'", str2.equals("                      "));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("0.00140.0140.00140.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.00140.0140.00140.1" + "'", str1.equals("0.00140.0140.00140.1"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) " Java0.0a0.0a0.0a10.0a-1.0a10.0", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1.equals(0.0d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        int[] intArray2 = new int[] { ' ', (-1) };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "32 -1" + "'", str5.equals("32 -1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "324-1" + "'", str8.equals("324-1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32 -1" + "'", str10.equals("32 -1"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "phie/Library/Java/Extensio", (java.lang.CharSequence) "-1.0 100.0 10.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sopsue/Lubrary/Java/Extensuons:/Lubrary/Java/Extensuons:/Network/Lubrary/Java/Extensuons:/System/Lubrary/Java/Extensuons:/usr/lub/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sopsue/Lubrary/Java/Extensuons:/Lubrary/Java/Extensuons:/Network/Lubrary/Java/Extensuons:/System/Lubrary/Java/Extensuons:/usr/lub/java:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("4# #4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4##4" + "'", str1.equals("4##4"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                    ", 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                    " + "'", str3.equals("                                                                                                    "));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8", "Java(TM) SE Runtime Environmentaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8" + "'", str2.equals("/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                        ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "4444444444444444444444444444444444444444444444100#04444444444444444444444444444444444444444444444", (java.lang.CharSequence) "0414100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                                                                    ", "", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                    " + "'", str3.equals("                                                                                                    "));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("4### ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10", "100#0", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("0.0#10.0#0.0#0.0#0.0", "hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0#10.0#0.0#0.0#0.0" + "'", str2.equals("0.0#10.0#0.0#0.0#0.0"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        char[] charArray6 = new char[] { ' ', '#', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ', 638, 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + " a#a4" + "'", str15.equals(" a#a4"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        char[] charArray8 = new char[] { ' ', '#', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100#0", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444", charArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                           1.3", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + " 4#44" + "'", str14.equals(" 4#44"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "###################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        char[] charArray8 = new char[] { '#', '4', ' ', ' ', ' ', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                ", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "##########", charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', 97, 16);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#444 4 4 4#" + "'", str12.equals("#444 4 4 4#"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM                                                                   ", (java.lang.CharSequence) "/U/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/rs/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1.0 100.0 10.0 100.0", 16, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0 100.0 10.0 100.0" + "'", str3.equals("-1.0 100.0 10.0 100.0"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "4##4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "/Users/sophie/Docum 444444444/Users/sophie/Docum");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/" + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/"));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("..._51964_1560279240/target/classes:/Users/sophie...", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(62.0d, 1.0d, (double) 630L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.41.41.41.sun.awt.CG1.41.41.41.", "", "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_51964_1560279240/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA" + "'", str3.equals("1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1, 30.0d, (double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 30.0d + "'", double3 == 30.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                                                                                                                                                                               /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav                                                                                                                                                                                                               ", "hi", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "354041004974100", 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Users/sopsue/Lubrary/Java/Extensuons:/Lubrary/Java/Extensuons:/Network/Lubrary/Java/Extensuons:/System/Lubrary/Java/Extensuons:/usr/lub/java:.", "SOPHIE", "sun.lwawt.macosx.CPrinterJob#######");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sopsue/Lubrary/Java/Extensuons:/Lubrary/Java/Extensuons:/Network/Lubrary/Java/Extensuons:/System/Lubrary/Java/Extensuons:/usr/lub/java:." + "'", str3.equals("/Users/sopsue/Lubrary/Java/Extensuons:/Lubrary/Java/Extensuons:/Network/Lubrary/Java/Extensuons:/System/Lubrary/Java/Extensuons:/usr/lub/java:."));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        char[] charArray10 = new char[] { '#', '4', ' ', ' ', ' ', '#' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                ", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "en", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JAVA vIRTUAL mACHINE sPECIFICATION", charArray10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "#a4a a a a#" + "'", str15.equals("#a4a a a a#"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str4 = javaVersion3.toString();
        boolean boolean5 = javaVersion2.atLeast(javaVersion3);
        boolean boolean6 = javaVersion1.atLeast(javaVersion2);
        boolean boolean7 = javaVersion0.atLeast(javaVersion2);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        java.lang.String str9 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2" + "'", str4.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.2" + "'", str9.equals("1.2"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.Class<?> wildcardClass4 = byteArray1.getClass();
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 1 + "'", byte9 == (byte) 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        int[] intArray2 = new int[] { 100, (short) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', 100, 1);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray2, '#', 35, 9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100a0" + "'", str14.equals("100a0"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!..._519hi!..._519hi!..._519hi!..._519hi!..._ 4#44hi!..._519hi!..._519hi!..._519hi!..._519hi!..._5");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(10L, (long) 10, (long) 2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("             ", (int) ' ', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.4/Extensions:/Ne1.7avary/Ja/Exte", charSequence1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("desrodne/bil/erj/emoH/stnetnoC/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        long[] longArray4 = new long[] { '4', (short) 0, 97L, 52 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 5, 0);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 31, (int) (short) -1);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52#0#97#52" + "'", str8.equals("52#0#97#52"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 97L + "'", long13 == 97L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("#444 4 4 4#", "        Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         E", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#aaaaaaaaa#" + "'", str3.equals("#aaaaaaaaa#"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "52 0 97 52IE");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "52 0 97 52IE" + "'", charSequence2.equals("52 0 97 52IE"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "       ", 40, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10 100", ' ');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "ensun");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", ":                                                                                                ");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "1.2");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.split("", "10");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, "         /");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("#444 4 4 4#", strArray9, strArray15);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8", strArray5, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str11.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "#444 4 4 4#" + "'", str18.equals("#444 4 4 4#"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "aaaaaaaaaaaaaaaxaCPaaaaaaJaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80S1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80o1.7.0_80r1.7.0_80g1.7.0_80.1.7.0_80a1.7.0_80p1.7.0_80a1.7.0_80c1.7.0_80h1.7.0_80e1.7.0_80.1.7.0_80c1.7.0_80o1.7.0_80m1.7.0_80m1.7.0_80o1.7.0_80n1.7.0_80s1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_8031.7.0_80.1.7.0_80J1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80V1.7.0_80e1.7.0_80r1.7.0_80s1.7.0_80i1.7.0_80o1.7.0_80n1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80S1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80o1.7.0_80r1.7.0_80g1.7.0_80.1.7.0_80a1.7.0_80p1.7.0_80a1.7.0_80c1.7.0_80h1.7.0_80e1.7.0_80.1.7.0_80c1.7.0_80o1.7.0_80m1.7.0_80m1.7.0_80o1.7.0_80n1.7.0_80s1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_8031.7.0_80.1.7.0_80J1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80V1.7.0_80e1.7.0_80r1.7.0_80s1.7.0_80i1.7.0_80o1.7.0_80n1.7.0_80" + "'", str1.equals("1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80S1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80o1.7.0_80r1.7.0_80g1.7.0_80.1.7.0_80a1.7.0_80p1.7.0_80a1.7.0_80c1.7.0_80h1.7.0_80e1.7.0_80.1.7.0_80c1.7.0_80o1.7.0_80m1.7.0_80m1.7.0_80o1.7.0_80n1.7.0_80s1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_8031.7.0_80.1.7.0_80J1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80V1.7.0_80e1.7.0_80r1.7.0_80s1.7.0_80i1.7.0_80o1.7.0_80n1.7.0_80"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 0.9d, (double) 35);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        long[] longArray4 = new long[] { '4', (short) 0, 97L, 52 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 69, 35);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52#0#97#52" + "'", str8.equals("52#0#97#52"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "5240497452" + "'", str15.equals("5240497452"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("S:USRIBAVA", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!", 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "S:USRIBAVA" + "'", str3.equals("S:USRIBAVA"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "###############################################sophie###############################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "4###4", (java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("a   4 # a");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "10 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("51.0", "Java Platform API Specific");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JAVA vIRTUAL mACHINE sPECIFICATION", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "ensun", (java.lang.CharSequence) "-1.0A100.0A10.0A100.0", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        int[] intArray5 = new int[] { (byte) 1, (byte) 10, (byte) -1, '4', (byte) 1 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a', (int) ' ', 79);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("################4.1################1.7################4.1################1.7################4.1################1.7################4.1################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################4.1################1.7################4.1################1.7################4.1################1.7################4.1################" + "'", str1.equals("################4.1################1.7################4.1################1.7################4.1################1.7################4.1################"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/extensions://extensio10.1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        char[] charArray6 = new char[] { ' ', '#', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ', 5, (int) (short) 1);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "52a10a...", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "a # 4 a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Ne1.7", "                                        ", 52, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                        Extensions:/Ne1.7" + "'", str4.equals("                                        Extensions:/Ne1.7"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        char[] charArray6 = new char[] { ' ', '#', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "l utriV  v J", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " ###4" + "'", str10.equals(" ###4"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " a#a4" + "'", str12.equals(" a#a4"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("#aaaaaaaaa#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("E", "", "/extensions:/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "E" + "'", str3.equals("E"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("GC.twa.nu", "52 0 97 52IE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52 0 97 52IE" + "'", str2.equals("52 0 97 52IE"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("-1.04100.0410.04100.0", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "           -1.04100.0410.04100.0" + "'", str2.equals("           -1.04100.0410.04100.0"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0.0a0.0a0.0a10.0a-1.0a10.0", 22, 53);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0" + "'", str3.equals("10.0"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        float[] floatArray6 = new float[] { 0.0f, 0, 0L, (short) 10, (-1L), 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4', (int) (byte) 0, 5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        float float15 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.040.040.0410.04-1.0" + "'", str12.equals("0.040.040.0410.04-1.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.040.040.0410.04-1.0410.0" + "'", str14.equals("0.040.040.0410.04-1.0410.0"));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 10.0f + "'", float15 == 10.0f);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("##########################################################################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "#0#1#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.Class<?> wildcardClass4 = byteArray1.getClass();
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', (int) (short) 0, 638);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.awt.CGraphicsEnvironment", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/", 97, "                                                                               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/" + "'", str3.equals("95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("10.14.3", "", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.71/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.70/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.71/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.74/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.73/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7" + "'", str3.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.71/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.70/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.71/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.74/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.73/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(". . . . -. .. . . . -. .");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7", (java.lang.CharSequence) "        Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         E", 324);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("         24.80-b11          ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51964_1560279240", (int) '4');
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "# 4", (java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("a");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!", "");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) ":                                                                                                ", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(":", "", 35);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.CPrinterJob#######", strArray4, strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "sun.lwawt.macosx.CPrinterJob#######" + "'", str10.equals("sun.lwawt.macosx.CPrinterJob#######"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!" + "'", str11.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "52a10a1a-1", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("10100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10100" + "'", str1.equals("10100"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("100#0100#0100#0100#0100#0100#0100#", 630, "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80100#0100#0100#0100#0100#0100#0100#" + "'", str3.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80100#0100#0100#0100#0100#0100#0100#"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "10.0 -1.0 10.0 0.0 0.0 10.0.0 -1.0 10.0 0.0 0.0 00.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "a", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        long[] longArray5 = new long[] { '#', (short) 0, 100L, 97L, 100L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', 20, (int) (byte) 1);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "354041004974100" + "'", str8.equals("354041004974100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("ironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmente", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmente" + "'", str2.equals("ironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmente"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTP://JAVA.ORACLE.COM/" + "'", str1.equals("HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "JAVAvIRTUALmACHINEsPECIFICATION", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(34, 8, 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("0.040.040.0410.04-1.0410.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("4# #4\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", 31, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "mixed ", (java.lang.CharSequence) ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0", "###############################################sophie###############################################", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 1, (int) (byte) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "/extensions:/");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /extensions:/");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(" ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Lib", 630, 638);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("class [Sclass [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersion", (long) 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str6 = javaVersion5.toString();
        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
        boolean boolean8 = javaVersion3.atLeast(javaVersion4);
        boolean boolean9 = javaVersion2.atLeast(javaVersion4);
        boolean boolean10 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.Class<?> wildcardClass12 = javaVersion11.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str17 = javaVersion16.toString();
        boolean boolean18 = javaVersion15.atLeast(javaVersion16);
        boolean boolean19 = javaVersion14.atLeast(javaVersion15);
        boolean boolean20 = javaVersion13.atLeast(javaVersion15);
        boolean boolean21 = javaVersion11.atLeast(javaVersion13);
        boolean boolean22 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean23 = javaVersion0.atLeast(javaVersion11);
        org.apache.commons.lang3.JavaVersion javaVersion24 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.Class<?> wildcardClass25 = javaVersion24.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion26 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion27 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion28 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion29 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str30 = javaVersion29.toString();
        boolean boolean31 = javaVersion28.atLeast(javaVersion29);
        boolean boolean32 = javaVersion27.atLeast(javaVersion28);
        boolean boolean33 = javaVersion26.atLeast(javaVersion28);
        boolean boolean34 = javaVersion24.atLeast(javaVersion26);
        boolean boolean35 = javaVersion11.atLeast(javaVersion24);
        java.lang.String str36 = javaVersion11.toString();
        java.lang.String str37 = javaVersion11.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.2" + "'", str6.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.2" + "'", str17.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + javaVersion24 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion24.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + javaVersion26 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion26.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion27 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion27.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion28 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion28.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion29 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion29.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1.2" + "'", str30.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1.5" + "'", str36.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1.5" + "'", str37.equals("1.5"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1N4FC0000GN/T/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1N4FC0000GN/T/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1N4FC0000GN/T/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, '#', 26, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "mixed mJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Ne1.7");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J", (int) '#', "ironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmentensun. wt.CGr phicsEnvironmente");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J" + "'", str3.equals("   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                  Java Platform API Specification                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 1, (int) (byte) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0a1a100" + "'", str10.equals("0a1a100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0#1#100" + "'", str12.equals("0#1#100"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "", " Java HotSpot(TM) 64-Bit Server VM ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        float[] floatArray6 = new float[] { 0.0f, 0, 0L, (short) 10, (-1L), 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4', (int) (byte) 0, 5);
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float15 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float16 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.040.040.0410.04-1.0" + "'", str12.equals("0.040.040.0410.04-1.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + (-1.0f) + "'", float13 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 10.0f + "'", float14 == 10.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 10.0f + "'", float15 == 10.0f);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 10.0f + "'", float16 == 10.0f);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0.040.040.0410.04-1.0410.0" + "'", str18.equals("0.040.040.0410.04-1.0410.0"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "ironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmente", (java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1.0a100.0a10.0a100.0", "-1.0#100.0#10.0#100.0", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        double[] doubleArray4 = new double[] { (byte) -1, 100, 10, 100L };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', (int) (short) 10, (int) (short) 0);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("         ###4", (int) '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444         ###444444444444" + "'", str3.equals("44444444444         ###444444444444"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("0.0#10.0#0.0#0.0#0.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        char[] charArray7 = new char[] { '4', '#', '4', '4', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "44#44444 " + "'", str11.equals("44#44444 "));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger(" Java HotSpot(TM) 64-Bit Server VM ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" Java HotSpot(TM) 64-Bit Server VM \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "Java HotSpot(TM) 64-Bit Server VM                                                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                mixed mJava Platform API Specification", (java.lang.CharSequence) "java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67 + "'", int2 == 67);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 1, (int) (byte) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 52, (int) (byte) 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ', 97, (int) (byte) -1);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "##########################################################################################");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ##########################################################################################");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0#1#100" + "'", str13.equals("0#1#100"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 1, (int) (byte) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', 26, (int) (byte) 1);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 35, 7);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte20 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0a1a100" + "'", str19.equals("0a1a100"));
        org.junit.Assert.assertTrue("'" + byte20 + "' != '" + (byte) 0 + "'", byte20 == (byte) 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                  Java Platform API Specification                                   ", 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                 " + "'", str2.equals("                                 "));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("24.80-b11", 11, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4424.80-b11" + "'", str3.equals("4424.80-b11"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "################################", (java.lang.CharSequence) "1.7.0_80", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("4###4", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#4" + "'", str2.equals("4#4"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("0.00140.0140.00140.1", "                                                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.00140.0140.00140.1" + "'", str2.equals("0.00140.0140.00140.1"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss", (java.lang.CharSequence) "# 4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        char[] charArray7 = new char[] { ' ', '#', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "32 -1", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " 4#44java Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual ", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "  # 4" + "'", str11.equals("  # 4"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" Java0.0a0.0a0.0a10.0a-1.0a10.0", "5", 53);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.2", '4');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "class [Dclass [Sclass [Bclass [Dclass [B", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "# 4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                   Java(TM) SE Runtime Environment                   ", (int) (short) 0, "#444 4 4 4#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                   Java(TM) SE Runtime Environment                   " + "'", str3.equals("                   Java(TM) SE Runtime Environment                   "));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 53, 638L, (long) (short) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("..._51964_1560279240/target/classes:/Users/sophie...");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "100.0#52.0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.3", (java.lang.CharSequence) "#0#1#100", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi", " Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0", 638);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100 0", "                               a       a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("         ###4", (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "a5", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":                                                                                                ", "", 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "-1.0 100.0 10.0 100.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + ":                                                                                                " + "'", str5.equals(":                                                                                                "));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        char[] charArray9 = new char[] { ' ', '#', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, '#', (int) '4', 0);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#", charArray9);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "5.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.1", charArray9);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                                  Java Platform API Specification                                   ", (java.lang.CharSequence) "################4.1################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        float[] floatArray6 = new float[] { 0.0f, 0, 0L, (short) 10, (-1L), 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.040.040.0410.04-1.0410.0" + "'", str9.equals("0.040.040.0410.04-1.0410.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 10.0f + "'", float10 == 10.0f);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Librar...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!..._519", "24.80-B11");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "0.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4#4", (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/var/folders/_v/6v59", 53, "10a100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v5910a10010a10010a10010a10010a10010a" + "'", str3.equals("/var/folders/_v/6v5910a10010a10010a10010a10010a10010a"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Li0.0 0.0 0.0 10.0 -1.0 10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Li0.0 0.0 0.0 10.0 -1.0 10.0 is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("J v  Virtu l M chine Specific tion", "4444444444444444444444444444444444444444444444100#04444444444444444444444444444444444444444444444", 324);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/h" + "'", str1.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/h"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        float[][] floatArray0 = new float[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(floatArray0);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "E");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "E        ", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("http://java.oracle.com/", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4###4", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4###4" + "'", str2.equals("4###4"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "/Users/sophie/Library/Java/Extensio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "#a4a a a a#", (int) (short) 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                       a       a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        long[] longArray5 = new long[] { (short) -1, 0L, 52L, 32, 20L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1 0 52 32 20" + "'", str7.equals("-1 0 52 32 20"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("USRSSOPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("  # 4", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  # 4" + "'", str3.equals("  # 4"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0#1#100", (java.lang.CharSequence) "ensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmenten");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/95v6/v_/sredlof/rav/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str4 = javaVersion3.toString();
        boolean boolean5 = javaVersion2.atLeast(javaVersion3);
        java.lang.String str6 = javaVersion3.toString();
        boolean boolean7 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str8 = javaVersion0.toString();
        java.lang.String str9 = javaVersion0.toString();
        java.lang.String str10 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2" + "'", str4.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.2" + "'", str6.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.2" + "'", str8.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.2" + "'", str9.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.2" + "'", str10.equals("1.2"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("#a4a a a a#", "ttp://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a4a a a a#" + "'", str2.equals("#a4a a a a#"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 1, (int) (byte) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray2, strArray5);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '#', 40, 2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str9.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str10.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "5.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.1", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444100#0444444444444444444444444444444444444444444444", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 69.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 69.0d + "'", double2 == 69.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80", 16, "/Users/sophie/Library/Java/Extensions:/Library/Java/100.0#52.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80/Users/s" + "'", str3.equals("1.7.0_80/Users/s"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', (int) 'a', (int) (byte) -1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', (int) '#', 22);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 100 + "'", short14 == (short) 100);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                           4# #4                                                mixed mJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4# #4                                                mixed mJava Platform API Specification" + "'", str1.equals("4# #4                                                mixed mJava Platform API Specification"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 354041004974100L, (float) (short) 10, (float) 10L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.54040999E14f + "'", float3 == 3.54040999E14f);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "# 4 4   a a", (java.lang.CharSequence) "52a10a1a-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " ###4", (java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("4###4", (float) 12);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 12.0f + "'", float2 == 12.0f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test477");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) " # 4 ", (java.lang.CharSequence) "0.040.040.0410.04-1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!", "");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) ":                                                                                                ", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "5240497452", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        long[] longArray5 = new long[] { (short) -1, 0L, 52L, 32, 20L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1 0 52 32 20" + "'", str7.equals("-1 0 52 32 20"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1#0#52#32#20" + "'", str9.equals("-1#0#52#32#20"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "################4.1###############", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        int[] intArray2 = new int[] { ' ', (-1) };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', (int) (byte) -1, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "32 -1" + "'", str5.equals("32 -1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "32a-1" + "'", str8.equals("32a-1"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.7.0_80/Users/s", (java.lang.CharSequence) "        Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         E");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "# #4                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(48, 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 48 + "'", int3 == 48);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                           4# #4                                                mixed mJava Platform API Specification", "                                                                                                                                                                                                                                                                             4# #4\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                           4# #4                                                mixed mJava Platform API Specification" + "'", str2.equals("                           4# #4                                                mixed mJava Platform API Specification"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        int[] intArray0 = new int[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ', (int) (byte) 1, (-1));
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a');
        try {
            int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80100#0100#0100#0100#0100#0100#0100#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "-1.0#100.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 21 + "'", int1 == 21);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "-1.0#100.0#10.0#100.0", (java.lang.CharSequence) "/extensions:/ne1.7avary/ja/extensions:/libravary/ja/users/sophie/libr1.7.0_80-b151.7.0_80-b151.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_51964_1560279240/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r", 62);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "HTTP://JAVA.ORACLE.COM/", "#4 4#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4###4", (java.lang.CharSequence) "                                 ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("324", 40);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                     324" + "'", str2.equals("                                     324"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################################" + "'", str1.equals("################################"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1a100a0a100a-1a-1", (java.lang.CharSequence) "-1.04100.0410.04100.0           ", 638);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 23 + "'", int3 == 23);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        long[] longArray4 = new long[] { '4', (short) 0, 97L, 52 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 5, 0);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52#0#97#52" + "'", str8.equals("52#0#97#52"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 97L + "'", long13 == 97L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("24.80-B11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }
}

