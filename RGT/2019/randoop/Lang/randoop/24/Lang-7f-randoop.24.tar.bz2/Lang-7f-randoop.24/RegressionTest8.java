import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) ":                                            ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("GC.tw.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GC.tw.nus" + "'", str1.equals("GC.tw.nus"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "52410414-1", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        float[] floatArray6 = new float[] { 0.0f, 0, 0L, (short) 10, (-1L), 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4', (int) (byte) 0, 5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', 0, 2);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.040.040.0410.04-1.0" + "'", str12.equals("0.040.040.0410.04-1.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0.0a0.0" + "'", str16.equals("0.0a0.0"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/extensions://extensio10.1.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/extensions://extensio10.1.3\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        char[] charArray8 = new char[] { ' ', '#', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "SOPHIE", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mJava Platform API Specification", charArray8);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophie", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " 4#44" + "'", str12.equals(" 4#44"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + " a#a4" + "'", str16.equals(" a#a4"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                           4# #4Java HotSpot(TM) 64-Bit Server VM              ", "sophie");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("NOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray3, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 6 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        char[] charArray10 = new char[] { '#', '4', '4', ' ', 'a', 'a' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                     Java(TM) SE Runtime Environment", charArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray10, '4');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#44444 4a4a" + "'", str14.equals("#44444 4a4a"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 47 + "'", int16 == 47);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        long[] longArray4 = new long[] { 48, (byte) 10, 69, 48 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 69L + "'", long5 == 69L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 69L + "'", long7 == 69L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 69L + "'", long8 == 69L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "48 10 69 48" + "'", str10.equals("48 10 69 48"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charSequence1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        long[] longArray4 = new long[] { '4', (short) 0, 97L, 52 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 100, (int) (byte) 0);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "52#0#97#52" + "'", str13.equals("52#0#97#52"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("100#0100#0100#0100#0100#0100#0100#", "100#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0100#0100#0100#0100#0" + "'", str2.equals("100#0100#0100#0100#0100#0"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("-1a100a0a100a-1a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1-a1-a001a0a001a1-" + "'", str1.equals("1-a1-a001a0a001a1-"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("0.00.00.010.0-1.010.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.010.1-0.010.00.00.0" + "'", str1.equals("0.010.1-0.010.00.00.0"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("         /");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "4###4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Users/sophie/Doc", (java.lang.CharSequence) "#4 4#", 254);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                                                                                                                                                                                                                                                    ", 23, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                    " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        double[] doubleArray4 = new double[] { (byte) -1, 100, 10, 100L };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', (int) (byte) 0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0 100.0 10.0 100.0" + "'", str7.equals("-1.0 100.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("100.0#52.0", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0#52.0" + "'", str2.equals("100.0#52.0"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("OracleCorporation", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporation" + "'", str2.equals("OracleCorporation"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 5, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 5 + "'", short3 == (short) 5);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1-a1-a001a0a001a1-", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1-a1-a001a0a001a1-" + "'", str3.equals("1-a1-a001a0a001a1-"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("jAVA hOTsPOT(tm) 64-bIT sERVER vm", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#4 4#", (java.lang.CharSequence) "/extensions://extensio10.1.3", 62);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!", "");
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("\n", strArray4, strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0.0410.040.040.040.0");
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("0.9", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 11");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "\n" + "'", str6.equals("\n"));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                    ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        char[] charArray7 = new char[] { ' ', '#', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0.00.00.010.0-1.010.0", charArray7);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                ", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " ###4" + "'", str11.equals(" ###4"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " a#a4" + "'", str13.equals(" a#a4"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + " 4#44" + "'", str15.equals(" 4#44"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80100#0100#0100#0100#0100#0100#0100#", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 26, (float) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0 -1 52 10 0 100");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("10.0 -1.0 10.0 0.0 0.0 10.0.0 -1.0 10.0 0.0 0.0 00.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0 -1.0 10.0 0.0 0.0 10.0.0 -1.0 10.0 0.0 0.0 00.0" + "'", str1.equals("10.0 -1.0 10.0 0.0 0.0 10.0.0 -1.0 10.0 0.0 0.0 00.0"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart(" ###4", "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " ###4" + "'", str2.equals(" ###4"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("4# #4                                                mixed mJava Platform API Specification", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4# #4               ..." + "'", str2.equals("4# #4               ..."));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                      ", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                      " + "'", str3.equals("                      "));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("mixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mixed mode\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        char[] charArray7 = new char[] { ' ', '#', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " 444444444", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(22, 38, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 38 + "'", int3 == 38);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("10.1.3", "0.0 0.0 0.0 10.0 -1.0 10.0", 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.3" + "'", str3.equals("10.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.3"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "#a4a a a a#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("################4.1################1.7################4.1################1.7################4.1################1.7################4.1################", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " 4#44java Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual ", (java.lang.CharSequence) "# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4# 4", (int) (short) 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("0.040.040.0410.04-1.0", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.040.040.0410.04-1.0" + "'", str2.equals("0.040.040.0410.04-1.0"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("JAVA HOTSPOT(TM) 64-BIT SERVER VM", "410.040.040.04");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str2.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1.0 100.0 10.0 100.0", 69, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 10.0 100.0" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 10.0 100.0"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                                    ", "                                                           mixed mJava Platform API Specification", "1.5");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111" + "'", str3.equals("1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "5.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1-1##########################################################################################", "/Users/sopsue/Lubrary/Java/Extensuons:/Lubrary/Java/Extensuons:/Network/Lubrary/Java/Extensuons:/System/Lubrary/Java/Extensuons:/usr/lub/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1-1##########################################################################################" + "'", str2.equals("1-1##########################################################################################"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("14104-145241");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("32#-1                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32#-1                             " + "'", str1.equals("32#-1                             "));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100#0100#0100#0100#0100#0", (java.lang.CharSequence) "0.00.00.010.0-1.010.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 21, (long) 32, (long) 38);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 21L + "'", long3 == 21L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                          ", "http://java.oracle.com");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          " + "'", str2.equals("                          "));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                                                                                                               /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav                                                                                                                                                                                                               ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "52 0 97 52IE", "sions:/Libr                        ###4v                        ###4ry/J                        ###4/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("100.0a52.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0a52.0" + "'", str1.equals("100.0a52.0"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("...sions:/Libr#ry/J#v#/Extensions:/Network/Libr#ry/J#v#/Extensions:/System/Libr#ry/J#v#/Extension...", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...sions:/Libr#ry/J#v#/Extensions:/Network/Libr#ry/J#v#/Extensions:/System/Libr#ry/J#v#/Extension..." + "'", str2.equals("...sions:/Libr#ry/J#v#/Extensions:/Network/Libr#ry/J#v#/Extensions:/System/Libr#ry/J#v#/Extension..."));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("java Virtual Machine Specification", "1.7.0_80", (int) (short) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java Virtual Machine Specification" + "'", str5.equals("java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java Virtual Machine Specification" + "'", str6.equals("java Virtual Machine Specification"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0414100", 30, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###########0414100############" + "'", str3.equals("###########0414100############"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "32#-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", ". . . . -. .. . . . -. .");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                               a       a");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        int[] intArray0 = new int[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ', (int) (byte) 1, (-1));
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        try {
            int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 97, 7L, (long) 48);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) -1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                       a       a./L0b010y/-1.1/Ex..0s00s:/L0b010y/-1.1/Ex..0s00s:/N..w0k/L0b010y/-1.1/Ex..0s00s:/ys..m/L0b010y/-1.1/Ex..0s00s:/0s0/10b/j1.1:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a       a./L0b010y/-1.1/Ex..0s00s:/L0b010y/-1.1/Ex..0s00s:/N..w0k/L0b010y/-1.1/Ex..0s00s:/ys..m/L0b010y/-1.1/Ex..0s00s:/0s0/10b/j1.1:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', 77, 70);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, '4', 48, (int) (short) 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0.0a0.0a0.0a10.0a-1.0a10.0                                                                       ", (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444100#0444444444444444444444444444444444444444444444", 21, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        char[] charArray8 = new char[] { '#', '4', '4', ' ', 'a', 'a' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                     Java(TM) SE Runtime Environment", charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#44444 4a4a" + "'", str12.equals("#44444 4a4a"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "# 4 4   a a" + "'", str14.equals("# 4 4   a a"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "##4#4# #a#a" + "'", str16.equals("##4#4# #a#a"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("a      ", (double) 69);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 69.0d + "'", double2 == 69.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "         24.80-B11          ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(" 444444444", "hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 444444444" + "'", str2.equals(" 444444444"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split(":", "-1.0 100.0 10.0 100.0", (int) (short) 100);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("java Virtual Machine Specification", "1.7.0_80", (int) (short) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("52#0#97#52", strArray6, strArray10);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.split("                        ###4", "                                                    ");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten", strArray10, strArray16);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "32#-1                              ", (java.lang.CharSequence[]) strArray10);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java Virtual Machine Specification" + "'", str12.equals("java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "52#0#97#52" + "'", str13.equals("52#0#97#52"));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten" + "'", str17.equals("ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J", "/Users/sophie/Library/Java/Extensions:/Library/Java/100.0#52.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J" + "'", str3.equals("   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        char[] charArray7 = new char[] { '#', '4', '4', ' ', 'a', 'a' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "# 4 4   a a" + "'", str10.equals("# 4 4   a a"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("\n", "/L...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        long[] longArray4 = new long[] { '4', (short) 0, 97L, 52 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) (short) -1, (int) (byte) -1);
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long15 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52#0#97#52" + "'", str8.equals("52#0#97#52"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        char[] charArray9 = new char[] { '#', '4', ' ', ' ', ' ', '#' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                ", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "##########", charArray9);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "java Virtual Machine Specification", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "#444 4 4 4#" + "'", str13.equals("#444 4 4 4#"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" ###4", "###############################################sophie###############################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(26.0f, (float) (byte) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 26.0f + "'", float3 == 26.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "51.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "USRSSOPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA", (java.lang.CharSequence) "###################################        E###################################", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("...sions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extension...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 100, (byte) 0, (byte) 100, (byte) -1, (byte) -1 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', (int) (short) 100, 20);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1a100a0a100a-1a-1" + "'", str12.equals("-1a100a0a100a-1a-1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1 100 0 100 -1 -1" + "'", str14.equals("-1 100 0 100 -1 -1"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        int[] intArray1 = new int[] { 10 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', (int) (byte) 10, (int) (byte) 1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "a   4 # a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie                                                                                    ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "####################################################", (java.lang.CharSequence) "-1a100a0a100a-1a-1", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "10.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.3", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:    4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("###################################        E###################################", 69, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        double[] doubleArray4 = new double[] { (byte) -1, 100, 10, 100L };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 0, (int) (short) 0);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0 100.0 10.0 100.0" + "'", str8.equals("-1.0 100.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(7L, 5L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("\n", 69, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.7.0_80-b15####################", "                                       a       a./L0b010y/-1.1/Ex..0s00s:/L0b010y/-1.1/Ex..0s00s:/N..w0k/L0b010y/-1.1/Ex..0s00s:/ys..m/L0b010y/-1.1/Ex..0s00s:/0s0/10b/j1.1:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split(" 444444444", ' ');
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(":", strArray4, strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + ":" + "'", str6.equals(":"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 9, (float) 13L, (float) (short) 5);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("X86_64X86_64X86_64X                               a       aX86_64X86_64X86_64X8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8X46_68X46_68X46_68Xa       a                               X46_68X46_68X46_68X" + "'", str1.equals("8X46_68X46_68X46_68Xa       a                               X46_68X46_68X46_68X"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "a   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J", (java.lang.CharSequence) "                                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" # 4 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# 4" + "'", str1.equals("# 4"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80100#0100#0100#0100#0100#0100#0100#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("         24.80-B11          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11" + "'", str1.equals("24.80-B11"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "48 10 69 48");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", charSequence2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                                        ", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRT1ALMACHINE./JDK1.7.0_80.JDK/CONTENT./HOME/JRE/LIB/ENDOR.ED");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("#52", "32#-1                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#52" + "'", str2.equals("#52"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("10.0 -1.0 10.0 0.0 0.0 10.0.0 -1.0 10.0 0.0 0.0 00.0", "14104-145241                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ", "JAVA vIRTUAL mACHINE sPECIFICATION                                                                  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0 -1.0 10.0 0.0 0.0 10.0.0 -1.0 10.0 0.0 0.0 00.0" + "'", str3.equals("10.0 -1.0 10.0 0.0 0.0 10.0.0 -1.0 10.0 0.0 0.0 00.0"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center(" Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0", 79);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0" + "'", str2.equals(" Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("J v  Virtu l M chine Specific tio", " a#a4", "        Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         Ea4 4 4         E");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Ne1.7", 53, "44#44444 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Ne1.7" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Ne1.7"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("-1.0a100.0a10.0a100.0", "hi!..._519hi!..._519hi!..._519hi!..._519hi!..._ 4#44hi!..._519hi!..._519hi!..._519hi!..._519hi!..._5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0a100.0a10.0a100.0" + "'", str2.equals("-1.0a100.0a10.0a100.0"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "        E");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.5", "                                        Extensions:/Ne1.7");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("SOPHIE", "/Librar...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SOPHIE" + "'", str2.equals("SOPHIE"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1 0 52 32 20", (java.lang.CharSequence) "5.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 5L, (double) 630L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "phie/LibraUsers/sophie/D0.0a0.0a0.0a10.0a-1.0a10.0                          phie/LibraUsers/sophie/D");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaxaCPaaaaaaJaa" + "'", str4.equals("aaaaaaaaaaaaaaaxaCPaaaaaaJaa"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("0.0a0.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "52a10a1a-1##########################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!..._519", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        double[] doubleArray4 = new double[] { (byte) -1, 100, 10, 100L };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.Class<?> wildcardClass6 = doubleArray4.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0a100.0a10.0a100.0" + "'", str8.equals("-1.0a100.0a10.0a100.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0a100.0a10.0a100.0" + "'", str10.equals("-1.0a100.0a10.0a100.0"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                        hi", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Mac OS X", "                        hi", 7);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "10", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/extensions:/", "10.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.3", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                        ###4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###4" + "'", str1.equals("###4"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str6 = javaVersion5.toString();
        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
        boolean boolean8 = javaVersion3.atLeast(javaVersion4);
        boolean boolean9 = javaVersion2.atLeast(javaVersion4);
        boolean boolean10 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str11 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.2" + "'", str6.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.3" + "'", str11.equals("1.3"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 0L, (double) 630);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 630.0d + "'", double3 == 630.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("JAVA vIRTUAL mACHINE sPECIFICATION                                                                  ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA vIRTUAL mACHINE sPECIFICATION                                                                  " + "'", str2.equals("JAVA vIRTUAL mACHINE sPECIFICATION                                                                  "));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("NOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"NOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("mixed ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed" + "'", str1.equals("mixed"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "324", (java.lang.CharSequence) "###############################################sophie###############################################", 630);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("24.80-b11", ":", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaUS");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("##########/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed##########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed##########" + "'", str1.equals("##########/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed##########"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("a      ", "354041004974100", 31);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 46, 2L, (long) 20);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", charSequence2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "100.0a52.", (java.lang.CharSequence) "JAVAvIRTUALmACHINEsPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(" Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/ Java0.0a0.0a0.0a10.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "100.0a52.0", (java.lang.CharSequence) "0.0a0.0a0.0a10.0a-1.0a10.0                          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1", " Java HotSpot(TM) 64-Bit Server VM ");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) " ###4", (java.lang.CharSequence[]) strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("-1 0 52 32 20", "# #4                           ", 53);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20" + "'", str3.equals("-1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("#a4a a a a#", 79, "                                  Java Platform API Specification                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                  Java Platform API Specification   #a4a a a a#" + "'", str3.equals("                                  Java Platform API Specification   #a4a a a a#"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 1, (int) (byte) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 79, 2);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0#1#100" + "'", str10.equals("0#1#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0414100" + "'", str12.equals("0414100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0 1 100" + "'", str18.equals("0 1 100"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "100a0", 272);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                                     Java(TM) SE Runtime Environment", "/Users/sophie", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                     Java(TM) SE Runtime Environment" + "'", str3.equals("                                                                     Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("5.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.1", "0");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   ", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   " + "'", str3.equals("                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   "));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        int[] intArray4 = new int[] { '4', 10, (byte) 1, (-1) };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52a10a1a-1" + "'", str6.equals("52a10a1a-1"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                        Extensions:/Ne1.7");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 57 + "'", int1 == 57);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "0a1a100", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Li0.0 0.0 0.0 10.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("51.0", "NOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/7.1EN/:SNOISNETXE/AVAJ/YRARBIL/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0 -1 52 10 0 100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "#44444 4a4a", (java.lang.CharSequence) "a5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        long[] longArray6 = new long[] { 0L, (-1), '4', (byte) 10, (byte) 0, 100 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 -1 52 10 0 100" + "'", str9.equals("0 -1 52 10 0 100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0 -1 52 10 0 100" + "'", str11.equals("0 -1 52 10 0 100"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100.0a52.", 97, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(":                                            ...");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "_80.jdk/Contents/Home/jre/lib/endorsed##########", (java.lang.CharSequence) "0.0a0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("         24.80-b11          ", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         2 .80-b11          " + "'", str3.equals("         2 .80-b11          "));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java Platform API Specific", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("a   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J", (float) 62);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 62.0f + "'", float2 == 62.0f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        double[] doubleArray4 = new double[] { (byte) -1, 100, 10, 100L };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', (int) (short) 10, (int) (short) 0);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#', (int) (short) 5, 48);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("14104-145241", 31, 96);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("tionatform API Specifica Plava                                                mixed mJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: tionatform API Specifica Plava                                                mixed mJ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "20#38#-1#1#638");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("32#-", "desrodne/bil/erj/emoH/stnetnoC/", "/var/folders/_v/6v59");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaa", 28, 26);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (float) 46);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 46.0f + "'", float2 == 46.0f);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Library/Java/Extensions:/Library/Java/100.0#52.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("5.1", "                           4a a4", "100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5.1" + "'", str3.equals("5.1"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(" 4#44java Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual ", 3, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 4#44java Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual " + "'", str3.equals(" 4#44java Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual "));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("JAVA vIRTUAL mACHINE sPECIFICATION                                                                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"J\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "##4#4# #a#a", (java.lang.CharSequence) "4# #4                                                mixed mJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/extensions:/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/EXTENSIONS:/" + "'", str1.equals("/EXTENSIONS:/"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaa", "                               a       a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("FC0000GN/T/41N");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "fC0000GN/T/41N" + "'", str1.equals("fC0000GN/T/41N"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("en", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0.040.040.0410.04-1.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("mixed ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 10, (byte) 1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ', (int) (short) 0, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 10 + "'", byte4 == (byte) 10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 96, (long) 5, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 96L + "'", long3 == 96L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        double[] doubleArray4 = new double[] { (byte) -1, 100, 10, 100L };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.04100.0410.04100.0" + "'", str8.equals("-1.04100.0410.04100.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0a100.0a10.0a100.0" + "'", str11.equals("-1.0a100.0a10.0a100.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.4/Extensions:/Ne1.7avary/Ja/Exte", (java.lang.CharSequence) "   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("http://java.oracle.com/", (long) 38);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 38L + "'", long2 == 38L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-B11");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java HotSpot(TM) 64-Bit Server VM", "aasun.awt.CGraphicsEnvironmentaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        double[] doubleArray1 = new double[] { 43 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 43.0d + "'", double2 == 43.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "\n", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Jav10", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("        SOPHIE        ", ":                                                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        SOPHIE        " + "'", str2.equals("        SOPHIE        "));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("         2 .80-b11          ", "_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss" + "'", str2.equals("_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                  Java Platform API Specification   #a4a a a a#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) " Java0.0a0.0a0.0a10.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "a   4 # as:/Ne1.7avary/Ja/Exte");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("phie/LibraUsers/sophie/D0.0a0.0a0.0a10.0a-1.0a10.0                          phie/LibraUsers/sophie/D", 43, 21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "....0a10.0        ..." + "'", str3.equals("....0a10.0        ..."));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "#######sophie#######UTF-8U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("GC.twa.nus", "###################################", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sophie", "AAAAAAAAAAAAAAAXACPAAAAAAJAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "mixed ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                               " + "'", str1.equals(":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                               "));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        float[] floatArray6 = new float[] { 0.0f, 0, 0L, (short) 10, (-1L), 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#', (int) (short) 100, 35);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.0a0.0a0.0a10.0a-1.0a10.0" + "'", str14.equals("0.0a0.0a0.0a10.0a-1.0a10.0"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aaaaa", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       aaaaa                        " + "'", str2.equals("                       aaaaa                        "));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("44444 4a4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "mixed mJava Platform API Specification", (java.lang.CharSequence) "51.");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "mixed mJava Platform API Specification" + "'", charSequence2.equals("mixed mJava Platform API Specification"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "0 10.0 100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "FC0000GN/T/41N", 38, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(272, 22, 630);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 22 + "'", int3 == 22);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7", 47, 77);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 82 + "'", int3 == 82);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '4', 10, (int) (short) 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("10.0 -1.0 10.0 0.0 0.0 10.0.0 -1.0 10.0 0.0 0.0 00.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1N4FC0000GN/T/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.71/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.70/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.71/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.74/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.73/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("          0.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0                                                                                                              /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav                                                                                                                                                                                                               ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "v                                                                                                                                                                                                               a/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja          0.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0                                                                                                              /Users/sophie/Libr" + "'", str2.equals("v                                                                                                                                                                                                               a/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja          0.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0                                                                                                              /Users/sophie/Libr"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!..._519", (java.lang.CharSequence) "1.4/Extensions:/Ne1.7avary/Ja/Exte", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                   " + "'", str1.equals("                                                                                                   "));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Lib", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        long[] longArray5 = new long[] { (short) -1, 0L, 52L, 32, 20L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1 0 52 32 20" + "'", str7.equals("-1 0 52 32 20"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-140452432420" + "'", str9.equals("-140452432420"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1a0a52a32a20" + "'", str11.equals("-1a0a52a32a20"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "tionatform API Specifica Plava                                                mixed mJ", (java.lang.CharSequence) "a   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0 10.0 100.0", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "\n", (java.lang.CharSequence) "1.7.0_80/Users/s");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Oracle Corporation", "", 66);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("         ", "fC0000GN/T/41N", "OPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         " + "'", str3.equals("         "));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("phie/LibraUsers/sophie/D0.0a0.0a0.0a10.0a-1.0a10.0                          phie/LibraUsers/sophie/D", "0.0a0.0a0.0a10.0a-1.0a10.0                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "phie/LibraUsers/sophie/D0.0a0.0a0.0a10.0a-1.0a10.0                          phie/LibraUsers/sophie/D" + "'", str2.equals("phie/LibraUsers/sophie/D0.0a0.0a0.0a10.0a-1.0a10.0                          phie/LibraUsers/sophie/D"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        boolean boolean7 = javaVersion1.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.Class<?> wildcardClass9 = javaVersion8.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str14 = javaVersion13.toString();
        boolean boolean15 = javaVersion12.atLeast(javaVersion13);
        boolean boolean16 = javaVersion11.atLeast(javaVersion12);
        boolean boolean17 = javaVersion10.atLeast(javaVersion12);
        boolean boolean18 = javaVersion8.atLeast(javaVersion10);
        boolean boolean19 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean20 = javaVersion4.atLeast(javaVersion8);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.2" + "'", str14.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Library/Java/Extensions:/Library/Java/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/library/java/extensions:/library/java/" + "'", str1.equals("/users/sophie/library/java/extensions:/library/java/"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(97.0d, 30.0d, (double) 5L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7.0_80-b15aaaaaaaaaaaaaaaaaaaa", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("4###", "100.0a52.0", "             ", 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4###" + "'", str4.equals("4###"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] { 'a', ' ', '4', '#', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "a   4 # a" + "'", str8.equals("a   4 # a"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/h");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.4:N1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4:N1.7" + "'", str1.equals("1.4:N1.7"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("       ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44" + "'", str2.equals("44"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("0#1#100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0#1#100" + "'", str3.equals("0#1#100"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 48, 630.0f, (float) 13L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 630.0f + "'", float3 == 630.0f);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("noit cificepS enihc M l utriV  v J", "         ###4", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noit cificepS enihc M l utriV  v J" + "'", str3.equals("noit cificepS enihc M l utriV  v J"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("", "hi!", (int) (short) 1);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                     Java(TM) SE Runtime Environment", (java.lang.CharSequence[]) strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "US", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "aaaaaaaaaaaaaaaaaaaaaa", 22);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("95v6/v_/sredlof/rav/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "95v6/v_/sredlof/rav/" + "'", str1.equals("95v6/v_/sredlof/rav/"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA", "1.5", "#######boJret#ocam.twawl.nus");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("0.0#10.0#0.0#0.0#0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(82, 47, 43);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 82 + "'", int3 == 82);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("..._51964_1560279240/target/classes:/Users/sophie...", "4# #4\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("# 4", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "# 4" + "'", str2.equals("# 4"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0.9", (java.lang.CharSequence) "#######boJret#ocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmenten", 47, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmenten" + "'", str3.equals("ensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmenten"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 43, (long) 3, (long) 38);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/extensions:/ne1.7avary/ja/extensions:/libravary/ja/users/sophie/libr1.7.0_80-b151.7.0_80-b151.7.0_8", 62, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "mixed mJava Platform API Specification", (java.lang.CharSequence) "20#38#-1#1#638", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "mixed mJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-140452432420");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4045243242E11d) + "'", double1.equals((-1.4045243242E11d)));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/h", (java.lang.CharSequence) "J v  Virtu l M chine Specific tio", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.0 -1.0 10.0 0.0 0.0 10.0.0 -1.0 10.0 0.0 0.0 00.0", "/LIBRARY/JAVA/JAVAVIRT1ALMACHINE./JDK1.7.0_80.JDK/CONTENT./HOME/JRE/LIB/ENDOR.ED");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        long[] longArray4 = new long[] { 28, 13, 0, (short) 100 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4###4", 20, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaa4###4aaaaaaaa" + "'", str3.equals("aaaaaaa4###4aaaaaaaa"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        long[] longArray5 = new long[] { 20, 38, (-1), (short) 1, 638 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "20#38#-1#1#638" + "'", str8.equals("20#38#-1#1#638"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 638L + "'", long9 == 638L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.7.0_80/Users/s");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80/uSERS/S" + "'", str1.equals("1.7.0_80/uSERS/S"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 5, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1N4FC0000GN/T/" + "'", str1.equals("1N4FC0000GN/T/"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "################4.1################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("43");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "4# #4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJob", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "a   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J", (java.lang.CharSequence) "0 10.0 100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 48);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) " # 4 ", (java.lang.CharSequence) "ensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmenten");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + " # 4 " + "'", charSequence2.equals(" # 4 "));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!", "");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) ":                                                                                                ", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "-1.04100.0410.04100.0");
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "#########", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("             ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             " + "'", str2.equals("             "));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "", (int) '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Users/sophie", 0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str4.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20", "0.0 0.0 0.0 10.0 -1.0 10.0", "5.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.10a1a1005.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025" + "'", str3.equals("1105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025#0#40000000000000000000000000001105052032025"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("0.00.00.010.0-1.010.0", "32#-1                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.00.00.010.0-1.010.0" + "'", str2.equals("0.00.00.010.0-1.010.0"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80S1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80[1.7.0_80L1.7.0_80j1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_80.1.7.0_80S1.7.0_80t1.7.0_80r1.7.0_80i1.7.0_80n1.7.0_80g1.7.0_80;1.7.0_80c1.7.0_80l1.7.0_80a1.7.0_80s1.7.0_80s1.7.0_80 1.7.0_80o1.7.0_80r1.7.0_80g1.7.0_80.1.7.0_80a1.7.0_80p1.7.0_80a1.7.0_80c1.7.0_80h1.7.0_80e1.7.0_80.1.7.0_80c1.7.0_80o1.7.0_80m1.7.0_80m1.7.0_80o1.7.0_80n1.7.0_80s1.7.0_80.1.7.0_80l1.7.0_80a1.7.0_80n1.7.0_80g1.7.0_8031.7.0_80.1.7.0_80J1.7.0_80a1.7.0_80v1.7.0_80a1.7.0_80V1.7.0_80e1.7.0_80r1.7.0_80s1.7.0_80i1.7.0_80o1.7.0_80n1.7.0_80", (java.lang.CharSequence) "4###");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "44#44444 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10", "desrodne/bil/erj/emoH/stnetnoC/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: sun.lwawt.macosx.LWCToolkit is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("..._51964_1560279240/target/classes:/Users/sophie...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaxaCPaaaaaaJaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("         0.00140.0140.00140.1         ", 48, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         0.00140.0140.00140.1         4444444444" + "'", str3.equals("         0.00140.0140.00140.1         4444444444"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/", "VVVVVVVVV/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VVVVVVVVV/" + "'", str2.equals("VVVVVVVVV/"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        long[] longArray1 = new long[] { (byte) 1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', 8, 0);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4# #4", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4# #4" + "'", str4.equals("4# #4"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJob", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(62L, (long) 26, (long) 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 62L + "'", long3 == 62L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/extensions:/", "         ###4", "                                                                     Java(TM) SE Runtime Environmen");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        long[] longArray5 = new long[] { '#', (short) 0, 100L, 97L, 100L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, '4');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "354041004974100" + "'", str8.equals("354041004974100"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!..._519hi!..._519hi!..._519hi!..._519hi!..._ 4#44hi!..._519hi!..._519hi!..._519hi!..._519hi!..._5", "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "5", 35, 40);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.2", "JAVAvIRTUALmACHINEsPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        double[] doubleArray4 = new double[] { (byte) -1, 100, 10, 100L };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', 22, (int) (short) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.0a100.0a10.0a100.0" + "'", str9.equals("-1.0a100.0a10.0a100.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1.0a100.0a10.0a100.0" + "'", str15.equals("-1.0a100.0a10.0a100.0"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        float[] floatArray2 = new float[] { (short) 100, 52 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 7, (int) (short) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 7, 23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0a52.0" + "'", str9.equals("100.0a52.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0#52.0" + "'", str11.equals("100.0#52.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.0452.0" + "'", str13.equals("100.0452.0"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0.010.1-0.010.00.00.0", (java.lang.CharSequence) "#44444 4a4a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("################4.1###############", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                          ", "4# #4                                                mixed mJava Platform API Specification", 40);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("...sions:/Libr#ry/J#v#/Extensions:/Network/Libr#ry/J#v#/Extensions:/System/Libr#ry/J#v#/Extension...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...sions:/Libr#ry/J#v#/Extensions:/Network/Libr#ry/J#v#/Extensions:/System/Libr#ry/J#v#/Extension..." + "'", str1.equals("...sions:/Libr#ry/J#v#/Extensions:/Network/Libr#ry/J#v#/Extensions:/System/Libr#ry/J#v#/Extension..."));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte[][] byteArray2 = new byte[][] { byteArray1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray2);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("#0#1#100", 48, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("l utriV  v J", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("##########", 21, "                                  Java Platform API Specification                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     ##########      " + "'", str3.equals("     ##########      "));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0#1#100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "     ##########      ", (java.lang.CharSequence) "                               a       a", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1-a1-a001a0a001a1-", 57);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                       1-a1-a001a0a001a1-" + "'", str2.equals("                                       1-a1-a001a0a001a1-"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(82, 4, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("0", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                   0" + "'", str2.equals("                                                                                                   0"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!", "");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("52 0 97 52");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15aaaaaaaaaaaaaaaaaaaa");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray8, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", strArray4, strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str13.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(":", "-1 100 0 100 -1 -1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 79, (int) (byte) 10);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("aaaaaaaaaaaaaaaaaaaaaa", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("52 0 97 52");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15aaaaaaaaaaaaaaaaaaaa");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray2, strArray5);
        java.lang.Class<?> wildcardClass7 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "###################################        E###################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "-1.0A100.0A10.0A100.0", 272);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        float[] floatArray5 = new float[] { (short) 0, 10L, 0, 0L, 0.0f };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', (int) (short) 100, (int) '#');
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.Class<?> wildcardClass11 = floatArray5.getClass();
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0.0 10.0 0.0 0.0 0.0" + "'", str13.equals("0.0 10.0 0.0 0.0 0.0"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        short[] shortArray2 = new short[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', 10, (int) (short) 10);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 10 + "'", short9 == (short) 10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10a100" + "'", str11.equals("10a100"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JAVAvIRTUALmACHINEsPECIFICATION", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("#0#1#100", '#');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "###############################################sophie###############################################");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.30.0 0.0 0.0 10.0 -1.0 10.010.1.3", "1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("         2 .80-b11          ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_51964_1560279240/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.0 100.0 10.0 100.0", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.4:N1.7", (java.lang.CharSequence) "                           4a a4", 79);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0.00.00.010.0-1.010.0", 96, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                           0.00.00.010.0-1.010.0" + "'", str3.equals("                                                                           0.00.00.010.0-1.010.0"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", (java.lang.CharSequence) "desrodne/bil/erj/emoH/stnetnoC/", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Librar...", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "32 -1", (java.lang.CharSequence) "..._51964_1560279240/target/classes:/Users/sophie...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 0, 0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("52#0#97#52", "#52");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52#0#97" + "'", str2.equals("52#0#97"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        char[] charArray7 = new char[] { ' ', '#', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Jav10", charArray7);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        java.lang.Class<?> wildcardClass16 = charArray7.getClass();
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " ###4" + "'", str11.equals(" ###4"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + " 4#44" + "'", str15.equals(" 4#44"));
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(324, 57, 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 324 + "'", int3 == 324);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (java.lang.CharSequence) "noit cificepS enihc M l utriV  v J");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("-1 100 0 100 -1 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 100 0 100 -1 -1" + "'", str1.equals("-1 100 0 100 -1 -1"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a', 9, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15aaaaaaaaaaaaaaaaaaaa", "a   4 # a", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("10 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 100" + "'", str1.equals("10 100"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "-1#0#52#32#20");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#", "5");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", ' ');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray12);
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "4### ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaa4###4aaaaaaaa", "..._51964_1560279240/target/classes:/Users/sophie...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaa4###4aaaaaaaa" + "'", str2.equals("aaaaaaa4###4aaaaaaaa"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("#44444 4a4a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#44444 4a4a" + "'", str1.equals("#44444 4a4a"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                   JAVA(TM) SE RUNTIME ENVIRONMENT                   ", 53, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                   JAVA(TM) SE RUNTIME ENVIRONMENT                   " + "'", str3.equals("                   JAVA(TM) SE RUNTIME ENVIRONMENT                   "));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("4###4", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAV", "/Users/sophie                                                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4###4" + "'", str3.equals("4###4"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("32#-1                              ", "##########/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed##########", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("5240497452", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5240497452" + "'", str3.equals("5240497452"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/...", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a4 4 4 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "             ...", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.71/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.70/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.71/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.74/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.73/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7", "OPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.71/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.70/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.71/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.74/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.73/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE" + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.71/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.70/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.71/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.74/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.73/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("#4 4#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("           0.00.00.010.0-1.010.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "           0.00.00.010.0-1.010.0" + "'", str1.equals("           0.00.00.010.0-1.010.0"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("#0#1#100", "a   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avary/Ja/Extea   4 # as:/Ne1.7avanoit cificepS enihc M l utriV  v J");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#0#1#100" + "'", str2.equals("#0#1#100"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/LIBRARY/JAVA/JAVAVIRT1ALMACHINE./JDK1.7.0_80.JDK/CONTENT./HOME/JRE/LIB/ENDOR.ED", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "/extensions:/");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("\n", strArray2, strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/LIBRARY/JAVA/JAVAVIRT1ALMACHINE./JDK1.7.0_80.JDK/CONTENT./HOME/JRE/LIB/ENDOR.ED" + "'", str7.equals("/LIBRARY/JAVA/JAVAVIRT1ALMACHINE./JDK1.7.0_80.JDK/CONTENT./HOME/JRE/LIB/ENDOR.ED"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/LIBRARY/JAVA/JAVAVIRT1ALMACHINE./JDK1.7.0_80.JDK/CONTENT./HOME/JRE/LIB/ENDOR.ED" + "'", str8.equals("/LIBRARY/JAVA/JAVAVIRT1ALMACHINE./JDK1.7.0_80.JDK/CONTENT./HOME/JRE/LIB/ENDOR.ED"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "\n" + "'", str9.equals("\n"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/100.0#52.0", " ###4");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java Platform API Specific", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I Specific" + "'", str2.equals("I Specific"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "....0a10.0        ...", (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("tionatform API Specifica Plava                                                mixed mJ", " 4#44java Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual ", "52 0 97 52");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tionatform API Specifica Plava                                                mixed mJ" + "'", str3.equals("tionatform API Specifica Plava                                                mixed mJ"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "S:USRIBAVA", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        int[] intArray5 = new int[] { (byte) 1, (byte) 10, (byte) -1, '4', (byte) 1 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray5, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ', 272, (int) (short) 5);
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "14104-145241" + "'", str9.equals("14104-145241"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XM1.7", "-140452432420", 77);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1-1##########################################################################################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.71/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.70/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.71/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.74/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.73/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7" + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(":", "", 35);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                                        ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + ":" + "'", str5.equals(":"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 10, (long) 40, (long) 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "UTF-8", (int) (byte) 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4###", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.3", "###################################        E###################################", "         0.00140.0140.00140.1         ", 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.3" + "'", str4.equals("1.3"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensio", 21, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("-1 0 52 32 20");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 0 52 32 20" + "'", str1.equals("-1 0 52 32 20"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("en", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("LyJvJvVM8CH");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "lyJvJvVM8CH" + "'", str1.equals("lyJvJvVM8CH"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("_8e.jdk/Contents/Home/jre/lib/endorsedssssssssss", "410.040.040.04", 23);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', (int) (short) 10, (int) (short) 1);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "                       aaaaa                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       aaaaa                        " + "'", str2.equals("                       aaaaa                        "));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("..._51964_1560279240/target/classes:/Users/sophie...", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a   4 # a", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                                               ", (java.lang.CharSequence) "44444 4a4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", ":                                                                                                ");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.2");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "-140452432420", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str5.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str7.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java(TM) SE Runtime Environmentaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environmentaaaaaaaaaaaaaaaaa" + "'", str1.equals("Java(TM) SE Runtime Environmentaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("324", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "324" + "'", str3.equals("324"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("0 10.0 100.0", "", (int) (short) 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 10.0 100.0" + "'", str3.equals("0 10.0 100.0"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 10, (long) (short) 10, (long) 11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", ' ');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', 0, 0);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray10 = null;
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("         ", strArray4, strArray10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "         " + "'", str11.equals("         "));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JAVA vIRTUAL mACHINE sPECIFICATION                                                                  ", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "-1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20# #4                           -1 0 52 32 20", charSequence1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("USRSSOPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(" Java HotSpot(TM) 64-Bit Server VM ", 2, 272);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " Java HotSpot(TM) 64-Bit Server VM " + "'", str3.equals(" Java HotSpot(TM) 64-Bit Server VM "));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                     324", (java.lang.CharSequence) "mixed ", 82);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("###################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################################" + "'", str1.equals("###################################"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("GC.twa.nus");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "/var/folders/_v/6v5910a10010a10010a10010a10010a10010a");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/var/folders/_v/6v5910a10010a10010a10010a10010a10010a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 28, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/...", "10 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/..." + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/..."));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime Environmentaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.14.3", "                                                    ", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("             ", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             " + "'", str2.equals("             "));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Platform API Specification", (float) 53);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 53.0f + "'", float2 == 53.0f);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        int[] intArray5 = new int[] { (byte) 1, (byte) 10, (byte) -1, '4', (byte) 1 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray5, '#', 79, 0);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.5", "                                                                                                   0", "                                 ", 20);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.5" + "'", str4.equals("1.5"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaaaa", (java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(47, 16, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 47 + "'", int3 == 47);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        int[] intArray2 = new int[] { 100, (short) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', 100, 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', 10, (int) (short) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a', 26, (int) (short) 0);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0" + "'", str8.equals("100#0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100 0" + "'", str14.equals("100 0"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100 0" + "'", str20.equals("100 0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10040" + "'", str22.equals("10040"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("#######boJret#ocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#######boJret#ocam.twawl.nus" + "'", str1.equals("#######boJret#ocam.twawl.nus"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("52#0#97", 97, 57);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("phie/Library/Java/Extensio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "phie/Library/Java/Extensio" + "'", str1.equals("phie/Library/Java/Extensio"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("X86_64", "4424.80-b11", "GC.twa.nus");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("           -1.04100.0410.04100.0", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        float[] floatArray6 = new float[] { 0.0f, 0, 0L, (short) 10, (-1L), 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#', (int) (short) 1, (-1));
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        float float14 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0.0a0.0a0.0a10.0a-1.0a10.0" + "'", str13.equals("0.0a0.0a0.0a10.0a-1.0a10.0"));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + (-1.0f) + "'", float14 == (-1.0f));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        long[] longArray4 = new long[] { '4', (short) 0, 97L, 52 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) (short) -1, (int) (byte) -1);
        java.lang.Class<?> wildcardClass14 = longArray4.getClass();
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52#0#97#52" + "'", str8.equals("52#0#97#52"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.04100.0410.04100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("J v  Virtu l M chine Specific tion");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"J v  Vi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "0.010.1-0.010.00.00.0", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 1, (int) (byte) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0a1a100" + "'", str10.equals("0a1a100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52 0 97 52IE", "", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("a   4 # a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a   4 # a" + "'", str1.equals("a   4 # a"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("#######sophie#######", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("4444444444444444444444444444444444444444444444100#0444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444100#0444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444100#0444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        char[] charArray8 = new char[] { 'a', ' ', '4', '#', 'a' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "phie/Library/Java/Extensio", charArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray8, '#', 34, 7);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "  # 4", charArray8);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a   4 # a" + "'", str10.equals("a   4 # a"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("# 4 4   a a", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Java(TM) SE Runtime Environmentaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Java(TM) SE Runtime Environmentaaaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Ne1.7", (java.lang.CharSequence) "1.04100.0410.04100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a', (int) 'a', 48);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(49, 11, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 49 + "'", int3 == 49);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', (int) 'a', (int) (byte) -1);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 324, 48);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100" + "'", str16.equals("100"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        long[] longArray5 = new long[] { (short) -1, 0L, 52L, 32, 20L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '4');
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1 0 52 32 20" + "'", str7.equals("-1 0 52 32 20"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-140452432420" + "'", str9.equals("-140452432420"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str4 = javaVersion3.toString();
        boolean boolean5 = javaVersion2.atLeast(javaVersion3);
        java.lang.String str6 = javaVersion3.toString();
        boolean boolean7 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str8 = javaVersion3.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2" + "'", str4.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.2" + "'", str6.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.2" + "'", str8.equals("1.2"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("#######sophie#######");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#######sophie#######" + "'", str1.equals("#######sophie#######"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(" 4#44 4#44 4#44 4#44 4#44 4#44 4#44 4#44 4#44 4#44 4#44 4#-1.0A100.0A10.0A100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("..._51964_1560279240/target/classes:/Users/sophie...", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "..._51964_1560279240/target/classes:/Users/sophie..." + "'", str2.equals("..._51964_1560279240/target/classes:/Users/sophie..."));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_80/Users/s", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("a      ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a      " + "'", str2.equals("a      "));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("UTF-8UTF-8UTF-8-1.04100.0410.04100.0UTF-8UTF-8UTF-8U");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8UTF-8UTF-8-1.04100.0410.04100.0UTF-8UTF-8UTF-8U" + "'", str1.equals("UTF-8UTF-8UTF-8-1.04100.0410.04100.0UTF-8UTF-8UTF-8U"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("desrodne/bil/erj/emoH/stnetnoC/", "1N4FC0000GN/T/", 0, (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1N4FC0000GN/T/" + "'", str4.equals("1N4FC0000GN/T/"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 31, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("###################################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 10, (float) 0, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("\n");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("  # 4", 62);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4" + "'", str2.equals("  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4  # 4"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 0, (long) 66, (long) 52);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 66L + "'", long3 == 66L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!", "");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) ":                                                                                                ", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(":", "", 35);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.CPrinterJob#######", strArray4, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "sun.lwawt.macosx.CPrinterJob#######" + "'", str10.equals("sun.lwawt.macosx.CPrinterJob#######"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0.040.040.0410.04-1.0410.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "52 0 97 52IE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob#######", "         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         ", (int) (short) 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("GC.twa.nu", "0.0 10.0 0.0 0.0 0.0", 254);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        double[] doubleArray4 = new double[] { (byte) -1, 100, 10, 100L };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0 100.0 10.0 100.0" + "'", str7.equals("-1.0 100.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0a100.0a10.0a100.0" + "'", str10.equals("-1.0a100.0a10.0a100.0"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        long[] longArray5 = new long[] { (short) -1, 0L, 52L, 32, 20L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1 0 52 32 20" + "'", str7.equals("-1 0 52 32 20"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-140452432420" + "'", str9.equals("-140452432420"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1#0#52#32#20" + "'", str11.equals("-1#0#52#32#20"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }
}

