import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test01");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1", ":                                            ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test02");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.4:N1.7", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test03");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("100", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100" + "'", str2.equals("100"));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test04");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test05");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "43", "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test06");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("LyJvJvVM8CH", "JAVA HOTSPOT(TM) 64-BIT SERVER VM", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test07");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray7 = new char[] { 'a', ' ', '4', '#', 'a' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ');
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "phie/Library/Java/Extensio", charArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', 34, 7);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "a   4 # a" + "'", str9.equals("a   4 # a"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test08");
        long[] longArray4 = new long[] { '4', (short) 0, 97L, 52 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52 0 97 52" + "'", str8.equals("52 0 97 52"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52#0#97#52" + "'", str10.equals("52#0#97#52"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test09");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("0414100", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0414100" + "'", str2.equals("0414100"));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test10");
        char[] charArray10 = new char[] { '#', '4', '4', ' ', 'a', 'a' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                     Java(TM) SE Runtime Environment", charArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray10, '4');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "a # 4 a", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#44444 4a4a" + "'", str14.equals("#44444 4a4a"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test11");
        float[] floatArray6 = new float[] { 0.0f, 0, 0L, (short) 10, (-1L), 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4', (int) (byte) 0, 5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', 62, 66);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 62");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.040.040.0410.04-1.0" + "'", str12.equals("0.040.040.0410.04-1.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.040.040.0410.04-1.0410.0" + "'", str14.equals("0.040.040.0410.04-1.0410.0"));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test12");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("        SOPHIE        ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/EXTENSIONS:/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "        SOPHIE        " + "'", str3.equals("        SOPHIE        "));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test13");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart(" ###4", "##########################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " ###4" + "'", str2.equals(" ###4"));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test14");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("desrodne/bil/erj/emoH/stnetnoC/", "a", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test15");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test16");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.4/Extensions:/Ne1.7avary/Ja/Exte", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test17");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "0.0a0.0a0.0a10.0a-1.0a10.0", (java.lang.CharSequence) "10a100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test18");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("################4.1###############");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test19");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (java.lang.CharSequence) "#52", 43);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test20");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("-1 0 52 32 20", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1 0 52 32 20" + "'", str3.equals("-1 0 52 32 20"));
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test21");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "-1.04100.0410.04100.0           ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test22");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("###############################################sophie###############################################");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test23");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                        0.0410.040.040.040.0                                        ", 82);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      0.0410.040.040.040.0                                        " + "'", str2.equals("                      0.0410.040.040.040.0                                        "));
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test24");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         ", "                      ", "#a4a a a a#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         " + "'", str3.equals("         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         52#0#97#52         0.00140.0140.00140.1         "));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test25");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test26");
        int[] intArray1 = new int[] { 10 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test27");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(" 4#44", 32, "      51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 4#44      51.0      51.0      5" + "'", str3.equals(" 4#44      51.0      51.0      5"));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test28");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Docum 444444444/Users/sophie/Docum", "                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Docum 444444444/Users/sophie/Docum" + "'", str2.equals("/Users/sophie/Docum 444444444/Users/sophie/Docum"));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test29");
        double[] doubleArray4 = new double[] { (byte) -1, 100, 10, 100L };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.04100.0410.04100.0" + "'", str8.equals("-1.04100.0410.04100.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0a100.0a10.0a100.0" + "'", str11.equals("-1.0a100.0a10.0a100.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.0a100.0a10.0a100.0" + "'", str13.equals("-1.0a100.0a10.0a100.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test30");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.4", "52a10a1a-1##########################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test31");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test32");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240", "class [Dclass [Sclass [Bclass [Dclass [B");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test33");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(48, 43, 38);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 48 + "'", int3 == 48);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test34");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase(" l utriV  v J");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " L UTRIV  V J" + "'", str1.equals(" L UTRIV  V J"));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test35");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "14104-145241", 30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test36");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Lib", (java.lang.CharSequence) "###4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

