import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse(" ###4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4### " + "'", str1.equals("4### "));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("324-1", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("USRSSOPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(" # 4 ", "Java Platform API Specification", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("##########", (int) (byte) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########" + "'", str3.equals("##########"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                   Java(TM) SE Runtime Environment                   ", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("http://java.oracle.com", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Oracle Corporation is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("52 0 97 52");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52 0 97 52" + "'", str1.equals("52 0 97 52"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                          ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "      51.0", (java.lang.CharSequence) "-1.0 100.0 10.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8", "0.0a0.0a0.0a10.0a-1.0a10.0                                                                       ", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) " ", (java.lang.CharSequence) "...sions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extension...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten" + "'", str1.equals("ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10", (int) '4', "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Ne1.7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Jav10" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Jav10"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a # 4 a", (java.lang.CharSequence) "", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "http://java.oracle.com", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("UTF-8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 0, 0, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce(":", "/LIBRARY/JAVA/JAVAVIRT1ALMACHINE./JDK1.7.0_80.JDK/CONTENT./HOME/JRE/LIB/ENDOR.ED", "1.2");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str1.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("##########");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ########## is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("en", " a#a4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " a#a4" + "'", str2.equals(" a#a4"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("http://java.oracle.com/", "###############################################sophie###############################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("100", (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("en", "", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("desrodne/bil/erj/emoH/stnetnoC/k");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/" + "'", str1.equals("desrodne/bil/erj/emoH/stnetnoC/"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("-1.0 100.0 10.0 100.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0 100.0 10.0 100.0" + "'", str2.equals("-1.0 100.0 10.0 100.0"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        float[] floatArray6 = new float[] { 0.0f, 0, 0L, (short) 10, (-1L), 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', (int) ' ', (int) (byte) 0);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', (-1), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.0a0.0a0.0a10.0a-1.0a10.0" + "'", str10.equals("0.0a0.0a0.0a10.0a-1.0a10.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 10.0f + "'", float11 == 10.0f);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 100.0f, (double) 48, (double) 22);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("         /", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification", '4');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0#1#100", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("http://java.oracle.com", "      51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      51.0" + "'", str2.equals("      51.0"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("###############################################sophie###############################################", "jAVA hOTsPOT(tm) 64-bIT sERVER vm", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############################################sophie###############################################" + "'", str3.equals("###############################################sophie###############################################"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0#1#100", "354041004974100", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten", "SOPHIE", "###############################################sophie###############################################");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("US", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1L, (long) (-1), (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("USRSSOPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA" + "'", str2.equals("OPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("phie/Library/Java/Extensio", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "phie/Library/Java/Extensio" + "'", str2.equals("phie/Library/Java/Extensio"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0.0a0.0a0.0a10.0a-1.0a10.0", "mixed mode");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) ":", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 0, (byte) 10, (byte) 100 };
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "                                  Java Platform API Specification                                  ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                   Java Platform API Specification                                  ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "52#0#97#52", (java.lang.CharSequence) "a   4 # a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten" + "'", str2.equals("ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("SOPHIE", "52 0 97 52", 4, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "52 0 97 52IE" + "'", str4.equals("52 0 97 52IE"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "mixed mJava Platform API Specification", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                  Java Platform API Specification                                  ", (java.lang.CharSequence) "phie/Library/Java/Extensio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java Virtual Machine Specification", "/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8", "hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(22, (int) (byte) 100, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 22 + "'", int3 == 22);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 0, (long) (byte) -1, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(strArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "desrodne/bil/erj/emoH/stnetnoC/k", (java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62 + "'", int2 == 62);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java Platform API Specification", "noit cificepS enihc M l utriV  v J", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL" + "'", str3.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(32, (int) (short) 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("100#0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0" + "'", str2.equals("100#0"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                     Java(TM) SE Runtime Environment", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "################################", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "#######sophie#######", (java.lang.CharSequence) ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(" # 4 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"# 4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "Java HotSpot(TM) 64-Bit Server VM", "_80.jdk/Contents/Home/jre/lib/endorsed##########");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str3.equals("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80-b15", 0, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "52 0 97 52IE", (int) ' ', 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("-1.04100.0410.04100.0", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.04100.0410.04100.0" + "'", str2.equals("-1.04100.0410.04100.0"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 0, (double) 630, (double) 52);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 630.0d + "'", double3 == 630.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 9, (float) 10L, (float) 69L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 9.0f + "'", float3 == 9.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("mixed mode", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "32 -1", (java.lang.CharSequence) "#######sophie#######");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("OPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA" + "'", str1.equals("OPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0.040.040.0410.04-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie", "OPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA", "aaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("      51.0", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("###############################################sophie###############################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(69, 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.awt.CG", "UTF-8", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 0, (float) ' ', (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", (java.lang.CharSequence) "0.0a0.0a0.0a10.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Ne1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("###############################################sophie###############################################", (int) (short) 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############################################sophie###############################################" + "'", str3.equals("###############################################sophie###############################################"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str2.equals("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "-1.0 100.0 10.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.5", ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.5" + "'", str4.equals("1.5"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "      51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 10, (byte) 1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XM1.7");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XM1.7");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 10 + "'", byte4 == (byte) 10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.awt.CG", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("...sions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extension...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("52a10a1a-1", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52a10a1a-1" + "'", str2.equals("52a10a1a-1"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.5", "0.0a0.0a0.0a10.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5" + "'", str2.equals("5"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", " Java HotSpot(TM) 64-Bit Server VM ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.4", (int) '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################1.4################" + "'", str3.equals("################1.4################"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("32 -1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "0", (java.lang.CharSequence) "##########/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed##########", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" Java HotSpot(TM) 64-Bit Server VM ", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java Virtual Machine Specification", (int) (byte) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                          " + "'", str1.equals("                          "));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRT1ALMACHINE./JDK1.7.0_80.JDK/CONTENT./HOME/JRE/LIB/ENDOR.ED");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str2 = javaVersion1.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str5 = javaVersion4.toString();
        boolean boolean6 = javaVersion3.atLeast(javaVersion4);
        java.lang.String str7 = javaVersion4.toString();
        boolean boolean8 = javaVersion1.atLeast(javaVersion4);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean10 = javaVersion0.atLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.2" + "'", str5.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.2" + "'", str7.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop(":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                               " + "'", str1.equals(":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                               "));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "100#0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        float[] floatArray2 = new float[] { (short) 100, 52 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 28, (int) (short) 0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        float[] floatArray5 = new float[] { (short) 0, 10L, 0, 0L, 0.0f };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', (int) (short) 100, (int) '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', (int) (byte) 100, (int) (byte) 10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', 630, 35);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240", 22, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("desrodne/bil/erj/emoH/stnetnoC/k", ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                               ", "sun.awt.CG");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/k" + "'", str3.equals("desrodne/bil/erj/emoH/stnetnoC/k"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Jav10", (java.lang.CharSequence) "0.040.040.0410.04-1.0", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "#44444 4a4a", (java.lang.CharSequence) "      51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                   Java(TM) SE Runtime Environment                   ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "#0#1#100", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                   Java(TM) SE Runtime Environment                   " + "'", str4.equals("                   Java(TM) SE Runtime Environment                   "));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "0.040.040.0410.04-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "J v  Virtu l M chine Specific tion", "                   Java(TM) SE Runtime Environment                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10.14.3", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.1.3" + "'", str2.equals("10.1.3"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Oracle Corporation", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/extensions:/ne1.7avary/ja/extensions:/libravary/ja/users/sophie/libr1.7.0_80-b151.7.0_80-b151.7.0_8", "a # 4 a");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwawt.macosx.CPrinterJob", 62, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("#4 4#", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#4 4#" + "'", str2.equals("#4 4#"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "0.0a0.0a0.0a10.0a-1.0a10.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.CharSequence[] charSequenceArray7 = new java.lang.CharSequence[] { "100", "100#0", "a4 4 4 ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/...", "aaaaaaaaaa" };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Us.0s/s10./L0b010y/-1.1/Ex..0s00s:/L0b010y/-1.1/Ex..0s00s:/N..w0k/L0b010y/-1.1/Ex..0s00s:/ys..m/L0b010y/-1.1/Ex..0s00s:/0s0/10b/j1.1:.", charSequenceArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray7, '#', 10, (int) (short) 10);
        org.junit.Assert.assertNotNull(charSequenceArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("####################################################", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################" + "'", str2.equals("####################################################"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) " ###4", (java.lang.CharSequence) "51.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("##########");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("32 -1", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                   Java(TM) SE Runtime Environment                   ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", 69);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sun.awt.CG");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GC.twa.nus" + "'", str1.equals("GC.twa.nus"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("JAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA vIRTUAL mACHINE sPECIFICATION" + "'", str1.equals("JAVA vIRTUAL mACHINE sPECIFICATION"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.4", 34, "/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4/Extensions:/Ne1.7avary/Ja/Exte" + "'", str3.equals("1.4/Extensions:/Ne1.7avary/Ja/Exte"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1, 0.0d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "-1.0 100.0 10.0 100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("4444444444444444444444444444444444444444444444100#04444444444444444444444444444444444444444444444", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444100#04444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444100#04444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", ":                                                                                                ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1.2");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (short) 1, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str4.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmenten" + "'", str2.equals("ensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmenten"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Us.0s/s10./L0b010y/-1.1/Ex..0s00s:/L0b010y/-1.1/Ex..0s00s:/N..w0k/L0b010y/-1.1/Ex..0s00s:/ys..m/L0b010y/-1.1/Ex..0s00s:/0s0/10b/j1.1:.", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                  Java Platform API Specification                                   ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                  Java Platform API Specification                                  ", charSequence1, 62);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("US", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "354041004974100", ":                                                                                                ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XM1.7", 34, 20);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaa", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("# 4 4   a a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# 4 4   a a" + "'", str1.equals("# 4 4   a a"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: en is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("       ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SOPHIE" + "'", str1.equals("SOPHIE"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4# #4", charSequence1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0, "aaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100, (float) 28, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "###############################################sophie###############################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwawt.macosx.LWCToolkit", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#######sophie#######", (java.lang.CharSequence) "0.0a0.0a0.0a10.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        long[] longArray4 = new long[] { '4', (short) 0, 97L, 52 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', (int) (short) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 9);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwawt.macosx.LWCToolkit", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80-b15aaaaaaaaaaaaaaaaaaaa", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJob", "/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJob" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left(" 444444444", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 444444444" + "'", str2.equals(" 444444444"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("52a10a1a-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"52a10a1a-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("100#0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/LIBRARY/JAVA/JAVAVIRT1ALMACHINE./JDK1.7.0_80.JDK/CONTENT./HOME/JRE/LIB/ENDOR.ED");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "#" + "'", str5.equals("#"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("52 0 97 52", " 4#44", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52 0 97 52" + "'", str3.equals("52 0 97 52"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1.4/Extensions:/Ne1.7avary/Ja/Exte");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#44444 4a4a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("24.80-b11", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         24.80-b11          " + "'", str2.equals("         24.80-b11          "));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0.0#10.0#0.0#0.0#0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("51.", 69L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 69L + "'", long2 == 69L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJob", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) '4', (float) (short) 0, (float) 0L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" 4#44", "                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   ", 22);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(" # 4 ", "1.4");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("GC.twa.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GC.twa.nu" + "'", str1.equals("GC.twa.nu"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                     Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                     Java(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                ", (java.lang.CharSequence) "USRSSOPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(" ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10 100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "1.7", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.7" + "'", charSequence2.equals("1.7"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(1.0d, (double) '#', (double) 9.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("_80.jdk/Contents/Home/jre/lib/endorsed##########", (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", (java.lang.CharSequence) "UTF-8", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("desrodne/bil/erj/emoH/stnetnoC/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "http://java.oracle.com", 0, 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType(":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("JAVA vIRTUAL mACHINE sPECIFICATION", (int) (byte) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA vIRTUAL mACHINE sPECIFICATION" + "'", str3.equals("JAVA vIRTUAL mACHINE sPECIFICATION"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(630, 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(52.0d, (double) 0, (double) 48);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("354041004974100", "0.00.00.010.0-1.010.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "354041004974100" + "'", str2.equals("354041004974100"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sun.awt.CG");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.awt.CG\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4# #4", "32 -1");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4###4" + "'", str4.equals("4###4"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) " 444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str1.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240", "", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        float[] floatArray6 = new float[] { 0.0f, 0, 0L, (short) 10, (-1L), 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4', (int) (byte) 0, 5);
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', (int) (byte) -1, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.040.040.0410.04-1.0" + "'", str12.equals("0.040.040.0410.04-1.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + (-1.0f) + "'", float13 == (-1.0f));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7", 4, "                          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7" + "'", str3.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "ensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmenten", (java.lang.CharSequence) "a   4 # a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        float[] floatArray2 = new float[] { ' ', 0.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "a   4 # a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        int[] intArray1 = new int[] { 10 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        short[] shortArray4 = new short[] { (short) 10, (short) 100, (byte) 10, (short) 10 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("GC.twa.nu", (float) 20);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 20.0f + "'", float2 == 20.0f);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(" 444444444", 630, "################1.4################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 444444444################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4######" + "'", str3.equals(" 444444444################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4################################1.4######"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "10 100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "      51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRT1ALMACHINE./JDK1.7.0_80.JDK/CONTENT./HOME/JRE/LIB/ENDOR.ED", (java.lang.CharSequence) "#", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str1.equals("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_80-b15aaaaaaaaaaaaaaaaaaaa", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sophie", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   ", (java.lang.CharSequence) "noit cificepS enihc M l utriV  v J", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" # 4 ", (int) (short) 1, "                                                                     Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " # 4 " + "'", str3.equals(" # 4 "));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "0.00.00.010.0-1.010.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("354041004974100", ":", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("################################", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################" + "'", str2.equals("################################"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("52#0#97#52", "100#0", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "", (int) '4');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 4, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("100", ":                                                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100" + "'", str2.equals("100"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("         24.80-b11          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "         24.80-b11          " + "'", str1.equals("         24.80-b11          "));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 100, 0L, (long) 48);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "# 4 4   a a", (java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "# 4 4   a a" + "'", charSequence2.equals("# 4 4   a a"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("0.0 0.0 0.0 10.0 -1.0 10.0", "100#0", 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0" + "'", str3.equals("0.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "_80.jdk/Contents/Home/jre/lib/endorsed##########");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "# 4 4   a a", charSequence1, 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XM1.7", (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "aaaaaaaaaa", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!", "");
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("\n", strArray3, strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "\n" + "'", str5.equals("\n"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("4# #4", ":");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("################1.4################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################4.1################" + "'", str1.equals("################4.1################"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("aaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaa", "         24.80-b11          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10", (int) 'a', "#44444 4a4a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444" + "'", str3.equals("#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#4410#44444 4a4a#44444 4a4a#44444 4a4a#44444 4a4a#444"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hi!", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "                                                                     Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1, 0, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" # 4 ", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "GC.twa.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n", "ensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmentensun.wt.CGrphicsEnvironmenten");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1." + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1."));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", 48, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 40 + "'", int3 == 40);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("US");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("java Virtual Machine Specification", "1.7.0_80", (int) (short) 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", ' ');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("-1.04100.0410.04100.0", strArray4, strArray11);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "/extensions:/ne1.7avary/ja/extensions:/libravary/ja/users/sophie/libr1.7.0_80-b151.7.0_80-b151.7.0_8", 22, 10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray11);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, 'a');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java Virtual Machine Specification" + "'", str6.equals("java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.04100.0410.04100.0" + "'", str12.equals("-1.04100.0410.04100.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str17.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str19.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                   Java(TM) SE Runtime Environment                   ", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                   Java(TM) SE Runtime Environment                   " + "'", str2.equals("                   Java(TM) SE Runtime Environment                   "));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0", (java.lang.CharSequence) "#######sophie#######", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8", "4# #4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8" + "'", str2.equals("sions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "################1.4################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sun.lwawt.macosx.CPrinterJob#######", "#", 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.maco#terJob#######" + "'", str3.equals("sun.lwawt.maco#terJob#######"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.maco#terJob#######", (java.lang.CharSequence) "##########/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed##########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("hi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("phie/Library/Java/Extensio", "_80.jdk/Contents/Home/jre/lib/endorsed##########");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("52a10a1a-1", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 0, (float) 'a', 32.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", (java.lang.CharSequence) "-1.0A100.0A10.0A100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/extensions:/ne1.7avary/ja/extensions:/libravary/ja/users/sophie/libr1.7.0_80-b151.7.0_80-b151.7.0_8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /extensions:/ne1.7avary/ja/extensions:/libravary/ja/users/sophie/libr1.7.0_80-b151.7.0_80-b151.7.0_8 is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.4", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.0 0.0 0.0 10.0 -1.0 10.0", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/extensions:/ne1.7avary/ja/extensions:/libravary/ja/users/sophie/libr1.7.0_80-b151.7.0_80-b151.7.0_8", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32.0f, (double) '4', 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("####################################################");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0100#00.0 0.0 0.0 10.0 -1.0 10.0", (long) 48);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 48L + "'", long2 == 48L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 22, (long) (byte) 100, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "J v  Virtu l M chine Specific tion", (java.lang.CharSequence) "51.", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 52, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "..._51964_1560279240/target/classes:/Users/sophie..." + "'", str3.equals("..._51964_1560279240/target/classes:/Users/sophie..."));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "################4.1################", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/...", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) -1, 69);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/...", 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "", 48, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 48");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten", "", "52 0 97 52");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten" + "'", str3.equals("ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("24.80-B11", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-B11" + "'", str2.equals("24.80-B11"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("324-1", "/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "324" + "'", str2.equals("324"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   " + "'", str2.equals("                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   "));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("...sions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extension...", (double) 9.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.0d + "'", double2 == 9.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("noit cificepS enihc M l utriV  v J", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " l utriV  v J" + "'", str2.equals(" l utriV  v J"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("24.80-B11", (int) 'a', 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/s\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(" Java HotSpot(TM) 64-Bit Server VM ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80-b15aaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "52#0#97#52");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("mixed mJava Platform API Specification", "10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mJava Platform API Specification" + "'", str2.equals("mixed mJava Platform API Specification"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                  Java Platform API Specification                                   ", (java.lang.CharSequence) "1.5", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("100", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100" + "'", str2.equals("100"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/extensions:/ne1.7avary/ja/extensions:/libravary/ja/users/sophie/libr1.7.0_80-b151.7.0_80-b151.7.0_8", (java.lang.CharSequence) "http://java.oracle.com/", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 1, (int) (byte) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0a1a100" + "'", str10.equals("0a1a100"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "_80.jdk/Contents/Home/jre/lib/endorsed##########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "       ", (java.lang.CharSequence) "4###4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("phie/Library/Java/Extensio", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "phie/Library/Java/Extensio" + "'", str2.equals("phie/Library/Java/Extensio"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "# 4 4   a a", 7, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        double[] doubleArray0 = new double[] {};
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaa", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "a4 4 4 ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        int[] intArray4 = new int[] { '4', 10, (byte) 1, (-1) };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52a10a1a-1" + "'", str6.equals("52a10a1a-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52410414-1" + "'", str8.equals("52410414-1"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 0, (int) (short) 0, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "100", (java.lang.CharSequence) "mixed mJava Platform API Specification", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   ", "a # 4 a", "/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   " + "'", str4.equals("                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   "));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.2");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0#1#100", (java.lang.CharSequence) "a # 4 a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":                                                                                                ", "", 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "-1.04100.0410.04100.0", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + ":                                                                                                " + "'", str5.equals(":                                                                                                "));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "10.1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "-1.04100.0410.04100.0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("51.0", "-1.0a100.0a10.0a100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "#4 4#", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "#4 4#" + "'", charSequence2.equals("#4 4#"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "", (int) '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str4.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("\n", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_51964_1560279240/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_51964_1560279240/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0.0a0.0a0.0a10.0a-1.0a10.0                                                                       ", 0, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0a0.0a0.0a10.0a-1.0a10.0                          " + "'", str3.equals("0.0a0.0a0.0a10.0a-1.0a10.0                          "));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("OPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA" + "'", str1.equals("OPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                  Java Platform API Specification                                   ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("USRSSOPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USRSSOPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA" + "'", str2.equals("USRSSOPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        float[] floatArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 40);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                        " + "'", str2.equals("                                        "));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Library/Java/Extensions:/Library/Java/", 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA", "", "1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA", 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA" + "'", str4.equals("1.7.0_80-B15AAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_80", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Jav10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("J v  Virtu l M chine Specific tion", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J v  Virtu l M chine Specific tion" + "'", str2.equals("J v  Virtu l M chine Specific tion"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "GC.twa.nu");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nE1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sun.awt.CG", "sun.awt.CG");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("SOPHIE", 5, 62);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "E" + "'", str3.equals("E"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XM1.7", "10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("java Virtual Machine Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java Virtual Machine Specification" + "'", str2.equals("java Virtual Machine Specification"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob#######");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", ":                                                                                                ", (int) (byte) -1);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("52 0 97 52");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java HotSpot(TM) 64-Bit Server VM                                                                   ", strArray5, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/...", "1.4/Extensions:/Ne1.7avary/Ja/Exte");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Lib" + "'", str2.equals("Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Lib"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("         24.80-b11          ", 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("-1.0 100.0 10.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        double[] doubleArray4 = new double[] { (byte) -1, 100, 10, 100L };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#', (int) (byte) 10, 630);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0 100.0 10.0 100.0" + "'", str7.equals("-1.0 100.0 10.0 100.0"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) " 4#44");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("52 0 97 52IE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52 0 97 52IE" + "'", str1.equals("52 0 97 52IE"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 22, (float) 32, (float) 630);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 630.0f + "'", float3 == 630.0f);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.0 0.0 0.0 10.0 -1.0 10.0", 7, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Ne1.7", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Ne1.7" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Ne1.7"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "################1.4################", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "####################################################", 69);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("32 -1", ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32 -1" + "'", str2.equals("32 -1"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4###4", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sun.lwawt.maco#terJob#######");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#######boJret#ocam.twawl.nus" + "'", str1.equals("#######boJret#ocam.twawl.nus"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4# #4\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", "1.7", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("0.0 0.0 0.0 10.0 -1.0 10.0", "0.0 0.0 0.0 10.0 -1.0 10.0", (int) (short) 1, 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "00.0 0.0 0.0 10.0 -1.0 10.0.0 0.0 0.0 10.0 -1.0 10.0" + "'", str4.equals("00.0 0.0 0.0 10.0 -1.0 10.0.0 0.0 0.0 10.0 -1.0 10.0"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 20, (double) 52, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        int[] intArray1 = new int[] { 10 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', 22, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 22");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaa", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                   Java(TM) SE Runtime Environment                   ", 69, " 4#44");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                   Java(TM) SE Runtime Environment                   " + "'", str3.equals("                   Java(TM) SE Runtime Environment                   "));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("a # 4 a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a # 4 a" + "'", str1.equals("a # 4 a"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "#", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.4");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.4/Extensions:/Ne1.7avary/Ja/Exte", "24.80-b11", 13);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 1, (int) (byte) 10);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification", 'a');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                ", strArray3, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 25 vs 6");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str7.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "phie/Library/Java/Extensio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "14104-145241", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 34, (float) (short) 0, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 34.0f + "'", float3 == 34.0f);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v59" + "'", str2.equals("/var/folders/_v/6v59"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "# 4 4   a a", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 35, (float) (-1), 20.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("J v  Virtu l M chine Specific tion", "                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "SOPHIE", (java.lang.CharSequence) "0.0a0.0a0.0a10.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-1.0 100.0 10.0 100.0", "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-b11", "10", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0.0a0.0a0.0a10.0a-1.0a10.0                          ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("#4 4#", "phie/Library/Java/Extensio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#4 4#" + "'", str2.equals("#4 4#"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(40, 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 40 + "'", int3 == 40);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        char[] charArray7 = new char[] { ' ', '#', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaa", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " ###4" + "'", str11.equals(" ###4"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 22, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                      " + "'", str3.equals("                      "));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Oracle Corporation", "10.1.3");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100L, (float) '#', (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Us.0s/s10./L0b010y/-1.1/Ex..0s00s:/L0b010y/-1.1/Ex..0s00s:/N..w0k/L0b010y/-1.1/Ex..0s00s:/ys..m/L0b010y/-1.1/Ex..0s00s:/0s0/10b/j1.1:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("USRSSOPHIIBRARYAVAXTNSIONS:IBRARYAVAAVAVIRTUAMACHINSDK1.7.0_80.DKCONTNTSHOMRIBXT:IBRARYAVAXTNSIONS:NTWORKIBRARYAVAXTNSIONS:SYSTMIBRARYAVAXTNSIONS:USRIBAVA", "1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "J v  Virtu l M chine Specific tion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        java.lang.CharSequence[] charSequenceArray2 = new java.lang.CharSequence[] { "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51964_1560279240/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" };
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.2", charSequenceArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray2, 'a', (int) (short) 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charSequenceArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                ", "/Extensions:/Ne1.7avary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr1.7.0_80-b151.7.0_80-b151.7.0_8", "100#0", 26);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                " + "'", str4.equals(":                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                :                                                                                                "));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("################################");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "       ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmenten");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmente" + "'", str1.equals("ensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmentensun.awt.CGraphicsEnvironmente"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 13, (long) (byte) 10, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 13L + "'", long3 == 13L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) -1, 52, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "5", (int) (short) 100, 4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(" l utriV  v J", "E");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " l utriV  v J" + "'", str2.equals(" l utriV  v J"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("52 0 97 52", "GC.twa.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52 0 97 52" + "'", str2.equals("52 0 97 52"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 7, (double) 48L, (double) 26L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 48.0d + "'", double3 == 48.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(" a#a4", "Java(TM) SE Runtime Environment", "10.1.3");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                                     Java(TM) SE Runtime Environment", "################1.4################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                     Java(TM) SE Runtime Environment" + "'", str2.equals("                                                                     Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 7, 20);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(" l utriV  v J", "                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   hi                                  Java Platform API Specification                                   ", "0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " l utriV  v J" + "'", str3.equals(" l utriV  v J"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("52a10a1a-1", "14104-145241", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NE1.7");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "E", (java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0.0a0.0a0.0a10.0a-1.0a10.0                                                                       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0a0.0a0.0a10.0a-1.0a10.0                                                                       " + "'", str1.equals("0.0a0.0a0.0a10.0a-1.0a10.0                                                                       "));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "phie/Library/Java/Extensio", (java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XM1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1.04100.0410.04100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("0.00.00.010.0-1.010.0", 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) 'a', "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.Class<?> wildcardClass4 = byteArray1.getClass();
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 0, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 1 + "'", byte9 == (byte) 1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "52a10a1a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52a10a1a-1" + "'", str2.equals("52a10a1a-1"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("32 -1", "http://java.oracle.com");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32 -1" + "'", str2.equals("32 -1"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("################4.1################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################1.4################" + "'", str1.equals("################1.4################"));
    }
}

