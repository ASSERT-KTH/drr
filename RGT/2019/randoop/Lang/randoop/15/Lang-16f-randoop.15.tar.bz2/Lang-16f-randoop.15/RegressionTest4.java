import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("x86_64x86_64");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("i", "r4cle Corpor4tion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i" + "'", str2.equals("i"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                 Java Virtual Machine Specification                                 ", 12, 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                   " + "'", str3.equals("                   "));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", "4444444444444444444444444444444444444444444444x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v" + "'", str2.equals("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification", 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nen\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nen\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nen\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64x86_64", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 211);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "###", (int) '#', 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "A4.NUC-POODNA/NOIANG/NOIANG_/BIL/KOWAF/44CFD/NUCOd/IHPO//:ALC/GA/6140120651_40459_LP.POODNA_NU/P/44CFD/NUCOd/IHPO/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "   51.0   ", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("mixed mode:");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "4444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                   ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "java hotspot(tm) 64-bit server vm", "10.14.3");
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("1.2", strArray4, strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.2" + "'", str6.equals("1.2"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("4.310.14.3", "1.11.21.51.51.21.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, charSequence1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 216, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        " + "'", str2.equals("        "));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        java.lang.String str4 = javaVersion0.toString();
        java.lang.Class<?> wildcardClass5 = javaVersion0.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.11.21.51.51.21.81.11.21.51.51.2", (java.lang.CharSequence) "/#Library#/#Java#/#Java#Virtual#Machines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#Contents#/#Home#/#jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("un.lwawt.macosx.LWCToolkit######...", (int) (short) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "un.lwawt.macosx.LWCToolkit######..." + "'", str3.equals("un.lwawt.macosx.LWCToolkit######..."));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("         sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                 Java VaaaaaatiklooTCWL.xsocam.twawl.nuaaaaartual Machine Specification                                 ", "TIKLOOTCWL.XSOCAM.TWAWL.NU");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("x86_64");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95404_1560210416/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 41 + "'", int4 == 41);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.j", 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nen\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "CORPORATION ORACLE 10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.en10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (java.lang.CharSequence) "/uSERS/SOP                                                                ", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "                                  Java(TM) SE Runtime Environment                                   ", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "x86_64x86_64", (java.lang.CharSequence) "4.310.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sophie444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        long[] longArray6 = new long[] { 0, 100, (byte) 0, (byte) 1, (short) -1, (short) 1 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("         x51.08651.0_51.064          ", 5, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         x51.08651.0_51.064          " + "'", str3.equals("         x51.08651.0_51.064          "));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.11.21.51.51.21.6       ", (int) ' ', 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("aaaaaun.lwawt.macosx.LWCToolkitaaaaaa", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "mixed mode:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray5 = new char[] { '#' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", charArray5);
        java.lang.Class<?> wildcardClass8 = charArray5.getClass();
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                    ", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_8         x51.08651.0_51.064          51.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification", 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification" + "'", str3.equals("4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                                                                                                                                                   ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "OTCWL.XSOCAM.TWAWL.NUTIKLOOTCWL.XSOCAM.TWAWL.NU3.41.01TCWL.XSOCAM.TWAWL.NUTIKLOOTCWL.XSOCAM.TWAWL.NU", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.4");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4f + "'", float1.equals(1.4f));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/uSERS/SOP          \naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          560210416/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOP aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 560210416/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str1.equals("/uSERS/SOP aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 560210416/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                 Java Virtual Machine Specification                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "AAAAAATIKLOOtcwl.XSOCAM.TWAWL.NUAAAA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        double[] doubleArray2 = new double[] { (short) 1, (-1.0d) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "Or4cle Corpor4tion4444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_64", "UTF-8                           ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 37, (double) 33, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("A4.NUC-POODNA/NOIANG/NOIANG_/BIL/KOWAF/44CFD/NUCOd/IHPO//:ALC/GA/6140120651_40459_LP.POODNA_NU/P/44CFD/NUCOd/IHPO/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("444444444444444444444444444444444444444444444441.144444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.4444444444444445E47d + "'", double1 == 4.4444444444444445E47d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0                 ", 4, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0                 " + "'", str3.equals("0                 "));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("4444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, charSequence1);
        org.junit.Assert.assertNull(charSequence2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                                                                 ", "aaaaaun.lwawt.macosx.LWCToolkitaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaun.lwawt.macosx.LWCToolkitaaaaaa" + "'", str2.equals("aaaaaun.lwawt.macosx.LWCToolkitaaaaaa"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", (int) (byte) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("6_644444444444444444444444444444444444444444444444x8", 12, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6_644444444444444444444444444444444444444444444444x8" + "'", str3.equals("6_644444444444444444444444444444444444444444444444x8"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.awt.CGraphicsEnvironment", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "sun.lwawt.macosx.CPrinterJob");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.2UTF-8                           1.2UTF-8                           1.2UTF-8                           1.2");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("hi!aaaaaaa", 31, 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!aaaaaaa" + "'", str3.equals("hi!aaaaaaa"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("TIKLOOTCWL.XSOCAM.TWAWL.NU");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: TIKLOOTCWL.XSOCAM.TWAWL.NU is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################################################################" + "'", str2.equals("#################################################################################################"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", (java.lang.CharSequence) "                                                                               Or4cle Corpor4tion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) -1, 216, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 216 + "'", int3 == 216);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "macOSX", (java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("##########################################################################tiklooTCWL.xsocam.twawl.nu", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("         x51.08651.0_51.064          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "         x51.08651.0_51.064          " + "'", str1.equals("         x51.08651.0_51.064          "));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "                         0                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Users/soph", "un.lwawt.macosx.LWCToolkit##########################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "un.lwawt.macosx.LWCToolkit##########################################################################" + "'", str2.equals("un.lwawt.macosx.LWCToolkit##########################################################################"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416", "                 ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("...44444444444444444444444444444", "Hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...44444444444444444444444444444" + "'", str2.equals("...44444444444444444444444444444"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 633 + "'", int1 == 633);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.en10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.en10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14." + "'", str1.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.en10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14."));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.en10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "USUSUSUhi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("mixed mode");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(104, 52, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 104 + "'", int3 == 104);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("          \naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "OTCWL.XSOCAM.TWAWL.NUTIKLOOTCWL.XSOCAM.TWAWL.NU3.41.01TCWL.XSOCAM.TWAWL.NUTIKLOOTCWL.XSOCAM.TWAWL.NU", "4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("va/Extensionshi!aaaaaaava/Extensions:\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("va/Extensionshi!aaaaaaava/Extensions:", 211, "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatva/Extensionshi!aaaaaaava/Extensions:Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporat" + "'", str3.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatva/Extensionshi!aaaaaaava/Extensions:Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporat"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 139);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                           " + "'", str2.equals("                                                                                                                                           "));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "/users/sop                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Hi!", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48 + "'", int2 == 48);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (java.lang.CharSequence) "Or4cle Corpor4tion4444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "MacOSXMacOSXMacOSXMacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("0                 ", "r/folders/_v/6v597zmn4_v31cq2n2x1n4", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0                 " + "'", str3.equals("0                 "));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/users/sop", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sop" + "'", str2.equals("/users/sop"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Library/Java/Java", "Hi!");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        char[] charArray1 = new char[] { ' ' };
        char[] charArray3 = new char[] { ' ' };
        char[][] charArray4 = new char[][] { charArray1, charArray3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray4);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", (java.lang.CharSequence) "                                                                               Or4cle Corpor4tion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                 ", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                 " + "'", str2.equals("                 "));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("N.LW", "  sun.lwawt.macosx.CPrinterJob    s");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "N.LW" + "'", str2.equals("N.LW"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "                                                    ", "eihpos");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API Specification", "4444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.7", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        int[] intArray1 = new int[] { (short) 100 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification", "                               x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               x86_64" + "'", str2.equals("                               x86_64"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) 0, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", (int) (byte) 1, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                               Or4cle Corpor4tion", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Or4cleCorpor4tion" + "'", str2.equals("Or4cleCorpor4tion"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Library/Java/Java", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/Java" + "'", str2.equals("/Library/Java/Java"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.11.21.51.51.21.81.11.21.51.51.2", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.11.21.51.51.21.81.11.21" + "'", str2.equals("1.11.21.51.51.21.81.11.21"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                 ", 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/uSERS/SOP");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i" + "'", str2.equals("i"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 104, 2.0f, (float) '#');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("AAAAAATIKLOOtcwl.XSOCAM.TWAWL.NUAAAA", 179);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 179 + "'", int2 == 179);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/uSERS/SOP                                                                ", 52.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "                                  Java(TM) SE Runtime Environment                                   ", "class [Dclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("AAAAAATIKLOOtcwl.XSOCAM.TWAWL.NUAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAATIKLOOtcwl.XSOCAM.TWAWL.NUAAAA" + "'", str1.equals("AAAAAATIKLOOtcwl.XSOCAM.TWAWL.NUAAAA"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "6_644444444444444444444444444444444444444444444444x8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 1, (double) 35, (double) 216.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "Users/soph");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/#Library#/#Java#/#Java#Virtual#Machines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#Contents#/#Home#/#jre", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/#Library#/#Java#/#Java#Virtual#Machines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#Contents#/#Home#/#jre" + "'", str2.equals("/#Library#/#Java#/#Java#Virtual#Machines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#Contents#/#Home#/#jre"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("x51.08651.0_51.064", "sunhi!sun.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("24.80-b11", (int) (byte) 10, 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4", 178, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                                                                                                                                                                                 ORACLE CORPORATION", "                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE CORPORATION" + "'", str2.equals("ORACLE CORPORATION"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("         x51.08651.0_51.064          ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "class [Dclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "/#Library#/#Java#/#Java#Virtual#Machines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#Contents#/#Home#/#jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("  1.6", (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6d + "'", double2 == 1.6d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/4users4/4sop4          4\n4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4          45602104164/4target4/4classes4:/4users4/4sophie4/", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4444444444", 41, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                 Java VaaaaaatiklooTCWL.xsocam.twawl.nuaaaaartual Machine Specification                                 ", "\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("r4cle Corpor4tion", "Java Virtual Machine Specification", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "r4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tion" + "'", str3.equals("r4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tion"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("##########################################################################################4.310.14.3", "  sun.lwawt.macosx.CPrinterJob  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!aaaaaaa", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(74.0d, 6.0d, (double) 35);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 74.0d + "'", double3 == 74.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        float[] floatArray1 = new float[] { (byte) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.7.0_80-b151.7.0_80-b151.7.0_8x51.08651.0_51.06451.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80-b151.7.0_80-b151.7.0_8x51.08651.0_51.06451.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob    s", ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaun.lwawt.macosx.LWCToolkitaaaaaa", "/u...", (int) (byte) 1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "a/u..." + "'", str4.equals("a/u..."));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatva/Extensionshi!aaaaaaava/Extensions:Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporat", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                   ", 0, "4444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                   " + "'", str3.equals("                   "));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 74);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 74.0f + "'", float2 == 74.0f);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("hi!", "i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sop");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "un.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "OTCWL.XSOCAM.TWAWL.NUTIKLOOTCWL.XSOCAM.TWAWL.NU3.41.01TCWL.XSOCAM.TWAWL.NUTIKLOOTCWL.XSOCAM.TWAWL.NU", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(37, (int) (byte) 100, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                               Or4cle Corpor4tion", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (java.lang.CharSequence) "java hotspot(tm) 64-bit server vm                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "", (int) (byte) 1);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob", '#');
        java.lang.String[] strArray11 = new java.lang.String[] {};
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", strArray10, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("Mac OS X", strArray6, strArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str12.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Mac OS X" + "'", str13.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str14.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/6140120651_40459_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("NOITAROPROC ELCARO", "x1n4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOITAROPROC ELCARO" + "'", str2.equals("NOITAROPROC ELCARO"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Mac OS X", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatva/Extensionshi!aaaaaaava/Extensions:Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporat", 2, 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "MaOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatva/Extensionshi!aaaaaaava/Extensions:Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporat" + "'", str4.equals("MaOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatva/Extensionshi!aaaaaaava/Extensions:Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporat"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "4444444444444444444444444444444444444444444444x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Or4cle Corpor4tion4444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_64", "r4cle Corpor4tion");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sop", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("i");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: i is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                       ORACLE CORPORATION                                                                                       ", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("         sun.awt.CGraphicsEnvironment         sun.awt.CGraphicsEnvironment         sun.awt.CGraphicsEnvironment         sun.awt.CGraphicsEnvironment", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "", "##########################################################################################4.310.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                   ", "####################################################################################################", 31);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Hi!", "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/6140120651_40459_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/uSERS/SOP          \naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          560210416/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOP          \naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          560210416/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str1.equals("/uSERS/SOP          \naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          560210416/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416", (java.lang.CharSequence) "lders/_v/6v597zmn4_v31cq2n2x1n4", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "va/Extensionshi!aaaaaaava/Extensions:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/", 179, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##################################################################################################################################################################################/" + "'", str3.equals("##################################################################################################################################################################################/"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/uSERS/SOP                                                                ", (java.lang.CharSequence) "                                                                                                                                           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "mixed mode:", (java.lang.CharSequence) "va/Extensionshi!aaaaaaava/Extensions:\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "        ", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "                                                                               Or4cle Corpor4tion", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                               Or4cle Corpor4tion" + "'", charSequence2.equals("                                                                               Or4cle Corpor4tion"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0L, (double) 1.1f, (double) 3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(" 1.8 ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8 " + "'", str2.equals(" 1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8 "));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nen\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aaaaaatiklooTCWL.xsocam.twawl.nuaaaaa", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaatiklooTCWL.xsocam.twawl.nuaaaaa" + "'", str4.equals("aaaaaatiklooTCWL.xsocam.twawl.nuaaaaa"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UN.LWAWT.MACOSX.LWCTOOLKIT", "");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!i!");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str6.equals("UN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 216 + "'", int1 == 216);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_8x51.08651.0_51.06451.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "UN.LWAWT.MACOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "OTCWL.XSOCAM.TWAWL.NUTIKLOOTCWL.XSOCAM.TWAWL.NU3.41.01TCWL.XSOCAM.TWAWL.NUTIKLOOTCWL.XSOCAM.TWAWL.NU");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode:", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        char[] charArray5 = new char[] { '#' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", charArray5);
        java.lang.Class<?> wildcardClass8 = charArray5.getClass();
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS X", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "\n", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("0                 ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "lders/_v/6v597zmn4_v31cq2n2x1n4", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("         sun.awt.CGraphicsEnvironment         sun.awt.CGraphicsEnvironment         sun.awt.CGraphicsEnvironment         sun.awt.CGraphicsEnvironment", "", 104);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "va/Extensionshi!aaaaaaava/Extensions:", "00000");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/uSERS/SOP");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa" + "'", str2.equals("aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        char[] charArray8 = new char[] { '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie444444444444444444444444444444444444444", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAATIKLOOtcwl.XSOCAM.TWAWL.NUAAAA", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.11.21.51.51.21.6       ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("va/Extensionshi!aaaaaaava/Extensions:", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "va/Extensionshi!aaaaaaava/Extensions:" + "'", str2.equals("va/Extensionshi!aaaaaaava/Extensions:"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "4444444444444444444444444444444444444444444444x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java Virtual Machine Specification", "1.2\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2\n" + "'", str2.equals("1.2\n"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaatiklooTCWL.xsocam.twawl.nuaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAATIKLOOTCWL.XSOCAM.TWAWL.NUAAAA" + "'", str1.equals("AAAAAATIKLOOTCWL.XSOCAM.TWAWL.NUAAAA"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("51.0", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("         x51.08651.0_51.064          ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80", "4444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("MaOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatva/Extensionshi!aaaaaaava/Extensions:Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporat");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mAoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATVA/eXTENSIONSHI!AAAAAAAVA/eXTENSIONS:oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORAT" + "'", str1.equals("mAoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATVA/eXTENSIONSHI!AAAAAAAVA/eXTENSIONS:oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORAT"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", (java.lang.CharSequence) "/uSERS/SOP          \naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          560210416/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("hi!aaaaaaa", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " hi!aaaaaaa " + "'", str2.equals(" hi!aaaaaaa "));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.j", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (int) (short) 0, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophi" + "'", str3.equals("/Users/sophi"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("NOITAROPROC ELCARO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOITAROPROC ELCARO" + "'", str1.equals("NOITAROPROC ELCARO"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.14.3", "51.0", 37);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "MacOSX", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 34, (long) (short) 0, (long) 48);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 48L + "'", long3 == 48L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) " 1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8 ", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.min(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification", (int) '#', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", (java.lang.CharSequence) "r4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tionJava Virtual Machine Specificationr4cle Corpor4tion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "###", "un.lwawt.macosx.LWCToolkit##########################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                                                                                                   ", "sunhi!sun.", (int) '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (short) 0, (-1));
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/users/sop                                                                ", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                " + "'", str2.equals("/users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                "));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/#Library#/#Java#/#Java#Virtual#Machines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#Contents#/#Home#/#jre", (java.lang.CharSequence) "/Library/Java/Java", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                                                                                                                                                                                              HI!AAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!AAAAAAA" + "'", str1.equals("HI!AAAAAAA"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("va/Extensionshi!aaaaaaava/Extensions:\n\n\n\n\n\n\n\n\n\n\n", 0, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "va/Extensionshi!aaaaaaava/Extensions:\n\n\n\n\n\n\n\n\n\n\n" + "'", str3.equals("va/Extensionshi!aaaaaaava/Extensions:\n\n\n\n\n\n\n\n\n\n\n"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.en10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.en10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14." + "'", str2.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.en10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14."));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                                6_644444444444444444444444444444444444444444444444x8                                                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"6_644444444444444444444444444444444444444444444444x8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aaaaaatiklooTCWL.xsocam.twawl.nuaaaaa", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaatiklooTCWL.xsocam.twawl.nuaaaaa" + "'", str2.equals("aaaaaatiklooTCWL.xsocam.twawl.nuaaaaa"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "444444444444444444444444444444444444444444444441.144444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 41, "444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("N.LW");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(74.0f, (float) 179, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 179.0f + "'", float3 == 179.0f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Or4cle Corpor4tion4444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_64", 0, "phicsEnvironmentawt.CGra         sun.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Or4cle Corpor4tion4444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_64" + "'", str3.equals("Or4cle Corpor4tion4444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_64"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("HI!AAAAAAA", "                                 Java Virtual Machine Specification                                 ", " 1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8 ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("JUTF-8al Machine Specification", "Java Virtual Machine Specification", 31);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 4, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JUTF-8al Machine Specification" + "'", str4.equals("JUTF-8al Machine Specification"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.7.0_80-b151.7.0_80-b151.7.0_8         x51.08651.0_51.064          51.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", "eihpos", "CLASS [dCLASS ORG.APACHE.COMMONS.LANG3.jAVAvERSION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_8         x51.08651.0_51.064          51.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str3.equals("1.7.0_80-b151.7.0_80-b151.7.0_8         x51.08651.0_51.064          51.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Hi!");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("mixed mode", "/users/sop                                                                ", "####################################################");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                                                                    ");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/uSERS/SOP", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_8         x51.08651.0_51.064          51.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/uSERS/SOP aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 560210416/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "          10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.en10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3                                                                                                                                                                                                                                                                             ORACLE CORPORATION                                                                                       ", (java.lang.CharSequence) "MacOSXMacOSXMacOSXMacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/users/sop                                                                ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sop                                                                " + "'", str2.equals("/users/sop                                                                "));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("mixed mode:");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaatiklooTCWL.xsocam.twawl.nuaaaa", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                                                               Or4cle Corpor4tion", "TIKLOOTCWL.XSOCAM.TWAWL.NU");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                               Or4cle Corpor4tion" + "'", str2.equals("                                                                               Or4cle Corpor4tion"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("java hotspot(tm) 64-bit server vm", "1.11.21.51.51.21.6       ", 25);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str3.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "un.lwawt.macosx.LWCToolkit######...", 633);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "         x51.08651.0_51.064          ", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "java hotspot(tm) 64-bit server vm                                                                   ", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("  sun.lwawt.macosx.CPrinterJob    s", "00000", 18);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       " + "'", str1.equals("1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       "));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("4444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444" + "'", str1.equals("4444444444"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("   51.0   ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                ", 25, "                                                                                                                                                                                                                                                                                       ORACLE CORPORATION                                                                                       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                " + "'", str3.equals("/users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                /users/sop                                                                "));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("r4cle Corpor4tion", "                                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "UTF-8                           ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("4444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444" + "'", str1.equals("4444444444444444444444444"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                       ORACLE CORPORATION                                                                                       ", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((-1.0f), (float) 179L, (float) ' ');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 179.0f + "'", float3 == 179.0f);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("sunhi!sun.", "4444444444444444444444444444444444444444444444x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sunhi!sun." + "'", str2.equals("sunhi!sun."));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("lders/_v/6v597zmn4_v31cq2n2x1n4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416", "                               x86_64", 211);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr" + "'", str1.equals("va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("          ", "", 135);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 178, (long) 34, (long) 384);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("##########################################################################TIKLOOtcwl.XSOCAM.TWAWL.NU", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                             Users/soph                                             ", (int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sop");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("x86_64x86_64");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                             ", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                             " + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                                                                                                                                                                                                             "));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Hi!", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" 1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8 ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa" + "'", str2.equals("aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("##########################################################################################4.310.14.3", 6, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############################################" + "'", str3.equals("##############################################"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/u...", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 97, (float) 34L, (float) 34);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 34.0f + "'", float3 == 34.0f);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "java hotspot(tm) 64-bit server vm", (int) (short) 10, 2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/#Library#/#Java#/#Java#Virtual#Machines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#Contents#/#Home#/#jre" + "'", str7.equals("/#Library#/#Java#/#Java#Virtual#Machines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#Contents#/#Home#/#jre"));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.2", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("un.lwawt.macosx.LWCToolkit##########################################################################", "51.0");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "un.lwawt.macosx.LWCToolkit##########################################################################" + "'", str4.equals("un.lwawt.macosx.LWCToolkit##########################################################################"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_8         x51.08651.0_51.064          51.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", (java.lang.CharSequence) "x1n4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("          ", 139, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "macOSX", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 31, (long) (byte) 100, (long) 18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "4", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("r/folders/_v/6v597zmn4_v31cq2n2x1n4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"r/folder\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sunhi!sun.", ' ');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "US", 104);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("4444444444444444444444444444444444444444444444x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444x86_64" + "'", str1.equals("4444444444444444444444444444444444444444444444x86_64"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification", (java.lang.CharSequence) "4.310.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        short[] shortArray6 = new short[] { (short) -1, (byte) 0, (byte) -1, (short) 0, (short) 0, (byte) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("UN.LWAWT.MACOSX.LWCTOOLKIT", "/users/sop          \naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          560210416/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str2.equals("UN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        char[] charArray5 = new char[] { '#' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "MacOSX", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                   ", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("UN.LWAWT.MACOSX.LWCTOOLKIT", 178, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444UN.LWAWT.MACOSX.LWCTOOLKIT4444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444UN.LWAWT.MACOSX.LWCTOOLKIT4444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification", 32.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "JUTF-8al Machine Specification", (java.lang.CharSequence) "444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (long) 12);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", 'a');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("         x51.08651.0_51.064          ", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 30 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Or4cle Corpor4tion" + "'", str9.equals("Or4cle Corpor4tion"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416", "Mac OS X", (int) (short) 1);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/6140120651_40459_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                 SU                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                 SU                " + "'", str1.equals("                 SU                "));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaai!", "Hi!", "", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaai!" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaai!"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("aaaaaatiklooTCWL.xsocam.twawl.nuaaaa", "mAoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATVA/eXTENSIONSHI!AAAAAAAVA/eXTENSIONS:oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORAT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaatiklooTCWL.xsocam.twawl.nuaaaa" + "'", str2.equals("aaaaaatiklooTCWL.xsocam.twawl.nuaaaa"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                                                                                                                                                 ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(" 1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8  1.8 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.8" + "'", str1.equals("1.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.8"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(48L, (long) 633, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray7 = new char[] { ' ', ' ', ' ', '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "x86_64x86_64", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80A4aNUa-POODNA/NOIANG/NOIANG_/BIa/KOaAF/44aFD/NUaOd/IHPO//:Aaa/GA/6140120651_40459_aPaPOODNA_NU/P/44aFD/NUaOd/IHPO/1.7.0_80", "          \naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", 12);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "1.8", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "                                                                                                 ", 384);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                 ", (java.lang.CharSequence) "sophie", 179);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("en");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(10L, (long) 48, (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        char[] charArray8 = new char[] { '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", charArray8);
        java.lang.Class<?> wildcardClass11 = charArray8.getClass();
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS X", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_6444444444", charArray8);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                                                                           ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/6140120651_40459_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/uSERS/SOP          \naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          560210416/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", (java.lang.CharSequence) "4.310.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 176 + "'", int2 == 176);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("a/u...", "Java(TM) SE Runtime Environmenti!", "1.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.81.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "./...." + "'", str3.equals("./...."));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                                                                                    ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("AAAAAATIKLOOtcwl.XSOCAM.TWAWL.NUAAAA", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("x86_64x86_64", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/users/sophie/documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("ORACLE CORPORATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ORACLE CORPORATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4.310.14.3", (int) (short) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4.310.14.3" + "'", str3.equals("4.310.14.3"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaai!", (java.lang.CharSequence) "                                 Java Virtual Machine Specification                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("US", (int) (byte) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "444444444444444444444444444444444444444444444441.144444444444444444444444444444444444444444444444");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Oracle Corporation");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Or4cle Corpor4tion", strArray3, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "AAAAAATIKLOOtcwl.XSOCAM.TWAWL.NUAAAA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE" + "'", str1.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        float[] floatArray1 = new float[] { (byte) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "en", (java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "macOSX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.6", 33, "java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.6java hotspot(tm) 64-bit server" + "'", str3.equals("1.6java hotspot(tm) 64-bit server"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java Virtual Machine Specification", "/Users/sophi", "sun.lwawt.macosx.CPrinterJob    s");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("r/folders/_v/6v597zmn4_v31cq2n2x1n4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Virtual Machine Specification", "          ", 12);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.8", "                               x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "CLASS [dCLASS ORG.APACHE.COMMONS.LANG3.jAVAvERSION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        char[] charArray5 = new char[] { '#' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "NOITAROPROC ELCARO", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) ' ', 0L, (long) 135);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 135L + "'", long3 == 135L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "##############################################", (java.lang.CharSequence) "\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        int[] intArray1 = new int[] { (short) 100 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "un.lwawt.macosx.LWCToolkit######...", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("  sun.lwawt.macosx.CPrinterJob  ", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                             Users/soph                                             ", 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("JUTF-8al Machine Specification", "UN.LWAWT.MACOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JUTF-8al Machine Specification" + "'", str2.equals("JUTF-8al Machine Specification"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("x86_64", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/uSERS/SOPHIE", "N.LW", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "#################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(33, 176, 41);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 33 + "'", int3 == 33);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "1.11.21.51.51.21.81.11.21", "1.7");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                                                                                                                           ", "sunhi!sun.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                           " + "'", str2.equals("                                                                                                                                           "));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '#', (long) 52, (long) 179);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("HI!AAAAAAA", "Java Virtual Machine Specification", "JUTF-8al Machine Specification");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                 Java VaaaaaatiklooTCWL.xsocam.twawl.nuaaaaartual Machine Specification                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/#Library#/#Java#/#Java#Virtual#Machines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#Contents#/#Home#/#jre", "x1n4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/#Library#/#Java#/#Java#Virtual#Machines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#Contents#/#Home#/#jre" + "'", str2.equals("/#Library#/#Java#/#Java#Virtual#Machines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#Contents#/#Home#/#jre"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/users/sophie/documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/users/sophie/documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification" + "'", str1.equals("4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/users/sophie/documents/defects4j/tmp/run_randoop.pl_95404_1560210416pecification"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("un.lwawt.macosx.LWCToolkit", "USUSUSUhi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "un.lwawt.macosx.LWCToolkit" + "'", str2.equals("un.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nen\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nen\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: en is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "                                                                                                                                                                                                 ORACLE CORPORATION", "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                         0                          ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416/Users/sophie/Documents/defects4j/tmp/run_rMacOSXMacOSXMacOSXMacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         0                          " + "'", str2.equals("                         0                          "));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                       ORACLE CORPORATION                                                                                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaatiklooT...", "", 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaatiklooT..." + "'", str3.equals("aaaaaatiklooT..."));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        char[][] charArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(charArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "x51.08651.0_51.064");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nen\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nen\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", "/uSERS/SOPHIE");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str1.equals("-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        double[] doubleArray1 = new double[] { 100 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("          ", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("###", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###" + "'", str2.equals("###"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4", (java.lang.CharSequence) "mixed mode:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/#Library#/#Java#/#Java#Virtual#Machines#/#jdk#1#.#7#.#0#_#80#.#jdk#/#Contents#/#Home#/#jre", (java.lang.CharSequence) "HI!AAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "###", (java.lang.CharSequence) "Java(TM) SE Runtime Environment", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95404_1560210416/Users/sophie/Documents/defects4j/tmp/run_rMacOSXMacOSXMacOSXMacOSXMacOSX", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("CORPORATION ORACLE 10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.en10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "class [Dclass org.apache.commons.lang3.JavaVersion", (int) (short) 10, 37);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.2UTF-8                           1.2UTF-8                           1.2UTF-8                           1.2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sophie", "", "un.lwawt.macosx.LWCToolkit######...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aaaaaatiklooT...", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/6140120651_40459_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/6140120651_40459_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/" + "'", str1.equals("RAJ.TNERRUC-POODNAR/NOITARENEG/NOITARENEG_TSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/:SESSALC/TEGRAT/6140120651_40459_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                                                                                                                                                                                                       ORACLE CORPORATION                                                                                       ", "aaaaaatiklooT...", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("mixed mode:", "UN.LWAWT.MACOSX.LWCTOOLKIT");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "i!", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b1" + "'", str1.equals("-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b1"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                                                                                                                                                 ORACLE CORPORATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                                                                                                                                                                                  ORACLE CORPORATION is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java(TM) SE Runtime Environment", 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        double[] doubleArray2 = new double[] { (short) 1, (-1.0d) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        short[] shortArray1 = new short[] { (byte) 1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 1 + "'", short4 == (short) 1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "###", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "phicsEnvironmentawt.CGra         sun.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("CORPORATION ORACLE 10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.en10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "1.2\n", (java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.2\n" + "'", charSequence2.equals("1.2\n"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("A4.NUC-POODNA/NOIANG/NOIANG_/BIL/KOWAF/44CFD/NUCOd/IHPO//:ALC/GA/6140120651_40459_LP.POODNA_NU/P/44CFD/NUCOd/IHPO/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A4.NUC-POODNA/NOIANG/NOIANG_/BIL/KOWAF/44CFD/NUCOD/IHPO//:ALC/GA/6140120651_40459_LP.POODNA_NU/P/44CFD/NUCOD/IHPO/" + "'", str1.equals("A4.NUC-POODNA/NOIANG/NOIANG_/BIL/KOWAF/44CFD/NUCOD/IHPO//:ALC/GA/6140120651_40459_LP.POODNA_NU/P/44CFD/NUCOD/IHPO/"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "##########################################################################tiklooTCWL.xsocam.twawl.nu", (java.lang.CharSequence) "10.14.3", 216);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nen\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nen\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("UN.LWAWT.MACOSX.LWCTOOLKITUN.LWAWT.MACOSX.LWCT10.14.3UN.LWAWT.MACOSX.LWCTOOLKITUN.LWAWT.MACOSX.LWCTO", 37, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UN.LWAWT.MACOSX.LWCTOOLKITUN.LWAWT.MACOSX.LWCT10.14.3UN.LWAWT.MACOSX.LWCTOOLKITUN.LWAWT.MACOSX.LWCTO" + "'", str3.equals("UN.LWAWT.MACOSX.LWCTOOLKITUN.LWAWT.MACOSX.LWCT10.14.3UN.LWAWT.MACOSX.LWCTOOLKITUN.LWAWT.MACOSX.LWCTO"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       ", "AAAAAATIKLOOTCWL.XSOCAM.TWAWL.NUAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       " + "'", str2.equals("1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       1.11.21.51.51.21.6       "));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", "/Users/sophie444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java Virtual Machine Specification");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                                                           ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!" + "'", str1.equals("Hi!"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "", (int) (byte) 1);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sunhi!sun.", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "##########", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode:", "class [Dclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("JUTF-8al Machine Specification", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JUTF-8al Machine Specification" + "'", str3.equals("JUTF-8al Machine Specification"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                                               Or4cle Corpor4tion");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                               Or4cle Corpor4tion\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/aaaaaatiklooTCWL.xsocam.twawl.nuaaaa", (java.lang.CharSequence) "./....");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        long[] longArray5 = new long[] { 0, 100L, (short) 10, 100, (byte) 1 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.11.21.51.51.21.6       ", "                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.11.21.51.51.21.6       " + "'", str2.equals("1.11.21.51.51.21.6       "));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 1, 51.0f, 216.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaai!", (java.lang.CharSequence) "va/Extensionshi!aaaaaaava/Extensions:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 126 + "'", int2 == 126);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0", 37, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray7 = new char[] { 'a', ' ', 'a', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "         sun.awt.CGraphicsEnvironment", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "NOITAROPROC ELCARO", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("   51.0   ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("macOSX", ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("444444444444444444444444444444444444444444444441.144444444444444444444444444444444444444444444444", strArray4, strArray8);
        java.lang.String[] strArray10 = null;
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("eihpos", strArray4, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "444444444444444444444444444444444444444444444441.144444444444444444444444444444444444444444444444" + "'", str9.equals("444444444444444444444444444444444444444444444441.144444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "eihpos" + "'", str11.equals("eihpos"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        int[] intArray1 = new int[] { (short) 100 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95404_1560210416/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "Or4cle Corpor4tion4444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95404_1560210416/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str2.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95404_1560210416/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_644444444444444444444444444444444444444444444444x86_6444444444", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0", "HI!AAAAAAA");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_8         x51.08651.0_51.064          51.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                  Java(TM) SE Runtime Environment                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        long[] longArray5 = new long[] { 0, 100L, (short) 10, 100, (byte) 1 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("CORPORATION ORACLE 10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.en10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "hi!aaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CORPORATION ORACLE 10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.en10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str2.equals("CORPORATION ORACLE 10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.en10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        char[] charArray3 = new char[] { '4' };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "eihpos", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie444444444444444444444444444444444444444", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
    }
}

